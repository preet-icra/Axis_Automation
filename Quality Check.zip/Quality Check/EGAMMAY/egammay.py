import sys
import re
import math
import traceback
from pathlib import Path
from decimal import Decimal, ROUND_HALF_UP

from PyQt6.QtCore import Qt, QThread, pyqtSignal
from PyQt6.QtWidgets import (
    QApplication, QWidget, QVBoxLayout, QHBoxLayout, QLabel, QLineEdit,
    QPushButton, QFileDialog, QMessageBox, QProgressBar, QPlainTextEdit,
    QGroupBox, QFormLayout
)
from openpyxl import load_workbook, Workbook
from openpyxl.styles import Font, PatternFill, Alignment, Border, Side
from openpyxl.utils import get_column_letter

# Scheme Code Regular + Scheme Code Direct mapped to Factsheet Display Name.
# Mapping is loaded dynamically from the Excel workbook selected in the GUI.
SCHEME_CODE_MAPPING = {}

REPORT_FILE_NAME = "Portfolio Metrics Compare report.xlsx"
SUPPORTED_EXTENSIONS = {".xlsx", ".xlsm"}

# Client-input column -> Fund factsheet label.
METRICS = [
    {"key": "macaulay_duration", "client": "Macaulay Duration", "fund": "Macaulay Duration", "kind": "duration"},
    {"key": "portfolio_ytm", "client": "Portfolio YTM", "fund": "Yield to Maturity", "kind": "percentage"},
    {"key": "modified_duration", "client": "Modified Duration", "fund": "Modified Duration", "kind": "duration"},
    {"key": "average_maturity", "client": "Average Maturity", "fund": "Average Maturity", "kind": "duration"},
    {"key": "equity_turnover", "client": "Equity Turnover", "fund": "Equity Turnover", "kind": "turnover"},
    {"key": "gross_turnover", "client": "Gross Turnover", "fund": "Gross Exposure Turnover", "kind": "turnover"},
    {"key": "portfolio_yield", "client": "Portfolio Yield", "fund": "Annualized Portfolio Yield", "kind": "percentage"},
]


def clean_text(value):
    return "" if value is None else re.sub(r"\s+", " ", str(value)).strip()


def normalize_header(value):
    return re.sub(r"[^a-z0-9]+", "", clean_text(value).casefold())


def normalize_name(value):
    text = clean_text(value).casefold().replace("&", " ")
    return " ".join(re.sub(r"[^a-z0-9]+", " ", text).split())


def round_2(value):
    if value is None:
        return None
    return float(Decimal(str(value)).quantize(Decimal("0.01"), rounding=ROUND_HALF_UP))


def number_from_text(value):
    if value is None or value == "":
        return None
    if isinstance(value, (int, float)):
        number = float(value)
    else:
        text = clean_text(value).replace(",", "")
        match = re.search(r"[-+]?\d+(?:\.\d+)?", text)
        if not match:
            return None
        number = float(match.group())
    return number if math.isfinite(number) else None


def metric_value(cell, kind):
    """Read text, numeric, percentage-formatted, and duration-formatted cells."""
    raw = cell.value
    number = number_from_text(raw)
    if number is None:
        return None
    text = clean_text(raw).casefold() if isinstance(raw, str) else ""
    number_format = clean_text(cell.number_format)

    # Percentages stored numerically in Excel use decimal storage.
    if not isinstance(raw, str) and "%" in number_format:
        number *= 100.0

    # A text value such as 7.81% is already in percentage points.
    # Duration values such as "2.46 Years" retain the numeric year value.
    return number


def clean_scheme_display_name(value):
    """Remove trailing plan/option words when no display-name column exists."""
    text = clean_text(value)
    if not text:
        return ""
    patterns = (
        r"\s*-\s*(?:reg(?:ular)?|dir(?:ect)?)\s*-\s*growth(?:\s+option)?\s*$",
        r"\s*-\s*growth(?:\s+option)?\s*$",
        r"\s*-\s*(?:reg(?:ular)?|dir(?:ect)?)\s*$",
        r"\s+growth(?:\s+option)?\s*$",
    )
    for pattern in patterns:
        text = re.sub(pattern, "", text, flags=re.IGNORECASE).strip(" -")
    return re.sub(r"\s+", " ", text).strip()


def read_scheme_mapping(path):
    """Load Scheme Code to Factsheet Display Name mapping dynamically.

    Supported layouts include:
    1. Scheme Code Regular, Scheme Code Direct, Factsheet Display Name
    2. Scheme Code Regular, ICRA Scheme Name Regular
    3. Scheme Code Direct, ICRA Scheme Name Direct
    4. Scheme Code, Scheme Name, optional Plan
    """
    aliases = {
        "regular_code": {"schemecoderegular", "regularschemecode"},
        "direct_code": {"schemecodedirect", "directschemecode"},
        "generic_code": {"schemecode", "icraschemecode"},
        "display_name": {"factsheetdisplayname", "displayname", "fundname", "factsheetname"},
        "regular_name": {"icraschemenameregular", "schemenameregular", "regularschemename"},
        "direct_name": {"icraschemenamedirect", "schemenamedirect", "directschemename"},
        "generic_name": {"schemename", "icraschemename"},
        "plan": {"plan", "plantype"},
    }

    wb = load_workbook(path, read_only=True, data_only=True)
    mapping = {}
    source_rows = []

    def add_mapping(code, name, plan, sheet_name, row_no):
        code = clean_text(code)
        name = clean_scheme_display_name(name)
        plan = clean_text(plan) or "Regular"
        if not code and not name:
            return
        if not code or not name:
            source_rows.append({
                "sheet": sheet_name, "row": row_no, "scheme_code": code,
                "display_name": name, "plan": plan,
                "status": "SKIPPED - blank code or name",
            })
            return
        if code in mapping and mapping[code]["display_name"] != name:
            raise ValueError(
                f"Scheme Code '{code}' has conflicting fund names: "
                f"'{mapping[code]['display_name']}' and '{name}'."
            )
        mapping[code] = {"display_name": name, "plan": plan}
        source_rows.append({
            "sheet": sheet_name, "row": row_no, "scheme_code": code,
            "display_name": name, "plan": plan, "status": "LOADED",
        })

    try:
        for ws in wb.worksheets:
            header_row = None
            columns = {}
            for row_no in range(1, min(ws.max_row, 50) + 1):
                found = {}
                for col in range(1, ws.max_column + 1):
                    header = normalize_header(ws.cell(row_no, col).value)
                    for key, accepted in aliases.items():
                        if header in accepted:
                            found[key] = col
                has_code = any(k in found for k in ("regular_code", "direct_code", "generic_code"))
                has_name = any(k in found for k in ("display_name", "regular_name", "direct_name", "generic_name"))
                if has_code and has_name:
                    header_row, columns = row_no, found
                    break
            if not header_row:
                continue

            for row_no in range(header_row + 1, ws.max_row + 1):
                display = ws.cell(row_no, columns["display_name"]).value if "display_name" in columns else None

                if "regular_code" in columns:
                    regular_name = display
                    if not regular_name and "regular_name" in columns:
                        regular_name = ws.cell(row_no, columns["regular_name"]).value
                    add_mapping(
                        ws.cell(row_no, columns["regular_code"]).value,
                        regular_name, "Regular", ws.title, row_no
                    )

                if "direct_code" in columns:
                    direct_name = display
                    if not direct_name and "direct_name" in columns:
                        direct_name = ws.cell(row_no, columns["direct_name"]).value
                    add_mapping(
                        ws.cell(row_no, columns["direct_code"]).value,
                        direct_name, "Direct", ws.title, row_no
                    )

                if "generic_code" in columns:
                    generic_name = display
                    if not generic_name and "generic_name" in columns:
                        generic_name = ws.cell(row_no, columns["generic_name"]).value
                    if not generic_name and "regular_name" in columns:
                        generic_name = ws.cell(row_no, columns["regular_name"]).value
                    plan = "Regular"
                    if "plan" in columns:
                        plan = clean_text(ws.cell(row_no, columns["plan"]).value) or "Regular"
                    add_mapping(
                        ws.cell(row_no, columns["generic_code"]).value,
                        generic_name, plan, ws.title, row_no
                    )
    finally:
        wb.close()

    if not mapping:
        raise ValueError(
            "No valid mapping was found. The mapping workbook must contain Scheme Code "
            "Regular/Direct with Factsheet Display Name or ICRA Scheme Name columns."
        )
    return mapping, source_rows


def find_client_columns(ws):
    required = {normalize_header(m["client"]): m["key"] for m in METRICS}
    scheme_aliases = {"schemecode", "schemecoderegular", "schemecodedirect", "icraschemecode"}
    for row_no in range(1, min(ws.max_row, 50) + 1):
        normalized = [normalize_header(ws.cell(row_no, c).value) for c in range(1, ws.max_column + 1)]
        scheme_col = next((i + 1 for i, h in enumerate(normalized) if h in scheme_aliases), None)
        metric_cols = {}
        for i, header in enumerate(normalized, 1):
            if header in required:
                metric_cols[required[header]] = i
        if scheme_col and len(metric_cols) == len(METRICS):
            return row_no, scheme_col, metric_cols
    expected = ", ".join(m["client"] for m in METRICS)
    raise ValueError(f"Required columns not found. Expected Scheme Code plus: {expected}")


def read_client_input(path):
    wb = load_workbook(path, read_only=True, data_only=True)
    records = []
    structure_found = False
    for ws in wb.worksheets:
        try:
            header_row, scheme_col, metric_cols = find_client_columns(ws)
        except ValueError:
            continue
        structure_found = True
        for row_no in range(header_row + 1, ws.max_row + 1):
            scheme_code = clean_text(ws.cell(row_no, scheme_col).value)
            if not scheme_code:
                continue
            values = {}
            for metric in METRICS:
                try:
                    values[metric["key"]] = metric_value(ws.cell(row_no, metric_cols[metric["key"]]), metric["kind"])
                except (TypeError, ValueError):
                    values[metric["key"]] = None
            records.append({"sheet": ws.title, "row": row_no, "scheme_code": scheme_code, "values": values})
    if not structure_found:
        raise ValueError("No worksheet contains the required Scheme Code and seven metric columns.")
    if not records:
        raise ValueError("No Scheme Code data rows were found.")
    return records


def extract_scheme_name(ws):
    for r in range(1, min(ws.max_row, 40) + 1):
        for c in range(1, min(ws.max_column, 10) + 1):
            if normalize_header(ws.cell(r, c).value) == "nameofthescheme":
                for cc in range(c + 1, min(ws.max_column, c + 4) + 1):
                    value = clean_text(ws.cell(r, cc).value)
                    if value:
                        return value
    return ""


def find_metric_label_value(ws, label, kind):
    target = normalize_header(label)
    for r in range(1, ws.max_row + 1):
        for c in range(1, ws.max_column + 1):
            if normalize_header(ws.cell(r, c).value) != target:
                continue
            # Search right first, which matches the fund factsheet layout.
            for cc in range(c + 1, min(ws.max_column, c + 5) + 1):
                value = metric_value(ws.cell(r, cc), kind)
                if value is not None:
                    return value
            # Fallback to cells below the label.
            for rr in range(r + 1, min(ws.max_row, r + 3) + 1):
                value = metric_value(ws.cell(rr, c), kind)
                if value is not None:
                    return value
    return None


def read_fund_metrics(path):
    """Read all seven fund metrics in one worksheet pass.

    The earlier version scanned the complete workbook separately for every
    metric. This version builds the label lookup once and scans each populated
    row only once, which is substantially faster for large factsheets.
    """
    wb = load_workbook(path, read_only=True, data_only=True)
    best_name = ""
    values = {metric["key"]: None for metric in METRICS}
    label_lookup = {
        normalize_header(metric["fund"]): metric
        for metric in METRICS
    }

    for ws in wb.worksheets:
        best_name = extract_scheme_name(ws) or best_name

        for row in ws.iter_rows():
            for index, cell in enumerate(row):
                metric = label_lookup.get(normalize_header(cell.value))
                if metric is None or values[metric["key"]] is not None:
                    continue

                # Factsheet values normally appear to the right of the label.
                for value_cell in row[index + 1:index + 5]:
                    value = metric_value(value_cell, metric["kind"])
                    if value is not None:
                        values[metric["key"]] = value
                        break

            if all(value is not None for value in values.values()):
                break

        if all(value is not None for value in values.values()):
            break

    wb.close()
    if all(value is None for value in values.values()):
        raise ValueError("None of the seven portfolio metrics were found in the fund workbook.")
    return best_name, values


def build_fund_index(folder, log):
    index = []
    for path in sorted(Path(folder).iterdir()):
        if path.suffix.lower() not in SUPPORTED_EXTENSIONS or path.name.startswith("~$"):
            continue
        try:
            wb = load_workbook(path, read_only=True, data_only=True)
            scheme = ""
            for ws in wb.worksheets:
                scheme = extract_scheme_name(ws)
                if scheme:
                    break
            index.append({"path": path, "scheme": scheme, "stem": path.stem})
            wb.close()
        except Exception as exc:
            log(f"Skipped unreadable workbook {path.name}: {exc}")
    return index


def find_fund_file(scheme_code, fund_index, scheme_mapping):
    meta = scheme_mapping.get(scheme_code)
    if not meta:
        return None
    target = normalize_name(meta["display_name"])
    matches = [rec for rec in fund_index if normalize_name(rec["scheme"]) == target]
    if len(matches) == 1:
        return matches[0]["path"]
    matches = [rec for rec in fund_index if normalize_name(rec["stem"]) == target]
    return matches[0]["path"] if len(matches) == 1 else None


def compare_value(client_value, fund_value):
    if client_value is None or fund_value is None:
        return False, None
    client_2 = round_2(client_value)
    fund_2 = round_2(fund_value)
    return client_2 == fund_2, round_2(client_2 - fund_2)


def create_report(output_path, rows, scheme_mapping, mapping_source):
    """Create a vertical audit report.

    Metrics are processed across all funds one at a time. The report first
    lists Macaulay Duration for every Scheme Code, then Portfolio YTM for every
    Scheme Code, followed by the remaining metrics in the configured order.
    """
    wb = Workbook()
    ws = wb.active
    ws.title = "Portfolio Metrics Audit"
    headers = [
        "Scheme Code", "Plan", "Factsheet Display Name", "Fund File",
        "Metric Sequence", "Client Column", "Fund Factsheet Label",
        "Client Value", "Fund Value", "Difference", "Result",
        "Overall Result", "Remarks", "Source Sheet", "Source Row"
    ]
    ws.append(headers)

    # Process metric-by-metric across all funds. First write Macaulay Duration
    # for every Scheme Code, then Portfolio YTM for every Scheme Code, and so on.
    for sequence, metric in enumerate(METRICS, start=1):
        for scheme_record in rows:
            ws.append([
                scheme_record.get("Scheme Code", ""),
                scheme_record.get("Plan", ""),
                scheme_record.get("Factsheet Display Name", ""),
                scheme_record.get("Fund File", ""),
                sequence,
                metric["client"],
                metric["fund"],
                scheme_record.get(f'Client {metric["client"]}', ""),
                scheme_record.get(f'Fund {metric["fund"]}', ""),
                scheme_record.get(f'{metric["client"]} Difference', ""),
                scheme_record.get(f'{metric["client"]} Result', "NOT AUDITED"),
                scheme_record.get("Overall Result", ""),
                scheme_record.get("Remarks", ""),
                scheme_record.get("Source Sheet", ""),
                scheme_record.get("Source Row", ""),
            ])

    summary = wb.create_sheet("Audit Summary")
    summary_headers = [
        "Scheme Code", "Plan", "Factsheet Display Name", "Fund File",
        "Overall Result", "Remarks", "Source Sheet", "Source Row"
    ]
    summary.append(summary_headers)
    for item in rows:
        summary.append([item.get(header, "") for header in summary_headers])

    wm = wb.create_sheet("Scheme Fund Mapping")
    wm.append(["Scheme Code", "Plan", "Factsheet Display Name"])
    for code, meta in sorted(scheme_mapping.items()):
        wm.append([code, meta["plan"], meta["display_name"]])

    dark, green, red, yellow = "17365D", "C6EFCE", "FFC7CE", "FFEB9C"
    thin = Side(style="thin", color="D9E1F2")
    for sheet in wb.worksheets:
        sheet.freeze_panes = "A2"
        sheet.auto_filter.ref = sheet.dimensions
        sheet.sheet_view.showGridLines = False
        for cell in sheet[1]:
            cell.fill = PatternFill("solid", fgColor=dark)
            cell.font = Font(color="FFFFFF", bold=True)
            cell.alignment = Alignment(horizontal="center", vertical="center", wrap_text=True)
        sheet.row_dimensions[1].height = 45
        for row in sheet.iter_rows(min_row=2):
            for cell in row:
                cell.alignment = Alignment(vertical="top", wrap_text=True)
                cell.border = Border(bottom=thin)
        for col in range(1, sheet.max_column + 1):
            max_len = max(
                len(clean_text(sheet.cell(r, col).value))
                for r in range(1, min(sheet.max_row, 500) + 1)
            )
            sheet.column_dimensions[get_column_letter(col)].width = min(max(max_len + 2, 12), 38)

    # Format the vertical comparison sheet.
    for row in range(2, ws.max_row + 1):
        for col in (8, 9, 10):
            ws.cell(row, col).number_format = "0.00"
        for col in (11, 12):
            cell = ws.cell(row, col)
            color = green if cell.value == "PASS" else red if cell.value == "FAIL" else yellow
            cell.fill = PatternFill("solid", fgColor=color)

        # Add a stronger separator at the beginning of each metric section.
        if row == 2 or ws.cell(row, 5).value != ws.cell(row - 1, 5).value:
            for col in range(1, ws.max_column + 1):
                ws.cell(row, col).border = Border(
                    top=Side(style="medium", color="7F8C8D"), bottom=thin
                )

    # Format summary results.
    for row in range(2, summary.max_row + 1):
        cell = summary.cell(row, 5)
        color = green if cell.value == "PASS" else red if cell.value == "FAIL" else yellow
        cell.fill = PatternFill("solid", fgColor=color)

    source_sheet = wb.create_sheet("Mapping Source Audit")
    source_sheet.append([
        "Source Sheet", "Source Row", "Scheme Code",
        "Factsheet Display Name", "Plan", "Status"
    ])
    for item in mapping_source:
        source_sheet.append([
            item.get("sheet", ""), item.get("row", ""),
            item.get("scheme_code", ""), item.get("display_name", ""),
            item.get("plan", ""), item.get("status", ""),
        ])
    wb.save(output_path)


def run_audit(client_input, mapping_file, fund_folder, output_folder,
              log=lambda x: None, progress=lambda x: None):
    log("Reading dynamic Scheme Code mapping workbook...")
    scheme_mapping, mapping_source = read_scheme_mapping(mapping_file)
    log(f"Loaded {len(scheme_mapping)} Scheme Code mappings.")
    records = read_client_input(client_input)
    log(f"Found {len(records)} Scheme Code rows in client input.")
    fund_index = build_fund_index(fund_folder, log)
    log(f"Indexed {len(fund_index)} fund workbooks.")
    report_rows = []
    # Regular and Direct Scheme Codes often point to the same fund factsheet.
    # Cache each parsed workbook so every fund file is read only once.
    fund_metrics_cache = {}

    for pos, record in enumerate(records, 1):
        code = record["scheme_code"]
        meta = scheme_mapping.get(code)
        fund_path = find_fund_file(code, fund_index, scheme_mapping) if meta else None
        display = meta["display_name"] if meta else ""
        plan = meta["plan"] if meta else ""
        row = {"Scheme Code": code, "Plan": plan, "Factsheet Display Name": display,
               "Fund File": fund_path.name if fund_path else "", "Source Sheet": record["sheet"],
               "Source Row": record["row"]}
        results = []
        remarks = ""
        fund_values = {m["key"]: None for m in METRICS}
        if not meta:
            overall = "NOT AUDITED"; remarks = "Scheme Code is not available in the mapping."
        elif not fund_path:
            overall = "NOT AUDITED"; remarks = "Exact matching fund workbook was not found."
        else:
            try:
                cache_key = str(fund_path.resolve())
                if cache_key not in fund_metrics_cache:
                    fund_metrics_cache[cache_key] = read_fund_metrics(fund_path)
                extracted, cached_values = fund_metrics_cache[cache_key]
                fund_values = cached_values.copy()
                row["Factsheet Display Name"] = extracted or display
                missing = []
                for metric in METRICS:
                    client_value = record["values"][metric["key"]]
                    fund_value = fund_values[metric["key"]]
                    passed, difference = compare_value(client_value, fund_value)
                    result = "PASS" if passed else "FAIL"
                    results.append(result)
                    if client_value is None or fund_value is None:
                        missing.append(metric["client"])
                    row[f'Client {metric["client"]}'] = client_value
                    row[f'Fund {metric["fund"]}'] = fund_value
                    row[f'{metric["client"]} Difference'] = difference
                    row[f'{metric["client"]} Result'] = result
                overall = "PASS" if all(r == "PASS" for r in results) else "FAIL"
                remarks = "All seven metrics matched at 2 decimals." if overall == "PASS" else "One or more metrics differ at 2 decimals."
                if missing:
                    remarks += " Missing value(s): " + ", ".join(missing) + "."
            except Exception as exc:
                overall = "ERROR"; remarks = str(exc)
        for metric in METRICS:
            row.setdefault(f'Client {metric["client"]}', record["values"][metric["key"]])
            row.setdefault(f'Fund {metric["fund"]}', fund_values[metric["key"]])
            row.setdefault(f'{metric["client"]} Difference', None)
            row.setdefault(f'{metric["client"]} Result', "NOT AUDITED")
        row["Overall Result"] = overall; row["Remarks"] = remarks
        report_rows.append(row)
        log(f"{code}: {overall} - {remarks}")
        progress(int(pos * 100 / len(records)))
    output = Path(output_folder) / REPORT_FILE_NAME
    create_report(output, report_rows, scheme_mapping, mapping_source)
    return output


class AuditWorker(QThread):
    log_message = pyqtSignal(str); progress_changed = pyqtSignal(int)
    completed = pyqtSignal(str); failed = pyqtSignal(str)
    def __init__(self, client, mapping_file, funds, output):
        super().__init__(); self.client=client; self.mapping_file=mapping_file; self.funds=funds; self.output=output
    def run(self):
        try:
            path=run_audit(self.client,self.mapping_file,self.funds,self.output,self.log_message.emit,self.progress_changed.emit)
            self.completed.emit(str(path))
        except Exception:
            self.failed.emit(traceback.format_exc())


class PortfolioMetricsAuditApp(QWidget):
    STYLE="""
    QWidget{background:#F4F7FB;color:#243447;font-family:'Segoe UI';font-size:10pt}
    QLabel#Title{color:#123B63;font-size:24px;font-weight:700} QLabel#Sub{color:#5D6D7E}
    QLabel#Status{background:#EAF2F8;color:#1F4E78;border-radius:6px;padding:9px 12px;font-weight:600}
    QGroupBox{background:white;border:1px solid #D7E1EC;border-radius:10px;margin-top:14px;padding:16px 12px 12px;font-weight:700;color:#1F4E78}
    QGroupBox::title{subcontrol-origin:margin;left:14px;padding:0 6px}
    QLineEdit{background:white;border:1px solid #C9D5E2;border-radius:6px;padding:9px} QLineEdit:focus{border:2px solid #2878B5}
    QPushButton{background:#E9F1F8;color:#1F4E78;border:1px solid #B9CDDF;border-radius:6px;padding:8px 14px;font-weight:600}
    QPushButton:hover{background:#D9EAF7} QPushButton#Run{background:#1F4E78;color:white;border:none;padding:12px 24px;font-size:11pt;font-weight:700}
    QPushButton#Run:hover{background:#2878B5} QPushButton#Run:disabled{background:#9EB2C4}
    QProgressBar{background:#DFE8F0;border:none;border-radius:6px;height:12px;color:transparent} QProgressBar::chunk{background:#2E86C1;border-radius:6px}
    QPlainTextEdit{background:#17202A;color:#D5E8F5;border:none;border-radius:8px;padding:10px;font-family:Consolas;font-size:9pt}
    """
    def __init__(self):
        super().__init__(); self.worker=None
        self.setWindowTitle("Portfolio Metrics Compare Audit"); self.setMinimumSize(940,680); self.resize(1040,740); self.setStyleSheet(self.STYLE)
        main=QVBoxLayout(self); main.setContentsMargins(28,24,28,24); main.setSpacing(14)
        title=QLabel("Portfolio Metrics Compare Audit"); title.setObjectName("Title"); main.addWidget(title)
        sub=QLabel("Compare seven portfolio metrics using a dynamically selected Scheme Code mapping workbook. The report first compares Macaulay Duration for all funds, then Portfolio YTM for all funds, followed by each remaining metric, at exactly two decimal places."); sub.setObjectName("Sub"); sub.setWordWrap(True); main.addWidget(sub)
        group=QGroupBox("Audit Inputs"); form=QFormLayout(group); form.setVerticalSpacing(13)
        self.client=QLineEdit(); self.mapping=QLineEdit(); self.funds=QLineEdit(); self.output=QLineEdit()
        self.client.setPlaceholderText("Select client input Excel"); self.mapping.setPlaceholderText("Select Scheme Code mapping Excel"); self.funds.setPlaceholderText("Select fund Excel folder"); self.output.setPlaceholderText("Select report save folder")
        form.addRow("Client Input Excel",self.path_row(self.client,self.pick_client,"Browse File")); form.addRow("Scheme Mapping Excel",self.path_row(self.mapping,self.pick_mapping,"Browse File")); form.addRow("Fund Excel Folder",self.path_row(self.funds,self.pick_funds,"Browse Folder")); form.addRow("Save Report Folder",self.path_row(self.output,self.pick_output,"Browse Folder")); main.addWidget(group)
        actions=QHBoxLayout(); clear=QPushButton("Clear"); clear.clicked.connect(self.clear_inputs); self.clear_button=clear; actions.addWidget(clear); actions.addStretch(1)
        self.run_button=QPushButton("Create Audit Report"); self.run_button.setObjectName("Run"); self.run_button.setMinimumWidth(220); self.run_button.clicked.connect(self.start); actions.addWidget(self.run_button); main.addLayout(actions)
        self.status=QLabel("Ready to run the audit"); self.status.setObjectName("Status"); main.addWidget(self.status)
        self.progress=QProgressBar(); self.progress.setRange(0,100); main.addWidget(self.progress)
        lg=QGroupBox("Audit Log"); ll=QVBoxLayout(lg); self.log=QPlainTextEdit(); self.log.setReadOnly(True); ll.addWidget(self.log); main.addWidget(lg,1)
        foot=QLabel(f'Report: "{REPORT_FILE_NAME}" | Mapping: dynamically loaded from selected Excel'); foot.setObjectName("Sub"); main.addWidget(foot)
    def path_row(self,edit,callback,text):
        w=QWidget(); w.setStyleSheet("background:transparent"); l=QHBoxLayout(w); l.setContentsMargins(0,0,0,0); l.addWidget(edit,1); b=QPushButton(text); b.setMinimumWidth(115); b.clicked.connect(callback); l.addWidget(b); return w
    def pick_client(self):
        p,_=QFileDialog.getOpenFileName(self,"Select Client Input","","Excel Files (*.xlsx *.xlsm)");
        if p: self.client.setText(p); self.output.setText(self.output.text() or str(Path(p).parent))
    def pick_mapping(self):
        p,_=QFileDialog.getOpenFileName(
            self,"Select Scheme Code Mapping Excel","","Excel Files (*.xlsx *.xlsm)"
        )
        if p: self.mapping.setText(p)
    def pick_funds(self):
        p=QFileDialog.getExistingDirectory(self,"Select Fund Excel Folder");
        if p: self.funds.setText(p)
    def pick_output(self):
        p=QFileDialog.getExistingDirectory(self,"Select Save Folder");
        if p: self.output.setText(p)
    def clear_inputs(self):
        if self.worker and self.worker.isRunning(): return
        self.client.clear(); self.mapping.clear(); self.funds.clear(); self.output.clear(); self.log.clear(); self.progress.setValue(0); self.status.setText("Ready to run the audit")
    def busy(self,state):
        for w in (self.client,self.mapping,self.funds,self.output,self.run_button,self.clear_button): w.setEnabled(not state)
    def start(self):
        errors=[]
        if not Path(self.client.text().strip()).is_file(): errors.append("Select a valid client input Excel file.")
        if not Path(self.mapping.text().strip()).is_file(): errors.append("Select a valid Scheme Code mapping Excel file.")
        if not Path(self.funds.text().strip()).is_dir(): errors.append("Select a valid fund Excel folder.")
        if not Path(self.output.text().strip()).is_dir(): errors.append("Select a valid save folder.")
        if errors: QMessageBox.warning(self,"Check Audit Inputs","\n".join(errors)); return
        self.log.clear(); self.progress.setValue(0); self.status.setText("Audit is running with fast workbook caching. Please wait..."); self.busy(True)
        self.worker=AuditWorker(self.client.text().strip(),self.mapping.text().strip(),self.funds.text().strip(),self.output.text().strip()); self.worker.log_message.connect(self.log.appendPlainText); self.worker.progress_changed.connect(self.progress.setValue); self.worker.completed.connect(self.done); self.worker.failed.connect(self.failed); self.worker.start()
    def done(self,path):
        self.busy(False); self.progress.setValue(100); self.status.setText("Audit completed successfully"); self.log.appendPlainText(f"Report saved: {path}"); QMessageBox.information(self,"Audit Complete",f"Report created successfully:\n{path}")
    def failed(self,message):
        self.busy(False); self.status.setText("Audit failed. Review the log."); self.log.appendPlainText(message); QMessageBox.critical(self,"Audit Failed","The audit failed. See the log for details.")


if __name__ == "__main__":
    app=QApplication(sys.argv); window=PortfolioMetricsAuditApp(); window.show(); sys.exit(app.exec())
