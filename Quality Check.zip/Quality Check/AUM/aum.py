import sys
import re
import math
import traceback
from pathlib import Path

from PyQt6.QtCore import Qt, QThread, pyqtSignal
from PyQt6.QtWidgets import (
    QApplication, QWidget, QVBoxLayout, QHBoxLayout, QLabel, QLineEdit,
    QPushButton, QFileDialog, QMessageBox, QProgressBar, QPlainTextEdit,
    QGroupBox, QFormLayout
)
from openpyxl import load_workbook, Workbook
from openpyxl.styles import Font, PatternFill, Alignment, Border, Side
from openpyxl.utils import get_column_letter

# Static mapping created from both Scheme Code Regular and Scheme Code Direct
# in SebiFactsheetUploader.xlsx. The uploader is not required at runtime.
SCHEME_CODE_MAPPING = {}

REPORT_FILE_NAME = "AUM and AAUM Compare report.xlsx"
SUPPORTED_EXTENSIONS = {".xlsx", ".xlsm"}


def clean_text(value):
    if value is None:
        return ""
    return re.sub(r"\s+", " ", str(value)).strip()


def normalize_name(value):
    text = clean_text(value).casefold().replace("&", " ")
    text = re.sub(r"[^a-z0-9]+", " ", text)
    return " ".join(text.split())


def normalize_header(value):
    return re.sub(r"[^a-z0-9]+", "", clean_text(value).casefold())


def to_number(value):
    if value is None or value == "":
        return None
    if isinstance(value, str):
        value = value.strip().replace(",", "")
        if not value:
            return None
    result = float(value)
    return result if math.isfinite(result) else None


def clean_scheme_display_name(value):
    text = clean_text(value)
    for pattern in (r"\s*-\s*(?:reg(?:ular)?|dir(?:ect)?)\s*-\s*growth\s*$", r"\s*-\s*growth(?:\s+option)?\s*$", r"\s+growth(?:\s+option)?\s*$"):
        text = re.sub(pattern, "", text, flags=re.I).strip(" -")
    return text


def read_scheme_mapping(path):
    wb = load_workbook(path, read_only=True, data_only=True)
    mapping, sources = {}, []
    aliases = {
        "rc":{"schemecoderegular","regularschemecode"}, "dc":{"schemecodedirect","directschemecode"},
        "gc":{"schemecode","icraschemecode"}, "dn":{"factsheetdisplayname","displayname","fundname"},
        "rn":{"icraschemenameregular","schemenameregular"}, "xn":{"icraschemenamedirect","schemenamedirect"},
        "gn":{"schemename","icraschemename"}, "pl":{"plan","plantype"}}
    def add(code,name,plan,sheet,row):
        code,name=clean_text(code),clean_scheme_display_name(name)
        if not code or not name: return
        if code in mapping and mapping[code]["display_name"] != name: raise ValueError(f"Conflicting duplicate Scheme Code: {code}")
        mapping[code]={"display_name":name,"plan":plan}; sources.append((sheet,row,code,name,plan))
    for ws in wb.worksheets:
        hr=None; cols={}
        for r in range(1,min(ws.max_row,50)+1):
            found={}
            for c in range(1,ws.max_column+1):
                h=normalize_header(ws.cell(r,c).value)
                for key,vals in aliases.items():
                    if h in vals: found[key]=c
            if any(k in found for k in ("rc","dc","gc")) and any(k in found for k in ("dn","rn","xn","gn")): hr,cols=r,found; break
        if not hr: continue
        for r in range(hr+1,ws.max_row+1):
            d=ws.cell(r,cols["dn"]).value if "dn" in cols else None
            if "rc" in cols: add(ws.cell(r,cols["rc"]).value,d or (ws.cell(r,cols["rn"]).value if "rn" in cols else None),"Regular",ws.title,r)
            if "dc" in cols: add(ws.cell(r,cols["dc"]).value,d or (ws.cell(r,cols["xn"]).value if "xn" in cols else None),"Direct",ws.title,r)
            if "gc" in cols:
                name=d or (ws.cell(r,cols["gn"]).value if "gn" in cols else None) or (ws.cell(r,cols["rn"]).value if "rn" in cols else None)
                plan=clean_text(ws.cell(r,cols["pl"]).value) if "pl" in cols else "Regular"
                add(ws.cell(r,cols["gc"]).value,name,plan or "Regular",ws.title,r)
    wb.close()
    if not mapping: raise ValueError("No Scheme Code mapping rows found in the selected mapping workbook.")
    return mapping,sources


def find_client_input_columns(ws):
    scheme_aliases = {
        "schemecode", "schemecoderegular", "schemecodedirect", "icraschemecode"
    }
    aum_aliases = {
        "aum", "aummonthend", "monthendaum", "assetsundermanagement"
    }
    aaum_aliases = {
        "aaum", "aaummonthend", "monthendaaum", "averageaum",
        "averageassetsundermanagement"
    }
    for row_no in range(1, min(ws.max_row, 50) + 1):
        values = [normalize_header(ws.cell(row_no, c).value) for c in range(1, ws.max_column + 1)]
        scheme_col = next((i + 1 for i, v in enumerate(values) if v in scheme_aliases), None)
        aum_col = next((i + 1 for i, v in enumerate(values) if v in aum_aliases), None)
        aaum_col = next((i + 1 for i, v in enumerate(values) if v in aaum_aliases), None)
        if scheme_col and aum_col and aaum_col:
            return row_no, scheme_col, aum_col, aaum_col
    raise ValueError(
        "Could not find Scheme Code, AUM, and AAUM columns in the client input workbook."
    )


def read_client_input(path):
    wb = load_workbook(path, read_only=True, data_only=True)
    records = []
    found_structure = False
    for ws in wb.worksheets:
        try:
            header_row, scheme_col, aum_col, aaum_col = find_client_input_columns(ws)
        except ValueError:
            continue
        found_structure = True
        for excel_row, row in enumerate(
            ws.iter_rows(min_row=header_row + 1, values_only=True),
            start=header_row + 1,
        ):
            scheme_code = clean_text(row[scheme_col - 1])
            if not scheme_code:
                continue
            try:
                aum = to_number(row[aum_col - 1])
            except (TypeError, ValueError):
                aum = None
            try:
                aaum = to_number(row[aaum_col - 1])
            except (TypeError, ValueError):
                aaum = None
            records.append({
                "sheet": ws.title,
                "row": excel_row,
                "scheme_code": scheme_code,
                "client_aum": aum,
                "client_aaum": aaum,
            })
    if not found_structure:
        raise ValueError(
            "No worksheet contains Scheme Code, AUM, and AAUM headers."
        )
    if not records:
        raise ValueError("No non-blank Scheme Code rows were found in the client input workbook.")
    return records


def extract_scheme_name(ws):
    for r in range(1, min(ws.max_row, 40) + 1):
        for c in range(1, min(ws.max_column, 10) + 1):
            if normalize_header(ws.cell(r, c).value) == "nameofthescheme":
                for cc in range(c + 1, min(ws.max_column, c + 4) + 1):
                    value = clean_text(ws.cell(r, cc).value)
                    if value:
                        return value
    return ""


def find_label_value(ws, aliases):
    aliases = {normalize_header(x) for x in aliases}
    for r in range(1, ws.max_row + 1):
        for c in range(1, ws.max_column + 1):
            if normalize_header(ws.cell(r, c).value) not in aliases:
                continue
            # Prefer values to the right of the label.
            for cc in range(c + 1, min(ws.max_column, c + 5) + 1):
                candidate = ws.cell(r, cc).value
                try:
                    number = to_number(candidate)
                except (TypeError, ValueError):
                    number = None
                if number is not None:
                    return number
            # Fallback to the next few rows in the same column.
            for rr in range(r + 1, min(ws.max_row, r + 3) + 1):
                candidate = ws.cell(rr, c).value
                try:
                    number = to_number(candidate)
                except (TypeError, ValueError):
                    number = None
                if number is not None:
                    return number
    return None


def read_fund_aum_aaum(path):
    wb = load_workbook(path, read_only=True, data_only=True)
    for ws in wb.worksheets:
        scheme_name = extract_scheme_name(ws)
        aum = find_label_value(ws, {"AUM (month end)", "AUM month end", "Month End AUM"})
        aaum = find_label_value(ws, {"AAUM (month end)", "AAUM month end", "Month End AAUM", "Average AUM"})
        if aum is not None or aaum is not None:
            return scheme_name, aum, aaum
    raise ValueError("AUM (month end) and AAUM (month end) were not found.")


def build_fund_index(folder, log):
    index = []
    for path in sorted(Path(folder).iterdir()):
        if path.suffix.lower() not in SUPPORTED_EXTENSIONS or path.name.startswith("~$"):
            continue
        try:
            wb = load_workbook(path, read_only=True, data_only=True)
            scheme = ""
            for ws in wb.worksheets:
                scheme = extract_scheme_name(ws)
                if scheme:
                    break
            index.append({"path": path, "scheme": scheme, "stem": path.stem})
        except Exception as exc:
            log(f"Skipped unreadable workbook {path.name}: {exc}")
    return index


def find_fund_file(scheme_code, fund_index, scheme_mapping):
    meta = scheme_mapping.get(scheme_code)
    if not meta:
        return None
    target = normalize_name(meta["display_name"])
    scheme_matches = [r for r in fund_index if normalize_name(r["scheme"]) == target]
    if len(scheme_matches) == 1:
        return scheme_matches[0]["path"]
    filename_matches = [r for r in fund_index if normalize_name(r["stem"]) == target]
    if len(filename_matches) == 1:
        return filename_matches[0]["path"]
    return None


def compare_value(client_value, fund_value):
    if client_value is None or fund_value is None:
        return False, None
    client_2dp = round(client_value, 2)
    fund_2dp = round(fund_value, 2)
    return client_2dp == fund_2dp, round(client_2dp - fund_2dp, 2)


def create_report(output_path, rows, scheme_mapping, mapping_sources):
    wb = Workbook()
    ws = wb.active
    ws.title = "AUM AAUM Audit"
    headers = [
        "Scheme Code", "Plan", "Factsheet Display Name", "Fund File",
        "Client Input AUM", "Fund AUM", "AUM Difference", "AUM Result",
        "Client Input AAUM", "Fund AAUM", "AAUM Difference", "AAUM Result",
        "Overall Result", "Remarks", "Source Sheet", "Source Row"
    ]
    ws.append(headers)
    for item in rows:
        ws.append([item.get(h, "") for h in headers])

    wm = wb.create_sheet("Scheme Fund Mapping")
    wm.append(["Scheme Code", "Plan", "Factsheet Display Name"])
    for code, meta in sorted(scheme_mapping.items()):
        wm.append([code, meta["plan"], meta["display_name"]])

    dark = "17365D"
    pass_fill = PatternFill("solid", fgColor="C6EFCE")
    fail_fill = PatternFill("solid", fgColor="FFC7CE")
    warning_fill = PatternFill("solid", fgColor="FFEB9C")
    thin = Side(style="thin", color="D9E1F2")
    for sheet in wb.worksheets:
        sheet.freeze_panes = "A2"
        sheet.auto_filter.ref = sheet.dimensions
        sheet.sheet_view.showGridLines = False
        for cell in sheet[1]:
            cell.fill = PatternFill("solid", fgColor=dark)
            cell.font = Font(color="FFFFFF", bold=True)
            cell.alignment = Alignment(horizontal="center", vertical="center", wrap_text=True)
        sheet.row_dimensions[1].height = 36
        for row in sheet.iter_rows(min_row=2):
            for cell in row:
                cell.alignment = Alignment(vertical="top", wrap_text=True)
                cell.border = Border(bottom=thin)
        for col in range(1, sheet.max_column + 1):
            max_len = max(
                len(clean_text(sheet.cell(r, col).value))
                for r in range(1, min(sheet.max_row, 300) + 1)
            )
            sheet.column_dimensions[get_column_letter(col)].width = min(max(max_len + 2, 12), 38)

    for row in range(2, ws.max_row + 1):
        for col in (5, 6, 7, 9, 10, 11):
            ws.cell(row, col).number_format = "0.00"
        for col in (8, 12, 13):
            cell = ws.cell(row, col)
            if cell.value == "PASS":
                cell.fill = pass_fill
            elif cell.value == "FAIL":
                cell.fill = fail_fill
            else:
                cell.fill = warning_fill
    ms=wb.create_sheet("Mapping Source"); ms.append(["Source Sheet","Source Row","Scheme Code","Factsheet Display Name","Plan"])
    for item in mapping_sources: ms.append(list(item))
    wb.save(output_path)


def run_audit(client_input, mapping_file, fund_folder, output_folder, log=lambda x: None, progress=lambda x: None):
    log("Reading mapping workbook...")
    scheme_mapping, mapping_sources = read_scheme_mapping(mapping_file)
    log(f"Loaded {len(scheme_mapping)} mappings.")
    log("Reading client input workbook...")
    records = read_client_input(client_input)
    log(f"Found {len(records)} Scheme Code rows.")
    fund_index = build_fund_index(fund_folder, log)
    log(f"Indexed {len(fund_index)} fund workbooks.")
    rows = []
    for position, record in enumerate(records, 1):
        code = record["scheme_code"]
        meta = scheme_mapping.get(code)
        fund_path = find_fund_file(code, fund_index, scheme_mapping) if meta else None
        fund_aum = fund_aaum = None
        aum_result = aaum_result = "NOT AUDITED"
        overall = "NOT AUDITED"
        remarks = ""
        display_name = meta["display_name"] if meta else ""
        plan = meta["plan"] if meta else ""

        if not meta:
            remarks = "Scheme Code is not available in the hardcoded mapping."
        elif not fund_path:
            remarks = "Exact matching fund workbook was not found in the selected folder."
        else:
            try:
                extracted_name, fund_aum, fund_aaum = read_fund_aum_aaum(fund_path)
                display_name = extracted_name or display_name
                aum_ok, aum_diff = compare_value(record["client_aum"], fund_aum)
                aaum_ok, aaum_diff = compare_value(record["client_aaum"], fund_aaum)
                aum_result = "PASS" if aum_ok else "FAIL"
                aaum_result = "PASS" if aaum_ok else "FAIL"
                overall = "PASS" if aum_ok and aaum_ok else "FAIL"
                remarks = "AUM and AAUM matched at 2 decimals." if overall == "PASS" else "AUM and/or AAUM differ at 2 decimals."
            except Exception as exc:
                aum_diff = aaum_diff = None
                overall = "ERROR"
                remarks = str(exc)
        if not fund_path or not meta:
            aum_diff = aaum_diff = None

        rows.append({
            "Scheme Code": code,
            "Plan": plan,
            "Factsheet Display Name": display_name,
            "Fund File": fund_path.name if fund_path else "",
            "Client Input AUM": record["client_aum"],
            "Fund AUM": fund_aum,
            "AUM Difference": aum_diff,
            "AUM Result": aum_result,
            "Client Input AAUM": record["client_aaum"],
            "Fund AAUM": fund_aaum,
            "AAUM Difference": aaum_diff,
            "AAUM Result": aaum_result,
            "Overall Result": overall,
            "Remarks": remarks,
            "Source Sheet": record["sheet"],
            "Source Row": record["row"],
        })
        log(f"{code}: {overall} - {remarks}")
        progress(int(position * 100 / len(records)))

    output_path = Path(output_folder) / REPORT_FILE_NAME
    create_report(output_path, rows, scheme_mapping, mapping_sources)
    return output_path


class AuditWorker(QThread):
    log_message = pyqtSignal(str)
    progress_changed = pyqtSignal(int)
    completed = pyqtSignal(str)
    failed = pyqtSignal(str)

    def __init__(self, client_input, mapping_file, fund_folder, output_folder):
        super().__init__()
        self.client_input = client_input
        self.mapping_file = mapping_file
        self.fund_folder = fund_folder
        self.output_folder = output_folder

    def run(self):
        try:
            path = run_audit(
                self.client_input, self.mapping_file, self.fund_folder, self.output_folder,
                self.log_message.emit, self.progress_changed.emit
            )
            self.completed.emit(str(path))
        except Exception:
            self.failed.emit(traceback.format_exc())


class AumAaumAuditApp(QWidget):
    APP_STYLE = """
        QWidget { background:#F4F7FB; color:#243447; font-family:"Segoe UI"; font-size:10pt; }
        QLabel#Title { color:#123B63; font-size:24px; font-weight:700; }
        QLabel#Subtitle { color:#5D6D7E; }
        QLabel#Status { background:#EAF2F8; color:#1F4E78; border-radius:6px; padding:9px 12px; font-weight:600; }
        QGroupBox { background:white; border:1px solid #D7E1EC; border-radius:10px; margin-top:14px; padding:16px 12px 12px; font-weight:700; color:#1F4E78; }
        QGroupBox::title { subcontrol-origin:margin; left:14px; padding:0 6px; }
        QLineEdit { background:white; border:1px solid #C9D5E2; border-radius:6px; padding:9px; }
        QLineEdit:focus { border:2px solid #2878B5; }
        QPushButton { background:#E9F1F8; color:#1F4E78; border:1px solid #B9CDDF; border-radius:6px; padding:8px 14px; font-weight:600; }
        QPushButton:hover { background:#D9EAF7; }
        QPushButton#Run { background:#1F4E78; color:white; border:none; padding:12px 24px; font-size:11pt; font-weight:700; }
        QPushButton#Run:hover { background:#2878B5; }
        QPushButton#Run:disabled { background:#9EB2C4; }
        QProgressBar { background:#DFE8F0; border:none; border-radius:6px; height:12px; color:transparent; }
        QProgressBar::chunk { background:#2E86C1; border-radius:6px; }
        QPlainTextEdit { background:#17202A; color:#D5E8F5; border:none; border-radius:8px; padding:10px; font-family:Consolas; font-size:9pt; }
    """

    def __init__(self):
        super().__init__()
        self.worker = None
        self.setWindowTitle("AUM and AAUM Compare Audit")
        self.setMinimumSize(920, 650)
        self.resize(1020, 720)
        self.setStyleSheet(self.APP_STYLE)
        main = QVBoxLayout(self)
        main.setContentsMargins(28, 24, 28, 24)
        main.setSpacing(14)

        title = QLabel("AUM and AAUM Compare Audit")
        title.setObjectName("Title")
        main.addWidget(title)
        subtitle = QLabel(
            "Compare client-input AUM and AAUM against fund factsheets using Scheme Code mapping. "
            "Values are compared at exactly two decimal places."
        )
        subtitle.setObjectName("Subtitle")
        subtitle.setWordWrap(True)
        main.addWidget(subtitle)

        group = QGroupBox("Audit Inputs")
        form = QFormLayout(group)
        form.setHorizontalSpacing(18)
        form.setVerticalSpacing(13)
        self.client_edit = QLineEdit()
        self.mapping_edit = QLineEdit()
        self.fund_edit = QLineEdit()
        self.output_edit = QLineEdit()
        self.client_edit.setPlaceholderText("Select the client input workbook")
        self.mapping_edit.setPlaceholderText("Select Scheme Code mapping Excel")
        self.fund_edit.setPlaceholderText("Select the folder containing fund Excel files")
        self.output_edit.setPlaceholderText("Select the report output folder")
        form.addRow("Client Input Excel", self.path_row(self.client_edit, self.pick_client, "Browse File"))
        form.addRow("Scheme Mapping Excel", self.path_row(self.mapping_edit, self.pick_mapping, "Browse File"))
        form.addRow("Fund Excel Folder", self.path_row(self.fund_edit, self.pick_funds, "Browse Folder"))
        form.addRow("Save Report Folder", self.path_row(self.output_edit, self.pick_output, "Browse Folder"))
        main.addWidget(group)

        actions = QHBoxLayout()
        self.clear_button = QPushButton("Clear")
        self.clear_button.clicked.connect(self.clear_inputs)
        actions.addWidget(self.clear_button)
        actions.addStretch(1)
        self.run_button = QPushButton("Create Audit Report")
        self.run_button.setObjectName("Run")
        self.run_button.setMinimumWidth(220)
        self.run_button.clicked.connect(self.start_audit)
        actions.addWidget(self.run_button)
        main.addLayout(actions)

        self.status = QLabel("Ready to run the audit")
        self.status.setObjectName("Status")
        main.addWidget(self.status)
        self.progress = QProgressBar()
        self.progress.setRange(0, 100)
        main.addWidget(self.progress)

        log_group = QGroupBox("Audit Log")
        log_layout = QVBoxLayout(log_group)
        self.log = QPlainTextEdit()
        self.log.setReadOnly(True)
        self.log.setPlaceholderText("Audit progress will appear here...")
        log_layout.addWidget(self.log)
        main.addWidget(log_group, 1)

        footer = QLabel(f'Report name: "{REPORT_FILE_NAME}" | Mapping: dynamically loaded from selected Excel')
        footer.setObjectName("Subtitle")
        main.addWidget(footer)

    def path_row(self, edit, callback, text):
        widget = QWidget()
        widget.setStyleSheet("background:transparent;")
        row = QHBoxLayout(widget)
        row.setContentsMargins(0, 0, 0, 0)
        row.setSpacing(8)
        row.addWidget(edit, 1)
        button = QPushButton(text)
        button.setMinimumWidth(115)
        button.clicked.connect(callback)
        row.addWidget(button)
        return widget

    def pick_client(self):
        path, _ = QFileDialog.getOpenFileName(self, "Select Client Input", "", "Excel Files (*.xlsx *.xlsm)")
        if path:
            self.client_edit.setText(path)
            if not self.output_edit.text().strip():
                self.output_edit.setText(str(Path(path).parent))

    def pick_mapping(self):
        path, _ = QFileDialog.getOpenFileName(self, "Select Scheme Mapping Excel", "", "Excel Files (*.xlsx *.xlsm)")
        if path: self.mapping_edit.setText(path)

    def pick_funds(self):
        path = QFileDialog.getExistingDirectory(self, "Select Fund Excel Folder")
        if path:
            self.fund_edit.setText(path)

    def pick_output(self):
        path = QFileDialog.getExistingDirectory(self, "Select Report Save Folder")
        if path:
            self.output_edit.setText(path)

    def clear_inputs(self):
        if self.worker and self.worker.isRunning():
            return
        self.client_edit.clear()
        self.mapping_edit.clear()
        self.fund_edit.clear()
        self.output_edit.clear()
        self.log.clear()
        self.progress.setValue(0)
        self.status.setText("Ready to run the audit")

    def set_busy(self, busy):
        for widget in (self.client_edit, self.mapping_edit, self.fund_edit, self.output_edit, self.run_button, self.clear_button):
            widget.setEnabled(not busy)

    def start_audit(self):
        client = self.client_edit.text().strip()
        mapping_file = self.mapping_edit.text().strip()
        funds = self.fund_edit.text().strip()
        output = self.output_edit.text().strip()
        errors = []
        if not Path(client).is_file(): errors.append("Select a valid client input Excel file.")
        if not Path(mapping_file).is_file(): errors.append("Select a valid Scheme Mapping Excel file.")
        if not Path(funds).is_dir(): errors.append("Select a valid fund Excel folder.")
        if not Path(output).is_dir(): errors.append("Select a valid save folder.")
        if errors:
            QMessageBox.warning(self, "Check Audit Inputs", "\n".join(errors))
            return
        self.log.clear()
        self.log.appendPlainText("Starting AUM and AAUM audit...")
        self.progress.setValue(0)
        self.status.setText("Audit is running. Please wait...")
        self.set_busy(True)
        self.worker = AuditWorker(client, mapping_file, funds, output)
        self.worker.log_message.connect(self.log.appendPlainText)
        self.worker.progress_changed.connect(self.progress.setValue)
        self.worker.completed.connect(self.audit_completed)
        self.worker.failed.connect(self.audit_failed)
        self.worker.start()

    def audit_completed(self, path):
        self.set_busy(False)
        self.progress.setValue(100)
        self.status.setText("Audit completed successfully")
        self.log.appendPlainText(f"Report saved: {path}")
        QMessageBox.information(self, "Audit Complete", f"Report created successfully:\n{path}")

    def audit_failed(self, message):
        self.set_busy(False)
        self.status.setText("Audit failed. Review the log.")
        self.log.appendPlainText(message)
        QMessageBox.critical(self, "Audit Failed", "The audit failed. See the log for details.")


if __name__ == "__main__":
    app = QApplication(sys.argv)
    window = AumAaumAuditApp()
    window.show()
    sys.exit(app.exec())
