import sys
import re
import math
import traceback
from pathlib import Path

from PyQt6.QtCore import Qt, QThread, pyqtSignal
from PyQt6.QtWidgets import (
    QApplication, QWidget, QVBoxLayout, QHBoxLayout, QLabel, QLineEdit,
    QPushButton, QFileDialog, QMessageBox, QProgressBar, QPlainTextEdit,
    QGroupBox, QFormLayout
)
from openpyxl import load_workbook, Workbook
from openpyxl.styles import Font, PatternFill, Alignment, Border, Side
from openpyxl.utils import get_column_letter

# Static mapping created from both Scheme Code Regular and Scheme Code Direct
# in SebiFactsheetUploader.xlsx. The uploader is not required at runtime.
# Scheme Code mapping is loaded dynamically from the Excel workbook selected in the GUI.
SCHEME_CODE_MAPPING = {}

REPORT_FILE_NAME = "Expense Ratio Compare report.xlsx"
SUPPORTED_EXTENSIONS = {".xlsx", ".xlsm"}


def clean_text(value):
    if value is None:
        return ""
    return re.sub(r"\s+", " ", str(value)).strip()


def normalize_name(value):
    text = clean_text(value).casefold().replace("&", " ")
    text = re.sub(r"[^a-z0-9]+", " ", text)
    return " ".join(text.split())


def normalize_header(value):
    return re.sub(r"[^a-z0-9]+", "", clean_text(value).casefold())


def to_number(value):
    if value is None or value == "":
        return None
    if isinstance(value, str):
        value = value.strip().replace(",", "")
        if not value:
            return None
    result = float(value)
    return result if math.isfinite(result) else None


def parse_percentage_parts(value, number_format="General"):
    """Parse one percentage or a slash-separated list of percentages.

    Examples:
    - "1.62%/2.2%" -> (1.62, 2.20)
    - "0.03%/0.03%" -> (0.03, 0.03)
    - 0.0182 with 0.00% format -> (1.82,)
    - 1.82 with General format -> (1.82,)
    """
    if value is None or value == "":
        return None

    if isinstance(value, str):
        text = value.strip().replace(",", "")
        if not text:
            return None
        parts = [part.strip() for part in re.split(r"[/|]", text)]
        numbers = []
        for part in parts:
            if not part:
                continue
            part = part.replace("%", "").strip()
            match = re.search(r"[-+]?\d+(?:\.\d+)?", part)
            if not match:
                continue
            number = float(match.group())
            if math.isfinite(number):
                numbers.append(number)
        return tuple(numbers) if numbers else None

    number = float(value)
    if "%" in clean_text(number_format):
        number *= 100.0
    return (number,) if math.isfinite(number) else None


def percentage_value(cell):
    """Return a scalar percentage or a tuple for slash-separated percentages."""
    parts = parse_percentage_parts(cell.value, cell.number_format)
    if parts is None:
        return None
    return parts[0] if len(parts) == 1 else parts


def percentage_display(value):
    """Create a consistent report value while retaining slash-separated values."""
    if value is None:
        return ""
    if isinstance(value, (tuple, list)):
        return "/".join(f"{round(float(item), 2):.2f}%" for item in value)
    return round(float(value), 2)


def clean_scheme_display_name(value):
    """Remove trailing plan/option words when no display-name column exists."""
    text = clean_text(value)
    if not text:
        return ""
    patterns = (
        r"\s*-\s*(?:reg(?:ular)?|dir(?:ect)?)\s*-\s*growth(?:\s+option)?\s*$",
        r"\s*-\s*growth(?:\s+option)?\s*$",
        r"\s*-\s*(?:reg(?:ular)?|dir(?:ect)?)\s*$",
        r"\s+growth(?:\s+option)?\s*$",
    )
    for pattern in patterns:
        text = re.sub(pattern, "", text, flags=re.IGNORECASE).strip(" -")
    return re.sub(r"\s+", " ", text).strip()


def read_scheme_mapping(path):
    """Load Scheme Code to Factsheet Display Name mapping dynamically.

    Supported layouts include:
    1. Scheme Code Regular, Scheme Code Direct, Factsheet Display Name
    2. Scheme Code Regular, ICRA Scheme Name Regular
    3. Scheme Code Direct, ICRA Scheme Name Direct
    4. Scheme Code, Scheme Name, optional Plan
    """
    aliases = {
        "regular_code": {"schemecoderegular", "regularschemecode"},
        "direct_code": {"schemecodedirect", "directschemecode"},
        "generic_code": {"schemecode", "icraschemecode"},
        "display_name": {"factsheetdisplayname", "displayname", "fundname", "factsheetname"},
        "regular_name": {"icraschemenameregular", "schemenameregular", "regularschemename"},
        "direct_name": {"icraschemenamedirect", "schemenamedirect", "directschemename"},
        "generic_name": {"schemename", "icraschemename"},
        "plan": {"plan", "plantype"},
    }

    wb = load_workbook(path, read_only=True, data_only=True)
    mapping = {}
    source_rows = []

    def add_mapping(code, name, plan, sheet_name, row_no):
        code = clean_text(code)
        name = clean_scheme_display_name(name)
        plan = clean_text(plan) or "Regular"
        if not code and not name:
            return
        if not code or not name:
            source_rows.append({
                "sheet": sheet_name, "row": row_no, "scheme_code": code,
                "display_name": name, "plan": plan,
                "status": "SKIPPED - blank code or name",
            })
            return
        if code in mapping and mapping[code]["display_name"] != name:
            raise ValueError(
                f"Scheme Code '{code}' has conflicting fund names: "
                f"'{mapping[code]['display_name']}' and '{name}'."
            )
        mapping[code] = {"display_name": name, "plan": plan}
        source_rows.append({
            "sheet": sheet_name, "row": row_no, "scheme_code": code,
            "display_name": name, "plan": plan, "status": "LOADED",
        })

    try:
        for ws in wb.worksheets:
            header_row = None
            columns = {}
            for row_no in range(1, min(ws.max_row, 50) + 1):
                found = {}
                for col in range(1, ws.max_column + 1):
                    header = normalize_header(ws.cell(row_no, col).value)
                    for key, accepted in aliases.items():
                        if header in accepted:
                            found[key] = col
                has_code = any(k in found for k in ("regular_code", "direct_code", "generic_code"))
                has_name = any(k in found for k in ("display_name", "regular_name", "direct_name", "generic_name"))
                if has_code and has_name:
                    header_row, columns = row_no, found
                    break
            if not header_row:
                continue

            for row_no in range(header_row + 1, ws.max_row + 1):
                display = ws.cell(row_no, columns["display_name"]).value if "display_name" in columns else None

                if "regular_code" in columns:
                    regular_name = display
                    if not regular_name and "regular_name" in columns:
                        regular_name = ws.cell(row_no, columns["regular_name"]).value
                    add_mapping(
                        ws.cell(row_no, columns["regular_code"]).value,
                        regular_name, "Regular", ws.title, row_no
                    )

                if "direct_code" in columns:
                    direct_name = display
                    if not direct_name and "direct_name" in columns:
                        direct_name = ws.cell(row_no, columns["direct_name"]).value
                    add_mapping(
                        ws.cell(row_no, columns["direct_code"]).value,
                        direct_name, "Direct", ws.title, row_no
                    )

                if "generic_code" in columns:
                    generic_name = display
                    if not generic_name and "generic_name" in columns:
                        generic_name = ws.cell(row_no, columns["generic_name"]).value
                    if not generic_name and "regular_name" in columns:
                        generic_name = ws.cell(row_no, columns["regular_name"]).value
                    plan = "Regular"
                    if "plan" in columns:
                        plan = clean_text(ws.cell(row_no, columns["plan"]).value) or "Regular"
                    add_mapping(
                        ws.cell(row_no, columns["generic_code"]).value,
                        generic_name, plan, ws.title, row_no
                    )
    finally:
        wb.close()

    if not mapping:
        raise ValueError(
            "No valid mapping was found. The mapping workbook must contain Scheme Code "
            "Regular/Direct with Factsheet Display Name or ICRA Scheme Name columns."
        )
    return mapping, source_rows


def find_client_input_columns(ws):
    scheme_aliases = {
        "schemecode", "schemecoderegular", "schemecodedirect", "icraschemecode"
    }
    regular_aliases = {
        "regularexpenseratio", "expenseratioregular", "terregular",
        "regularexpense", "regularter"
    }
    direct_aliases = {
        "directexpenseratio", "expenseratiodirect", "terdirect",
        "directexpense", "directter"
    }
    for row_no in range(1, min(ws.max_row, 50) + 1):
        values = [normalize_header(ws.cell(row_no, c).value) for c in range(1, ws.max_column + 1)]
        scheme_col = next((i + 1 for i, v in enumerate(values) if v in scheme_aliases), None)
        regular_col = next((i + 1 for i, v in enumerate(values) if v in regular_aliases), None)
        direct_col = next((i + 1 for i, v in enumerate(values) if v in direct_aliases), None)
        if scheme_col and regular_col and direct_col:
            return row_no, scheme_col, regular_col, direct_col
    raise ValueError(
        "Could not find Scheme Code, Regular Expense Ratio, and Direct Expense Ratio columns."
    )


def read_client_input(path):
    wb = load_workbook(path, read_only=True, data_only=True)
    records = []
    found_structure = False
    for ws in wb.worksheets:
        try:
            header_row, scheme_col, regular_col, direct_col = find_client_input_columns(ws)
        except ValueError:
            continue
        found_structure = True
        for excel_row in range(header_row + 1, ws.max_row + 1):
            scheme_code = clean_text(ws.cell(excel_row, scheme_col).value)
            if not scheme_code:
                continue
            try:
                regular_ratio = percentage_value(ws.cell(excel_row, regular_col))
            except (TypeError, ValueError):
                regular_ratio = None
            try:
                direct_ratio = percentage_value(ws.cell(excel_row, direct_col))
            except (TypeError, ValueError):
                direct_ratio = None
            records.append({
                "sheet": ws.title,
                "row": excel_row,
                "scheme_code": scheme_code,
                "client_regular": regular_ratio,
                "client_direct": direct_ratio,
            })
    if not found_structure:
        raise ValueError(
            "No worksheet contains Scheme Code, Regular Expense Ratio, and Direct Expense Ratio headers."
        )
    if not records:
        raise ValueError("No non-blank Scheme Code rows were found in the client input workbook.")
    return records


def extract_scheme_name(ws):
    for r in range(1, min(ws.max_row, 40) + 1):
        for c in range(1, min(ws.max_column, 10) + 1):
            if normalize_header(ws.cell(r, c).value) == "nameofthescheme":
                for cc in range(c + 1, min(ws.max_column, c + 4) + 1):
                    value = clean_text(ws.cell(r, cc).value)
                    if value:
                        return value
    return ""


def nearby_percentage_value(ws, row_no, col_no):
    """Read a percentage value to the right, below, or inside the label cell."""
    label_cell = ws.cell(row_no, col_no)
    label_text = clean_text(label_cell.value)

    # Some factsheets place label and value in one cell, such as
    # "Regular Plan: 1.62%/2.20%".
    inline = re.search(r"\d+(?:\.\d+)?\s*%(?:\s*[/|]\s*\d+(?:\.\d+)?\s*%)*", label_text)
    if inline:
        parts = parse_percentage_parts(inline.group())
        if parts:
            return parts[0] if len(parts) == 1 else parts

    for cc in range(col_no + 1, min(ws.max_column, col_no + 6) + 1):
        cell = ws.cell(row_no, cc)
        value = percentage_value(cell)
        if value is not None:
            return value

    for rr in range(row_no + 1, min(ws.max_row, row_no + 4) + 1):
        for cc in range(max(1, col_no - 1), min(ws.max_column, col_no + 3) + 1):
            cell = ws.cell(rr, cc)
            value = percentage_value(cell)
            if value is not None:
                return value
    return None


def read_fund_expense_ratios(path):
    """Read expense ratios from different AMC factsheet layouts dynamically."""
    wb = load_workbook(path, read_only=True, data_only=True)
    scheme_name = ""
    regular = None
    direct = None

    try:
        for ws in wb.worksheets:
            scheme_name = extract_scheme_name(ws) or scheme_name

            # Pass 1: explicit Regular and Direct labels.
            for row in ws.iter_rows():
                for cell in row:
                    label = normalize_header(cell.value)
                    if not label:
                        continue
                    is_expense = "expenseratio" in label or label.startswith("ter") or label.endswith("ter")
                    if not is_expense:
                        continue
                    if regular is None and ("regular" in label or "regplan" in label or label.endswith("reg")):
                        regular = nearby_percentage_value(ws, cell.row, cell.column)
                    if direct is None and ("direct" in label or "directplan" in label or label.endswith("dir")):
                        direct = nearby_percentage_value(ws, cell.row, cell.column)

            # Pass 2: generic Expense Ratio heading with Regular/Direct rows nearby.
            if regular is None or direct is None:
                for row in ws.iter_rows():
                    for cell in row:
                        label = normalize_header(cell.value)
                        if "expenseratio" not in label and label not in {"ter", "totalexpenseratio"}:
                            continue
                        start_row = cell.row
                        for rr in range(start_row, min(ws.max_row, start_row + 10) + 1):
                            row_text = " ".join(
                                clean_text(ws.cell(rr, cc).value)
                                for cc in range(1, ws.max_column + 1)
                            )
                            normalized = normalize_header(row_text)
                            if regular is None and ("regular" in normalized or "regplan" in normalized):
                                for cc in range(1, ws.max_column + 1):
                                    candidate = percentage_value(ws.cell(rr, cc))
                                    if candidate is not None:
                                        regular = candidate
                                        break
                            if direct is None and "direct" in normalized:
                                for cc in range(1, ws.max_column + 1):
                                    candidate = percentage_value(ws.cell(rr, cc))
                                    if candidate is not None:
                                        direct = candidate
                                        break

            if regular is not None or direct is not None:
                break
    finally:
        wb.close()

    if regular is None and direct is None:
        raise ValueError(
            "Expense Ratio values were not found. The reader searched explicit "
            "Regular/Direct labels and generic Expense Ratio sections."
        )
    return scheme_name, regular, direct


def build_fund_index(folder, log):
    index = []
    for path in sorted(Path(folder).iterdir()):
        if path.suffix.lower() not in SUPPORTED_EXTENSIONS or path.name.startswith("~$"):
            continue
        try:
            wb = load_workbook(path, read_only=True, data_only=True)
            scheme = ""
            for ws in wb.worksheets:
                scheme = extract_scheme_name(ws)
                if scheme:
                    break
            index.append({"path": path, "scheme": scheme, "stem": path.stem})
        except Exception as exc:
            log(f"Skipped unreadable workbook {path.name}: {exc}")
    return index


def find_fund_file(scheme_code, fund_index, scheme_mapping):
    meta = scheme_mapping.get(scheme_code)
    if not meta:
        return None
    target = normalize_name(meta["display_name"])
    scheme_matches = [r for r in fund_index if normalize_name(r["scheme"]) == target]
    if len(scheme_matches) == 1:
        return scheme_matches[0]["path"]
    filename_matches = [r for r in fund_index if normalize_name(r["stem"]) == target]
    if len(filename_matches) == 1:
        return filename_matches[0]["path"]
    return None


def compare_value(client_value, fund_value):
    """Compare scalar or slash-separated percentage values at two decimals."""
    if client_value is None or fund_value is None:
        return False, ""

    client_parts = client_value if isinstance(client_value, (tuple, list)) else (client_value,)
    fund_parts = fund_value if isinstance(fund_value, (tuple, list)) else (fund_value,)
    client_2dp = tuple(round(float(value), 2) for value in client_parts)
    fund_2dp = tuple(round(float(value), 2) for value in fund_parts)

    if len(client_2dp) != len(fund_2dp):
        return False, "Different number of values"

    differences = tuple(round(c - f, 2) for c, f in zip(client_2dp, fund_2dp))
    passed = client_2dp == fund_2dp
    difference_text = "/".join(f"{value:.2f}" for value in differences)
    return passed, difference_text


def create_report(output_path, rows, scheme_mapping, mapping_source):
    wb = Workbook()
    ws = wb.active
    ws.title = "Expense Ratio Audit"
    headers = [
        "Scheme Code", "Plan", "Factsheet Display Name", "Fund File",
        "Client Regular Expense Ratio (%)", "Fund Regular Expense Ratio (%)",
        "Regular Difference (pp)", "Regular Result",
        "Client Direct Expense Ratio (%)", "Fund Direct Expense Ratio (%)",
        "Direct Difference (pp)", "Direct Result",
        "Overall Result", "Remarks", "Source Sheet", "Source Row"
    ]
    ws.append(headers)
    for item in rows:
        ws.append([item.get(h, "") for h in headers])

    wm = wb.create_sheet("Scheme Fund Mapping")
    wm.append(["Scheme Code", "Plan", "Factsheet Display Name"])
    for code, meta in sorted(scheme_mapping.items()):
        wm.append([code, meta["plan"], meta["display_name"]])

    dark = "17365D"
    pass_fill = PatternFill("solid", fgColor="C6EFCE")
    fail_fill = PatternFill("solid", fgColor="FFC7CE")
    warning_fill = PatternFill("solid", fgColor="FFEB9C")
    thin = Side(style="thin", color="D9E1F2")
    for sheet in wb.worksheets:
        sheet.freeze_panes = "A2"
        sheet.auto_filter.ref = sheet.dimensions
        sheet.sheet_view.showGridLines = False
        for cell in sheet[1]:
            cell.fill = PatternFill("solid", fgColor=dark)
            cell.font = Font(color="FFFFFF", bold=True)
            cell.alignment = Alignment(horizontal="center", vertical="center", wrap_text=True)
        sheet.row_dimensions[1].height = 42
        for row in sheet.iter_rows(min_row=2):
            for cell in row:
                cell.alignment = Alignment(vertical="top", wrap_text=True)
                cell.border = Border(bottom=thin)
        for col in range(1, sheet.max_column + 1):
            max_len = max(len(clean_text(sheet.cell(r, col).value)) for r in range(1, min(sheet.max_row, 300) + 1))
            sheet.column_dimensions[get_column_letter(col)].width = min(max(max_len + 2, 12), 40)

    for row in range(2, ws.max_row + 1):
        for col in (5, 6, 7, 9, 10, 11):
            if isinstance(ws.cell(row, col).value, (int, float)):
                ws.cell(row, col).number_format = "0.00"
        for col in (8, 12, 13):
            cell = ws.cell(row, col)
            cell.fill = pass_fill if cell.value == "PASS" else fail_fill if cell.value == "FAIL" else warning_fill
    source_sheet = wb.create_sheet("Mapping Source Audit")
    source_sheet.append([
        "Source Sheet", "Source Row", "Scheme Code",
        "Factsheet Display Name", "Plan", "Status"
    ])
    for item in mapping_source:
        source_sheet.append([
            item.get("sheet", ""),
            item.get("row", ""),
            item.get("scheme_code", ""),
            item.get("display_name", ""),
            item.get("plan", ""),
            item.get("status", ""),
        ])
    wb.save(output_path)


def run_audit(client_input, mapping_file, fund_folder, output_folder, log=lambda x: None, progress=lambda x: None):
    log("Reading dynamic Scheme Code mapping workbook...")
    scheme_mapping, mapping_source = read_scheme_mapping(mapping_file)
    log(f"Loaded {len(scheme_mapping)} Scheme Code mappings.")
    log("Reading client input workbook...")
    records = read_client_input(client_input)
    log(f"Found {len(records)} Scheme Code rows.")
    fund_index = build_fund_index(fund_folder, log)
    log(f"Indexed {len(fund_index)} fund workbooks.")
    rows = []

    for position, record in enumerate(records, 1):
        code = record["scheme_code"]
        meta = scheme_mapping.get(code)
        fund_path = find_fund_file(code, fund_index, scheme_mapping) if meta else None
        fund_regular = fund_direct = None
        regular_result = direct_result = "NOT AUDITED"
        overall = "NOT AUDITED"
        remarks = ""
        display_name = meta["display_name"] if meta else ""
        plan = meta["plan"] if meta else ""
        regular_diff = direct_diff = None

        if not meta:
            remarks = "Scheme Code is not available in the selected mapping workbook."
        elif not fund_path:
            remarks = "Exact matching fund workbook was not found in the selected folder."
        else:
            try:
                extracted_name, fund_regular, fund_direct = read_fund_expense_ratios(fund_path)
                display_name = extracted_name or display_name
                regular_ok, regular_diff = compare_value(record["client_regular"], fund_regular)
                direct_ok, direct_diff = compare_value(record["client_direct"], fund_direct)
                regular_result = "PASS" if regular_ok else "FAIL"
                direct_result = "PASS" if direct_ok else "FAIL"
                overall = "PASS" if regular_ok and direct_ok else "FAIL"
                remarks = (
                    "Regular and Direct Expense Ratios matched at 2 decimals."
                    if overall == "PASS"
                    else "Regular and/or Direct Expense Ratio differs at 2 decimals."
                )
                if record["client_regular"] is None or fund_regular is None:
                    remarks += " Regular value is missing on one side."
                if record["client_direct"] is None or fund_direct is None:
                    remarks += " Direct value is missing on one side."
            except Exception as exc:
                overall = "ERROR"
                remarks = str(exc)

        rows.append({
            "Scheme Code": code,
            "Plan": plan,
            "Factsheet Display Name": display_name,
            "Fund File": fund_path.name if fund_path else "",
            "Client Regular Expense Ratio (%)": percentage_display(record["client_regular"]),
            "Fund Regular Expense Ratio (%)": percentage_display(fund_regular),
            "Regular Difference (pp)": regular_diff,
            "Regular Result": regular_result,
            "Client Direct Expense Ratio (%)": percentage_display(record["client_direct"]),
            "Fund Direct Expense Ratio (%)": percentage_display(fund_direct),
            "Direct Difference (pp)": direct_diff,
            "Direct Result": direct_result,
            "Overall Result": overall,
            "Remarks": remarks,
            "Source Sheet": record["sheet"],
            "Source Row": record["row"],
        })
        log(f"{code}: {overall} - {remarks}")
        progress(int(position * 100 / len(records)))

    output_path = Path(output_folder) / REPORT_FILE_NAME
    create_report(output_path, rows, scheme_mapping, mapping_source)
    return output_path


class AuditWorker(QThread):
    log_message = pyqtSignal(str)
    progress_changed = pyqtSignal(int)
    completed = pyqtSignal(str)
    failed = pyqtSignal(str)

    def __init__(self, client_input, mapping_file, fund_folder, output_folder):
        super().__init__()
        self.client_input = client_input
        self.mapping_file = mapping_file
        self.fund_folder = fund_folder
        self.output_folder = output_folder

    def run(self):
        try:
            path = run_audit(
                self.client_input, self.mapping_file, self.fund_folder, self.output_folder,
                self.log_message.emit, self.progress_changed.emit
            )
            self.completed.emit(str(path))
        except Exception:
            self.failed.emit(traceback.format_exc())


class ExpenseRatioAuditApp(QWidget):
    APP_STYLE = """
        QWidget { background:#F4F7FB; color:#243447; font-family:"Segoe UI"; font-size:10pt; }
        QLabel#Title { color:#123B63; font-size:24px; font-weight:700; }
        QLabel#Subtitle { color:#5D6D7E; }
        QLabel#Status { background:#EAF2F8; color:#1F4E78; border-radius:6px; padding:9px 12px; font-weight:600; }
        QGroupBox { background:white; border:1px solid #D7E1EC; border-radius:10px; margin-top:14px; padding:16px 12px 12px; font-weight:700; color:#1F4E78; }
        QGroupBox::title { subcontrol-origin:margin; left:14px; padding:0 6px; }
        QLineEdit { background:white; border:1px solid #C9D5E2; border-radius:6px; padding:9px; }
        QLineEdit:focus { border:2px solid #2878B5; }
        QPushButton { background:#E9F1F8; color:#1F4E78; border:1px solid #B9CDDF; border-radius:6px; padding:8px 14px; font-weight:600; }
        QPushButton:hover { background:#D9EAF7; }
        QPushButton#Run { background:#1F4E78; color:white; border:none; padding:12px 24px; font-size:11pt; font-weight:700; }
        QPushButton#Run:hover { background:#2878B5; }
        QPushButton#Run:disabled { background:#9EB2C4; }
        QProgressBar { background:#DFE8F0; border:none; border-radius:6px; height:12px; color:transparent; }
        QProgressBar::chunk { background:#2E86C1; border-radius:6px; }
        QPlainTextEdit { background:#17202A; color:#D5E8F5; border:none; border-radius:8px; padding:10px; font-family:Consolas; font-size:9pt; }
    """

    def __init__(self):
        super().__init__()
        self.worker = None
        self.setWindowTitle("Expense Ratio Compare Audit")
        self.setMinimumSize(920, 650)
        self.resize(1020, 720)
        self.setStyleSheet(self.APP_STYLE)
        main = QVBoxLayout(self)
        main.setContentsMargins(28, 24, 28, 24)
        main.setSpacing(14)

        title = QLabel("Expense Ratio Compare Audit")
        title.setObjectName("Title")
        main.addWidget(title)
        subtitle = QLabel(
            "Compare client-input Regular and Direct Expense Ratios against fund factsheets using a dynamically selected Scheme Code mapping workbook. "
            "Percentage values are compared at exactly two decimal places."
        )
        subtitle.setObjectName("Subtitle")
        subtitle.setWordWrap(True)
        main.addWidget(subtitle)

        group = QGroupBox("Audit Inputs")
        form = QFormLayout(group)
        form.setHorizontalSpacing(18)
        form.setVerticalSpacing(13)
        self.client_edit = QLineEdit()
        self.mapping_edit = QLineEdit()
        self.fund_edit = QLineEdit()
        self.output_edit = QLineEdit()
        self.client_edit.setPlaceholderText("Select the client input workbook")
        self.mapping_edit.setPlaceholderText("Select the Scheme Code mapping workbook")
        self.fund_edit.setPlaceholderText("Select the folder containing fund Excel files")
        self.output_edit.setPlaceholderText("Select the report output folder")
        form.addRow("Client Input Excel", self.path_row(self.client_edit, self.pick_client, "Browse File"))
        form.addRow("Scheme Mapping Excel", self.path_row(self.mapping_edit, self.pick_mapping, "Browse File"))
        form.addRow("Fund Excel Folder", self.path_row(self.fund_edit, self.pick_funds, "Browse Folder"))
        form.addRow("Save Report Folder", self.path_row(self.output_edit, self.pick_output, "Browse Folder"))
        main.addWidget(group)

        actions = QHBoxLayout()
        self.clear_button = QPushButton("Clear")
        self.clear_button.clicked.connect(self.clear_inputs)
        actions.addWidget(self.clear_button)
        actions.addStretch(1)
        self.run_button = QPushButton("Create Audit Report")
        self.run_button.setObjectName("Run")
        self.run_button.setMinimumWidth(220)
        self.run_button.clicked.connect(self.start_audit)
        actions.addWidget(self.run_button)
        main.addLayout(actions)

        self.status = QLabel("Ready to run the audit")
        self.status.setObjectName("Status")
        main.addWidget(self.status)
        self.progress = QProgressBar()
        self.progress.setRange(0, 100)
        main.addWidget(self.progress)

        log_group = QGroupBox("Audit Log")
        log_layout = QVBoxLayout(log_group)
        self.log = QPlainTextEdit()
        self.log.setReadOnly(True)
        self.log.setPlaceholderText("Audit progress will appear here...")
        log_layout.addWidget(self.log)
        main.addWidget(log_group, 1)

        footer = QLabel(f'Report name: "{REPORT_FILE_NAME}" | Mapping: dynamically loaded from selected Excel')
        footer.setObjectName("Subtitle")
        main.addWidget(footer)

    def path_row(self, edit, callback, text):
        widget = QWidget()
        widget.setStyleSheet("background:transparent;")
        row = QHBoxLayout(widget)
        row.setContentsMargins(0, 0, 0, 0)
        row.setSpacing(8)
        row.addWidget(edit, 1)
        button = QPushButton(text)
        button.setMinimumWidth(115)
        button.clicked.connect(callback)
        row.addWidget(button)
        return widget

    def pick_client(self):
        path, _ = QFileDialog.getOpenFileName(self, "Select Client Input", "", "Excel Files (*.xlsx *.xlsm)")
        if path:
            self.client_edit.setText(path)
            if not self.output_edit.text().strip():
                self.output_edit.setText(str(Path(path).parent))

    def pick_mapping(self):
        path, _ = QFileDialog.getOpenFileName(
            self,
            "Select Scheme Code Mapping Excel",
            "",
            "Excel Files (*.xlsx *.xlsm)",
        )
        if path:
            self.mapping_edit.setText(path)

    def pick_funds(self):
        path = QFileDialog.getExistingDirectory(self, "Select Fund Excel Folder")
        if path:
            self.fund_edit.setText(path)

    def pick_output(self):
        path = QFileDialog.getExistingDirectory(self, "Select Report Save Folder")
        if path:
            self.output_edit.setText(path)

    def clear_inputs(self):
        if self.worker and self.worker.isRunning():
            return
        self.client_edit.clear()
        self.mapping_edit.clear()
        self.fund_edit.clear()
        self.output_edit.clear()
        self.log.clear()
        self.progress.setValue(0)
        self.status.setText("Ready to run the audit")

    def set_busy(self, busy):
        for widget in (self.client_edit, self.mapping_edit, self.fund_edit, self.output_edit, self.run_button, self.clear_button):
            widget.setEnabled(not busy)

    def start_audit(self):
        client = self.client_edit.text().strip()
        mapping_file = self.mapping_edit.text().strip()
        funds = self.fund_edit.text().strip()
        output = self.output_edit.text().strip()
        errors = []
        if not Path(client).is_file(): errors.append("Select a valid client input Excel file.")
        if not Path(mapping_file).is_file(): errors.append("Select a valid Scheme Code mapping Excel file.")
        if not Path(funds).is_dir(): errors.append("Select a valid fund Excel folder.")
        if not Path(output).is_dir(): errors.append("Select a valid save folder.")
        if errors:
            QMessageBox.warning(self, "Check Audit Inputs", "\n".join(errors))
            return
        self.log.clear()
        self.log.appendPlainText("Starting Expense Ratio audit...")
        self.progress.setValue(0)
        self.status.setText("Audit is running. Please wait...")
        self.set_busy(True)
        self.worker = AuditWorker(client, mapping_file, funds, output)
        self.worker.log_message.connect(self.log.appendPlainText)
        self.worker.progress_changed.connect(self.progress.setValue)
        self.worker.completed.connect(self.audit_completed)
        self.worker.failed.connect(self.audit_failed)
        self.worker.start()

    def audit_completed(self, path):
        self.set_busy(False)
        self.progress.setValue(100)
        self.status.setText("Audit completed successfully")
        self.log.appendPlainText(f"Report saved: {path}")
        QMessageBox.information(self, "Audit Complete", f"Report created successfully:\n{path}")

    def audit_failed(self, message):
        self.set_busy(False)
        self.status.setText("Audit failed. Review the log.")
        self.log.appendPlainText(message)
        QMessageBox.critical(self, "Audit Failed", "The audit failed. See the log for details.")


if __name__ == "__main__":
    app = QApplication(sys.argv)
    window = ExpenseRatioAuditApp()
    window.show()
    sys.exit(app.exec())
