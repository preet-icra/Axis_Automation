from __future__ import annotations

import re
import unicodedata
from dataclasses import asdict, dataclass
from datetime import date, datetime
from decimal import Decimal, InvalidOperation
from pathlib import Path
from typing import Any, Iterable

from openpyxl import Workbook, load_workbook
from openpyxl.styles import Alignment, Font, PatternFill
from openpyxl.utils import get_column_letter

UPLOADER_SHEET = "Uploader"
FUND_SHEET = "Factsheet"

# Uploader columns included in Excel-to-Excel QC.
UPLOADER_FIELDS = {
    "Fund Name": "Factsheet Display Name",
    "Fund Type": "Fund Type",
    "Fund Manager": "Fund Manager",
    "Managing Since": "Managing Since",
    "Fundman Total Experience": "Fundman Total Experience",
    "Display Benchmark": "Display Benchmark",
    "Load Structure": "Load Structure",
    "Date of Inception": "Date of Inception",
    "Product Label": "Product Label",
    "Minimum SIP Amount": "Minimum SIP Amount",
    "Minimum Investment": "Minimum Investment",
    "Scheme Riskometer": "Scheme Riskometer",
    "Benchmark Riskometer": "Benchmark Riskometer",
}

# Labels found in the fund-level Factsheet workbook.
FUND_LABELS = {
    "Fund Name": "Name of the Scheme",
    "Fund Type": "Type of Scheme",
    "Fund Manager": "Fund Manager Names",
    "Managing Since": "Fund Manager Managing Since",
    "Fundman Total Experience": "Fund Manager Total Experience",
    "Display Benchmark": "Benchmark Name",
    "Load Structure": "Load Structure",
    "Date of Inception": "Date of Inception",
    "Product Label": "Product Labeling",
    "Minimum SIP Amount": "Minimum SIP Amount",
    "Minimum Investment": "Minimum Investment (Lumpsum)",
}

# showDebtQuants is not present as a direct field in the examined fund workbook.
DEFERRED_FIELDS = ["showDebtQuants"]


@dataclass
class AuditRow:
    fund_name: str
    uploader_row: int | None
    fund_file: str
    field: str
    uploader_column: str
    uploader_value: str
    fund_value: str
    status: str
    remarks: str


def clean_text(value: Any) -> str:
    if value is None:
        return ""
    if isinstance(value, datetime):
        return value.strftime("%d/%m/%Y")
    if isinstance(value, date):
        return value.strftime("%d/%m/%Y")
    if isinstance(value, float) and value.is_integer():
        return str(int(value))
    text = unicodedata.normalize("NFKC", str(value)).replace("\xa0", " ")
    text = text.replace("–", "-").replace("—", "-").replace("−", "-")
    text = re.sub(r"<br\s*/?>", "\n", text, flags=re.I)
    text = re.sub(r"<[^>]+>", " ", text)
    text = re.sub(r"[ \t]+", " ", text)
    text = re.sub(r"\s*\n\s*", "\n", text)
    return text.strip()


def norm_text(value: Any) -> str:
    value = clean_text(value).casefold()
    value = re.sub(r"[^\w]+", " ", value, flags=re.UNICODE)
    return re.sub(r"\s+", " ", value).strip()


def split_items(value: Any) -> list[str]:
    text = clean_text(value)
    items = re.split(r"\s*(?:#|/|\n|;|\|)\s*", text)
    return [norm_text(x) for x in items if norm_text(x)]


def numeric_items(value: Any) -> list[str]:
    text = clean_text(value).replace(",", "")
    return re.findall(r"\d+(?:\.\d+)?", text)


def canonical_numbers(value: Any) -> list[Decimal]:
    """Return numbers in a format where 100, 100.0, and 100.00 are equal."""
    output = []
    for item in numeric_items(value):
        try:
            output.append(Decimal(item).normalize())
        except InvalidOperation:
            pass
    return output


def parse_date_item(value: Any) -> datetime | None:
    if isinstance(value, datetime):
        return value
    if isinstance(value, date):
        return datetime(value.year, value.month, value.day)
    text = clean_text(value)
    for fmt in (
        "%d/%m/%Y", "%m/%d/%Y", "%Y-%m-%d", "%d-%m-%Y",
        "%B %d, %Y", "%b %d, %Y", "%d %B %Y", "%d %b %Y",
    ):
        try:
            return datetime.strptime(text, fmt)
        except ValueError:
            pass
    return None


def date_items(value: Any) -> list[str]:
    if isinstance(value, (datetime, date)):
        dt = parse_date_item(value)
        return [dt.strftime("%Y-%m-%d")] if dt else []
    text = clean_text(value)
    parts = re.split(r"\s*(?:#|/\s*(?=[A-Za-z])|\n|;|\|)\s*", text)
    # If slash-separated numeric dates were broken incorrectly, parse the whole value first.
    whole = parse_date_item(text)
    if whole:
        return [whole.strftime("%Y-%m-%d")]
    out = []
    for part in parts:
        dt = parse_date_item(part)
        if dt:
            out.append(dt.strftime("%Y-%m-%d"))
    return out


def compare_values(field: str, uploader_value: Any, fund_value: Any) -> tuple[bool, str]:
    # IMPORTANT: check normalized text equality first. This prevents false mismatches
    # for equal non-numeric values such as "NA" and "In creation unit size" in
    # Minimum SIP Amount / Minimum Investment fields.
    uploader_normalized = norm_text(uploader_value)
    fund_normalized = norm_text(fund_value)
    if uploader_normalized == fund_normalized and uploader_normalized:
        return True, "Values are equal after text normalization"

    if field == "Fund Manager":
        left, right = split_items(uploader_value), split_items(fund_value)
        return left == right and bool(left), "Compared as an ordered list of manager names"

    if field == "Fundman Total Experience":
        left, right = canonical_numbers(uploader_value), canonical_numbers(fund_value)
        if left and right:
            return left == right, "Compared numeric experience values only"
        return False, "Experience values are not text-equal and usable numbers were not found on both sides"

    if field == "Managing Since":
        left, right = date_items(uploader_value), date_items(fund_value)
        if left and right:
            return left == right, "Compared normalized dates in manager order"
        return False, "Managing Since values are not text-equal and valid dates were not found on both sides"

    if field == "Date of Inception":
        left, right = date_items(uploader_value), date_items(fund_value)
        if left and right:
            return left == right, "Compared normalized calendar dates"
        return False, "Date values are not text-equal and valid dates were not found on both sides"

    if field in {"Minimum SIP Amount", "Minimum Investment"}:
        left, right = canonical_numbers(uploader_value), canonical_numbers(fund_value)
        if left and right:
            return left == right, "Compared numeric amount values"
        # Non-numeric amount descriptions must match as normalized text. Examples:
        # NA, N/A, Not Applicable, and In creation unit size.
        return False, "Non-numeric amount descriptions are different after normalization"

    return uploader_normalized == fund_normalized and bool(uploader_normalized), "Normalized text comparison"


def excel_column_letter(headers: dict[str, int], header_name: str) -> str:
    col = headers.get(header_name)
    return get_column_letter(col) if col else ""


def load_uploader(path: str | Path) -> tuple[list[dict[str, Any]], dict[str, int]]:
    wb = load_workbook(path, data_only=True, read_only=True)
    if UPLOADER_SHEET not in wb.sheetnames:
        raise ValueError(f"Sheet '{UPLOADER_SHEET}' was not found in the uploader workbook.")
    ws = wb[UPLOADER_SHEET]
    headers = {clean_text(c.value): c.column for c in ws[1] if c.value is not None}
    missing = [name for name in UPLOADER_FIELDS.values() if name not in headers]
    if missing:
        raise ValueError("Missing uploader columns: " + ", ".join(missing))
    rows = []
    for row_no in range(2, ws.max_row + 1):
        record = {"_row": row_no}
        for field, header in UPLOADER_FIELDS.items():
            record[field] = ws.cell(row_no, headers[header]).value
        if clean_text(record["Fund Name"]):
            rows.append(record)
    return rows, headers


def _lookup_label(ws, label: str) -> Any:
    target = norm_text(label)
    for row in ws.iter_rows():
        for cell in row:
            if norm_text(cell.value) == target:
                # Standard layout: label in one cell, value in the next non-empty cell.
                for col in range(cell.column + 1, ws.max_column + 1):
                    val = ws.cell(cell.row, col).value
                    if val is not None and clean_text(val):
                        return val
                return None
    return None


def _lookup_riskometer(ws, risk_name: str) -> Any:
    target = norm_text(risk_name)
    for row in ws.iter_rows():
        for cell in row:
            if norm_text(cell.value) == target:
                for col in range(cell.column + 1, ws.max_column + 1):
                    val = ws.cell(cell.row, col).value
                    if val is not None and clean_text(val):
                        return val
    return None


def load_fund_workbook(path: str | Path) -> dict[str, Any]:
    wb = load_workbook(path, data_only=True, read_only=True)
    if FUND_SHEET not in wb.sheetnames:
        raise ValueError(f"Sheet '{FUND_SHEET}' was not found in {Path(path).name}.")
    ws = wb[FUND_SHEET]
    record = {"_file": Path(path).name}
    for field, label in FUND_LABELS.items():
        record[field] = _lookup_label(ws, label)
    record["Scheme Riskometer"] = _lookup_riskometer(ws, "Scheme Riskometer")
    record["Benchmark Riskometer"] = _lookup_riskometer(ws, "Benchmark Riskometer")
    if not clean_text(record["Fund Name"]):
        raise ValueError(f"Name of the Scheme is blank in {Path(path).name}.")
    return record


def compare_workbooks(uploader_path: str | Path, fund_paths: Iterable[str | Path]) -> list[AuditRow]:
    uploader_rows, headers = load_uploader(uploader_path)
    uploader_by_fund = {norm_text(r["Fund Name"]): r for r in uploader_rows}
    audits: list[AuditRow] = []

    for path in fund_paths:
        fund = load_fund_workbook(path)
        key = norm_text(fund["Fund Name"])
        uploader = uploader_by_fund.get(key)
        if uploader is None:
            audits.append(AuditRow(
                clean_text(fund["Fund Name"]), None, fund["_file"], "Fund Name",
                excel_column_letter(headers, UPLOADER_FIELDS["Fund Name"]), "",
                clean_text(fund["Fund Name"]), "MISSING IN UPLOADER",
                "No matching Factsheet Display Name in uploader workbook",
            ))
            continue

        for field, header in UPLOADER_FIELDS.items():
            left, right = uploader.get(field), fund.get(field)
            if not clean_text(left) and not clean_text(right):
                status, detail = "PASS", "Both values are blank"
            elif not clean_text(right):
                status, detail = "MISSING IN FUND", "Fund workbook value is blank or label was not found"
            elif not clean_text(left):
                status, detail = "MISSING IN UPLOADER", "Uploader value is blank"
            else:
                matched, detail = compare_values(field, left, right)
                status = "PASS" if matched else "MISMATCH"
            audits.append(AuditRow(
                clean_text(uploader["Fund Name"]), uploader["_row"], fund["_file"], field,
                excel_column_letter(headers, header), clean_text(left), clean_text(right), status, detail,
            ))
    return audits


def audit_summary(audits: list[AuditRow]) -> list[dict[str, Any]]:
    funds: dict[str, list[AuditRow]] = {}
    for item in audits:
        funds.setdefault(item.fund_name, []).append(item)
    output = []
    for fund, items in funds.items():
        counts = {s: sum(x.status == s for x in items) for s in ("PASS", "MISMATCH", "MISSING IN FUND", "MISSING IN UPLOADER")}
        output.append({
            "Fund Name": fund,
            "Checks": len(items),
            **counts,
            "Overall Status": "PASS" if all(x.status == "PASS" for x in items) else "REVIEW",
        })
    return output


def safe_sheet_name(name: str, used: set[str]) -> str:
    base = re.sub(r"[\\/*?:\[\]]", " ", clean_text(name))[:31] or "Fund"
    result, n = base, 2
    while result in used:
        suffix = f"_{n}"
        result = base[:31 - len(suffix)] + suffix
        n += 1
    used.add(result)
    return result


def _style_sheet(ws) -> None:
    header_fill = PatternFill("solid", fgColor="1F4E78")
    for cell in ws[1]:
        cell.fill = header_fill
        cell.font = Font(color="FFFFFF", bold=True)
        cell.alignment = Alignment(horizontal="center", vertical="center")
    ws.freeze_panes = "A2"
    ws.auto_filter.ref = ws.dimensions
    status_col = next((c.column for c in ws[1] if c.value in {"Status", "Overall Status"}), None)
    colors = {
        "PASS": "C6EFCE", "REVIEW": "FFEB9C", "MISMATCH": "FFC7CE",
        "MISSING IN FUND": "F4B084", "MISSING IN UPLOADER": "F4B084",
    }
    for row in ws.iter_rows(min_row=2):
        for cell in row:
            cell.alignment = Alignment(vertical="top", wrap_text=True)
        if status_col:
            cell = row[status_col - 1]
            if cell.value in colors:
                cell.fill = PatternFill("solid", fgColor=colors[cell.value])
    for col in range(1, ws.max_column + 1):
        length = max(len(clean_text(ws.cell(r, col).value)) for r in range(1, min(ws.max_row, 200) + 1))
        ws.column_dimensions[get_column_letter(col)].width = min(max(length + 2, 12), 55)


def export_audit(audits: list[AuditRow], output_path: str | Path) -> None:
    wb = Workbook()
    summary_ws = wb.active
    summary_ws.title = "Summary"
    summary = audit_summary(audits)
    summary_headers = ["Fund Name", "Checks", "PASS", "MISMATCH", "MISSING IN FUND", "MISSING IN UPLOADER", "Overall Status"]
    summary_ws.append(summary_headers)
    for row in summary:
        summary_ws.append([row.get(h, 0) for h in summary_headers])
    _style_sheet(summary_ws)

    detail_ws = wb.create_sheet("Audit Detail")
    headers = ["Fund Name", "Uploader Row", "Fund File", "Field", "Uploader Column", "Uploader Value", "Fund Value", "Status", "Remarks"]
    detail_ws.append(headers)
    for item in audits:
        detail_ws.append(list(asdict(item).values()))
    _style_sheet(detail_ws)

    by_fund: dict[str, list[AuditRow]] = {}
    for item in audits:
        by_fund.setdefault(item.fund_name, []).append(item)
    used = {"Summary", "Audit Detail"}
    for fund_name, items in by_fund.items():
        ws = wb.create_sheet(safe_sheet_name(fund_name, used))
        ws.append(headers)
        for item in items:
            ws.append(list(asdict(item).values()))
        _style_sheet(ws)

    wb.save(output_path)


# ----------------------------- PYQT6 GUI -----------------------------
import sys
from PyQt6.QtCore import QThread, pyqtSignal
from PyQt6.QtGui import QColor
from PyQt6.QtWidgets import (
    QApplication, QFileDialog, QHBoxLayout, QLabel, QMainWindow, QMessageBox,
    QPushButton, QTabWidget, QTableWidget, QTableWidgetItem, QVBoxLayout, QWidget,
)


class QCWorker(QThread):
    completed = pyqtSignal(object)
    failed = pyqtSignal(str)

    def __init__(self, uploader_path: str, fund_folder: str):
        super().__init__()
        self.uploader_path = uploader_path
        self.fund_folder = fund_folder

    def run(self):
        try:
            files = discover_fund_files(self.fund_folder, self.uploader_path)
            if not files:
                raise ValueError("No valid .xlsx fund files were found in the selected folder or its subfolders.")
            self.completed.emit((compare_workbooks(self.uploader_path, files), files))
        except Exception as exc:
            self.failed.emit(str(exc))


def discover_fund_files(folder: str | Path, uploader_path: str | Path | None = None) -> list[str]:
    """Find all usable .xlsx fund workbooks recursively, excluding temporary and uploader files."""
    root = Path(folder)
    if not root.is_dir():
        raise ValueError("The selected fund folder is not valid.")
    uploader_resolved = Path(uploader_path).resolve() if uploader_path else None
    files = []
    for path in sorted(root.rglob("*.xlsx"), key=lambda p: str(p).casefold()):
        if path.name.startswith("~$"):
            continue
        if uploader_resolved and path.resolve() == uploader_resolved:
            continue
        try:
            wb = load_workbook(path, read_only=True, data_only=True)
            valid = FUND_SHEET in wb.sheetnames
            wb.close()
            if valid:
                files.append(str(path))
        except Exception:
            # Corrupt, password-protected, or unrelated workbooks are skipped.
            continue
    return files


class MainWindow(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("Uploader to Fund Excel Folder QC")
        self.resize(1500, 880)
        self.uploader_path = None
        self.fund_folder = None
        self.fund_files = []
        self.audits = []
        self.worker = None

        central = QWidget()
        self.setCentralWidget(central)
        layout = QVBoxLayout(central)

        controls = QHBoxLayout()
        self.btn_uploader = QPushButton("1. Select Uploader Excel")
        self.btn_folder = QPushButton("2. Select Funds Folder")
        self.btn_run = QPushButton("3. Run QC")
        self.btn_export = QPushButton("4. Export Audit Excel")
        for button in (self.btn_uploader, self.btn_folder, self.btn_run, self.btn_export):
            controls.addWidget(button)
        layout.addLayout(controls)

        self.status = QLabel("Select the uploader workbook, then select the folder containing fund Excel files.")
        self.status.setStyleSheet("font-weight: bold; padding: 6px;")
        layout.addWidget(self.status)
        deferred = QLabel("Deferred: " + ", ".join(DEFERRED_FIELDS) + " because the examined fund workbook has no direct corresponding field.")
        deferred.setStyleSheet("color: #8a5500; padding: 4px;")
        layout.addWidget(deferred)

        self.tabs = QTabWidget()
        self.uploader_table = QTableWidget()
        self.folder_table = QTableWidget()
        self.summary_table = QTableWidget()
        self.audit_table = QTableWidget()
        self.tabs.addTab(self.uploader_table, "Uploader Preview")
        self.tabs.addTab(self.folder_table, "Fund Files Preview")
        self.tabs.addTab(self.summary_table, "QC Summary")
        self.tabs.addTab(self.audit_table, "Audit Detail")
        layout.addWidget(self.tabs)

        self.btn_uploader.clicked.connect(self.select_uploader)
        self.btn_folder.clicked.connect(self.select_folder)
        self.btn_run.clicked.connect(self.run_qc)
        self.btn_export.clicked.connect(self.export_report)
        self.btn_export.setEnabled(False)

    def populate_table(self, table, rows, headers, status_header=None):
        table.clear()
        table.setRowCount(len(rows))
        table.setColumnCount(len(headers))
        table.setHorizontalHeaderLabels(headers)
        for r, row in enumerate(rows):
            values = row if isinstance(row, (list, tuple)) else [row.get(h, "") for h in headers]
            for c, value in enumerate(values):
                item = QTableWidgetItem("" if value is None else str(value))
                item.setToolTip(item.text())
                table.setItem(r, c, item)
        if status_header in headers:
            status_col = headers.index(status_header)
            colors = {
                "PASS": QColor("#C6EFCE"), "REVIEW": QColor("#FFEB9C"),
                "MISMATCH": QColor("#FFC7CE"), "MISSING IN FUND": QColor("#F4B084"),
                "MISSING IN UPLOADER": QColor("#F4B084"),
            }
            for r in range(table.rowCount()):
                item = table.item(r, status_col)
                if item and item.text() in colors:
                    item.setBackground(colors[item.text()])
        table.setAlternatingRowColors(True)
        table.resizeColumnsToContents()

    def select_uploader(self):
        path, _ = QFileDialog.getOpenFileName(self, "Select Uploader Excel", "", "Excel files (*.xlsx)")
        if not path:
            return
        try:
            rows, _ = load_uploader(path)
            self.uploader_path = path
            headers = [key for key in rows[0] if not key.startswith("_")]
            display = [{h: row.get(h, "") for h in headers} for row in rows]
            self.populate_table(self.uploader_table, display, headers)
            self.status.setText(f"Uploader loaded: {Path(path).name} | {len(rows)} uploader funds")
            self.tabs.setCurrentWidget(self.uploader_table)
        except Exception as exc:
            QMessageBox.critical(self, "Uploader error", str(exc))

    def select_folder(self):
        folder = QFileDialog.getExistingDirectory(self, "Select Folder Containing Fund Excel Files")
        if not folder:
            return
        try:
            files = discover_fund_files(folder, self.uploader_path)
            if not files:
                raise ValueError("No .xlsx workbook containing a 'Factsheet' sheet was found in the selected folder or its subfolders.")
            self.fund_folder = folder
            self.fund_files = files
            preview = []
            for path in files:
                try:
                    record = load_fund_workbook(path)
                    preview.append({
                        "File Name": Path(path).name,
                        "Relative Path": str(Path(path).relative_to(folder)),
                        "Fund Name": clean_text(record.get("Fund Name")),
                        "Status": "READY",
                    })
                except Exception as exc:
                    preview.append({
                        "File Name": Path(path).name,
                        "Relative Path": str(Path(path).relative_to(folder)),
                        "Fund Name": "",
                        "Status": "READ ERROR: " + str(exc),
                    })
            self.populate_table(self.folder_table, preview, ["File Name", "Relative Path", "Fund Name", "Status"])
            self.status.setText(f"Funds folder loaded: {folder} | {len(files)} valid fund workbook(s)")
            self.tabs.setCurrentWidget(self.folder_table)
        except Exception as exc:
            QMessageBox.critical(self, "Folder error", str(exc))

    def run_qc(self):
        if not self.uploader_path or not self.fund_folder:
            QMessageBox.warning(self, "Missing input", "Select the uploader Excel and the funds folder first.")
            return
        self.btn_run.setEnabled(False)
        self.btn_export.setEnabled(False)
        self.status.setText("QC is running for all fund Excel files in the folder...")
        self.worker = QCWorker(self.uploader_path, self.fund_folder)
        self.worker.completed.connect(self.qc_completed)
        self.worker.failed.connect(self.qc_failed)
        self.worker.start()

    def qc_completed(self, result):
        audits, files = result
        self.audits = audits
        self.fund_files = files
        summary = audit_summary(audits)
        summary_headers = ["Fund Name", "Checks", "PASS", "MISMATCH", "MISSING IN FUND", "MISSING IN UPLOADER", "Overall Status"]
        self.populate_table(self.summary_table, summary, summary_headers, "Overall Status")
        detail_headers = ["Fund Name", "Uploader Row", "Fund File", "Field", "Uploader Column", "Uploader Value", "Fund Value", "Status", "Remarks"]
        detail_rows = [[
            a.fund_name, a.uploader_row, a.fund_file, a.field, a.uploader_column,
            a.uploader_value, a.fund_value, a.status, a.remarks,
        ] for a in audits]
        self.populate_table(self.audit_table, detail_rows, detail_headers, "Status")
        review_count = sum(a.status != "PASS" for a in audits)
        self.status.setText(
            f"QC completed: {len(files)} fund file(s), {len(audits)} checks, {review_count} item(s) need review"
        )
        self.btn_run.setEnabled(True)
        self.btn_export.setEnabled(True)
        self.tabs.setCurrentWidget(self.summary_table)

    def qc_failed(self, message):
        self.btn_run.setEnabled(True)
        self.status.setText("QC failed.")
        QMessageBox.critical(self, "QC error", message)

    def export_report(self):
        if not self.audits:
            QMessageBox.warning(self, "No audit", "Run QC before exporting the report.")
            return
        path, _ = QFileDialog.getSaveFileName(
            self, "Save Audit Report", "Uploader_QC_Audit.xlsx", "Excel files (*.xlsx)"
        )
        if not path:
            return
        if not path.lower().endswith(".xlsx"):
            path += ".xlsx"
        try:
            export_audit(self.audits, path)
            self.status.setText(f"Audit report saved: {path}")
            QMessageBox.information(self, "Export complete", "The QC audit workbook was created successfully.")
        except Exception as exc:
            QMessageBox.critical(self, "Export error", str(exc))


def main():
    app = QApplication(sys.argv)
    app.setStyle("Fusion")
    window = MainWindow()
    window.show()
    sys.exit(app.exec())


if __name__ == "__main__":
    main()
