import sys
import re
import math
import traceback
from pathlib import Path

from openpyxl import Workbook
from openpyxl.styles import Font, PatternFill, Alignment
from openpyxl.utils import get_column_letter
from PyQt6.QtCore import QThread, pyqtSignal
from PyQt6.QtWidgets import (
    QApplication, QWidget, QVBoxLayout, QHBoxLayout, QLabel, QLineEdit,
    QPushButton, QFileDialog, QProgressBar, QPlainTextEdit, QMessageBox,
    QGroupBox, QGridLayout
)

try:
    import pythoncom
    import win32com.client
except ImportError as exc:
    raise SystemExit("pywin32 is required. Run: pip install pywin32") from exc

SUPPORTED = {".xlsx", ".xlsm", ".xlsb", ".xls"}
REPORT_NAME = "Tracking Error and Tracking Difference Compare Report.xlsx"
METRICS = [
    "Tracking Error 1 Year",
    "Tracking Difference 1 Year",
    "Tracking Difference 3 Year",
    "Tracking Difference 5 Year",
    "Tracking Difference Since Inception",
]


def clean(value):
    if value is None:
        return ""
    return " ".join(str(value).replace("\r", " ").replace("\n", " ").split())


def norm(value):
    return re.sub(r"[^a-z0-9]+", "", clean(value).casefold())


def number(value):
    if value is None or isinstance(value, bool):
        return None
    if isinstance(value, (int, float)):
        if isinstance(value, float) and (math.isnan(value) or math.isinf(value)):
            return None
        return float(value)
    text = clean(value).replace(",", "")
    if not text or norm(text) in {"na", "nil", "none", "notavailable", "-"}:
        return None
    percent = text.endswith("%")
    text = text.rstrip("%").strip()
    try:
        result = float(text)
        return result if not percent else result
    except ValueError:
        return None


def round2(value):
    return None if value is None else round(float(value) + 0.0, 2)


def same_value(left, right):
    if left is None or right is None:
        return False, None
    l2, r2 = round2(left), round2(right)
    return l2 == r2, round2(l2 - r2)


def to_matrix(value):
    if value is None:
        return []
    if isinstance(value, tuple):
        if value and isinstance(value[0], tuple):
            return [list(row) for row in value]
        return [list(value)]
    return [[value]]


class ExcelSession:
    def __init__(self):
        self.excel = None

    def __enter__(self):
        pythoncom.CoInitialize()
        self.excel = win32com.client.DispatchEx("Excel.Application")
        self.excel.Visible = False
        self.excel.DisplayAlerts = False
        self.excel.ScreenUpdating = False
        self.excel.EnableEvents = False
        self.excel.AskToUpdateLinks = False
        try:
            self.excel.AutomationSecurity = 3
            self.excel.Calculation = -4135  # manual
        except Exception:
            pass
        return self.excel

    def __exit__(self, exc_type, exc, tb):
        if self.excel is not None:
            self.excel.Quit()
        pythoncom.CoUninitialize()


def sheet_matrix(com_ws, max_rows=None, max_cols=None):
    used = com_ws.UsedRange
    rows = int(used.Rows.Count)
    cols = int(used.Columns.Count)
    if max_rows:
        rows = min(rows, max_rows)
    if max_cols:
        cols = min(cols, max_cols)
    if rows <= 0 or cols <= 0:
        return []
    return to_matrix(com_ws.Range(com_ws.Cells(1, 1), com_ws.Cells(rows, cols)).Value2)


def find_header_row(matrix, required_alias_groups, scan_rows=30):
    for r, row in enumerate(matrix[:scan_rows]):
        normalized = [norm(v) for v in row]
        if all(any(alias in normalized for alias in aliases) for aliases in required_alias_groups):
            return r
    return None


def read_mapping_sheet1(excel, mapping_path):
    wb = excel.Workbooks.Open(str(Path(mapping_path).resolve()), UpdateLinks=0, ReadOnly=True, AddToMru=False)
    try:
        ws = wb.Worksheets(1)
        data = sheet_matrix(ws, max_rows=5000, max_cols=30)
    finally:
        wb.Close(False)

    scheme_aliases = {"schemecode", "clientcode"}
    name_aliases = {"displayname", "schemename", "nameofthescheme", "fundname"}
    header = find_header_row(data, [scheme_aliases, name_aliases])
    if header is None:
        raise ValueError("Sheet 1 must contain Scheme Code and Display Name/Scheme Name columns.")
    headers = [norm(v) for v in data[header]]
    code_col = next(i for i, h in enumerate(headers) if h in scheme_aliases)
    name_col = next(i for i, h in enumerate(headers) if h in name_aliases)
    result = {}
    for row in data[header + 1:]:
        code = clean(row[code_col] if code_col < len(row) else None)
        name = clean(row[name_col] if name_col < len(row) else None)
        if code and name:
            result[norm(code)] = {"scheme_code": code, "display_name": name}
    if not result:
        raise ValueError("No valid Scheme Code mappings were found on Sheet 1.")
    return result


def read_client_file(excel, client_path):
    wb = excel.Workbooks.Open(str(Path(client_path).resolve()), UpdateLinks=0, ReadOnly=True, AddToMru=False)
    try:
        ws = wb.Worksheets(1)
        data = sheet_matrix(ws, max_rows=100000, max_cols=60)
    finally:
        wb.Close(False)
    if not data:
        raise ValueError("The client file is empty.")
    headers = [norm(v) for v in data[0]]
    aliases = {norm(m): m for m in METRICS}
    try:
        code_col = headers.index("schemecode")
    except ValueError as exc:
        raise ValueError("Scheme Code was not found in the client file.") from exc
    metric_cols = {metric: headers.index(norm(metric)) for metric in METRICS if norm(metric) in headers}
    if not metric_cols:
        raise ValueError("Required Tracking Error 1 Year / Tracking Difference columns were not found in the client file.")
    records = {}
    for row_no, row in enumerate(data[1:], 2):
        code = clean(row[code_col] if code_col < len(row) else None)
        if not code:
            continue
        records[norm(code)] = {
            "scheme_code": code,
            "row": row_no,
            "values": {m: number(row[c] if c < len(row) else None) for m, c in metric_cols.items()},
        }
    return records


def tracking_period(value):
    """Normalize fund-file tracking-difference subheaders."""
    text = norm(value)
    if text in {"1yr", "1year", "oneyear", "1y"}:
        return "Tracking Difference 1 Year"
    if text in {"3yr", "3yrs", "3year", "3years", "threeyear", "3y"}:
        return "Tracking Difference 3 Year"
    if text in {"5yr", "5yrs", "5year", "5years", "fiveyear", "5y"}:
        return "Tracking Difference 5 Year"
    if text in {"si", "sinceinception", "inception", "sinceincep"}:
        return "Tracking Difference Since Inception"
    return None


def first_numeric_right(data, row_index, col_index, maximum_columns=8):
    row = data[row_index]
    for col in range(col_index + 1, min(len(row), col_index + maximum_columns + 1)):
        value = number(row[col])
        if value is not None:
            return value
    return None


def extract_tracking_error(data, row_index, col_index):
    """Fund Excel uses one Tracking Error value, representing 1 Year only."""
    value = first_numeric_right(data, row_index, col_index)
    if value is not None:
        return value
    # Support a value directly below the Tracking Error label.
    for row in range(row_index + 1, min(len(data), row_index + 4)):
        for col in range(col_index, min(len(data[row]), col_index + 4)):
            value = number(data[row][col])
            if value is not None:
                return value
    return None


def extract_tracking_difference(data, row_index, col_index):
    """Read Tracking Difference table headed 1Yr, 3Yr, 5Yr and SI.

    Supported layouts include:
      Tracking Difference | 1Yr | 3Yr | 5Yr | SI
                          | val | val | val | val
    and a header row immediately above or below the Tracking Difference label.
    """
    result = {
        "Tracking Difference 1 Year": None,
        "Tracking Difference 3 Year": None,
        "Tracking Difference 5 Year": None,
        "Tracking Difference Since Inception": None,
    }

    # Search nearby rows for the period headers and remember their columns.
    header_columns = {}
    search_start = max(0, row_index - 2)
    search_end = min(len(data), row_index + 4)
    header_row = None
    for row in range(search_start, search_end):
        for col in range(col_index + 1, len(data[row])):
            metric = tracking_period(data[row][col])
            if metric:
                header_columns[metric] = col
                header_row = row
        if len(header_columns) >= 2:
            break

    if header_columns:
        # Values normally sit on the first numeric row below the header.
        candidate_rows = list(range(header_row + 1, min(len(data), header_row + 4)))
        # If headers are above the label, the label row itself may hold values.
        if row_index not in candidate_rows:
            candidate_rows.insert(0, row_index)
        for metric, col in header_columns.items():
            for row in candidate_rows:
                if col < len(data[row]):
                    value = number(data[row][col])
                    if value is not None:
                        result[metric] = value
                        break
        return result

    # Fallback: four ordered values to the right of Tracking Difference.
    ordered_metrics = list(result)
    values = []
    for row in range(row_index, min(len(data), row_index + 3)):
        for col in range(col_index + 1, len(data[row])):
            value = number(data[row][col])
            if value is not None:
                values.append(value)
        if len(values) >= 4:
            break
    for metric, value in zip(ordered_metrics, values[:4]):
        result[metric] = value
    return result


def extract_fund_metrics(data):
    """Extract the exact fund-file structures requested by the audit.

    Tracking Error: one value under the header Tracking Error, compared only
    with client Tracking Error 1 Year.

    Tracking Difference: values under subheaders 1Yr, 3Yr, 5Yr and SI.
    """
    result = {metric: None for metric in METRICS}
    scheme_name = ""

    for row_index, row in enumerate(data):
        for col_index, raw_value in enumerate(row):
            label = norm(raw_value)
            if label == "nameofthescheme":
                for col in range(col_index + 1, min(len(row), col_index + 5)):
                    if clean(row[col]):
                        scheme_name = clean(row[col])
                        break
            elif label == "trackingerror":
                result["Tracking Error 1 Year"] = extract_tracking_error(
                    data, row_index, col_index
                )
            elif label == "trackingdifference":
                result.update(extract_tracking_difference(data, row_index, col_index))

    return scheme_name, result


def read_fund_folder(excel, folder, log, progress):
    files = [p for p in sorted(Path(folder).iterdir()) if p.is_file() and p.suffix.lower() in SUPPORTED and not p.name.startswith("~$")]
    records = []
    for index, path in enumerate(files, 1):
        log(f"Reading fund workbook {index}/{len(files)}: {path.name}")
        wb = None
        try:
            wb = excel.Workbooks.Open(str(path.resolve()), UpdateLinks=0, ReadOnly=True, AddToMru=False, IgnoreReadOnlyRecommended=True)
            best = None
            for ws in wb.Worksheets:
                data = sheet_matrix(ws, max_rows=300, max_cols=30)
                scheme_name, values = extract_fund_metrics(data)
                if scheme_name:
                    best = {"scheme_name": scheme_name, "values": values, "file": path.name, "sheet": ws.Name}
                    break
            if best:
                records.append(best)
            else:
                log(f"No Name of the Scheme was found in {path.name}")
        except Exception as exc:
            log(f"Skipped {path.name}: {exc}")
        finally:
            if wb is not None:
                wb.Close(False)
        progress(30 + int(45 * index / max(len(files), 1)))
    return records


def build_report(output_path, rows, summary):
    wb = Workbook()
    ws = wb.active
    ws.title = "Comparison"
    headers = [
        "Scheme Code", "Display Name", "Fund Scheme Name", "Metric",
        "Client Value", "Fund Excel Value", "Difference", "Result",
        "Client Row", "Fund Excel File", "Fund Sheet", "Remarks"
    ]
    ws.append(headers)
    for item in rows:
        ws.append([item.get(h, "") for h in headers])
    ws.freeze_panes = "A2"
    ws.auto_filter.ref = ws.dimensions

    summary_ws = wb.create_sheet("Summary")
    summary_headers = ["Scheme Code", "Display Name", "Result", "Passed", "Failed", "Not Compared", "Remarks"]
    summary_ws.append(summary_headers)
    for item in summary:
        summary_ws.append([item.get(h, "") for h in summary_headers])
    summary_ws.freeze_panes = "A2"
    summary_ws.auto_filter.ref = summary_ws.dimensions

    dark = PatternFill("solid", fgColor="1F4E78")
    for sheet in (ws, summary_ws):
        for cell in sheet[1]:
            cell.fill = dark
            cell.font = Font(color="FFFFFF", bold=True)
            cell.alignment = Alignment(horizontal="center")
        for col in range(1, sheet.max_column + 1):
            width = min(55, max(12, max(len(clean(sheet.cell(r, col).value)) for r in range(1, sheet.max_row + 1)) + 2))
            sheet.column_dimensions[get_column_letter(col)].width = width
    for r in range(2, ws.max_row + 1):
        for c in (5, 6, 7):
            ws.cell(r, c).number_format = "0.00"
        result = ws.cell(r, 8)
        if result.value == "PASS":
            result.fill = PatternFill("solid", fgColor="C6EFCE")
        elif result.value == "FAIL":
            result.fill = PatternFill("solid", fgColor="FFC7CE")
        else:
            result.fill = PatternFill("solid", fgColor="FCE4D6")
    wb.save(output_path)


def run_audit(mapping_path, client_path, fund_folder, output_folder, log, progress):
    output_path = str(Path(output_folder) / REPORT_NAME)
    with ExcelSession() as excel:
        log("Stage 1/4: Reading Scheme Code mapping from Sheet 1...")
        mapping = read_mapping_sheet1(excel, mapping_path)
        log(f"Loaded {len(mapping)} Scheme Code mappings.")
        progress(10)

        log("Stage 2/4: Reading Tracking Error and Tracking Difference from client file...")
        client = read_client_file(excel, client_path)
        log(f"Loaded {len(client)} client Scheme Code records.")
        progress(30)

        log("Stage 3/4: Reading individual fund workbooks with pywin32...")
        funds = read_fund_folder(excel, fund_folder, log, progress)
        fund_by_name = {norm(x["scheme_name"]): x for x in funds}
        fund_by_file = {norm(Path(x["file"]).stem): x for x in funds}
        log(f"Loaded {len(funds)} individual fund workbooks.")

    log("Stage 4/4: Comparing values and creating report...")
    detail, summary = [], []
    eligible_codes = sorted(set(mapping) & set(client))
    for index, code_key in enumerate(eligible_codes, 1):
        map_row, client_row = mapping[code_key], client[code_key]
        target = norm(map_row["display_name"])
        fund = fund_by_name.get(target) or fund_by_file.get(target)
        passed = failed = skipped = 0
        notes = []
        if not fund:
            summary.append({
                "Scheme Code": map_row["scheme_code"], "Display Name": map_row["display_name"],
                "Result": "NOT AUDITED", "Passed": 0, "Failed": 0, "Not Compared": len(METRICS),
                "Remarks": "Matching fund workbook was not found by Name of the Scheme or filename."
            })
            continue
        for metric in METRICS:
            cv = client_row["values"].get(metric)
            fv = fund["values"].get(metric)
            if cv is None and fv is None:
                result, diff, remark = "NOT AVAILABLE", None, "Blank on both sides"
                skipped += 1
            elif cv is None or fv is None:
                result, diff, remark = "NOT COMPARED", None, "Value exists on only one side"
                skipped += 1
            else:
                ok, diff = same_value(cv, fv)
                result, remark = ("PASS", "Matched at two decimals") if ok else ("FAIL", "Values differ at two decimals")
                passed += int(ok)
                failed += int(not ok)
            detail.append({
                "Scheme Code": map_row["scheme_code"], "Display Name": map_row["display_name"],
                "Fund Scheme Name": fund["scheme_name"], "Metric": metric,
                "Client Value": cv, "Fund Excel Value": fv, "Difference": diff,
                "Result": result, "Client Row": client_row["row"],
                "Fund Excel File": fund["file"], "Fund Sheet": fund["sheet"], "Remarks": remark,
            })
        overall = "FAIL" if failed else "PASS" if passed else "NOT AUDITED"
        summary.append({
            "Scheme Code": map_row["scheme_code"], "Display Name": map_row["display_name"],
            "Result": overall, "Passed": passed, "Failed": failed, "Not Compared": skipped,
            "Remarks": "; ".join(notes) if notes else "Compared available values only."
        })
        if index % 10 == 0 or index == len(eligible_codes):
            log(f"Compared {index}/{len(eligible_codes)} mapped Scheme Codes.")
        progress(75 + int(20 * index / max(len(eligible_codes), 1)))

    build_report(output_path, detail, summary)
    progress(100)
    log(f"Report saved: {output_path}")
    return output_path


class Worker(QThread):
    log_signal = pyqtSignal(str)
    progress_signal = pyqtSignal(int)
    done_signal = pyqtSignal(str)
    error_signal = pyqtSignal(str)

    def __init__(self, mapping, client, fund_folder, output):
        super().__init__()
        self.mapping, self.client, self.fund_folder, self.output = mapping, client, fund_folder, output

    def run(self):
        try:
            path = run_audit(self.mapping, self.client, self.fund_folder, self.output,
                             self.log_signal.emit, self.progress_signal.emit)
            self.done_signal.emit(path)
        except Exception:
            self.error_signal.emit(traceback.format_exc())


class App(QWidget):
    def __init__(self):
        super().__init__()
        self.worker = None
        self.setWindowTitle("Tracking Error & Tracking Difference Audit")
        self.resize(900, 650)
        layout = QVBoxLayout(self)
        title = QLabel("Tracking Error 1 Year and Tracking Difference Comparison")
        title.setStyleSheet("font-size: 22px; font-weight: 700; color: #1f4e78;")
        layout.addWidget(title)
        box = QGroupBox("Inputs")
        grid = QGridLayout(box)
        self.mapping = QLineEdit(); self.client = QLineEdit(); self.funds = QLineEdit(); self.output = QLineEdit()
        items = [
            ("Scheme Code Mapping Excel (Sheet 1)", self.mapping, self.pick_mapping),
            ("SEBI Client Excel", self.client, self.pick_client),
            ("Individual Fund Excel Folder", self.funds, self.pick_funds),
            ("Report Output Folder", self.output, self.pick_output),
        ]
        for row, (label, edit, callback) in enumerate(items):
            grid.addWidget(QLabel(label), row, 0); grid.addWidget(edit, row, 1)
            button = QPushButton("Browse"); button.clicked.connect(callback); grid.addWidget(button, row, 2)
        layout.addWidget(box)
        self.run_button = QPushButton("Run Audit")
        self.run_button.setStyleSheet("padding: 10px; font-weight: 700; background: #1f4e78; color: white;")
        self.run_button.clicked.connect(self.start)
        layout.addWidget(self.run_button)
        self.progress = QProgressBar(); layout.addWidget(self.progress)
        self.log = QPlainTextEdit(); self.log.setReadOnly(True); layout.addWidget(self.log)

    def pick_mapping(self):
        p, _ = QFileDialog.getOpenFileName(self, "Select mapping file", "", "Excel (*.xlsx *.xlsm *.xlsb *.xls)")
        if p: self.mapping.setText(p)
    def pick_client(self):
        p, _ = QFileDialog.getOpenFileName(self, "Select client file", "", "Excel (*.xlsx *.xlsm *.xlsb *.xls)")
        if p: self.client.setText(p)
    def pick_funds(self):
        p = QFileDialog.getExistingDirectory(self, "Select fund Excel folder")
        if p: self.funds.setText(p)
    def pick_output(self):
        p = QFileDialog.getExistingDirectory(self, "Select report output folder")
        if p: self.output.setText(p)

    def start(self):
        paths = [self.mapping.text().strip(), self.client.text().strip(), self.funds.text().strip(), self.output.text().strip()]
        if not all(paths):
            QMessageBox.warning(self, "Missing input", "Select all four inputs.")
            return
        self.log.clear(); self.progress.setValue(0); self.run_button.setEnabled(False)
        self.worker = Worker(*paths)
        self.worker.log_signal.connect(self.log.appendPlainText)
        self.worker.progress_signal.connect(self.progress.setValue)
        self.worker.done_signal.connect(self.finished)
        self.worker.error_signal.connect(self.failed)
        self.worker.start()

    def finished(self, path):
        self.run_button.setEnabled(True)
        QMessageBox.information(self, "Completed", f"Audit completed.\n\n{path}")

    def failed(self, message):
        self.run_button.setEnabled(True)
        self.log.appendPlainText(message)
        QMessageBox.critical(self, "Audit failed", "The audit failed. See the log for details.")


if __name__ == "__main__":
    app = QApplication(sys.argv)
    window = App()
    window.show()
    sys.exit(app.exec())
