import sys
import re
import math
import traceback
from pathlib import Path
from decimal import Decimal, ROUND_HALF_UP

from PyQt6.QtCore import QThread, pyqtSignal
from PyQt6.QtWidgets import (
    QApplication, QWidget, QVBoxLayout, QHBoxLayout, QLabel, QLineEdit,
    QPushButton, QFileDialog, QMessageBox, QProgressBar, QPlainTextEdit,
    QGroupBox, QFormLayout
)
from openpyxl import load_workbook, Workbook
from openpyxl.styles import Font, PatternFill, Alignment, Border, Side
from openpyxl.utils import get_column_letter

REPORT_FILE_NAME = "Performance Table Compare report.xlsx"
SUPPORTED_EXTENSIONS = {".xlsx", ".xlsm"}

# Sheets with these suffixes are helper/direct/data sheets and must not be audited.
SKIP_SHEET_SUFFIXES = (
    "_data_dir", "_dir_data", "_data_direct", "_direct_data",
    "_data", "_dir", "_direct",
)

PERIODS = ["1 Year", "3 Year", "5 Year", "Since Inception"]


def clean_text(value):
    return "" if value is None else re.sub(r"\s+", " ", str(value)).strip()


def normalize(value):
    return re.sub(r"[^a-z0-9]+", "", clean_text(value).casefold())


def normalize_fund_name(value):
    text = clean_text(value).casefold().replace("&", " and ")
    text = re.sub(r"\([^)]*\)", " ", text)
    text = re.sub(r"\b(?:regular|direct)\s+plan\b", " ", text)
    text = re.sub(r"\b(?:regular|direct|reg|dir)\b", " ", text)
    text = re.sub(r"\b(?:growth|option)\b", " ", text)
    text = re.sub(r"[^a-z0-9]+", " ", text)
    return " ".join(text.split())


def round_2(value):
    if value is None:
        return None
    return float(Decimal(str(value)).quantize(Decimal("0.01"), rounding=ROUND_HALF_UP))


def parse_number(value):
    if value is None or value == "":
        return None
    if isinstance(value, (int, float)):
        number = float(value)
    else:
        text = clean_text(value).replace(",", "").replace("₹", "").replace("%", "")
        match = re.search(r"[-+]?\d+(?:\.\d+)?", text)
        if not match:
            return None
        number = float(match.group())
    return number if math.isfinite(number) else None


def parse_performance_cell(cell, metric):
    """Read a performance cell using the Excel percentage format.

    The consolidated performance workbooks use Return headers containing (%)
    and store values as Excel decimals, for example 0.0284 displayed as 2.84%.
    Individual fund workbooks store the same return as the plain number 2.8444.
    Therefore only cells whose Excel number format contains % are multiplied
    by 100. Amount cells are never scaled.
    """
    value = parse_number(cell.value)
    if value is None:
        return None
    if metric == "Return" and "%" in clean_text(cell.number_format):
        value *= 100.0
    return value


def display_number(value):
    return "" if value is None else round_2(value)


def is_skipped_sheet(sheet_name):
    name = clean_text(sheet_name).casefold()
    return any(name.endswith(suffix) for suffix in SKIP_SHEET_SUFFIXES)


def find_header_row(ws, required_alias_groups, max_rows=80):
    for row_no in range(1, min(ws.max_row, max_rows) + 1):
        values = [normalize(ws.cell(row_no, c).value) for c in range(1, ws.max_column + 1)]
        columns = {}
        for key, aliases in required_alias_groups.items():
            columns[key] = next((i + 1 for i, value in enumerate(values) if value in aliases), None)
        if all(columns.values()):
            return row_no, columns
    return None, None


def read_mapping(path):
    """Read Client Code and Display Name from worksheet 2 only.

    The examined QCMappingFile.xlsx has:
      Worksheet 1: SchemeCode Mapping
      Worksheet 2: Client Code Mapping

    Worksheet 2 contains Client Code, Display Name, and AMC. Only Client Code
    and Display Name are required. Each Client Code is expanded into Regular
    and Direct audit records because the eligible base factsheet contains both.
    """
    wb = load_workbook(path, read_only=True, data_only=True)
    mapping = {}
    audit_rows = []
    try:
        if len(wb.worksheets) < 2:
            raise ValueError(
                "The Client Mapping workbook must contain worksheet 2 with "
                "Client Code and Display Name columns."
            )
        ws = wb.worksheets[1]
        header_row = None
        client_code_col = None
        display_name_col = None

        for row_no in range(1, min(ws.max_row, 100) + 1):
            row_headers = {
                normalize(ws.cell(row_no, col).value): col
                for col in range(1, ws.max_column + 1)
                if clean_text(ws.cell(row_no, col).value)
            }
            client_code_col = row_headers.get("clientcode")
            display_name_col = row_headers.get("displayname")
            if client_code_col and display_name_col:
                header_row = row_no
                break

        if header_row is None:
            raise ValueError(
                f"Worksheet 2 ('{ws.title}') does not contain the required "
                "Client Code and Display Name headers."
            )

        for row_no in range(header_row + 1, ws.max_row + 1):
            client_code = clean_text(ws.cell(row_no, client_code_col).value)
            display_name = clean_text(ws.cell(row_no, display_name_col).value)
            if not client_code and not display_name:
                continue
            if not client_code or not display_name:
                audit_rows.append(
                    (ws.title, row_no, client_code, display_name, "", "SKIPPED - blank Client Code or Display Name")
                )
                continue

            for plan in ("Regular", "Direct"):
                internal_key = f"{client_code}||{plan}"
                mapping[internal_key] = {
                    "client_code": client_code,
                    "display_name": display_name,
                    "plan": plan,
                }
                audit_rows.append(
                    (ws.title, row_no, client_code, display_name, plan, "LOADED")
                )
    finally:
        wb.close()

    if not mapping:
        raise ValueError(
            "No valid Client Code and Display Name records were found in worksheet 2."
        )
    return mapping, audit_rows


def classify_performance_header(value):
    """Classify single-cell fund Excel headers.

    Examples:
      1 Year_Amount in Rs. -> (1 Year, Amount)
      1 Year_Returns (%)   -> (1 Year, Return)
    """
    text = normalize(value)
    period = None
    if "sinceinception" in text or text.startswith("inception"):
        period = "Since Inception"
    elif "10year" in text or "10years" in text:
        period = "10 Year"
    elif "5year" in text or "5years" in text:
        period = "5 Year"
    elif "3year" in text or "3years" in text:
        period = "3 Year"
    elif "1year" in text or "1years" in text:
        period = "1 Year"
    if not period:
        return None, None

    if any(token in text for token in ("amount", "currentvalue", "valueofinvestment")):
        return period, "Amount"
    if any(token in text for token in ("return", "cagr")):
        return period, "Return"
    return period, None


def read_performance_sources(paths, log, raise_if_empty=True):
    """Read performance rows directly from Axis Equity, Debt and Hybrid factsheets.

    The uploaded workbooks are not flat input tables. Each eligible base sheet
    contains its own Performance section. Helper sheets ending in _Dir, _Data,
    or _Data_Dir are deliberately ignored.
    """
    records = []

    for path_text in paths:
        path = Path(path_text)
        file_records = []
        parsed_sheets = 0
        skipped_sheets = 0

        try:
            wb = load_workbook(path, read_only=True, data_only=True)
        except Exception as exc:
            log(f"Skipped unreadable performance file {path.name}: {exc}")
            continue

        try:
            for ws in wb.worksheets:
                if is_skipped_sheet(ws.title):
                    skipped_sheets += 1
                    continue

                try:
                    plans = find_fund_performance_table(ws)
                except ValueError:
                    continue

                sheet_added = False
                for plan in ("Regular", "Direct"):
                    plan_row = plans.get(plan)
                    if not plan_row:
                        continue
                    fund_name = plan_row["name"]
                    file_records.append({
                        "fund_name": fund_name,
                        "normalized_name": normalize_fund_name(fund_name),
                        "values": plan_row["values"],
                        "file": path.name,
                        "sheet": ws.title,
                        "client_code": clean_text(ws.title),
                        "client_code_normalized": normalize(ws.title),
                        "row": plan_row.get("row", ""),
                        "plan": plan,
                    })
                    sheet_added = True
                if sheet_added:
                    parsed_sheets += 1
        finally:
            wb.close()

        if file_records:
            records.extend(file_records)
            log(
                f"Read performance source: {path.name} | {len(file_records)} "
                f"Regular/Direct rows from {parsed_sheets} base sheet(s); "
                f"ignored {skipped_sheets} helper sheet(s)"
            )
        else:
            log(
                f"Skipped performance source: {path.name} | no usable Regular/Direct "
                "performance rows were found in eligible base sheets"
            )

    if not records and raise_if_empty:
        raise ValueError(
            "No usable Regular or Direct performance rows were found in any "
            "Equity, Debt, or Hybrid factsheet workbook."
        )
    return records


def find_source_record(client_code, display_name, plan, source_records):
    """Match source performance row by Client Code first, then Display Name.

    Axis base factsheet tabs are named with Client Codes such as AXISEQF,
    AXISF25, and AXISONF. Matching only Display Name caused valid Axis rows to
    be missed. Client Code is therefore the primary and safest key.
    """
    code_key = normalize(client_code)
    code_matches = [
        record for record in source_records
        if record.get("client_code_normalized") == code_key
        and record.get("plan") == plan
    ]
    if len(code_matches) == 1:
        return code_matches[0]
    if len(code_matches) > 1:
        return code_matches[0]

    target = normalize_fund_name(display_name)
    name_matches = []
    for record in source_records:
        if record["normalized_name"] != target:
            continue
        record_plan = record.get("plan")
        full = clean_text(record["fund_name"]).casefold()
        if record_plan == plan or plan.casefold() in full or (plan == "Regular" and "direct" not in full):
            name_matches.append(record)
    return name_matches[0] if name_matches else None


def extract_internal_scheme_name(ws):
    """Read Name of the Scheme from an individual fund workbook sheet."""
    for row_no in range(1, min(ws.max_row, 40) + 1):
        for col in range(1, min(ws.max_column, 10) + 1):
            if normalize(ws.cell(row_no, col).value) == "nameofthescheme":
                for value_col in range(col + 1, min(ws.max_column, col + 4) + 1):
                    value = clean_text(ws.cell(row_no, value_col).value)
                    if value:
                        return value
    return ""


def locate_fund_workbooks(folder):
    """Index individual fund workbooks by internal Name of the Scheme.

    Individual fund files use generic sheet names such as Factsheet, so their
    sheet names cannot be matched to Client Codes. The internal scheme name is
    the correct key for the Fund Excel Folder.
    """
    records = []
    for path in sorted(Path(folder).iterdir()):
        if path.suffix.lower() not in SUPPORTED_EXTENSIONS or path.name.startswith("~$"):
            continue
        wb = load_workbook(path, read_only=True, data_only=True)
        try:
            for ws in wb.worksheets:
                scheme_name = extract_internal_scheme_name(ws)
                if not scheme_name:
                    continue
                records.append({
                    "path": path,
                    "sheet": ws.title,
                    "scheme_name": scheme_name,
                    "scheme_name_normalized": normalize_fund_name(scheme_name),
                    "filename_normalized": normalize_fund_name(path.stem),
                })
        finally:
            wb.close()
    return records


def find_fund_sheet(client_code, display_name, fund_index):
    """Find an individual fund workbook by Display Name/internal scheme name."""
    target = normalize_fund_name(display_name)
    internal_matches = [
        record for record in fund_index
        if record.get("scheme_name_normalized") == target
    ]
    if len(internal_matches) == 1:
        return internal_matches[0]

    filename_matches = [
        record for record in fund_index
        if record.get("filename_normalized") == target
    ]
    if len(filename_matches) == 1:
        return filename_matches[0]
    return None


def period_from_text(value):
    text = normalize(value)
    if "sinceinception" in text or text.startswith("siannualized") or text == "si":
        return "Since Inception"
    if "10year" in text:
        return "10 Year"
    if "5year" in text:
        return "5 Year"
    if "3year" in text:
        return "3 Year"
    if "1year" in text:
        return "1 Year"
    return None


def locate_performance_heading(ws):
    for row_no in range(1, min(ws.max_row, 140) + 1):
        for col in range(1, ws.max_column + 1):
            if normalize(ws.cell(row_no, col).value) == "performance":
                return row_no, col
    return None, None


def classify_fund_plan_row(name):
    """Return Regular/Direct only for the main Growth Option rows.

    Excludes variant rows such as Lock-in, Without Lock-in, IDCW, Dividend,
    Bonus, payout, reinvestment, and other non-main plan variants.
    """
    text = clean_text(name)
    normalized = normalize(text)
    if not normalized or "fund" not in normalized:
        return None
    if "benchmark" in normalized or "additionalbenchmark" in normalized:
        return None

    excluded_tokens = (
        "lockin", "withoutlockin", "nolockin", "withlockin",
        "idcw", "dividend", "bonus", "payout", "reinvestment",
        "monthlyincome", "quarterlyincome", "annualincome",
    )
    if any(token in normalized for token in excluded_tokens):
        return None

    # Accept only the principal Growth / Growth Option rows.
    if "growth" not in normalized:
        return None

    if "direct" in normalized or "dirgrowth" in normalized:
        return "Direct"
    if "regular" in normalized or "reggrowth" in normalized:
        return "Regular"
    return None


def parse_standard_performance_table(ws, performance_row):
    """Parse the horizontal performance layout using header rows only.

    The examined performance files use a two-level header:
      Row 1: 1 Year, 3 Year, 5 Year, 10 Year, Since Inception
      Row 2: (%), Value of

    In the consolidated performance files, CAGR plus (%) means Return, while
    Current Value of Investment of INR 10,000 means Amount. Restricting period
    detection to the header area prevents benchmark names such as NIFTY 1 Year
    T-Bill Index from being mistaken for performance headers.
    """
    rows = {"Regular": None, "Direct": None}

    # Find the first actual Regular/Direct fund row. Everything between the
    # Performance heading and this row is the table header area.
    first_plan_row = None
    for row_no in range(performance_row + 1, min(ws.max_row, performance_row + 15) + 1):
        row_text = " ".join(
            clean_text(ws.cell(row_no, col).value)
            for col in range(1, min(ws.max_column, 6) + 1)
        )
        if classify_fund_plan_row(row_text):
            first_plan_row = row_no
            break

    if first_plan_row is None:
        return rows

    header_start = performance_row + 1
    header_end = first_plan_row - 1
    metric_cols = {}

    # Read period headings only from the true header area.
    period_positions = []
    for row_no in range(header_start, header_end + 1):
        for col in range(1, ws.max_column + 1):
            period = period_from_text(ws.cell(row_no, col).value)
            if period:
                period_positions.append((period, row_no, col))

    for period, period_row, period_col in period_positions:
        # Search the period column and the next few columns for the subheaders.
        # (%) is Return; Value of / Current Value / Amount is Amount.
        assigned_return = False
        assigned_amount = False
        for col in range(period_col, min(ws.max_column, period_col + 3) + 1):
            subheader = " ".join(
                clean_text(ws.cell(row_no, col).value)
                for row_no in range(period_row + 1, header_end + 1)
            )
            sub_norm = normalize(subheader)
            raw_subheader = subheader.casefold()

            if not assigned_return and (
                "%" in raw_subheader
                or "return" in sub_norm
                or "cagr" in sub_norm
            ):
                metric_cols[(period, "Return")] = col
                assigned_return = True
                continue

            if not assigned_amount and any(
                token in sub_norm
                for token in ("valueof", "currentvalue", "valueofinvestment", "amount")
            ):
                metric_cols[(period, "Amount")] = col
                assigned_amount = True

        # Axis headers consistently place Return in the period column and
        # Amount in the immediately following column. Use this as a fallback
        # when merged cells hide the lower-level header text.
        if not assigned_return:
            metric_cols[(period, "Return")] = period_col
        if not assigned_amount and period_col + 1 <= ws.max_column:
            metric_cols[(period, "Amount")] = period_col + 1

    if not metric_cols:
        return rows

    # Read only actual fund rows, excluding benchmark lines.
    for row_no in range(first_plan_row, min(ws.max_row, first_plan_row + 15) + 1):
        name = ""
        for name_col in range(1, min(ws.max_column, 5) + 1):
            candidate = clean_text(ws.cell(row_no, name_col).value)
            candidate_norm = normalize(candidate)
            if "fund" in candidate_norm and "benchmark" not in candidate_norm:
                name = candidate
                break
        if not name:
            continue

        plan = classify_fund_plan_row(name)
        if not plan:
            continue

        values = {
            key: parse_performance_cell(ws.cell(row_no, col), key[1])
            for key, col in metric_cols.items()
        }
        if any(value is not None for value in values.values()):
            rows[plan] = {"name": name, "values": values, "row": row_no}

    return rows


def parse_debt_matrix_performance_table(ws, performance_row):
    """Parse liquid/overnight/money-market layout with plans across columns."""
    plan_columns = {}
    plan_names = {}

    for row_no in range(performance_row + 1, min(ws.max_row, performance_row + 8) + 1):
        for col in range(1, ws.max_column + 1):
            name = clean_text(ws.cell(row_no, col).value)
            text = normalize(name)
            if "benchmark" in text or "additionalbenchmark" in text:
                continue
            plan = classify_fund_plan_row(name)
            if plan:
                plan_columns[plan] = col
                plan_names[plan] = name

    rows = {"Regular": None, "Direct": None}
    for plan, value_col in plan_columns.items():
        values = {}
        for row_no in range(performance_row + 1, min(ws.max_row, performance_row + 40) + 1):
            label = clean_text(ws.cell(row_no, 2).value)
            period = period_from_text(label)
            if not period:
                continue
            if "annualized" not in normalize(label) and "return" not in normalize(label):
                continue
            values[(period, "Return")] = parse_performance_cell(
                ws.cell(row_no, value_col), "Return"
            )
            # Amount usually appears on the immediately following row.
            for amount_row in range(row_no + 1, min(ws.max_row, row_no + 3) + 1):
                amount_label = normalize(ws.cell(amount_row, 2).value)
                if "currentvalueofinvestment" in amount_label:
                    values[(period, "Amount")] = parse_performance_cell(
                        ws.cell(amount_row, value_col), "Amount"
                    )
                    break
        if values:
            rows[plan] = {
                "name": plan_names[plan],
                "values": values,
                "row": performance_row,
            }
    return rows


def parse_individual_fund_performance_table(ws):
    """Parse individual fund files with separate Regular and Direct headers.

    Example:
    Performance - Regular Plan | Fund / Benchmark | 1 Year_Amount | 1 Year_Returns
    Performance - Direct Plan  | Fund / Benchmark | 1 Year_Amount | 1 Year_Returns
    """
    rows = {"Regular": None, "Direct": None}
    for header_row in range(1, ws.max_row + 1):
        first_cell = normalize(ws.cell(header_row, 1).value)
        plan = None
        if "performance" in first_cell and "regular" in first_cell:
            plan = "Regular"
        elif "performance" in first_cell and "direct" in first_cell:
            plan = "Direct"
        if not plan:
            continue

        metric_cols = {}
        name_col = None
        for col in range(1, ws.max_column + 1):
            header = clean_text(ws.cell(header_row, col).value)
            normalized = normalize(header)
            if normalized in {"fundbenchmark", "fundname", "schemename"}:
                name_col = col
            period, metric = classify_performance_header(header)
            if period and metric:
                metric_cols[(period, metric)] = col

        if not name_col or not metric_cols:
            continue

        for row_no in range(header_row + 1, min(ws.max_row, header_row + 5) + 1):
            name = clean_text(ws.cell(row_no, name_col).value)
            if classify_fund_plan_row(name) != plan:
                continue
            values = {
                key: parse_performance_cell(ws.cell(row_no, col), key[1])
                for key, col in metric_cols.items()
            }
            if any(value is not None for value in values.values()):
                rows[plan] = {"name": name, "values": values, "row": row_no}
                break
    return rows


def find_fund_performance_table(ws):
    """Parse both performance layouts found in the examined Axis workbooks."""
    individual_rows = parse_individual_fund_performance_table(ws)
    if individual_rows["Regular"] is not None or individual_rows["Direct"] is not None:
        return individual_rows

    performance_row, _ = locate_performance_heading(ws)
    if not performance_row:
        raise ValueError("Performance heading was not found.")

    # Standard horizontal layout is tested first. Its parser now restricts
    # period detection to the true header rows and recognizes (%) as Return.
    rows = parse_standard_performance_table(ws, performance_row)
    if rows["Regular"] is not None or rows["Direct"] is not None:
        return rows

    rows = parse_debt_matrix_performance_table(ws, performance_row)
    if rows["Regular"] is not None or rows["Direct"] is not None:
        return rows

    raise ValueError("Regular and Direct fund rows were not found in the performance section.")


def compare_values(source, fund):
    if source is None or fund is None:
        return False, None
    s, f = round_2(source), round_2(fund)
    return s == f, round_2(s - f)


def get_performance_files(performance_folder):
    """Return all supported Excel files from the selected performance folder."""
    folder = Path(performance_folder)
    files = [
        path for path in sorted(folder.iterdir())
        if path.is_file()
        and path.suffix.lower() in SUPPORTED_EXTENSIONS
        and not path.name.startswith("~$")
    ]
    if not files:
        raise ValueError(
            "No .xlsx or .xlsm performance files were found in the selected performance folder."
        )
    return files


def stage_progress(progress_callback, start, end, current, total):
    """Convert progress within one stage to the overall 0-100 range."""
    total = max(total, 1)
    current = min(max(current, 0), total)
    value = start + ((end - start) * current / total)
    progress_callback(int(round(value)))


def run_audit(mapping_file, performance_folder, fund_folder, output_folder, log, progress):
    """Run the audit with visible progress across every major processing stage."""
    progress(0)

    log("Stage 1/5: Reading Client Mapping from worksheet 2...")
    mapping, mapping_audit = read_mapping(mapping_file)
    log(f"Loaded {len(mapping) // 2} Client Codes, expanded to {len(mapping)} Regular/Direct audit records.")
    progress(8)

    log("Stage 2/5: Discovering performance Excel files...")
    performance_files = get_performance_files(performance_folder)
    log(f"Found {len(performance_files)} Excel files in the performance folder.")

    source_records = []
    for file_number, performance_file in enumerate(performance_files, 1):
        records = read_performance_sources([performance_file], log, raise_if_empty=False)
        source_records.extend(records)
        stage_progress(progress, 8, 28, file_number, len(performance_files))
    if not source_records:
        raise ValueError("None of the Excel files in the performance folder contained usable performance-table rows.")
    log(f"Loaded {len(source_records)} performance source rows.")

    log("Stage 3/5: Indexing individual fund workbooks by Name of the Scheme...")
    fund_files = [
        path for path in sorted(Path(fund_folder).iterdir())
        if path.is_file()
        and path.suffix.lower() in SUPPORTED_EXTENSIONS
        and not path.name.startswith("~$")
    ]
    fund_index = []
    for file_number, path in enumerate(fund_files, 1):
        wb = load_workbook(path, read_only=True, data_only=True)
        try:
            for ws in wb.worksheets:
                scheme_name = extract_internal_scheme_name(ws)
                if not scheme_name:
                    continue
                fund_index.append({
                    "path": path,
                    "sheet": ws.title,
                    "scheme_name": scheme_name,
                    "scheme_name_normalized": normalize_fund_name(scheme_name),
                    "filename_normalized": normalize_fund_name(path.stem),
                })
        finally:
            wb.close()
        stage_progress(progress, 28, 43, file_number, len(fund_files))
    log(f"Indexed {len(fund_index)} individual fund workbooks using internal scheme names.")

    log(
        "Stage 4/5: Comparing 1 Year, 3 Year, 5 Year, and "
        "Since Inception values for Regular and Direct plans..."
    )
    detail_rows, summary_rows = [], []
    fund_cache = {}
    available_source_keys = {
        (record.get("client_code_normalized"), record.get("plan"))
        for record in source_records
    }
    items = [
        (mapping_key, meta)
        for mapping_key, meta in sorted(mapping.items())
        if (normalize(meta["client_code"]), meta["plan"]) in available_source_keys
    ]
    skipped_mapping_count = len(mapping) - len(items)
    log(
        f"Auditing {len(items)} Client Code/Plan rows present in the performance files; "
        f"skipping {skipped_mapping_count} mapping rows not present in those files."
    )

    for position, (mapping_key, meta) in enumerate(items, 1):
        client_code = meta["client_code"]
        display_name, plan = meta["display_name"], meta["plan"]
        source = find_source_record(client_code, display_name, plan, source_records)
        fund_ref = find_fund_sheet(client_code, display_name, fund_index)
        result, remarks = "NOT AUDITED", ""
        passed_count = failed_count = 0

        if source is None:
            remarks = f"Client Code {client_code} was not found as an eligible base sheet in the performance files."
        elif fund_ref is None:
            remarks = f"Display Name '{display_name}' was not found as Name of the Scheme in the fund Excel folder."
        else:
            cache_key = (str(fund_ref["path"]), fund_ref["sheet"])
            try:
                if cache_key not in fund_cache:
                    wb = load_workbook(fund_ref["path"], read_only=True, data_only=True)
                    try:
                        fund_cache[cache_key] = find_fund_performance_table(wb[fund_ref["sheet"]])
                    finally:
                        wb.close()

                plan_row = fund_cache[cache_key].get(plan)
                if not plan_row:
                    remarks = f"{plan} row was not found in the base fund sheet performance table."
                    result = "FAIL"
                else:
                    for period in PERIODS:
                        for metric in ("Return", "Amount"):
                            source_value = source["values"].get((period, metric))
                            fund_value = plan_row["values"].get((period, metric))
                            if source_value is None and fund_value is None:
                                continue
                            passed, difference = compare_values(source_value, fund_value)
                            status = "PASS" if passed else "FAIL"
                            passed_count += int(passed)
                            failed_count += int(not passed)
                            detail_rows.append({
                                "Client Code": client_code,
                                "Plan": plan,
                                "Factsheet Display Name": display_name,
                                "Performance Source File": source["file"],
                                "Performance Source Sheet": source["sheet"],
                                "Fund Excel File": fund_ref["path"].name,
                                "Fund Sheet": fund_ref["sheet"],
                                "Period": period,
                                "Metric": metric,
                                "Performance File Value": source_value,
                                "Fund Excel Value": fund_value,
                                "Difference": difference,
                                "Result": status,
                            })
                    result = "PASS" if failed_count == 0 else "FAIL"
                    remarks = (
                        f"{passed_count} comparisons passed; {failed_count} comparisons failed. "
                        "Checked main Regular Growth/Direct Growth rows only for 1 Year, 3 Year, 5 Year, and Since Inception."
                    )
            except Exception as exc:
                result, remarks = "ERROR", str(exc)

        summary_rows.append({
            "Client Code": client_code,
            "Plan": plan,
            "Factsheet Display Name": display_name,
            "Performance Source File": source["file"] if source else "",
            "Fund Excel File": fund_ref["path"].name if fund_ref else "",
            "Fund Sheet": fund_ref["sheet"] if fund_ref else "",
            "Result": result,
            "Remarks": remarks,
        })
        log(f"{client_code} [{plan}]: {result} - {remarks}")
        stage_progress(progress, 43, 92, position, len(items))

    log("Stage 5/5: Creating formatted audit report...")
    progress(94)
    output = Path(output_folder) / REPORT_FILE_NAME
    create_report(output, summary_rows, detail_rows, mapping, mapping_audit)
    progress(100)
    log("Audit report creation completed.")
    return output


def create_report(path, summary_rows, detail_rows, mapping, mapping_audit):
    wb = Workbook()
    summary = wb.active
    summary.title = "Audit Summary"
    summary_headers = ["Client Code", "Plan", "Factsheet Display Name", "Performance Source File",
                       "Fund Excel File", "Fund Sheet", "Result", "Remarks"]
    summary.append(summary_headers)
    for item in summary_rows:
        summary.append([item.get(h, "") for h in summary_headers])

    detail = wb.create_sheet("Performance Comparison")
    detail_headers = ["Client Code", "Plan", "Factsheet Display Name", "Performance Source File",
                      "Performance Source Sheet", "Fund Excel File", "Fund Sheet", "Period", "Metric",
                      "Performance File Value", "Fund Excel Value", "Difference", "Result"]
    detail.append(detail_headers)
    for item in detail_rows:
        detail.append([item.get(h, "") for h in detail_headers])

    map_sheet = wb.create_sheet("Client Fund Mapping")
    map_sheet.append(["Client Code", "Plan", "Display Name"])
    for mapping_key, meta in sorted(mapping.items()):
        map_sheet.append([meta["client_code"], meta["plan"], meta["display_name"]])

    source_sheet = wb.create_sheet("Client Mapping Audit")
    source_sheet.append(["Source Sheet", "Source Row", "Client Mapping Code", "Factsheet Display Name", "Plan", "Status"])
    for row in mapping_audit:
        source_sheet.append(list(row))

    dark, green, red, yellow = "17365D", "C6EFCE", "FFC7CE", "FFEB9C"
    thin = Side(style="thin", color="D9E1F2")
    for ws in wb.worksheets:
        ws.freeze_panes = "A2"
        ws.auto_filter.ref = ws.dimensions
        ws.sheet_view.showGridLines = False
        for cell in ws[1]:
            cell.fill = PatternFill("solid", fgColor=dark)
            cell.font = Font(color="FFFFFF", bold=True)
            cell.alignment = Alignment(horizontal="center", vertical="center", wrap_text=True)
        for row in ws.iter_rows(min_row=2):
            for cell in row:
                cell.alignment = Alignment(vertical="top", wrap_text=True)
                cell.border = Border(bottom=thin)
        for col in range(1, ws.max_column + 1):
            width = max(len(clean_text(ws.cell(r, col).value)) for r in range(1, min(ws.max_row, 500) + 1))
            ws.column_dimensions[get_column_letter(col)].width = min(max(width + 2, 12), 40)

    for row in range(2, summary.max_row + 1):
        cell = summary.cell(row, 7)
        cell.fill = PatternFill("solid", fgColor=green if cell.value == "PASS" else red if cell.value in {"FAIL", "ERROR"} else yellow)
    for row in range(2, detail.max_row + 1):
        for col in (10, 11, 12):
            detail.cell(row, col).number_format = "0.00"
        cell = detail.cell(row, 13)
        cell.fill = PatternFill("solid", fgColor=green if cell.value == "PASS" else red)

    wb.save(path)


class AuditWorker(QThread):
    log_message = pyqtSignal(str)
    progress_changed = pyqtSignal(int)
    completed = pyqtSignal(str)
    failed = pyqtSignal(str)

    def __init__(self, mapping, performance_folder, funds, output):
        super().__init__()
        self.mapping, self.performance_folder = mapping, performance_folder
        self.funds, self.output = funds, output

    def run(self):
        try:
            result = run_audit(self.mapping, self.performance_folder, self.funds, self.output,
                               self.log_message.emit, self.progress_changed.emit)
            self.completed.emit(str(result))
        except Exception:
            self.failed.emit(traceback.format_exc())


class PerformanceAuditApp(QWidget):
    STYLE = """
    QWidget{background:#F4F7FB;color:#243447;font-family:'Segoe UI';font-size:10pt}
    QLabel#Title{color:#123B63;font-size:24px;font-weight:700} QLabel#Sub{color:#5D6D7E}
    QLabel#Status{background:#EAF2F8;color:#1F4E78;border-radius:7px;padding:10px 12px;font-weight:600}
    QGroupBox{background:white;border:1px solid #D7E1EC;border-radius:10px;margin-top:14px;padding:16px 12px 12px;font-weight:700;color:#1F4E78}
    QGroupBox::title{subcontrol-origin:margin;left:14px;padding:0 6px}
    QLineEdit{background:white;border:1px solid #C9D5E2;border-radius:6px;padding:9px}
    QLineEdit:focus{border:2px solid #2878B5}
    QPushButton{background:#E9F1F8;color:#1F4E78;border:1px solid #B9CDDF;border-radius:6px;padding:8px 14px;font-weight:600}
    QPushButton:hover{background:#D9EAF7} QPushButton#Run{background:#1F4E78;color:white;border:none;padding:12px 24px;font-size:11pt;font-weight:700}
    QPushButton#Run:hover{background:#2878B5} QPushButton#Run:disabled{background:#9EB2C4}
    QProgressBar{background:#DFE8F0;border:none;border-radius:6px;height:22px;color:#17365D;text-align:center;font-weight:700}
    QProgressBar::chunk{background:#2E86C1;border-radius:6px}
    QPlainTextEdit{background:#17202A;color:#D5E8F5;border:none;border-radius:8px;padding:10px;font-family:Consolas;font-size:9pt}
    """

    def __init__(self):
        super().__init__()
        self.worker = None
        self.setWindowTitle("Performance Table Compare Audit")
        self.setMinimumSize(980, 720)
        self.resize(1080, 780)
        self.setStyleSheet(self.STYLE)
        main = QVBoxLayout(self)
        main.setContentsMargins(28, 24, 28, 24)
        main.setSpacing(14)

        title = QLabel("Performance Table Compare Audit")
        title.setObjectName("Title")
        main.addWidget(title)
        sub = QLabel(
            "Use the selected Client Mapping workbook to match Client Codes and Display Names, then compare Regular and Direct performance values from the Equity, Debt, and Hybrid performance-files folder "
            "against eligible base fund sheets. Helper sheets ending in _Dir, _Data, or _Data_Dir are excluded."
        )
        sub.setObjectName("Sub")
        sub.setWordWrap(True)
        main.addWidget(sub)

        group = QGroupBox("Audit Inputs")
        form = QFormLayout(group)
        form.setVerticalSpacing(12)
        self.mapping = QLineEdit()
        self.mapping.setPlaceholderText("Select workbook; Client Mapping is read from worksheet 2")
        self.performance = QLineEdit()
        self.performance.setPlaceholderText("Select folder containing Equity, Debt, and Hybrid performance files")
        self.funds = QLineEdit()
        self.funds.setPlaceholderText("Select folder containing fund Excel workbooks")
        self.output = QLineEdit()
        self.output.setPlaceholderText("Select folder where the audit report will be saved")
        form.addRow("Client Mapping Excel (Sheet 2)", self.path_row(self.mapping, self.pick_mapping, "Browse File"))
        form.addRow("Performance Files Folder", self.path_row(self.performance, self.pick_performance_folder, "Browse Folder"))
        form.addRow("Fund Excel Folder", self.path_row(self.funds, self.pick_funds, "Browse Folder"))
        form.addRow("Save Report Folder", self.path_row(self.output, self.pick_output, "Browse Folder"))
        main.addWidget(group)

        actions = QHBoxLayout()
        self.clear_button = QPushButton("Clear")
        self.clear_button.clicked.connect(self.clear)
        actions.addWidget(self.clear_button)
        actions.addStretch(1)
        self.run_button = QPushButton("Create Audit Report")
        self.run_button.setObjectName("Run")
        self.run_button.setMinimumWidth(220)
        self.run_button.clicked.connect(self.start)
        actions.addWidget(self.run_button)
        main.addLayout(actions)

        self.status = QLabel("Ready to run the audit")
        self.status.setObjectName("Status")
        main.addWidget(self.status)
        self.progress = QProgressBar()
        self.progress.setRange(0, 100)
        main.addWidget(self.progress)
        log_group = QGroupBox("Audit Log")
        log_layout = QVBoxLayout(log_group)
        self.log = QPlainTextEdit()
        self.log.setReadOnly(True)
        log_layout.addWidget(self.log)
        main.addWidget(log_group, 1)
        foot = QLabel(f'Report: "{REPORT_FILE_NAME}" | Rows: Regular Growth and Direct Growth only | Periods: 1Y, 3Y, 5Y, Since Inception | Exact two-decimal comparison')
        foot.setObjectName("Sub")
        main.addWidget(foot)

    def path_row(self, edit, callback, text):
        widget = QWidget()
        widget.setStyleSheet("background:transparent")
        layout = QHBoxLayout(widget)
        layout.setContentsMargins(0, 0, 0, 0)
        layout.addWidget(edit, 1)
        button = QPushButton(text)
        button.setMinimumWidth(120)
        button.clicked.connect(callback)
        layout.addWidget(button)
        return widget

    def pick_mapping(self):
        path, _ = QFileDialog.getOpenFileName(self, "Select Client Mapping", "", "Excel Files (*.xlsx *.xlsm)")
        if path:
            self.mapping.setText(path)

    def pick_performance_folder(self):
        path = QFileDialog.getExistingDirectory(
            self, "Select Equity, Debt, and Hybrid Performance Files Folder"
        )
        if path:
            self.performance.setText(path)

    def pick_funds(self):
        path = QFileDialog.getExistingDirectory(self, "Select Fund Excel Folder")
        if path:
            self.funds.setText(path)

    def pick_output(self):
        path = QFileDialog.getExistingDirectory(self, "Select Report Save Folder")
        if path:
            self.output.setText(path)

    def clear(self):
        if self.worker and self.worker.isRunning():
            return
        self.mapping.clear(); self.performance.clear(); self.funds.clear(); self.output.clear()
        self.log.clear(); self.progress.setValue(0)
        self.status.setText("Ready to run the audit")

    def busy(self, state):
        for widget in (self.mapping, self.performance, self.funds, self.output, self.run_button, self.clear_button):
            widget.setEnabled(not state)

    def start(self):
        errors = []
        if not Path(self.mapping.text().strip()).is_file():
            errors.append("Select a valid Client Mapping Excel file.")
        if not Path(self.performance.text().strip()).is_dir():
            errors.append("Select a valid Equity, Debt, and Hybrid performance files folder.")
        if not Path(self.funds.text().strip()).is_dir():
            errors.append("Select a valid Fund Excel folder.")
        if not Path(self.output.text().strip()).is_dir():
            errors.append("Select a valid report save folder.")
        if errors:
            QMessageBox.warning(self, "Check Audit Inputs", "\n".join(errors))
            return
        self.log.clear(); self.progress.setValue(0); self.busy(True)
        self.status.setText("Audit is running with workbook caching. Please wait...")
        self.worker = AuditWorker(
            self.mapping.text().strip(),
            self.performance.text().strip(),
            self.funds.text().strip(),
            self.output.text().strip(),
        )
        self.worker.log_message.connect(self.log.appendPlainText)
        self.worker.progress_changed.connect(self.update_progress)
        self.worker.completed.connect(self.done)
        self.worker.failed.connect(self.failed)
        self.worker.start()

    def update_progress(self, value):
        self.progress.setValue(value)
        if value < 8:
            stage = "Loading mapping"
        elif value < 28:
            stage = "Reading performance files"
        elif value < 43:
            stage = "Indexing fund workbooks"
        elif value < 92:
            stage = "Comparing performance values"
        elif value < 100:
            stage = "Creating audit report"
        else:
            stage = "Completed"
        self.status.setText(f"{stage}: {value}%")

    def done(self, path):
        self.busy(False); self.progress.setValue(100)
        self.status.setText("Audit completed successfully")
        self.log.appendPlainText(f"Report saved: {path}")
        QMessageBox.information(self, "Audit Complete", f"Report created successfully:\n{path}")

    def failed(self, message):
        self.busy(False); self.status.setText("Audit failed. Review the log.")
        self.log.appendPlainText(message)
        QMessageBox.critical(self, "Audit Failed", "The audit failed. See the log for details.")


if __name__ == "__main__":
    app = QApplication(sys.argv)
    window = PerformanceAuditApp()
    window.show()
    sys.exit(app.exec())
