from __future__ import annotations
import re, math, unicodedata
from decimal import Decimal, InvalidOperation
from datetime import datetime
from dataclasses import dataclass, asdict
from pathlib import Path
from typing import Any, Iterable
from openpyxl import load_workbook, Workbook
from openpyxl.styles import Font, PatternFill, Alignment
from openpyxl.utils import get_column_letter
from pptx import Presentation
from pptx.enum.shapes import MSO_SHAPE_TYPE

EXCEL_SHEET = "Uploader"
DISPLAY_COLUMNS = {
    "Fund Name": "Factsheet Display Name",
    "Fund Type": "Fund Type",
    "Fund Manager": "Fund Manager",
    "Managing Since": "Managing Since",
    "Fundman Total Experience": "Fundman Total Experience",
    "Display Benchmark": "Display Benchmark",
    "Load Structure": "Load Structure",
    "Date of Inception": "Date of Inception",
    "Product Label": "Product Label",
    "Minimum SIP Amount": "Minimum SIP Amount",
    "Minimum Investment": "Minimum Investment",
}
PPT_OBJECTS = {
    "Fund Name": "FundName",
    "Fund Type": "FundType",
    "Fund Manager": "FundManager",
    "Managing Since": "FundManager",
    "Fundman Total Experience": "FundManager",
    "Display Benchmark": "Benchmark",
    "Load Structure": "EETable",
    "Date of Inception": "DOA",
    "Product Label": "FundBox*",
    "Minimum SIP Amount": "MinimumSIPAmount",
    "Minimum Investment": "MinimumSIPAmount",
}
DEFERRED_FIELDS = ["Scheme Riskometer", "Benchmark Riskometer", "showDebtQuants"]

@dataclass
class AuditRow:
    fund_name: str
    excel_row: int
    slide_number: int | None
    field: str
    object_name: str
    excel_value: str
    ppt_value: str
    status: str
    remarks: str


def clean_text(v: Any) -> str:
    if v is None: return ""
    s = str(v).replace("\xa0", " ")
    s = unicodedata.normalize("NFKC", s)
    s = re.sub(r"<br\s*/?>", "\n", s, flags=re.I)
    s = re.sub(r"<[^>]+>", " ", s)
    s = s.replace("–", "-").replace("—", "-").replace("−", "-")
    s = re.sub(r"[ \t]+", " ", s)
    s = re.sub(r"\s*\n\s*", "\n", s)
    return s.strip()


def norm(v: Any) -> str:
    s = clean_text(v).casefold()
    s = re.sub(r"[^\w]+", " ", s, flags=re.UNICODE)
    return re.sub(r"\s+", " ", s).strip()


def digits(v: Any) -> list[str]:
    return re.findall(r"\d+(?:\.\d+)?", clean_text(v).replace(",", ""))


def money_numbers(v: Any) -> list[str]:
    return digits(v)


def canonical_numbers(v: Any) -> list[Decimal]:
    """Make 100, 100.0, 100.00, and 1,00.00 comparable as numbers."""
    values = []
    for item in digits(v):
        try:
            values.append(Decimal(item).normalize())
        except InvalidOperation:
            pass
    return values


def remove_temporary_manager_annotations(value: Any) -> str:
    """Remove temporary/non-comparable manager annotations from either source."""
    text = clean_text(value)
    text = re.sub(
        r"\s*\(\s*for\s+foreign\s+securities\s*\)\s*",
        " ",
        text,
        flags=re.I,
    )
    return clean_text(text)


def normalized_list(v: Any) -> list[str]:
    """Compare manager/list values while ignoring temporary annotations."""
    text = remove_temporary_manager_annotations(v)
    parts = re.split(r"\s*(?:#|/|\n|;|\|)\s*", text)
    return [norm(part) for part in parts if norm(part)]


def extracted_dates(v: Any) -> list[str]:
    """Extract and normalize single or repeated dates from Excel/PPT text."""
    text = clean_text(v)
    month = r"(?:Jan(?:uary)?|Feb(?:ruary)?|Mar(?:ch)?|Apr(?:il)?|May|Jun(?:e)?|Jul(?:y)?|Aug(?:ust)?|Sep(?:tember)?|Oct(?:ober)?|Nov(?:ember)?|Dec(?:ember)?)"
    patterns = [
        r"\b\d{4}-\d{1,2}-\d{1,2}\b",
        r"\b\d{1,2}[/-]\d{1,2}[/-]\d{4}\b",
        rf"\b{month}\s+\d{{1,2}}(?:st|nd|rd|th)?,?\s+\d{{4}}\b",
        rf"\b\d{{1,2}}(?:st|nd|rd|th)?\s+{month},?\s+\d{{4}}\b",
    ]
    found = []
    occupied = []
    for pattern in patterns:
        for match in re.finditer(pattern, text, flags=re.I):
            span = match.span()
            if not any(span[0] < old[1] and old[0] < span[1] for old in occupied):
                found.append((span[0], match.group(0)))
                occupied.append(span)
    found.sort(key=lambda item: item[0])

    formats = (
        "%Y-%m-%d", "%d/%m/%Y", "%m/%d/%Y", "%d-%m-%Y", "%m-%d-%Y",
        "%B %d, %Y", "%B %d %Y", "%b %d, %Y", "%b %d %Y",
        "%d %B %Y", "%d %b %Y",
    )
    normalized = []
    for _, item in found:
        item = re.sub(r"(?<=\d)(st|nd|rd|th)\b", "", item, flags=re.I)
        item = re.sub(r"\s+", " ", item).strip()
        item = item.replace(",", "")
        parsed = None
        for fmt in formats:
            try:
                parsed = datetime.strptime(item, fmt)
                break
            except ValueError:
                pass
        if parsed:
            normalized.append(parsed.strftime("%Y-%m-%d"))
    return normalized


def equivalent(a: Any, b: Any, mode: str = "text") -> bool:
    # Always check normalized text first. Equal text values such as NA and
    # In creation unit size must pass even in numeric fields.
    left_text = norm(a)
    right_text = norm(b)
    if left_text == right_text and left_text:
        return True

    if mode in {"numbers", "money"}:
        left_numbers = canonical_numbers(a)
        right_numbers = canonical_numbers(b)
        return bool(left_numbers) and left_numbers == right_numbers

    if mode == "list":
        left_items = normalized_list(a)
        right_items = normalized_list(b)
        return bool(left_items) and left_items == right_items

    if mode == "date_list":
        left_dates = extracted_dates(a)
        right_dates = extracted_dates(b)
        return bool(left_dates) and left_dates == right_dates

    return left_text == right_text and bool(left_text)


def load_excel(path: str | Path) -> list[dict[str, Any]]:
    wb = load_workbook(path, data_only=True, read_only=True)
    if EXCEL_SHEET not in wb.sheetnames:
        raise ValueError(f"Sheet '{EXCEL_SHEET}' was not found.")
    ws = wb[EXCEL_SHEET]
    headers = {clean_text(c.value): c.column for c in ws[1] if c.value is not None}
    missing = [c for c in DISPLAY_COLUMNS.values() if c not in headers]
    if missing: raise ValueError(f"Missing Excel columns: {missing}")
    rows=[]
    for r in range(2, ws.max_row+1):
        item={"_excel_row": r}
        for label,colname in DISPLAY_COLUMNS.items():
            item[label]=ws.cell(r,headers[colname]).value
        if clean_text(item["Fund Name"]): rows.append(item)
    return rows


def iter_shapes(shapes: Iterable[Any]):
    for shape in shapes:
        yield shape
        if shape.shape_type == MSO_SHAPE_TYPE.GROUP:
            yield from iter_shapes(shape.shapes)


def shape_text(shape: Any) -> str:
    parts=[]
    if getattr(shape, "has_text_frame", False): parts.append(shape.text)
    if getattr(shape, "has_table", False):
        for row in shape.table.rows:
            parts.append("\n".join(clean_text(c.text) for c in row.cells))
    # Alternative text can contain generated HTML/lexical content.
    try:
        cNvPr = shape._element.xpath('.//p:cNvPr')[0]
        parts.extend([cNvPr.get('descr') or '', cNvPr.get('title') or ''])
    except Exception:
        pass
    return clean_text("\n".join(p for p in parts if p))


def shape_table_data(shape: Any) -> list[list[str]]:
    """Return PowerPoint table cells as rows and columns instead of flattened text."""
    if not getattr(shape, "has_table", False):
        return []
    return [
        [clean_text(cell.text) for cell in row.cells]
        for row in shape.table.rows
    ]


def get_slide_objects(ppt_paths: str | Path | Iterable[str | Path]) -> list[dict[str, Any]]:
    """Read one or multiple PPTX files into one searchable slide collection."""
    if isinstance(ppt_paths, (str, Path)):
        ppt_paths = [ppt_paths]
    ppt_paths = [Path(path) for path in ppt_paths]
    if not ppt_paths:
        raise ValueError("No PowerPoint files were selected.")

    output = []
    for ppt_path in ppt_paths:
        prs = Presentation(ppt_path)
        for sno, slide in enumerate(prs.slides, 1):
            objs = []
            for shape in iter_shapes(slide.shapes):
                objs.append({
                    "name": clean_text(getattr(shape, "name", "")),
                    "text": shape_text(shape),
                    "table_data": shape_table_data(shape),
                })
            output.append({
                "slide": sno,
                "ppt_file": ppt_path.name,
                "ppt_path": str(ppt_path),
                "objects": objs,
                "all_text": "\n".join(obj["text"] for obj in objs),
            })
    return output


def object_values(slide: dict[str,Any], target: str, prefix: bool=False) -> list[str]:
    vals=[]
    for o in slide["objects"]:
        name=o["name"]
        ok=name.casefold().startswith(target.casefold()) if prefix else name.casefold()==target.casefold()
        if ok and o["text"]: vals.append(o["text"])
    return vals


def find_fund_slide(slides, fund_name: str):
    # Highest priority: exact FundName object. Fallback: fund name anywhere on slide.
    for slide in slides:
        vals=object_values(slide,"FundName")
        if any(equivalent(fund_name,v) or norm(fund_name) in norm(v) for v in vals): return slide
    for slide in slides:
        if norm(fund_name) and norm(fund_name) in norm(slide["all_text"]): return slide
    return None


def canonical_fund_key(value: Any) -> str:
    """Normalize harmless scheme-name variations used between Excel and PowerPoint."""
    key = norm(value)
    replacements = (
        (r"\bmid\s+cap\b", "midcap"),
        (r"\blarge\s+cap\b", "largecap"),
        (r"\bsmall\s+cap\b", "smallcap"),
        (r"\bmulti\s+cap\b", "multicap"),
        (r"\bfof\b", "fund of fund"),
        (r"\bfund\s+of\s+funds\b", "fund of fund"),
        (r"\bnifty\s+50\b", "nifty50"),
        (r"\bnifty\s+100\b", "nifty100"),
        (r"\bnasdaq\s+100\b", "nasdaq100"),
    )
    for pattern, replacement in replacements:
        key = re.sub(pattern, replacement, key, flags=re.I)
    return re.sub(r"\s+", " ", key).strip()


def fund_names_equal(left: Any, right: Any) -> bool:
    return bool(canonical_fund_key(left)) and canonical_fund_key(left) == canonical_fund_key(right)


def text_has_exact_fund(text: Any, fund_name: str, all_fund_names: list[str] | None = None) -> bool:
    """Detect a distinct fund-name row/heading, allowing Mid Cap vs Midcap spacing."""
    source = clean_text(text)
    wanted = canonical_fund_key(fund_name)
    if not source or not wanted:
        return False

    for line in [clean_text(x) for x in source.splitlines() if clean_text(x)]:
        if canonical_fund_key(line) == wanted:
            return True

    # Structured tables can be flattened with adjacent cell content. Match the
    # canonical fund phrase only when bounded by a start/end or known fund heading.
    if all_fund_names:
        source_key = canonical_fund_key(source)
        candidates = sorted(
            {canonical_fund_key(name) for name in all_fund_names if canonical_fund_key(name)},
            key=len,
            reverse=True,
        )
        if wanted in candidates:
            return bool(re.search(r"(?:^|\s)" + re.escape(wanted) + r"(?=\s|$)", source_key))
    return False


def slide_has_exact_fundname(slide: dict[str, Any], fund_name: str) -> bool:
    """Bind a slide through a FundName object, allowing harmless spacing variants."""
    for value in object_values(slide, "FundName"):
        cleaned = strip_object_heading(value, ["Fund Name"])
        if fund_names_equal(cleaned, fund_name):
            return True
    return False


def find_object_for_fund(
    slides,
    target: str,
    fund_name: str,
    prefix: bool = False,
    all_fund_names: list[str] | None = None,
):
    """Find a named object for the exact fund without borrowing another fund's data.

    Standard objects are accepted only from a slide whose FundName object exactly
    equals the Excel fund name. Multi-fund objects such as FundBox* and
    MinimumSIPAmount may instead contain the exact fund heading inside the object.
    """
    candidates = []
    multi_fund_object = prefix or target.casefold() in {"minimumsipamount", "eetable"}

    for slide in slides:
        exact_slide_fund = slide_has_exact_fundname(slide, fund_name)
        for obj in slide["objects"]:
            object_name = clean_text(obj.get("name", ""))
            matched = (
                object_name.casefold().startswith(target.casefold())
                if prefix else object_name.casefold() == target.casefold()
            )
            if not matched:
                continue

            object_text = clean_text(obj.get("text", ""))
            exact_object_fund = text_has_exact_fund(object_text, fund_name, all_fund_names)

            if target.casefold() == "fundname":
                cleaned = strip_object_heading(object_text, ["Fund Name"])
                if not fund_names_equal(cleaned, fund_name):
                    continue
                score = 400
                reason = "Exact FundName object matched the Excel fund name"
            elif exact_slide_fund:
                score = 350
                reason = "Object found on slide with exact FundName match"
            elif multi_fund_object and exact_object_fund:
                score = 300
                reason = "Exact fund heading found inside multi-fund object"
            else:
                continue

            candidates.append({
                "score": score,
                "slide": slide,
                "object": obj,
                "text": object_text,
                "reason": reason,
            })

    if not candidates:
        return None
    candidates.sort(key=lambda item: (-item["score"], item["slide"]["slide"]))
    return candidates[0]


def extract_fund_section(text: Any, fund_name: str, all_fund_names: list[str]) -> str:
    """Return only the exact fund block from a multi-fund object.

    A section starts only on a distinct fund-name heading. A mention such as
    "investing in Axis Gold ETF" is not treated as the Axis Gold ETF section.
    """
    source = clean_text(text)
    if not source:
        return ""
    lines = [clean_text(line) for line in source.splitlines() if clean_text(line)]
    fund_norm = norm(fund_name)
    known_funds = {norm(name) for name in all_fund_names if norm(name)}

    start = None
    for i, line in enumerate(lines):
        line_norm = norm(line)
        if fund_names_equal(line, fund_name):
            start = i
            break
        # Permit a heading with a category in parentheses immediately after the name.
        if line_norm.startswith(fund_norm + " "):
            remainder = line_norm[len(fund_norm):].strip()
            if remainder.startswith(("an open", "a fund", "an index", "fund type", "type of scheme")):
                start = i
                break
    if start is None:
        return ""

    end = len(lines)
    for i in range(start + 1, len(lines)):
        if canonical_fund_key(lines[i]) in {canonical_fund_key(x) for x in all_fund_names} and not fund_names_equal(lines[i], fund_name):
            end = i
            break
    return clean_text("\n".join(lines[start:end]))


def extract_product_label(section: Any) -> str:
    """Extract the two product-label statements from a fund-specific FundBox section."""
    source = clean_text(section)
    lines = [clean_text(line) for line in source.splitlines() if clean_text(line)]
    if not lines:
        return ""

    start = None
    for i, line in enumerate(lines):
        if "product is suitable for investors who are seeking" in norm(line):
            start = i + 1
            break
        if norm(line) in {"product label", "product labeling", "product labelling"}:
            start = i + 1
            break
    if start is None:
        return ""

    collected = []
    stop_phrases = (
        "investors should consult their financial advisers",
        "riskometer", "scheme riskometer", "benchmark riskometer",
    )
    for line in lines[start:]:
        line_norm = norm(line)
        if any(phrase in line_norm for phrase in stop_phrases):
            break
        collected.append(line)
    return clean_text("\n".join(collected))


def extract_amount_after_label(section: Any, label_kind: str) -> str:
    """Extract SIP or investment amount from a fund-specific MinimumSIPAmount section."""
    source = clean_text(section)
    lines = [clean_text(line) for line in source.splitlines() if clean_text(line)]
    if label_kind == "sip":
        keys = ("minimum sip amount", "sip amount")
    else:
        keys = ("minimum investment amount", "minimum investment", "lumpsum")

    special = re.compile(r"^(?:NA|N/A|Not Applicable|In creation unit size)$", re.I)
    amount = re.compile(r"(?:₹|Rs\.?|INR)?\s*([0-9][0-9,]*(?:\.[0-9]+)?)", re.I)

    for i, line in enumerate(lines):
        line_norm = norm(line)
        if not any(key in line_norm for key in keys):
            continue

        # Check remainder on the same line after the label wording.
        remainder = line
        for key in keys:
            remainder = re.sub(re.escape(key), " ", remainder, flags=re.I)
        remainder = clean_text(remainder.strip(" :-/"))
        if special.match(remainder):
            return remainder
        match = amount.search(remainder)
        if match:
            return match.group(1)

        # Scan following cells/lines until another minimum-field label or fund begins.
        for next_line in lines[i + 1:i + 8]:
            next_norm = norm(next_line)
            if label_kind == "sip" and "minimum investment" in next_norm:
                break
            if label_kind == "investment" and "minimum sip" in next_norm:
                break
            cleaned = clean_text(next_line.strip(" :-/"))
            if special.match(cleaned):
                return cleaned
            match = amount.search(cleaned)
            if match:
                return match.group(1)
    return ""


def first_amount_component(value: Any) -> str:
    """Convert table values such as 100/1 or 500/1 to the comparable amount 100 or 500."""
    text = clean_text(value)
    if not text:
        return ""
    special_patterns = (
        r"\bIn\s+creation\s+unit\s+size\b",
        r"\bNot\s+Applicable\b",
        r"\bN/?A\b",
    )
    for pattern in special_patterns:
        match = re.search(pattern, text, flags=re.I)
        if match:
            return clean_text(match.group(0))
    numbers = digits(text)
    return numbers[0] if numbers else text


def find_header_index(headers: list[str], kind: str) -> int | None:
    normalized = [norm(header) for header in headers]
    for index, header in enumerate(normalized):
        if kind == "sip":
            if "minimum sip" in header and "monthly" in header:
                return index
        elif kind == "investment":
            if "minimum investment" in header and "additional" not in header:
                return index
    # Fallback if Monthly is omitted from the SIP header.
    if kind == "sip":
        for index, header in enumerate(normalized):
            if "minimum sip" in header:
                return index
    return None


def extract_minimum_from_table(
    table_data: list[list[str]],
    fund_name: str,
    kind: str,
) -> str:
    """Read fixed columns from the MinimumSIPAmount PowerPoint table.

    Visual table positions are fixed:
    - Column 1: Fund Name
    - Column 2: Minimum Investment Amount
    - Column 4: Minimum SIP Amount (Monthly)
    """
    if not table_data:
        return ""

    fund_key = norm(fund_name)
    fund_column = 0
    value_column = 3 if kind == "sip" else 1

    # Allow title rows above the actual header. Start after the row containing Fund Name.
    data_start = 1
    for row_index, row in enumerate(table_data):
        if row and norm(row[0]) in {"fund name", "fundname", "scheme name"}:
            data_start = row_index + 1
            break

    for row in table_data[data_start:]:
        if len(row) <= max(fund_column, value_column):
            continue
        if not fund_names_equal(row[fund_column], fund_name):
            continue
        return first_amount_component(row[value_column])
    return ""


def labelled_value(text: str, labels: list[str]) -> str:
    s=clean_text(text)
    # Capture after a label until the next likely label/line. Also supports table lines.
    for label in labels:
        pat=re.compile(re.escape(label)+r"\s*[:\-]?\s*(.*?)(?=\n|$)",re.I)
        m=pat.search(s)
        if m and clean_text(m.group(1)): return clean_text(m.group(1))
    lines=[clean_text(x) for x in s.splitlines() if clean_text(x)]
    for i,line in enumerate(lines):
        if any(norm(label) in norm(line) for label in labels):
            remainder=line
            for label in labels: remainder=re.sub(re.escape(label),"",remainder,flags=re.I)
            remainder=clean_text(remainder.strip(" :-"))
            if remainder: return remainder
            if i+1<len(lines): return lines[i+1]
    return ""


def extract_fund_manager_data(text: Any) -> tuple[str, str, str]:
    """Extract manager names, managing-since dates, and experience from FundManager."""
    source = clean_text(text)
    lines = [clean_text(line) for line in source.splitlines() if clean_text(line)]

    # Manager names appear before the first Work experience block.
    name_lines = []
    for line in lines:
        if re.search(r"\bWork\s*experience\b", line, flags=re.I):
            break
        if re.search(r"\b(?:Fund Manager|Managing Since|Total Experience)\b", line, flags=re.I):
            continue
        if line.startswith("(") and name_lines:
            name_lines[-1] = clean_text(name_lines[-1] + " " + line)
        else:
            name_lines.append(line)

    # Remove headings that may be stored in the same object.
    name_lines = [
        re.sub(r"^Fund\s*Manager(?:\s*Names?)?\s*[:\-]?\s*", "", line, flags=re.I).strip()
        for line in name_lines
    ]
    name_lines = [remove_temporary_manager_annotations(line) for line in name_lines if line]
    name_lines = [line for line in name_lines if line]

    # Each Work experience statement contributes one experience number.
    experiences = re.findall(
        r"Work\s*experience\s*[:\-]?\s*(\d+(?:\.\d+)?)\s*years?",
        source,
        flags=re.I,
    )

    # Managing-since dates may use numeric dates or ordinal month dates.
    dates = extracted_dates(source)

    return "#".join(name_lines), "#".join(dates), "#".join(experiences)


def strip_object_heading(text: Any, headings: list[str]) -> str:
    """Remove object headings such as BENCHMARK while preserving the actual value."""
    value = clean_text(text)
    lines = [clean_text(line) for line in value.splitlines() if clean_text(line)]
    heading_norms = {norm(item) for item in headings}
    kept = [line for line in lines if norm(line) not in heading_norms]
    return clean_text("\n".join(kept))


def extract_exit_load_from_table(table_data: list[list[str]], fund_name: str) -> str:
    """Read Exit Load from the exact fund row of a multi-fund EETable."""
    if not table_data:
        return ""

    header_row_index = None
    fund_column = 0
    exit_column = None
    for row_index, row in enumerate(table_data):
        normalized = [norm(cell) for cell in row]
        for column_index, cell in enumerate(normalized):
            if cell in {"fund name", "fundname", "scheme name"}:
                fund_column = column_index
                header_row_index = row_index
            if "exit load" in cell:
                exit_column = column_index
        if header_row_index is not None and exit_column is not None:
            break

    if header_row_index is None:
        header_row_index = 0
    if exit_column is None:
        # Common EETable layout: Fund Name, Entry Load, Exit Load.
        widest = max((len(row) for row in table_data), default=0)
        if widest >= 3:
            exit_column = 2
        elif widest >= 2:
            exit_column = 1
        else:
            return ""

    for row in table_data[header_row_index + 1:]:
        if len(row) <= max(fund_column, exit_column):
            continue
        if fund_names_equal(row[fund_column], fund_name):
            return clean_text(row[exit_column])
    return ""


def extract_exit_load(text: Any) -> str:
    """Extract the complete Exit Load section from EETable without truncating lines."""
    source = clean_text(text)
    lines = [clean_text(line) for line in source.splitlines() if clean_text(line)]
    if not lines:
        return ""

    start_index = None
    collected = []
    stop_headings = {
        "entry load", "expense ratio", "minimum application amount",
        "minimum sip amount", "minimum investment", "load structure",
    }

    for index, line in enumerate(lines):
        normalized = norm(line)
        if "exit load" in normalized:
            start_index = index
            remainder = re.sub(r"^.*?Exit\s*Load\s*[:\-]?\s*", "", line, flags=re.I).strip()
            if remainder:
                collected.append(remainder)
            break

    if start_index is None:
        # Some EETable objects contain only the Exit Load value and no heading.
        return source

    for line in lines[start_index + 1:]:
        normalized = norm(line)
        if normalized in stop_headings:
            break
        if any(normalized.startswith(heading + " ") for heading in stop_headings):
            break
        collected.append(line)

    return clean_text("\n".join(collected))


def compare(excel_path: str|Path, ppt_paths: str | Path | Iterable[str | Path]) -> list[AuditRow]:
    rows = load_excel(excel_path)
    slides = get_slide_objects(ppt_paths)
    audit = []
    all_fund_names = [clean_text(item.get("Fund Name", "")) for item in rows]

    for row in rows:
        fund = clean_text(row["Fund Name"])

        def add(field, ppt_value, slide_number=None, mode="text", remark="", ppt_file=""):
            excel_value = clean_text(row.get(field, ""))
            ppt_value = clean_text(ppt_value)
            if ppt_file:
                remark = f"PPT: {ppt_file} | {remark}" if remark else f"PPT: {ppt_file}"
            if not ppt_value:
                status = "MISSING IN PPT"
            elif equivalent(excel_value, ppt_value, mode):
                status = "PASS"
            else:
                status = "MISMATCH"
            audit.append(AuditRow(
                fund,
                row["_excel_row"],
                slide_number,
                field,
                PPT_OBJECTS[field],
                excel_value,
                ppt_value,
                status,
                remark,
            ))

        # Each field independently searches every slide. The fund's first slide is
        # not assumed to contain all named objects.
        fund_result = find_object_for_fund(slides, "FundName", fund, all_fund_names=all_fund_names)
        if fund_result:
            fund_value = strip_object_heading(fund_result["text"], ["Fund Name"])
            add("Fund Name", fund_value, fund_result["slide"]["slide"], remark=fund_result["reason"], ppt_file=fund_result["slide"].get("ppt_file", ""))
        else:
            add("Fund Name", "", None, remark="FundName object for this fund was not found on any slide")

        type_result = find_object_for_fund(slides, "FundType", fund, all_fund_names=all_fund_names)
        if type_result:
            value = strip_object_heading(type_result["text"], ["Fund Type", "Type of Scheme"])
            add("Fund Type", value, type_result["slide"]["slide"], remark=type_result["reason"], ppt_file=type_result["slide"].get("ppt_file", ""))
        else:
            add("Fund Type", "", None, remark="FundType object for this fund was not found on any slide")

        manager_result = find_object_for_fund(slides, "FundManager", fund, all_fund_names=all_fund_names)
        if manager_result:
            names, dates, experience = extract_fund_manager_data(manager_result["text"])
            slide_number = manager_result["slide"]["slide"]
            add("Fund Manager", names, slide_number, "list", "Extracted manager names from fund-specific FundManager object", manager_result["slide"].get("ppt_file", ""))
            add("Managing Since", dates, slide_number, "date_list", "Extracted dates from fund-specific FundManager object", manager_result["slide"].get("ppt_file", ""))
            add("Fundman Total Experience", experience, slide_number, "numbers", "Extracted Work experience values from fund-specific FundManager object", manager_result["slide"].get("ppt_file", ""))
        else:
            add("Fund Manager", "", None, "list", "FundManager object for this fund was not found on any slide")
            add("Managing Since", "", None, "date_list", "FundManager object for this fund was not found on any slide")
            add("Fundman Total Experience", "", None, "numbers", "FundManager object for this fund was not found on any slide")

        benchmark_result = find_object_for_fund(slides, "Benchmark", fund, all_fund_names=all_fund_names)
        if benchmark_result:
            value = strip_object_heading(benchmark_result["text"], ["Benchmark", "Benchmark Name"])
            add("Display Benchmark", value, benchmark_result["slide"]["slide"], remark=benchmark_result["reason"], ppt_file=benchmark_result["slide"].get("ppt_file", ""))
        else:
            add("Display Benchmark", "", None, remark="Benchmark object for this fund was not found on any slide")

        exit_result = find_object_for_fund(slides, "EETable", fund, all_fund_names=all_fund_names)
        if exit_result:
            table_data = exit_result["object"].get("table_data", [])
            value = extract_exit_load_from_table(table_data, fund)
            if not value:
                section = extract_fund_section(exit_result["text"], fund, all_fund_names)
                value = extract_exit_load(section or exit_result["text"])
            add("Load Structure", value, exit_result["slide"]["slide"], remark="Exit Load read from exact fund row in EETable", ppt_file=exit_result["slide"].get("ppt_file", ""))
        else:
            add("Load Structure", "", None, remark="EETable object containing this fund row was not found in selected PPT files")

        doa_result = find_object_for_fund(slides, "DOA", fund, all_fund_names=all_fund_names)
        if doa_result:
            value = "#".join(extracted_dates(doa_result["text"]))
            add("Date of Inception", value, doa_result["slide"]["slide"], "date_list", "Date extracted from fund-specific DOA object", doa_result["slide"].get("ppt_file", ""))
        else:
            add("Date of Inception", "", None, "date_list", "DOA object for this fund was not found on any slide")

        product_result = find_object_for_fund(slides, "FundBox", fund, prefix=True, all_fund_names=all_fund_names)
        if product_result:
            section = extract_fund_section(product_result["text"], fund, all_fund_names)
            value = extract_product_label(section)
            # If the exact Excel product label occurs inside the correct fund section,
            # report that matching text. This handles line wrapping without false mismatches.
            if norm(row.get("Product Label", "")) in norm(section):
                value = clean_text(row.get("Product Label", ""))
            add("Product Label", value, product_result["slide"]["slide"], remark="Fund-specific section extracted from FundBox object", ppt_file=product_result["slide"].get("ppt_file", ""))
        else:
            add("Product Label", "", None, remark="No FundBox* object associated with this fund was found on any slide")

        minimum_result = find_object_for_fund(slides, "MinimumSIPAmount", fund, all_fund_names=all_fund_names)
        if minimum_result:
            table_data = minimum_result["object"].get("table_data", [])
            sip = extract_minimum_from_table(table_data, fund, "sip")
            investment = extract_minimum_from_table(table_data, fund, "investment")

            # Fallback for non-table objects or unusual layouts.
            if not sip or not investment:
                section = extract_fund_section(minimum_result["text"], fund, all_fund_names)
                if not sip:
                    sip = extract_amount_after_label(section, "sip")
                if not investment:
                    investment = extract_amount_after_label(section, "investment")

            slide_number = minimum_result["slide"]["slide"]
            add("Minimum SIP Amount", sip, slide_number, "money", "Value read from exact fund row and Minimum SIP column in MinimumSIPAmount table", minimum_result["slide"].get("ppt_file", ""))
            add("Minimum Investment", investment, slide_number, "money", "Value read from exact fund row and Minimum Investment column in MinimumSIPAmount table", minimum_result["slide"].get("ppt_file", ""))
        else:
            add("Minimum SIP Amount", "", None, "money", "MinimumSIPAmount object for this fund was not found on any slide")
            add("Minimum Investment", "", None, "money", "MinimumSIPAmount object for this fund was not found on any slide")

    return audit


def export_audit(audit: list[AuditRow], out_path: str|Path):
    wb=Workbook(); ws=wb.active; ws.title="Audit Summary"
    headers=list(asdict(audit[0]).keys()) if audit else ["fund_name","excel_row","slide_number","field","object_name","excel_value","ppt_value","status","remarks"]
    pretty=[h.replace("_"," ").title() for h in headers]
    ws.append(pretty)
    for x in audit: ws.append(list(asdict(x).values()))
    _style(ws)
    byfund={}
    for x in audit: byfund.setdefault(x.fund_name,[]).append(x)
    used={"Audit Summary"}
    for fund,items in byfund.items():
        title=safe_sheet_name(fund,used); used.add(title); sh=wb.create_sheet(title); sh.append(pretty)
        for x in items: sh.append(list(asdict(x).values()))
        _style(sh)
    wb.save(out_path)


def safe_sheet_name(name,used):
    s=re.sub(r'[\\/*?:\[\]]',' ',clean_text(name))[:31] or 'Fund'
    base=s; i=2
    while s in used:
        suffix=f"_{i}"; s=base[:31-len(suffix)]+suffix; i+=1
    return s


def _style(ws):
    fill=PatternFill('solid',fgColor='1F4E78'); white=Font(color='FFFFFF',bold=True)
    for c in ws[1]: c.fill=fill; c.font=white; c.alignment=Alignment(horizontal='center')
    ws.freeze_panes='A2'; ws.auto_filter.ref=ws.dimensions
    status_col=None
    for c in ws[1]:
        if c.value=='Status': status_col=c.column
    for row in ws.iter_rows(min_row=2):
        if status_col:
            cell=row[status_col-1]
            color={'PASS':'C6EFCE','MISMATCH':'FFC7CE','MISSING IN PPT':'FFEB9C','MISSING SLIDE':'F4B084'}.get(cell.value)
            if color: cell.fill=PatternFill('solid',fgColor=color)
        for c in row: c.alignment=Alignment(vertical='top',wrap_text=True)
    for col in range(1,ws.max_column+1):
        maxlen=max(len(clean_text(ws.cell(r,col).value)) for r in range(1,min(ws.max_row,100)+1))
        ws.column_dimensions[get_column_letter(col)].width=min(max(maxlen+2,12),55)

# PyQt6 GUI
import sys
import pandas as pd
from PyQt6.QtCore import Qt, QThread, pyqtSignal
from PyQt6.QtGui import QAction, QColor, QFont, QIcon, QKeySequence
from PyQt6.QtWidgets import (
    QApplication, QAbstractItemView, QFileDialog, QFrame, QHBoxLayout,
    QHeaderView, QLabel, QMainWindow, QMessageBox, QProgressBar, QPushButton,
    QSizePolicy, QSpacerItem, QSplitter, QStatusBar, QTabWidget, QTableWidget,
    QTableWidgetItem, QToolBar, QVBoxLayout, QWidget
)


APP_STYLE = """
QMainWindow, QWidget {
    background-color: #F4F7FB;
    color: #172033;
    font-family: "Segoe UI";
    font-size: 10pt;
}
QToolBar {
    background: #FFFFFF;
    border: none;
    border-bottom: 1px solid #DCE3ED;
    spacing: 6px;
    padding: 6px 10px;
}
QFrame#heroCard, QFrame#contentCard, QFrame#metricCard {
    background: #FFFFFF;
    border: 1px solid #DCE3ED;
    border-radius: 10px;
}
QLabel#appTitle {
    color: #12345B;
    font-size: 20pt;
    font-weight: 700;
}
QLabel#appSubtitle {
    color: #607089;
    font-size: 10pt;
}
QLabel#sectionTitle {
    color: #183B66;
    font-size: 12pt;
    font-weight: 700;
}
QLabel#fileValue {
    color: #253858;
    background: #F7F9FC;
    border: 1px solid #DDE5EF;
    border-radius: 6px;
    padding: 8px 10px;
}
QLabel#metricTitle {
    color: #6B778C;
    font-size: 9pt;
    font-weight: 600;
}
QLabel#metricValue {
    color: #12345B;
    font-size: 18pt;
    font-weight: 700;
}
QPushButton {
    min-height: 34px;
    padding: 0 16px;
    border-radius: 6px;
    border: 1px solid #CBD5E1;
    background: #FFFFFF;
    color: #24364B;
    font-weight: 600;
}
QPushButton:hover {
    background: #F0F5FA;
    border-color: #9FB2C8;
}
QPushButton:pressed {
    background: #E4ECF5;
}
QPushButton#primaryButton {
    color: #FFFFFF;
    background: #1769AA;
    border-color: #1769AA;
}
QPushButton#primaryButton:hover {
    background: #125A92;
}
QPushButton#successButton {
    color: #FFFFFF;
    background: #16845B;
    border-color: #16845B;
}
QPushButton#successButton:hover {
    background: #106C4A;
}
QPushButton:disabled {
    color: #98A4B3;
    background: #E9EEF4;
    border-color: #D7DEE7;
}
QTabWidget::pane {
    background: #FFFFFF;
    border: 1px solid #DCE3ED;
    border-radius: 8px;
    top: -1px;
}
QTabBar::tab {
    background: #EAF0F7;
    color: #516179;
    padding: 10px 18px;
    margin-right: 3px;
    border-top-left-radius: 6px;
    border-top-right-radius: 6px;
    font-weight: 600;
}
QTabBar::tab:selected {
    background: #FFFFFF;
    color: #1769AA;
    border: 1px solid #DCE3ED;
    border-bottom-color: #FFFFFF;
}
QTableWidget {
    background: #FFFFFF;
    alternate-background-color: #F7F9FC;
    gridline-color: #E5EAF1;
    border: none;
    selection-background-color: #DCEEFF;
    selection-color: #172033;
}
QHeaderView::section {
    background: #183B66;
    color: #FFFFFF;
    border: none;
    border-right: 1px solid #36577D;
    padding: 8px;
    font-weight: 700;
}
QProgressBar {
    border: 1px solid #CFD8E3;
    border-radius: 5px;
    background: #EDF2F7;
    height: 10px;
    text-align: center;
}
QProgressBar::chunk {
    background: #1769AA;
    border-radius: 4px;
}
QStatusBar {
    background: #FFFFFF;
    color: #526277;
    border-top: 1px solid #DCE3ED;
}
"""


class QCWorker(QThread):
    completed = pyqtSignal(object)
    failed = pyqtSignal(str)

    def __init__(self, excel_path, ppt_paths):
        super().__init__()
        self.excel_path = excel_path
        self.ppt_paths = list(ppt_paths)

    def run(self):
        try:
            self.completed.emit(compare(self.excel_path, self.ppt_paths))
        except Exception as exc:
            self.failed.emit(str(exc))


class MetricCard(QFrame):
    def __init__(self, title, accent='#1769AA'):
        super().__init__()
        self.setObjectName('metricCard')
        self.setMinimumWidth(150)
        layout = QVBoxLayout(self)
        layout.setContentsMargins(14, 10, 14, 10)
        layout.setSpacing(2)
        title_label = QLabel(title)
        title_label.setObjectName('metricTitle')
        self.value_label = QLabel('0')
        self.value_label.setObjectName('metricValue')
        self.value_label.setStyleSheet(f'color: {accent};')
        layout.addWidget(title_label)
        layout.addWidget(self.value_label)

    def set_value(self, value):
        self.value_label.setText(str(value))


class Window(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle('Uploader Excel to PowerPoint QC')
        self.resize(1480, 880)
        self.setMinimumSize(1100, 700)

        self.excel = None
        self.ppts = []
        self.audit = None
        self.worker = None

        self._build_actions()
        self._build_toolbar()
        self._build_ui()
        self._build_status_bar()
        self._update_action_state()

    def _build_actions(self):
        self.action_excel = QAction('Open Excel', self)
        self.action_excel.setShortcut(QKeySequence('Ctrl+O'))
        self.action_excel.triggered.connect(self.load_excel)

        self.action_ppt = QAction('Open PowerPoints', self)
        self.action_ppt.setShortcut(QKeySequence('Ctrl+Shift+O'))
        self.action_ppt.triggered.connect(self.load_ppt)

        self.action_run = QAction('Run QC', self)
        self.action_run.setShortcut(QKeySequence('F5'))
        self.action_run.triggered.connect(self.run_qc)

        self.action_export = QAction('Export Audit', self)
        self.action_export.setShortcut(QKeySequence('Ctrl+S'))
        self.action_export.triggered.connect(self.export)

        self.action_exit = QAction('Exit', self)
        self.action_exit.setShortcut(QKeySequence.StandardKey.Quit)
        self.action_exit.triggered.connect(self.close)

    def _build_toolbar(self):
        toolbar = QToolBar('Main actions')
        toolbar.setMovable(False)
        toolbar.addAction(self.action_excel)
        toolbar.addAction(self.action_ppt)
        toolbar.addSeparator()
        toolbar.addAction(self.action_run)
        toolbar.addAction(self.action_export)
        toolbar.addSeparator()
        toolbar.addAction(self.action_exit)
        self.addToolBar(toolbar)

    def _build_ui(self):
        root = QWidget()
        self.setCentralWidget(root)
        main_layout = QVBoxLayout(root)
        main_layout.setContentsMargins(18, 16, 18, 14)
        main_layout.setSpacing(12)

        hero = QFrame()
        hero.setObjectName('heroCard')
        hero_layout = QHBoxLayout(hero)
        hero_layout.setContentsMargins(20, 16, 20, 16)
        title_box = QVBoxLayout()
        title = QLabel('Uploader Excel to PowerPoint QC')
        title.setObjectName('appTitle')
        subtitle = QLabel(
            'Compare uploader values with named PowerPoint objects and produce a fund-wise audit workbook.'
        )
        subtitle.setObjectName('appSubtitle')
        subtitle.setWordWrap(True)
        title_box.addWidget(title)
        title_box.addWidget(subtitle)
        hero_layout.addLayout(title_box, 1)
        main_layout.addWidget(hero)

        selector_card = QFrame()
        selector_card.setObjectName('contentCard')
        selector_layout = QVBoxLayout(selector_card)
        selector_layout.setContentsMargins(16, 14, 16, 14)
        selector_layout.setSpacing(10)

        selector_title = QLabel('Input files')
        selector_title.setObjectName('sectionTitle')
        selector_layout.addWidget(selector_title)

        excel_row = QHBoxLayout()
        excel_label = QLabel('Uploader Excel')
        excel_label.setFixedWidth(125)
        self.excel_value = QLabel('No Excel file selected')
        self.excel_value.setObjectName('fileValue')
        self.excel_value.setTextInteractionFlags(Qt.TextInteractionFlag.TextSelectableByMouse)
        self.btn_excel = QPushButton('Browse Excel')
        self.btn_excel.clicked.connect(self.load_excel)
        excel_row.addWidget(excel_label)
        excel_row.addWidget(self.excel_value, 1)
        excel_row.addWidget(self.btn_excel)
        selector_layout.addLayout(excel_row)

        ppt_row = QHBoxLayout()
        ppt_label = QLabel('PowerPoint')
        ppt_label.setFixedWidth(125)
        self.ppt_value = QLabel('No PowerPoint files selected')
        self.ppt_value.setObjectName('fileValue')
        self.ppt_value.setTextInteractionFlags(Qt.TextInteractionFlag.TextSelectableByMouse)
        self.btn_ppt = QPushButton('Browse PPTX Files')
        self.btn_ppt.clicked.connect(self.load_ppt)
        ppt_row.addWidget(ppt_label)
        ppt_row.addWidget(self.ppt_value, 1)
        ppt_row.addWidget(self.btn_ppt)
        selector_layout.addLayout(ppt_row)

        action_row = QHBoxLayout()
        self.btn_run = QPushButton('Run QC')
        self.btn_run.setObjectName('primaryButton')
        self.btn_run.clicked.connect(self.run_qc)
        self.btn_export = QPushButton('Export Audit')
        self.btn_export.setObjectName('successButton')
        self.btn_export.clicked.connect(self.export)
        action_row.addStretch(1)
        action_row.addWidget(self.btn_run)
        action_row.addWidget(self.btn_export)
        selector_layout.addLayout(action_row)
        main_layout.addWidget(selector_card)

        metrics_row = QHBoxLayout()
        metrics_row.setSpacing(10)
        self.metric_funds = MetricCard('Funds', '#1769AA')
        self.metric_checks = MetricCard('Total checks', '#4C64D3')
        self.metric_pass = MetricCard('Pass', '#16845B')
        self.metric_mismatch = MetricCard('Mismatch', '#C43D4B')
        self.metric_missing = MetricCard('Missing', '#C87813')
        for card in (
            self.metric_funds, self.metric_checks, self.metric_pass,
            self.metric_mismatch, self.metric_missing
        ):
            metrics_row.addWidget(card)
        main_layout.addLayout(metrics_row)

        self.progress = QProgressBar()
        self.progress.setRange(0, 100)
        self.progress.setValue(0)
        self.progress.setTextVisible(False)
        self.progress.hide()
        main_layout.addWidget(self.progress)

        self.tabs = QTabWidget()
        self.excel_table = self._new_table()
        self.audit_table = self._new_table()
        self.issue_table = self._new_table()
        self.tabs.addTab(self.excel_table, 'Excel preview')
        self.tabs.addTab(self.audit_table, 'Full audit')
        self.tabs.addTab(self.issue_table, 'Issues only')
        main_layout.addWidget(self.tabs, 1)

    def _build_status_bar(self):
        status_bar = QStatusBar()
        self.setStatusBar(status_bar)
        self.status_label = QLabel('Ready. Select the uploader Excel file first.')
        status_bar.addWidget(self.status_label, 1)
        self.file_count_label = QLabel('')
        status_bar.addPermanentWidget(self.file_count_label)

    def _new_table(self):
        table = QTableWidget()
        table.setAlternatingRowColors(True)
        table.setSortingEnabled(True)
        table.setSelectionBehavior(QAbstractItemView.SelectionBehavior.SelectRows)
        table.setSelectionMode(QAbstractItemView.SelectionMode.ExtendedSelection)
        table.setEditTriggers(QAbstractItemView.EditTrigger.NoEditTriggers)
        table.setWordWrap(True)
        table.verticalHeader().setVisible(False)
        table.horizontalHeader().setStretchLastSection(True)
        table.horizontalHeader().setSectionResizeMode(QHeaderView.ResizeMode.Interactive)
        return table

    def _show_dataframe(self, table, dataframe, status_column=None):
        table.setSortingEnabled(False)
        table.clear()
        table.setRowCount(len(dataframe))
        table.setColumnCount(len(dataframe.columns))
        table.setHorizontalHeaderLabels([str(x) for x in dataframe.columns])

        status_colors = {
            'PASS': QColor('#C6EFCE'),
            'MISMATCH': QColor('#FFC7CE'),
            'MISSING IN PPT': QColor('#FFEB9C'),
            'MISSING SLIDE': QColor('#F4B084'),
        }

        for row_index, (_, row) in enumerate(dataframe.fillna('').iterrows()):
            for column_index, value in enumerate(row):
                item = QTableWidgetItem(str(value))
                item.setToolTip(str(value))
                item.setTextAlignment(Qt.AlignmentFlag.AlignLeft | Qt.AlignmentFlag.AlignVCenter)
                if status_column and dataframe.columns[column_index] == status_column:
                    color = status_colors.get(str(value))
                    if color:
                        item.setBackground(color)
                        item.setFont(QFont('Segoe UI', 9, QFont.Weight.DemiBold))
                table.setItem(row_index, column_index, item)

        table.resizeRowsToContents()
        for column in range(table.columnCount()):
            table.resizeColumnToContents(column)
            current = table.columnWidth(column)
            table.setColumnWidth(column, min(max(current, 110), 420))
        table.setSortingEnabled(True)

    def _update_action_state(self):
        can_run = bool(self.excel and self.ppts and not (self.worker and self.worker.isRunning()))
        can_export = bool(self.audit and not (self.worker and self.worker.isRunning()))
        self.btn_run.setEnabled(can_run)
        self.action_run.setEnabled(can_run)
        self.btn_export.setEnabled(can_export)
        self.action_export.setEnabled(can_export)

    def _set_busy(self, busy):
        self.btn_excel.setEnabled(not busy)
        self.btn_ppt.setEnabled(not busy)
        self.action_excel.setEnabled(not busy)
        self.action_ppt.setEnabled(not busy)
        if busy:
            self.progress.setRange(0, 0)
            self.progress.show()
        else:
            self.progress.setRange(0, 100)
            self.progress.setValue(100)
            self.progress.hide()
        self._update_action_state()

    def load_excel(self):
        path, _ = QFileDialog.getOpenFileName(
            self, 'Select uploader Excel', '', 'Excel workbooks (*.xlsx)'
        )
        if not path:
            return
        try:
            rows = load_excel(path)
            dataframe = pd.DataFrame([
                {key: value for key, value in row.items() if not key.startswith('_')}
                for row in rows
            ])
            self.excel = path
            self.audit = None
            self.excel_value.setText(path)
            self.excel_value.setToolTip(path)
            self._show_dataframe(self.excel_table, dataframe)
            self.metric_funds.set_value(len(dataframe))
            self.metric_checks.set_value(0)
            self.metric_pass.set_value(0)
            self.metric_mismatch.set_value(0)
            self.metric_missing.set_value(0)
            self.audit_table.clear()
            self.issue_table.clear()
            self.status_label.setText(f'Excel loaded successfully: {len(rows)} funds')
            self.file_count_label.setText(Path(path).name)
            self.tabs.setCurrentWidget(self.excel_table)
            self._update_action_state()
        except Exception as exc:
            QMessageBox.critical(self, 'Excel error', str(exc))

    def load_ppt(self):
        paths, _ = QFileDialog.getOpenFileNames(
            self,
            'Select one or multiple PowerPoint files',
            '',
            'PowerPoint presentations (*.pptx)'
        )
        if not paths:
            return
        self.ppts = paths
        self.audit = None
        names = [Path(path).name for path in paths]
        display_text = f"{len(paths)} PPTX file(s): " + "; ".join(names)
        self.ppt_value.setText(display_text)
        self.ppt_value.setToolTip("\n".join(paths))
        self.status_label.setText(
            f'{len(paths)} PowerPoint file(s) loaded. Click Run QC to start comparison.'
        )
        excel_name = Path(self.excel).name if self.excel else 'No Excel'
        self.file_count_label.setText(f'{excel_name} | {len(paths)} PPTX file(s)')
        self._update_action_state()

    def run_qc(self):
        if not self.excel or not self.ppts:
            QMessageBox.warning(self, 'Missing input', 'Select the uploader Excel and at least one PowerPoint file.')
            return
        self.status_label.setText('Running QC. Please wait...')
        self._set_busy(True)
        self.worker = QCWorker(self.excel, self.ppts)
        self.worker.completed.connect(self._qc_completed)
        self.worker.failed.connect(self._qc_failed)
        self.worker.start()

    def _qc_completed(self, audit):
        self.audit = audit
        dataframe = pd.DataFrame([item.__dict__ for item in audit])
        issues = dataframe[dataframe['status'] != 'PASS'].copy() if not dataframe.empty else dataframe
        self._show_dataframe(self.audit_table, dataframe, 'status')
        self._show_dataframe(self.issue_table, issues, 'status')

        status_counts = dataframe['status'].value_counts().to_dict() if not dataframe.empty else {}
        self.metric_checks.set_value(len(dataframe))
        self.metric_pass.set_value(status_counts.get('PASS', 0))
        self.metric_mismatch.set_value(status_counts.get('MISMATCH', 0))
        missing = status_counts.get('MISSING IN PPT', 0) + status_counts.get('MISSING SLIDE', 0)
        self.metric_missing.set_value(missing)
        self.metric_funds.set_value(dataframe['fund_name'].nunique() if not dataframe.empty else 0)

        self.status_label.setText(
            f'QC complete: {len(dataframe)} checks, {len(issues)} issue(s) requiring review'
        )
        self.tabs.setTabText(1, f'Full audit ({len(dataframe)})')
        self.tabs.setTabText(2, f'Issues only ({len(issues)})')
        self.tabs.setCurrentWidget(self.issue_table if len(issues) else self.audit_table)
        self._set_busy(False)

    def _qc_failed(self, message):
        self.audit = None
        self.status_label.setText('QC failed.')
        self._set_busy(False)
        QMessageBox.critical(self, 'QC error', message)

    def export(self):
        if not self.audit:
            QMessageBox.warning(self, 'No audit', 'Run QC before exporting the audit workbook.')
            return
        path, _ = QFileDialog.getSaveFileName(
            self, 'Save audit workbook', 'QC_Audit_Report.xlsx', 'Excel workbooks (*.xlsx)'
        )
        if not path:
            return
        if not path.lower().endswith('.xlsx'):
            path += '.xlsx'
        try:
            export_audit(self.audit, path)
            self.status_label.setText(f'Audit saved successfully: {path}')
            QMessageBox.information(self, 'Export complete', f'Audit workbook saved to:\n{path}')
        except Exception as exc:
            QMessageBox.critical(self, 'Export error', str(exc))

    def closeEvent(self, event):
        if self.worker and self.worker.isRunning():
            QMessageBox.information(self, 'QC running', 'Please wait for the QC process to finish before closing.')
            event.ignore()
            return
        event.accept()


if __name__ == '__main__':
    app = QApplication(sys.argv)
    app.setApplicationName('Uploader Excel to PowerPoint QC')
    app.setStyle('Fusion')
    app.setStyleSheet(APP_STYLE)
    window = Window()
    window.show()
    sys.exit(app.exec())
