import sys, tempfile
from pathlib import Path
import pandas as pd
from PyQt6.QtWidgets import QApplication,QMainWindow,QWidget,QVBoxLayout,QHBoxLayout,QPushButton,QLabel,QTableWidget,QTableWidgetItem,QFileDialog,QMessageBox
from qc_engine import load_excel,compare,export_audit

class Window(QMainWindow):
    def __init__(self):
        super().__init__(); self.setWindowTitle("Uploader vs PPT QC"); self.resize(1250,750)
        self.excel=None; self.ppt=None; self.audit=None
        root=QWidget(); self.setCentralWidget(root); layout=QVBoxLayout(root)
        top=QHBoxLayout(); layout.addLayout(top)
        for text,fn in [("Load Excel",self.load_excel),("Load PPTX",self.load_ppt),("Run QC",self.run_qc),("Export Audit",self.export)]:
            b=QPushButton(text); b.clicked.connect(fn); top.addWidget(b)
        self.status=QLabel("Load Excel first."); layout.addWidget(self.status)
        self.table=QTableWidget(); layout.addWidget(self.table)
    def show_df(self,df):
        self.table.setRowCount(len(df)); self.table.setColumnCount(len(df.columns)); self.table.setHorizontalHeaderLabels([str(x) for x in df.columns])
        for i,row in df.fillna('').iterrows():
            for j,v in enumerate(row): self.table.setItem(i,j,QTableWidgetItem(str(v)))
        self.table.resizeColumnsToContents()
    def load_excel(self):
        p,_=QFileDialog.getOpenFileName(self,"Select Excel","","Excel (*.xlsx)")
        if not p:return
        try:
            self.excel=p; rows=load_excel(p); self.show_df(pd.DataFrame([{k:v for k,v in r.items() if not k.startswith('_')} for r in rows])); self.status.setText(f"Excel loaded: {len(rows)} funds")
        except Exception as e: QMessageBox.critical(self,"Error",str(e))
    def load_ppt(self):
        p,_=QFileDialog.getOpenFileName(self,"Select PowerPoint","","PowerPoint (*.pptx)")
        if p:self.ppt=p; self.status.setText("PPTX loaded. Click Run QC.")
    def run_qc(self):
        if not self.excel or not self.ppt: QMessageBox.warning(self,"Missing input","Load Excel and PPTX first."); return
        try:
            self.audit=compare(self.excel,self.ppt); self.show_df(pd.DataFrame([a.__dict__ for a in self.audit])); self.status.setText(f"QC complete: {len(self.audit)} checks")
        except Exception as e: QMessageBox.critical(self,"Error",str(e))
    def export(self):
        if not self.audit: QMessageBox.warning(self,"No audit","Run QC first."); return
        p,_=QFileDialog.getSaveFileName(self,"Save audit","QC_Audit_Report.xlsx","Excel (*.xlsx)")
        if p:
            try: export_audit(self.audit,p); self.status.setText(f"Saved: {p}")
            except Exception as e: QMessageBox.critical(self,"Error",str(e))
if __name__=='__main__':
    app=QApplication(sys.argv); w=Window(); w.show(); sys.exit(app.exec())
