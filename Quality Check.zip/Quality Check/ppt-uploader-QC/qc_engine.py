from __future__ import annotations
import re, math, unicodedata
from dataclasses import dataclass, asdict
from pathlib import Path
from typing import Any, Iterable
from openpyxl import load_workbook, Workbook
from openpyxl.styles import Font, PatternFill, Alignment
from openpyxl.utils import get_column_letter
from pptx import Presentation
from pptx.enum.shapes import MSO_SHAPE_TYPE

EXCEL_SHEET = "Uploader"
DISPLAY_COLUMNS = {
    "Fund Name": "Factsheet Display Name",
    "Fund Type": "Fund Type",
    "Fund Manager": "Fund Manager",
    "Managing Since": "Managing Since",
    "Fundman Total Experience": "Fundman Total Experience",
    "Display Benchmark": "Display Benchmark",
    "Load Structure": "Load Structure",
    "Date of Inception": "Date of Inception",
    "Product Label": "Product Label",
    "Minimum SIP Amount": "Minimum SIP Amount",
    "Minimum Investment": "Minimum Investment",
}
PPT_OBJECTS = {
    "Fund Name": "FundName",
    "Fund Type": "FundType",
    "Fund Manager": "FundManager",
    "Fundman Total Experience": "FundManager",
    "Display Benchmark": "Benchmark",
    "Load Structure": "EETable",
    "Date of Inception": "DOA",
    "Product Label": "FundBox*",
    "Minimum SIP Amount": "MinimumSIPAmount",
    "Minimum Investment": "MinimumSIPAmount",
}
DEFERRED_FIELDS = ["Scheme Riskometer", "Benchmark Riskometer", "showDebtQuants"]

@dataclass
class AuditRow:
    fund_name: str
    excel_row: int
    slide_number: int | None
    field: str
    object_name: str
    excel_value: str
    ppt_value: str
    status: str
    remarks: str


def clean_text(v: Any) -> str:
    if v is None: return ""
    s = str(v).replace("\xa0", " ")
    s = unicodedata.normalize("NFKC", s)
    s = re.sub(r"<br\s*/?>", "\n", s, flags=re.I)
    s = re.sub(r"<[^>]+>", " ", s)
    s = s.replace("–", "-").replace("—", "-").replace("−", "-")
    s = re.sub(r"[ \t]+", " ", s)
    s = re.sub(r"\s*\n\s*", "\n", s)
    return s.strip()


def norm(v: Any) -> str:
    s = clean_text(v).casefold()
    s = re.sub(r"[^\w]+", " ", s, flags=re.UNICODE)
    return re.sub(r"\s+", " ", s).strip()


def digits(v: Any) -> list[str]:
    return re.findall(r"\d+(?:\.\d+)?", clean_text(v).replace(",", ""))


def money_numbers(v: Any) -> list[str]:
    return digits(v)


def equivalent(a: Any, b: Any, mode: str = "text") -> bool:
    if mode == "numbers":
        return digits(a) == digits(b) and bool(digits(a))
    if mode == "money":
        return money_numbers(a) == money_numbers(b) and bool(money_numbers(a))
    return norm(a) == norm(b) and bool(norm(a))


def load_excel(path: str | Path) -> list[dict[str, Any]]:
    wb = load_workbook(path, data_only=True, read_only=True)
    if EXCEL_SHEET not in wb.sheetnames:
        raise ValueError(f"Sheet '{EXCEL_SHEET}' was not found.")
    ws = wb[EXCEL_SHEET]
    headers = {clean_text(c.value): c.column for c in ws[1] if c.value is not None}
    missing = [c for c in DISPLAY_COLUMNS.values() if c not in headers]
    if missing: raise ValueError(f"Missing Excel columns: {missing}")
    rows=[]
    for r in range(2, ws.max_row+1):
        item={"_excel_row": r}
        for label,colname in DISPLAY_COLUMNS.items():
            item[label]=ws.cell(r,headers[colname]).value
        if clean_text(item["Fund Name"]): rows.append(item)
    return rows


def iter_shapes(shapes: Iterable[Any]):
    for shape in shapes:
        yield shape
        if shape.shape_type == MSO_SHAPE_TYPE.GROUP:
            yield from iter_shapes(shape.shapes)


def shape_text(shape: Any) -> str:
    parts=[]
    if getattr(shape, "has_text_frame", False): parts.append(shape.text)
    if getattr(shape, "has_table", False):
        for row in shape.table.rows:
            parts.append("\n".join(clean_text(c.text) for c in row.cells))
    # Alternative text can contain generated HTML/lexical content.
    try:
        cNvPr = shape._element.xpath('.//p:cNvPr')[0]
        parts.extend([cNvPr.get('descr') or '', cNvPr.get('title') or ''])
    except Exception:
        pass
    return clean_text("\n".join(p for p in parts if p))


def get_slide_objects(ppt_path: str | Path) -> list[dict[str, Any]]:
    prs=Presentation(ppt_path)
    output=[]
    for sno,slide in enumerate(prs.slides,1):
        objs=[]
        for shape in iter_shapes(slide.shapes):
            objs.append({"name": clean_text(getattr(shape,"name","")), "text": shape_text(shape)})
        output.append({"slide":sno,"objects":objs,"all_text":"\n".join(o["text"] for o in objs)})
    return output


def object_values(slide: dict[str,Any], target: str, prefix: bool=False) -> list[str]:
    vals=[]
    for o in slide["objects"]:
        name=o["name"]
        ok=name.casefold().startswith(target.casefold()) if prefix else name.casefold()==target.casefold()
        if ok and o["text"]: vals.append(o["text"])
    return vals


def find_fund_slide(slides, fund_name: str):
    # Highest priority: exact FundName object. Fallback: fund name anywhere on slide.
    for slide in slides:
        vals=object_values(slide,"FundName")
        if any(equivalent(fund_name,v) or norm(fund_name) in norm(v) for v in vals): return slide
    for slide in slides:
        if norm(fund_name) and norm(fund_name) in norm(slide["all_text"]): return slide
    return None


def labelled_value(text: str, labels: list[str]) -> str:
    s=clean_text(text)
    # Capture after a label until the next likely label/line. Also supports table lines.
    for label in labels:
        pat=re.compile(re.escape(label)+r"\s*[:\-]?\s*(.*?)(?=\n|$)",re.I)
        m=pat.search(s)
        if m and clean_text(m.group(1)): return clean_text(m.group(1))
    lines=[clean_text(x) for x in s.splitlines() if clean_text(x)]
    for i,line in enumerate(lines):
        if any(norm(label) in norm(line) for label in labels):
            remainder=line
            for label in labels: remainder=re.sub(re.escape(label),"",remainder,flags=re.I)
            remainder=clean_text(remainder.strip(" :-"))
            if remainder: return remainder
            if i+1<len(lines): return lines[i+1]
    return ""


def compare(excel_path: str|Path, ppt_path: str|Path) -> list[AuditRow]:
    rows=load_excel(excel_path); slides=get_slide_objects(ppt_path); audit=[]
    for row in rows:
        fund=clean_text(row["Fund Name"]); slide=find_fund_slide(slides,fund)
        if not slide:
            for field,obj in PPT_OBJECTS.items():
                audit.append(AuditRow(fund,row["_excel_row"],None,field,obj,clean_text(row.get(field,"")),"","MISSING SLIDE","Fund name not found in PPT"))
            continue
        sno=slide["slide"]
        def add(field,ppt_value,mode="text",remark=""):
            ev=clean_text(row.get(field,"")); pv=clean_text(ppt_value)
            if not pv: status="MISSING IN PPT"
            elif equivalent(ev,pv,mode): status="PASS"
            else: status="MISMATCH"
            audit.append(AuditRow(fund,row["_excel_row"],sno,field,PPT_OBJECTS[field],ev,pv,status,remark))

        add("Fund Name", "\n".join(object_values(slide,"FundName")))
        add("Fund Type", "\n".join(object_values(slide,"FundType")))
        fm="\n".join(object_values(slide,"FundManager"))
        add("Fund Manager", fm)
        add("Fundman Total Experience", fm, "numbers", "Only numeric values are compared")
        add("Display Benchmark", "\n".join(object_values(slide,"Benchmark")))
        ee="\n".join(object_values(slide,"EETable"))
        add("Load Structure", labelled_value(ee,["Exit Load"]) or ee, remark="Compared with Exit Load content in EETable")
        add("Date of Inception", "\n".join(object_values(slide,"DOA")))

        boxes=object_values(slide,"FundBox",prefix=True)
        box=next((x for x in boxes if norm(fund) in norm(x)), "")
        product=labelled_value(box,["Product Label","Investment Objective","Product Labelling"]) or box
        add("Product Label",product,remark="FundBox object selected by fund name")

        mins="\n".join(object_values(slide,"MinimumSIPAmount"))
        sip=labelled_value(mins,["Minimum SIP Amount/on Multiples of (₹) (Monthly)","Minimum SIP Amount/on Multiples of (Rs.) (Monthly)","Minimum SIP Amount"])
        inv=labelled_value(mins,["Minimum Investment Amount/in Multiples of (₹)","Minimum Investment Amount/in Multiples of (Rs.)","Minimum Investment Amount"])
        add("Minimum SIP Amount",sip,"money")
        add("Minimum Investment",inv,"money")
    return audit


def export_audit(audit: list[AuditRow], out_path: str|Path):
    wb=Workbook(); ws=wb.active; ws.title="Audit Summary"
    headers=list(asdict(audit[0]).keys()) if audit else ["fund_name","excel_row","slide_number","field","object_name","excel_value","ppt_value","status","remarks"]
    pretty=[h.replace("_"," ").title() for h in headers]
    ws.append(pretty)
    for x in audit: ws.append(list(asdict(x).values()))
    _style(ws)
    byfund={}
    for x in audit: byfund.setdefault(x.fund_name,[]).append(x)
    used={"Audit Summary"}
    for fund,items in byfund.items():
        title=safe_sheet_name(fund,used); used.add(title); sh=wb.create_sheet(title); sh.append(pretty)
        for x in items: sh.append(list(asdict(x).values()))
        _style(sh)
    wb.save(out_path)


def safe_sheet_name(name,used):
    s=re.sub(r'[\\/*?:\[\]]',' ',clean_text(name))[:31] or 'Fund'
    base=s; i=2
    while s in used:
        suffix=f"_{i}"; s=base[:31-len(suffix)]+suffix; i+=1
    return s


def _style(ws):
    fill=PatternFill('solid',fgColor='1F4E78'); white=Font(color='FFFFFF',bold=True)
    for c in ws[1]: c.fill=fill; c.font=white; c.alignment=Alignment(horizontal='center')
    ws.freeze_panes='A2'; ws.auto_filter.ref=ws.dimensions
    status_col=None
    for c in ws[1]:
        if c.value=='Status': status_col=c.column
    for row in ws.iter_rows(min_row=2):
        if status_col:
            cell=row[status_col-1]
            color={'PASS':'C6EFCE','MISMATCH':'FFC7CE','MISSING IN PPT':'FFEB9C','MISSING SLIDE':'F4B084'}.get(cell.value)
            if color: cell.fill=PatternFill('solid',fgColor=color)
        for c in row: c.alignment=Alignment(vertical='top',wrap_text=True)
    for col in range(1,ws.max_column+1):
        maxlen=max(len(clean_text(ws.cell(r,col).value)) for r in range(1,min(ws.max_row,100)+1))
        ws.column_dimensions[get_column_letter(col)].width=min(max(maxlen+2,12),55)
