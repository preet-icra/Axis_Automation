# Uploader Excel vs PowerPoint QC

## Files
- `qc_engine.py`: shared Excel/PPT extraction, comparison, and audit export logic
- `streamlit_app.py`: browser UI
- `pyqt_app.py`: desktop UI
- `requirements.txt`: dependencies

## Run Streamlit
```bash
pip install -r requirements.txt
streamlit run streamlit_app.py
```

## Run PyQt6
```bash
pip install -r requirements.txt
python pyqt_app.py
```

## Implemented mapping
- Fund Name -> `FundName`
- Fund Type -> `FundType`
- Fund Manager -> `FundManager`
- Fundman Total Experience -> numeric values inside `FundManager`
- Display Benchmark -> `Benchmark`
- Load Structure -> Exit Load content inside `EETable`
- Date of Inception -> `DOA`
- Product Label -> `FundBox1`, `FundBox2`, etc., selected by fund name
- Minimum SIP Amount -> labelled content inside `MinimumSIPAmount`
- Minimum Investment -> labelled content inside `MinimumSIPAmount`

Scheme Riskometer, Benchmark Riskometer, and showDebtQuants are deliberately deferred.

## Notes
The first version uses normalized exact comparison after removing HTML tags, line-break differences, repeated spaces, case differences, and common dash variations. Numeric-only comparison is used for total experience and monetary fields.
