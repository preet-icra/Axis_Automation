import tempfile
from pathlib import Path
import pandas as pd
import streamlit as st
from qc_engine import load_excel, compare, export_audit, DISPLAY_COLUMNS, DEFERRED_FIELDS

st.set_page_config(page_title="Uploader vs PPT QC", layout="wide")
st.title("Uploader Excel vs PowerPoint QC")
st.caption("Upload Excel first to preview selected data, then upload PPTX to compare named objects and create a fund-wise audit workbook.")
excel=st.file_uploader("1. Upload Uploader Excel",type=["xlsx"])
if excel:
    with tempfile.NamedTemporaryFile(delete=False,suffix='.xlsx') as f:
        f.write(excel.getbuffer()); excel_path=f.name
    try:
        rows=load_excel(excel_path)
        df=pd.DataFrame([{k:v for k,v in r.items() if not k.startswith('_')} for r in rows])
        st.success(f"Loaded {len(df)} funds")
        st.subheader("Columns and data selected for QC")
        st.dataframe(df,use_container_width=True,height=430)
        st.info("Deferred for separate logic: "+", ".join(DEFERRED_FIELDS))
        ppt=st.file_uploader("2. Upload PowerPoint",type=["pptx"])
        if ppt:
            with tempfile.NamedTemporaryFile(delete=False,suffix='.pptx') as f:
                f.write(ppt.getbuffer()); ppt_path=f.name
            if st.button("Run QC",type="primary"):
                with st.spinner("Comparing Excel and PPT objects..."):
                    audit=compare(excel_path,ppt_path)
                    adf=pd.DataFrame([a.__dict__ for a in audit])
                    st.session_state['audit']=audit; st.session_state['adf']=adf
            if 'adf' in st.session_state:
                adf=st.session_state['adf']; st.subheader("Audit preview")
                st.dataframe(adf,use_container_width=True,height=480)
                st.write(adf['status'].value_counts())
                out=Path(tempfile.gettempdir())/'QC_Audit_Report.xlsx'
                export_audit(st.session_state['audit'],out)
                st.download_button("Download audit Excel",out.read_bytes(),"QC_Audit_Report.xlsx","application/vnd.openxmlformats-officedocument.spreadsheetml.sheet")
    except Exception as e: st.exception(e)
