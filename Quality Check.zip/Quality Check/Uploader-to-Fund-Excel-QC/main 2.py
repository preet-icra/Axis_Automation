from __future__ import annotations
from openpyxl.utils.datetime import from_excel
import re
import unicodedata
from dataclasses import asdict, dataclass
from datetime import date, datetime
from decimal import Decimal
from pathlib import Path
from typing import Any, Iterable

from openpyxl import Workbook, load_workbook
from openpyxl.styles import Alignment, Font, PatternFill
from openpyxl.utils import get_column_letter

UPLOADER_SHEET = "Uploader"
FUND_SHEET = "Factsheet"

# Uploader columns included in Excel-to-Excel QC.
UPLOADER_FIELDS = {
    "Fund Name": "Factsheet Display Name",
    "Fund Type": "Fund Type",
    "Fund Manager": "Fund Manager",
    "Managing Since": "Managing Since",
    "Fundman Total Experience": "Fundman Total Experience",
    "Display Benchmark": "Display Benchmark",
    "Load Structure": "Load Structure",
    "Date of Inception": "Date of Inception",
    "Product Label": "Product Label",
    "Minimum SIP Amount": "Minimum SIP Amount",
    "Minimum Investment": "Minimum Investment",
    "Scheme Riskometer": "Scheme Riskometer",
    "Benchmark Riskometer": "Benchmark Riskometer",
}

# Labels found in the fund-level Factsheet workbook.
FUND_LABELS = {
    "Fund Name": "Name of the Scheme",
    "Fund Type": "Type of Scheme",
    "Fund Manager": "Fund Manager Names",
    "Managing Since": "Fund Manager Managing Since",
    "Fundman Total Experience": "Fund Manager Total Experience",
    "Display Benchmark": "Benchmark Name",
    "Load Structure": "Load Structure",
    "Date of Inception": "Date of Inception",
    "Product Label": "Product Labeling",
    "Minimum SIP Amount": "Minimum SIP Amount",
    "Minimum Investment": "Minimum Investment (Lumpsum)",
}

# showDebtQuants is not present as a direct field in the examined fund workbook.
DEFERRED_FIELDS = ["showDebtQuants"]


@dataclass
class AuditRow:
    fund_name: str
    uploader_row: int | None
    fund_file: str
    field: str
    uploader_column: str
    uploader_value: str
    fund_value: str
    status: str
    remarks: str


def clean_text(value: Any) -> str:
    if value is None:
        return ""
    if isinstance(value, datetime):
        return value.strftime("%d/%m/%Y")
    if isinstance(value, date):
        return value.strftime("%d/%m/%Y")
    if isinstance(value, float) and value.is_integer():
        return str(int(value))
    text = unicodedata.normalize("NFKC", str(value)).replace("\xa0", " ")
    text = text.replace("–", "-").replace("—", "-").replace("−", "-")
    text = re.sub(r"<br\s*/?>", "\n", text, flags=re.I)
    text = re.sub(r"<[^>]+>", " ", text)
    text = re.sub(r"[ \t]+", " ", text)
    text = re.sub(r"\s*\n\s*", "\n", text)
    return text.strip()


def norm_text(value: Any) -> str:
    value = clean_text(value).casefold()
    value = re.sub(r"[^\w]+", " ", value, flags=re.UNICODE)
    return re.sub(r"\s+", " ", value).strip()


def split_items(value: Any) -> list[str]:
    text = clean_text(value)
    items = re.split(r"\s*(?:#|/|\n|;|\|)\s*", text)
    return [norm_text(x) for x in items if norm_text(x)]


def numeric_items(value: Any) -> list[str]:
    text = clean_text(value).replace(",", "")
    return re.findall(r"\d+(?:\.\d+)?", text)


def canonical_numbers(value: Any) -> list[Decimal]:
    """Normalize numeric values so 100, 100.0, and 100.00 compare equally."""
    output: list[Decimal] = []
    for item in numeric_items(value):
        try:
            output.append(Decimal(item).normalize())
        except Exception:
            continue
    return output


def parse_date_item(value: Any) -> datetime | None:
    """
    Convert Excel dates and common textual date formats into datetime.

    Supported examples:
        Oct 21, 2015
        Oct 21 2015
        21.10.15
        21/10/2015
        21-10-2015
        Mar, 01 2024
        30 Jun, 2014
        Excel serial 46111
    """
    if value is None:
        return None

    if isinstance(value, datetime):
        return value

    if isinstance(value, date):
        return datetime(value.year, value.month, value.day)

    # Handle real Excel serial numbers.
    if isinstance(value, (int, float, Decimal)):
        try:
            serial = float(value)

            # Restrict conversion to a reasonable Excel date range.
            if 1 <= serial <= 100000:
                converted = from_excel(serial)
                if isinstance(converted, datetime):
                    return converted
                if isinstance(converted, date):
                    return datetime(
                        converted.year,
                        converted.month,
                        converted.day,
                    )
        except (TypeError, ValueError, OverflowError):
            pass

    text = clean_text(value)

    if not text:
        return None

    # Handle Excel serial stored as text, for example "46111".
    if re.fullmatch(r"\d{5}(?:\.0+)?", text):
        try:
            converted = from_excel(float(text))
            if isinstance(converted, datetime):
                return converted
            if isinstance(converted, date):
                return datetime(
                    converted.year,
                    converted.month,
                    converted.day,
                )
        except (TypeError, ValueError, OverflowError):
            pass

    # Normalize spaces without removing meaningful date punctuation.
    text = re.sub(r"\s+", " ", text).strip()
    text = re.sub(r"\s*,\s*", ", ", text)

    date_formats = (
        # Dot-separated dates.
        "%d.%m.%Y",
        "%d.%m.%y",

        # Slash-separated dates.
        "%d/%m/%Y",
        "%d/%m/%y",
        "%m/%d/%Y",
        "%m/%d/%y",

        # Hyphen-separated dates.
        "%d-%m-%Y",
        "%d-%m-%y",
        "%Y-%m-%d",

        # Month first, with comma.
        "%B %d, %Y",
        "%b %d, %Y",

        # Month first, without comma.
        "%B %d %Y",
        "%b %d %Y",

        # Formats such as "Mar, 01 2024".
        "%B, %d %Y",
        "%b, %d %Y",
        "%B, %d, %Y",
        "%b, %d, %Y",

        # Day first with month name.
        "%d %B %Y",
        "%d %b %Y",
        "%d %B, %Y",
        "%d %b, %Y",
    )

    for fmt in date_formats:
        try:
            return datetime.strptime(text, fmt)
        except ValueError:
            continue

    return None

def date_items(value: Any) -> list[str]:
    """
    Extract one or more dates and normalize them to YYYY-MM-DD.

    Supports:
    - Oct 21, 2015
    - 21.10.15
    - 21/10/2015
    - Mar, 01 2024
    - 30 Jun, 2014
    - Excel serial numbers such as 46111
    - Multiple dates separated by #, /, newline, ;, or |
    """
    if value is None:
        return []

    # Handlee objects and Excel numeric date serials.
    if isinstance(value, (datetime, date, int, float, Decimal)):
        dt = parse_date_item(value)
        if dt:
            return [dt.strftime("%Y-%m-%d")]
        return []

    text = clean_text(value)

    if not text:
        return []

    # Check whether the entire value represents one date.
    whole_date = parse_date_item(text)

    if whole_date:
        return [whole_date.strftime("%Y-%m-%d")]

    month_names = (
        r"Jan(?:uary)?|"
        r"Feb(?:ruary)?|"
        r"Mar(?:ch)?|"
        r"Apr(?:il)?|"
        r"May|"
        r"Jun(?:e)?|"
        r"Jul(?:y)?|"
        r"Aug(?:ust)?|"
        r"Sep(?:tember)?|"
        r"Oct(?:ober)?|"
        r"Nov(?:ember)?|"
        r"Dec(?:ember)?"
    )

    date_pattern = re.compile(
        rf"""
        (?:
            # Example: Oct 21, 2015 or Mar, 01 2024
            (?:{month_names})
            \s*,?\s*
            \d{{1,2}}
            \s*,?\s*
            \d{{2,4}}
        )
        |
        (?:
            # Example: 21 Oct 2015 or 30 Jun, 2014
            \d{{1,2}}
            \s+
            (?:{month_names})
            \s*,?\s*
            \d{{2,4}}
        )
        |
        (?:
            # Example: 21.10.15, 21/10/2015, or 21-10-2015
            \d{{1,2}}
            [./-]
            \d{{1,2}}
            [./-]
            \d{{2,4}}
        )
        |
        (?:
            # Example: 2015-10-21
            \d{{4}}
            -
            \d{{1,2}}
            -
            \d{{1,2}}
        )
        |
        (?:
            # Excel serial number stored as text, such as 46111
            (?<!\d)
            \d{{5}}(?:\.0+)?
            (?!\d)
        )
        """,
        flags=re.IGNORECASE | re.VERBOSE,
    )

    output: list[str] = []

    for match in date_pattern.finditer(text):
        date_text = match.group(0).strip(" ,")
        dt = parse_date_item(date_text)

        if dt:
            output.append(dt.strftime("%Y-%m-%d"))

    return output

def compare_values(field: str, uploader_value: Any, fund_value: Any) -> tuple[bool, str]:
    uploader_normalized = norm_text(uploader_value)
    fund_normalized = norm_text(fund_value)
    if uploader_normalized == fund_normalized and uploader_normalized:
        return True, "Values are equal after text normalization"
    if field == "Fund Manager":
        left, right = split_items(uploader_value), split_items(fund_value)
        return left == right and bool(left), "Compared as an ordered list of manager names"
    if field == "Fundman Total Experience":
        left, right = canonical_numbers(uploader_value), canonical_numbers(fund_value)
        return bool(left) and left == right, "Compared numeric experience values only"
    if field == "Managing Since":
        left, right = date_items(uploader_value), date_items(fund_value)
        return bool(left) and left == right, "Compared normalized dates in manager order"
    if field == "Date of Inception":
        left, right = date_items(uploader_value), date_items(fund_value)
        return bool(left) and left == right, "Compared normalized calendar dates"
    if field in {"Minimum SIP Amount", "Minimum Investment"}:
        left, right = canonical_numbers(uploader_value), canonical_numbers(fund_value)
        if left and right:
            return left == right, "Compared numeric amount values"
        return False, "Non-numeric amount descriptions differ after normalization"
    if field == "Load Structure":
        if compact_text(uploader_value) == compact_text(fund_value) and compact_text(uploader_value):
            return True, "Load Structure values are equal after formatting normalization"
        left_pairs, right_pairs = load_pairs(uploader_value), load_pairs(fund_value)
        if left_pairs and right_pairs:
            return left_pairs == right_pairs, "Compared ordered day/range and exit-load pairs"
        return False, "Load Structure wording differs after normalization"
    return uploader_normalized == fund_normalized and bool(uploader_normalized), "Normalized text comparison"


def compact_text(value: Any) -> str:
    """Remove formatting-only differences while preserving the wording and numbers."""
    return re.sub(r"[^a-z0-9%]+", "", clean_text(value).casefold())


def load_pairs(value: Any) -> list[tuple[str, str]]:
    """Extract ordered day/range and rate pairs where the load is tabular."""
    text = clean_text(value)
    pattern = re.compile(
        r"(?i)(day\s*\d+(?:\s*(?:and\s+)?onwards?)?|\d+\s*days?(?:\s*(?:and\s+)?onwards?)?)"
        r"\s*(?:-|:|=)?\s*(nil|n/?a|not\s+applicable|[-+]?\d+(?:\.\d+)?\s*%?)"
    )
    output = []
    for label, rate in pattern.findall(text):
        label_key = norm_text(label).replace(" and onwards", " onwards")
        rate_key = norm_text(rate)
        if rate_key in {"nil", "na", "n a", "not applicable"}:
            rate_key = "0"
        else:
            number = re.search(r"[-+]?\d+(?:\.\d+)?", rate.replace(",", ""))
            rate_key = format(Decimal(number.group(0)).normalize(), "f") if number else rate_key
        output.append((label_key, rate_key))
    return output


def excel_column_letter(headers: dict[str, int], header_name: str) -> str:
    col = headers.get(header_name)
    return get_column_letter(col) if col else ""


def load_uploader(path: str | Path) -> tuple[list[dict[str, Any]], dict[str, int]]:
    wb = load_workbook(path, data_only=True, read_only=True)
    if UPLOADER_SHEET not in wb.sheetnames:
        raise ValueError(f"Sheet '{UPLOADER_SHEET}' was not found in the uploader workbook.")
    ws = wb[UPLOADER_SHEET]
    headers = {clean_text(c.value): c.column for c in ws[1] if c.value is not None}
    missing = [name for name in UPLOADER_FIELDS.values() if name not in headers]
    if missing:
        raise ValueError("Missing uploader columns: " + ", ".join(missing))
    rows = []
    for row_no in range(2, ws.max_row + 1):
        record = {"_row": row_no}
        for field, header in UPLOADER_FIELDS.items():
            record[field] = ws.cell(row_no, headers[header]).value
        if clean_text(record["Fund Name"]):
            rows.append(record)
    return rows, headers


def displayed_cell_value(cell) -> str:
    value = cell.value
    if value is None:
        return ""
    if isinstance(value, (int, float, Decimal)) and "%" in clean_text(cell.number_format):
        decimals = 0
        match = re.search(r"\.(0+)", clean_text(cell.number_format))
        if match:
            decimals = len(match.group(1))
        return f"{float(value) * 100:.{decimals}f}%"
    # Do not mistake an unevaluated formula for displayed data.
    if isinstance(value, str) and value.startswith("="):
        return ""
    return clean_text(value)


def find_label_cells(ws, labels: Iterable[str]):
    targets = [norm_text(label) for label in labels]
    for row in ws.iter_rows():
        for cell in row:
            current = norm_text(cell.value)
            if not current:
                continue
            if any(current == target or current.startswith(target + " ") for target in targets):
                yield cell


def _lookup_label(ws, labels: str | Iterable[str]) -> Any:
    if isinstance(labels, str):
        labels = [labels]
    for label_cell in find_label_cells(ws, labels):
        # Same-row value, which is the standard Factsheet layout.
        for col in range(label_cell.column + 1, ws.max_column + 1):
            value = displayed_cell_value(ws.cell(label_cell.row, col))
            if value:
                return value
        # Merged/template layout can place the value in the row below.
        for row_no in range(label_cell.row + 1, min(ws.max_row, label_cell.row + 4) + 1):
            for col in range(label_cell.column, ws.max_column + 1):
                value = displayed_cell_value(ws.cell(row_no, col))
                if value and norm_text(value) not in {norm_text(x) for x in labels}:
                    return value
    return None


def _lookup_load_structure(ws) -> Any:
    """Read the value associated with the Load Structure label.

    Supported layouts:
    1. Label in A19 and statement in merged B18:B20 or B19.
    2. Statement in any merged cell whose range intersects rows near the label.
    3. Borderless Day 1 / rate tables to the right or below the label.
    4. Plain text below or diagonally right of the label.
    """
    label_terms = ("load structure", "exit load", "exit load structure")
    boundary_terms = {
        "riskometer", "scheme riskometer", "benchmark riskometer", "product labeling",
        "product labelling", "product label", "minimum sip amount", "minimum investment",
        "minimum investment lumpsum", "fund manager names", "date of inception",
        "aum month end", "aaum month end",
    }
    heading_terms = (
        "units redeemed switched out within", "exit load as a of redemption proceeds",
        "exit load as a % of redemption proceeds", "particulars", "details",
    )
    day_pattern = re.compile(r"(?i)^(?:day\s*\d+|\d+\s*days?)(?:\s*(?:and\s+)?onwards?)?$")

    def is_label(value: Any) -> bool:
        key = norm_text(value)
        # Only short heading cells are labels. A full statement beginning with
        # "Exit Load of 1%..." is data, not a label.
        if not key or len(key.split()) > 5:
            return False
        return key in label_terms or any(key == term + " details" for term in label_terms)

    def is_heading(value: Any) -> bool:
        key = norm_text(value)
        return any(norm_text(term) in key for term in heading_terms)

    def is_rate(value: Any) -> bool:
        text = clean_text(value)
        if not text or text.startswith("=") or is_heading(text):
            return False
        key = norm_text(text)
        return (
            key in {"nil", "na", "n a", "not applicable", "none"}
            or bool(re.search(r"[-+]?\d+(?:\.\d+)?\s*%", text))
            or bool(re.fullmatch(r"[-+]?\d+(?:\.\d+)?", text.replace(",", "")))
        )

    label_cells = [cell for row in ws.iter_rows() for cell in row if is_label(cell.value)]
    if not label_cells:
        return None

    for label_cell in label_cells:
        section_start = max(1, label_cell.row - 3)
        section_end = min(ws.max_row, label_cell.row + 80)
        for row_no in range(label_cell.row + 1, section_end + 1):
            nearby = [norm_text(ws.cell(row_no, col).value) for col in range(1, min(ws.max_column, 6) + 1)]
            if any(item in boundary_terms for item in nearby):
                section_end = row_no - 1
                break

        # Merged ranges are critical. In the Children's Fund layout, A19 contains
        # Load Structure while the value starts at B18 in a merged B18:B20 range.
        merged_values = []
        for merged in ws.merged_cells.ranges:
            if merged.max_row < section_start or merged.min_row > section_end:
                continue
            if merged.max_col <= label_cell.column:
                continue
            anchor = ws.cell(merged.min_row, merged.min_col)
            value = displayed_cell_value(anchor)
            if not value or value.startswith("=") or is_label(value) or is_heading(value):
                continue
            merged_values.append((abs(merged.min_row - label_cell.row), merged.min_col, value))
        if merged_values:
            merged_values.sort(key=lambda item: (item[0], item[1]))
            return merged_values[0][2]

        # Borderless Day/rate table. Borders are deliberately ignored.
        pairs = []
        for row_no in range(section_start, section_end + 1):
            for col_no in range(1, ws.max_column + 1):
                day = displayed_cell_value(ws.cell(row_no, col_no))
                if not day_pattern.fullmatch(day):
                    continue
                rate = ""
                for candidate_col in range(col_no + 1, ws.max_column + 1):
                    candidate = displayed_cell_value(ws.cell(row_no, candidate_col))
                    if day_pattern.fullmatch(candidate):
                        break
                    if is_rate(candidate):
                        rate = candidate
                        break
                if not rate:
                    for candidate_row in range(row_no + 1, min(section_end, row_no + 3) + 1):
                        candidate = displayed_cell_value(ws.cell(candidate_row, col_no))
                        if is_rate(candidate):
                            rate = candidate
                            break
                if rate:
                    pairs.append(f"{day} - {rate}")
        if pairs:
            return "; ".join(dict.fromkeys(pairs))

        # Same-row statement to the right.
        right_values = []
        for col_no in range(label_cell.column + 1, ws.max_column + 1):
            value = displayed_cell_value(ws.cell(label_cell.row, col_no))
            if value and not value.startswith("=") and not is_label(value) and not is_heading(value):
                right_values.append(value)
        if right_values:
            return " ".join(dict.fromkeys(right_values)).strip()

        # Search nearby rows on the right. Start above the label to catch vertically
        # merged cells whose anchor sits one row earlier.
        values = []
        for row_no in range(section_start, section_end + 1):
            for col_no in range(label_cell.column + 1, ws.max_column + 1):
                value = displayed_cell_value(ws.cell(row_no, col_no))
                key = norm_text(value)
                if not value or value.startswith("=") or is_label(value):
                    continue
                if key in boundary_terms or is_heading(value) or day_pattern.fullmatch(value):
                    continue
                values.append((abs(row_no - label_cell.row), col_no, value))
        if values:
            values.sort(key=lambda item: (item[0], item[1]))
            return values[0][2]
    return None


def _lookup_riskometer(ws, risk_name: str) -> Any:
    return _lookup_label(ws, [risk_name])


def load_fund_workbook(path: str | Path) -> dict[str, Any]:
    # Non-read-only mode is intentional. It exposes merged cells and full template layout.
    wb = load_workbook(path, data_only=True, read_only=False)
    if FUND_SHEET not in wb.sheetnames:
        wb.close()
        raise ValueError(f"Sheet '{FUND_SHEET}' was not found in {Path(path).name}.")
    ws = wb[FUND_SHEET]
    record = {"_file": Path(path).name}
    aliases = {
        "Fund Name": ["Name of the Scheme", "Scheme Name"],
        "Fund Type": ["Type of Scheme", "Scheme Type"],
        "Fund Manager": ["Fund Manager Names", "Fund Manager Name", "Fund Manager"],
        "Managing Since": ["Fund Manager Managing Since", "Managing Since"],
        "Fundman Total Experience": ["Fund Manager Total Experience", "Total Experience"],
        "Display Benchmark": ["Benchmark Name", "Benchmark"],
        "Date of Inception": ["Date of Inception", "Date of Allotment"],
        "Product Label": ["Product Labeling", "Product Labelling", "Product Label"],
        "Minimum SIP Amount": ["Minimum SIP Amount", "Minimum SIP"],
        "Minimum Investment": ["Minimum Investment (Lumpsum)", "Minimum Investment Amount", "Minimum Investment"],
    }
    for field in FUND_LABELS:
        if field == "Load Structure":
            record[field] = _lookup_load_structure(ws)
        else:
            record[field] = _lookup_label(ws, aliases.get(field, [FUND_LABELS[field]]))
    record["Scheme Riskometer"] = _lookup_riskometer(ws, "Scheme Riskometer")
    record["Benchmark Riskometer"] = _lookup_riskometer(ws, "Benchmark Riskometer")
    wb.close()
    if not clean_text(record["Fund Name"]):
        raise ValueError(f"Name of the Scheme is blank in {Path(path).name}.")
    return record


def compare_workbooks(uploader_path: str | Path, fund_paths: Iterable[str | Path]) -> list[AuditRow]:
    uploader_rows, headers = load_uploader(uploader_path)
    uploader_by_fund = {norm_text(r["Fund Name"]): r for r in uploader_rows}
    audits: list[AuditRow] = []

    for path in fund_paths:
        fund = load_fund_workbook(path)
        key = norm_text(fund["Fund Name"])
        uploader = uploader_by_fund.get(key)
        if uploader is None:
            audits.append(AuditRow(
                clean_text(fund["Fund Name"]), None, fund["_file"], "Fund Name",
                excel_column_letter(headers, UPLOADER_FIELDS["Fund Name"]), "",
                clean_text(fund["Fund Name"]), "MISSING IN UPLOADER",
                "No matching Factsheet Display Name in uploader workbook",
            ))
            continue

        for field, header in UPLOADER_FIELDS.items():
            left, right = uploader.get(field), fund.get(field)
            if not clean_text(left) and not clean_text(right):
                status, detail = "PASS", "Both values are blank"
            elif not clean_text(right):
                status, detail = "MISSING IN FUND", "Fund workbook value is blank or label was not found"
            elif not clean_text(left):
                status, detail = "MISSING IN UPLOADER", "Uploader value is blank"
            else:
                matched, detail = compare_values(field, left, right)
                status = "PASS" if matched else "MISMATCH"
            audits.append(AuditRow(
                clean_text(uploader["Fund Name"]), uploader["_row"], fund["_file"], field,
                excel_column_letter(headers, header), clean_text(left), clean_text(right), status, detail,
            ))
    return audits


def audit_summary(audits: list[AuditRow]) -> list[dict[str, Any]]:
    funds: dict[str, list[AuditRow]] = {}
    for item in audits:
        funds.setdefault(item.fund_name, []).append(item)
    output = []
    for fund, items in funds.items():
        counts = {s: sum(x.status == s for x in items) for s in ("PASS", "MISMATCH", "MISSING IN FUND", "MISSING IN UPLOADER")}
        output.append({
            "Fund Name": fund,
            "Checks": len(items),
            **counts,
            "Overall Status": "PASS" if all(x.status == "PASS" for x in items) else "REVIEW",
        })
    return output


def safe_sheet_name(name: str, used: set[str]) -> str:
    base = re.sub(r"[\\/*?:\[\]]", " ", clean_text(name))[:31] or "Fund"
    result, n = base, 2
    while result in used:
        suffix = f"_{n}"
        result = base[:31 - len(suffix)] + suffix
        n += 1
    used.add(result)
    return result


def _style_sheet(ws) -> None:
    header_fill = PatternFill("solid", fgColor="1F4E78")
    for cell in ws[1]:
        cell.fill = header_fill
        cell.font = Font(color="FFFFFF", bold=True)
        cell.alignment = Alignment(horizontal="center", vertical="center")
    ws.freeze_panes = "A2"
    ws.auto_filter.ref = ws.dimensions
    status_col = next((c.column for c in ws[1] if c.value in {"Status", "Overall Status"}), None)
    colors = {
        "PASS": "C6EFCE", "REVIEW": "FFEB9C", "MISMATCH": "FFC7CE",
        "MISSING IN FUND": "F4B084", "MISSING IN UPLOADER": "F4B084",
    }
    for row in ws.iter_rows(min_row=2):
        for cell in row:
            cell.alignment = Alignment(vertical="top", wrap_text=True)
        if status_col:
            cell = row[status_col - 1]
            if cell.value in colors:
                cell.fill = PatternFill("solid", fgColor=colors[cell.value])
    for col in range(1, ws.max_column + 1):
        length = max(len(clean_text(ws.cell(r, col).value)) for r in range(1, min(ws.max_row, 200) + 1))
        ws.column_dimensions[get_column_letter(col)].width = min(max(length + 2, 12), 55)


def export_audit(audits: list[AuditRow], output_path: str | Path) -> None:
    wb = Workbook()
    summary_ws = wb.active
    summary_ws.title = "Summary"
    summary = audit_summary(audits)
    summary_headers = ["Fund Name", "Checks", "PASS", "MISMATCH", "MISSING IN FUND", "MISSING IN UPLOADER", "Overall Status"]
    summary_ws.append(summary_headers)
    for row in summary:
        summary_ws.append([row.get(h, 0) for h in summary_headers])
    _style_sheet(summary_ws)

    detail_ws = wb.create_sheet("Audit Detail")
    headers = ["Fund Name", "Uploader Row", "Fund File", "Field", "Uploader Column", "Uploader Value", "Fund Value", "Status", "Remarks"]
    detail_ws.append(headers)
    for item in audits:
        detail_ws.append(list(asdict(item).values()))
    _style_sheet(detail_ws)

    by_fund: dict[str, list[AuditRow]] = {}
    for item in audits:
        by_fund.setdefault(item.fund_name, []).append(item)
    used = {"Summary", "Audit Detail"}
    for fund_name, items in by_fund.items():
        ws = wb.create_sheet(safe_sheet_name(fund_name, used))
        ws.append(headers)
        for item in items:
            ws.append(list(asdict(item).values()))
        _style_sheet(ws)

    wb.save(output_path)

# ----------------------------- PYQT6 GUI -----------------------------
import sys
from pathlib import Path

from PyQt6.QtCore import QThread, pyqtSignal
from PyQt6.QtGui import QColor
from PyQt6.QtWidgets import (
    QApplication, QFileDialog, QHBoxLayout, QLabel, QMainWindow, QMessageBox,
    QPushButton, QTabWidget, QTableWidget, QTableWidgetItem, QVBoxLayout, QWidget,
)



def discover_fund_files(folder: str | Path, uploader_path: str | Path | None = None) -> list[str]:
    """Find every valid fund workbook in the selected folder and subfolders."""
    root = Path(folder)
    if not root.is_dir():
        raise ValueError("The selected funds folder is not valid.")
    uploader = Path(uploader_path).resolve() if uploader_path else None
    files = []
    for path in sorted(root.rglob("*.xlsx"), key=lambda item: str(item).casefold()):
        if path.name.startswith("~$"):
            continue
        if uploader and path.resolve() == uploader:
            continue
        try:
            wb = load_workbook(path, read_only=True, data_only=True)
            valid = FUND_SHEET in wb.sheetnames
            wb.close()
            if valid:
                files.append(str(path))
        except Exception:
            continue
    return files


class QCWorker(QThread):
    completed = pyqtSignal(object)
    failed = pyqtSignal(str)

    def __init__(self, uploader_path, fund_folder):
        super().__init__()
        self.uploader_path = uploader_path
        self.fund_folder = fund_folder

    def run(self):
        try:
            files = discover_fund_files(self.fund_folder, self.uploader_path)
            if not files:
                raise ValueError("No valid fund .xlsx files with a Factsheet sheet were found.")
            audits = compare_workbooks(self.uploader_path, files)
            self.completed.emit((audits, files))
        except Exception as exc:
            self.failed.emit(str(exc))


class MainWindow(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("Uploader to Fund Excel QC")
        self.resize(1450, 850)
        self.uploader_path = None
        self.fund_folder = None
        self.fund_paths = []
        self.audits = []
        self.worker = None

        central = QWidget()
        self.setCentralWidget(central)
        layout = QVBoxLayout(central)

        controls = QHBoxLayout()
        self.btn_uploader = QPushButton("1. Select Uploader Excel")
        self.btn_funds = QPushButton("2. Select Funds Folder")
        self.btn_run = QPushButton("3. Run QC")
        self.btn_export = QPushButton("4. Export Audit Excel")
        controls.addWidget(self.btn_uploader)
        controls.addWidget(self.btn_funds)
        controls.addWidget(self.btn_run)
        controls.addWidget(self.btn_export)
        layout.addLayout(controls)

        self.status = QLabel("Select the uploader workbook first.")
        self.status.setStyleSheet("font-weight: bold; padding: 8px; background: #FFFFFF; border: 1px solid #DCE3ED; border-radius: 6px;")
        layout.addWidget(self.status)
        self.kpi = QLabel("Funds: 0   |   Checks: 0   |   Pass: 0   |   Review: 0")
        self.kpi.setStyleSheet("background:#17365D;color:white;padding:9px;border-radius:6px;font-weight:700;")
        layout.addWidget(self.kpi)
        deferred = QLabel("Deferred because no direct field exists in the examined fund workbook: " + ", ".join(DEFERRED_FIELDS))
        deferred.setStyleSheet("color: #8a5500; padding: 4px;")
        layout.addWidget(deferred)

        self.tabs = QTabWidget()
        self.uploader_table = QTableWidget()
        self.fund_table = QTableWidget()
        self.summary_table = QTableWidget()
        self.audit_table = QTableWidget()
        self.issues_table = QTableWidget()
        self.tabs.addTab(self.uploader_table, "Uploader Preview")
        self.tabs.addTab(self.fund_table, "Fund Excel Preview")
        self.tabs.addTab(self.summary_table, "QC Summary")
        self.tabs.addTab(self.audit_table, "Audit Detail")
        self.tabs.addTab(self.issues_table, "Issues Only")
        layout.addWidget(self.tabs)

        self.btn_uploader.clicked.connect(self.select_uploader)
        self.btn_funds.clicked.connect(self.select_funds)
        self.btn_run.clicked.connect(self.run_qc)
        self.btn_export.clicked.connect(self.export_report)
        self.btn_export.setEnabled(False)

    def populate_table(self, table, rows, headers, status_header=None):
        table.clear()
        table.setRowCount(len(rows))
        table.setColumnCount(len(headers))
        table.setHorizontalHeaderLabels(headers)
        for r, row in enumerate(rows):
            values = row if isinstance(row, (list, tuple)) else [row.get(h, "") for h in headers]
            for c, value in enumerate(values):
                item = QTableWidgetItem("" if value is None else str(value))
                item.setToolTip(item.text())
                table.setItem(r, c, item)
        if status_header in headers:
            c = headers.index(status_header)
            colors = {
                "PASS": QColor("#C6EFCE"), "REVIEW": QColor("#FFEB9C"),
                "MISMATCH": QColor("#FFC7CE"), "MISSING IN FUND": QColor("#F4B084"),
                "MISSING IN UPLOADER": QColor("#F4B084"),
            }
            for r in range(table.rowCount()):
                item = table.item(r, c)
                if item and item.text() in colors:
                    item.setBackground(colors[item.text()])
        table.resizeColumnsToContents()
        table.setAlternatingRowColors(True)

    def select_uploader(self):
        path, _ = QFileDialog.getOpenFileName(self, "Select Uploader Excel", "", "Excel files (*.xlsx)")
        if not path:
            return
        try:
            rows, _ = load_uploader(path)
            self.uploader_path = path
            headers = [k for k in rows[0] if not k.startswith("_")]
            display = [{h: row.get(h, "") for h in headers} for row in rows]
            self.populate_table(self.uploader_table, display, headers)
            self.status.setText(f"Uploader loaded: {Path(path).name} | {len(rows)} funds")
            self.tabs.setCurrentWidget(self.uploader_table)
        except Exception as exc:
            QMessageBox.critical(self, "Uploader error", str(exc))

    def select_funds(self):
        folder = QFileDialog.getExistingDirectory(self, "Select Folder Containing Fund Excel Files")
        if not folder:
            return
        try:
            paths = discover_fund_files(folder, self.uploader_path)
            if not paths:
                raise ValueError("No valid .xlsx fund workbooks containing a Factsheet sheet were found.")
            self.fund_folder = folder
            self.fund_paths = paths
            records = [load_fund_workbook(path) for path in paths]
            headers = ["Fund File"] + [key for key in records[0] if not key.startswith("_")]
            display = []
            for record in records:
                row = {"Fund File": record["_file"]}
                row.update({key: value for key, value in record.items() if not key.startswith("_")})
                display.append(row)
            self.populate_table(self.fund_table, display, headers)
            self.status.setText(f"Funds folder loaded: {folder} | {len(paths)} workbook(s)")
            self.tabs.setCurrentWidget(self.fund_table)
        except Exception as exc:
            QMessageBox.critical(self, "Funds folder error", str(exc))

    def run_qc(self):
        if not self.uploader_path or not self.fund_folder:
            QMessageBox.warning(self, "Missing input", "Select the uploader Excel and the funds folder.")
            return
        self.btn_run.setEnabled(False)
        self.btn_export.setEnabled(False)
        self.status.setText("QC is running...")
        self.worker = QCWorker(self.uploader_path, self.fund_folder)
        self.worker.completed.connect(self.qc_completed)
        self.worker.failed.connect(self.qc_failed)
        self.worker.start()

    def qc_completed(self, result):
        audits, files = result
        self.audits = audits
        self.fund_paths = files
        summary = audit_summary(audits)
        summary_headers = ["Fund Name", "Checks", "PASS", "MISMATCH", "MISSING IN FUND", "MISSING IN UPLOADER", "Overall Status"]
        self.populate_table(self.summary_table, summary, summary_headers, "Overall Status")
        detail_headers = ["Fund Name", "Uploader Row", "Fund File", "Field", "Uploader Column", "Uploader Value", "Fund Value", "Status", "Remarks"]
        detail_rows = [[
            a.fund_name, a.uploader_row, a.fund_file, a.field, a.uploader_column,
            a.uploader_value, a.fund_value, a.status, a.remarks,
        ] for a in audits]
        self.populate_table(self.audit_table, detail_rows, detail_headers, "Status")
        issue_rows = [row for row, item in zip(detail_rows, audits) if item.status != "PASS"]
        self.populate_table(self.issues_table, issue_rows, detail_headers, "Status")
        failures = sum(a.status != "PASS" for a in audits)
        passes = sum(a.status == "PASS" for a in audits)
        self.kpi.setText(f"Funds: {len(self.fund_paths)}   |   Checks: {len(audits)}   |   Pass: {passes}   |   Review: {failures}")
        self.tabs.setTabText(4, f"Issues Only ({failures})")
        self.status.setText(f"QC completed: {len(audits)} checks | {failures} item(s) need review")
        self.btn_run.setEnabled(True)
        self.btn_export.setEnabled(True)
        self.tabs.setCurrentWidget(self.summary_table)

    def qc_failed(self, message):
        self.btn_run.setEnabled(True)
        self.status.setText("QC failed.")
        QMessageBox.critical(self, "QC error", message)

    def export_report(self):
        if not self.audits:
            QMessageBox.warning(self, "No audit", "Please run QC before exporting.")
            return
        path, _ = QFileDialog.getSaveFileName(self, "Save Audit Report", "Excel_to_Excel_QC_Audit.xlsx", "Excel files (*.xlsx)")
        if not path:
            return
        if not path.lower().endswith(".xlsx"):
            path += ".xlsx"
        try:
            export_audit(self.audits, path)
            self.status.setText(f"Audit report saved: {path}")
            QMessageBox.information(self, "Export complete", "The QC audit workbook was created successfully.")
        except Exception as exc:
            QMessageBox.critical(self, "Export error", str(exc))


if __name__ == "__main__":
    app = QApplication(sys.argv)
    app.setStyle("Fusion")
    window = MainWindow()
    window.show()
    sys.exit(app.exec())
