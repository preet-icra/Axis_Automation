import sys
import re
import math
import traceback
from pathlib import Path
from datetime import datetime
from difflib import SequenceMatcher

from PyQt6.QtCore import Qt, QThread, pyqtSignal
from PyQt6.QtWidgets import (
    QApplication, QWidget, QVBoxLayout, QHBoxLayout, QLabel, QLineEdit,
    QPushButton, QFileDialog, QMessageBox, QProgressBar, QPlainTextEdit,
    QGroupBox, QFormLayout
)
from openpyxl import load_workbook, Workbook
from openpyxl.styles import Font, PatternFill, Alignment, Border, Side
from openpyxl.utils import get_column_letter

# Static client-code to Factsheet Display Name mapping.
# Only display_name is used to locate fund workbooks; the uploader is not required at runtime.
# Client Code mapping is loaded dynamically from the SECOND worksheet
# of the mapping workbook selected in the GUI.
CLIENT_DISPLAY_NAME_MAPPING = {}

REPORT_FILE_NAME = "Top 10 Holding Compare report.xlsx"
SUPPORTED_EXTENSIONS = {".xlsx", ".xlsm"}


def clean_text(value):
    if value is None:
        return ""
    return re.sub(r"\s+", " ", str(value)).strip()


def normalize_name(value):
    """Normalize issuer/holding names for practical Excel-to-factsheet matching."""
    text = clean_text(value).casefold().replace("&", " ")
    text = re.sub(r"\([^)]*\)", " ", text)
    text = re.sub(r"[^a-z0-9]+", " ", text)
    replacements = {
        "limited": "", "ltd": "", "private": "", "pvt": "",
        "company": "", "co": "", "corporation": "corp",
        "industries": "industry", "services": "service",
        "financial": "finance", "investment": "invest",
    }
    words = [replacements.get(w, w) for w in text.split()]
    return " ".join(w for w in words if w)


def names_match(a, b):
    na, nb = normalize_name(a), normalize_name(b)
    if not na or not nb:
        return False
    if na == nb or na in nb or nb in na:
        return True
    return SequenceMatcher(None, na, nb).ratio() >= 0.88


def value_to_percentage(value):
    if value is None or value == "":
        return None
    if isinstance(value, str):
        s = value.strip().replace(",", "").replace("%", "")
        if not s:
            return None
        value = float(s)
    return float(value)


def read_client_code_mapping(path):
    """Read Client Fund Code and Factsheet Display Name from worksheet 2.

    Required mapping workbook structure:
    - The workbook must contain at least two worksheets.
    - The second worksheet must contain Client Fund Code and
      Factsheet Display Name columns within its first 50 rows.
    """
    wb = load_workbook(path, read_only=True, data_only=True)
    try:
        if len(wb.worksheets) < 2:
            raise ValueError(
                "The mapping workbook must contain at least two worksheets. "
                "Client Code mapping must be in the second worksheet."
            )

        ws = wb.worksheets[1]
        header_row = None
        client_col = None
        display_col = None

        client_aliases = {
            "clientfundcode", "clientcode", "fundclientcode"
        }
        display_aliases = {
            "factsheetdisplayname", "displayname", "fundname",
            "factsheetname"
        }

        for row_no in range(1, min(ws.max_row, 50) + 1):
            for col in range(1, ws.max_column + 1):
                header = re.sub(
                    r"[^a-z0-9]+", "",
                    clean_text(ws.cell(row_no, col).value).casefold()
                )
                if header in client_aliases:
                    client_col = col
                if header in display_aliases:
                    display_col = col
            if client_col and display_col:
                header_row = row_no
                break

        if not header_row:
            raise ValueError(
                f"Second worksheet '{ws.title}' does not contain the required "
                "Client Fund Code and Factsheet Display Name columns."
            )

        mapping = {}
        source_rows = []
        for row_no in range(header_row + 1, ws.max_row + 1):
            client_code = clean_text(ws.cell(row_no, client_col).value)
            display_name = clean_text(ws.cell(row_no, display_col).value)
            if not client_code and not display_name:
                continue
            if not client_code or not display_name:
                source_rows.append({
                    "sheet": ws.title,
                    "row": row_no,
                    "client_code": client_code,
                    "display_name": display_name,
                    "status": "SKIPPED - blank code or display name",
                })
                continue
            if client_code in mapping and mapping[client_code] != display_name:
                raise ValueError(
                    f"Client Code '{client_code}' has conflicting display names "
                    f"in the second worksheet: '{mapping[client_code]}' and "
                    f"'{display_name}'."
                )
            mapping[client_code] = display_name
            source_rows.append({
                "sheet": ws.title,
                "row": row_no,
                "client_code": client_code,
                "display_name": display_name,
                "status": "LOADED",
            })

        if not mapping:
            raise ValueError(
                f"No valid Client Code mappings were found in second worksheet "
                f"'{ws.title}'."
            )
        return mapping, source_rows, ws.title
    finally:
        wb.close()


def find_header_row_and_map(ws, required):
    required_norm = {clean_text(x).casefold() for x in required}
    for row_no in range(1, min(ws.max_row, 50) + 1):
        values = [clean_text(ws.cell(row_no, c).value) for c in range(1, ws.max_column + 1)]
        norm = {v.casefold() for v in values if v}
        if required_norm.issubset(norm):
            return row_no, {v.casefold(): i + 1 for i, v in enumerate(values) if v}
    raise ValueError(f"Required headers not found: {', '.join(required)}")


def read_consolidated_top10(path):
    wb = load_workbook(path, read_only=True, data_only=True)
    ws = wb["Portfolio"] if "Portfolio" in wb.sheetnames else wb[wb.sheetnames[0]]
    header_row, hm = find_header_row_and_map(
        ws, ["Client Fund Code", "Security Name", "% to Net Assets"]
    )
    c_client = hm["client fund code"]
    c_issuer = hm["security name"]
    c_value = hm["% to net assets"]
    c_considered = hm.get("is_holdings_considered")

    # Keep every valid row separately. The source row number is retained so
    # equal % values remain in their original top-to-bottom Excel order.
    grouped = {}
    for source_row, row in enumerate(
        ws.iter_rows(min_row=header_row + 1, values_only=True),
        start=header_row + 1,
    ):
        client = clean_text(row[c_client - 1])
        security_name = clean_text(row[c_issuer - 1])
        if not client or not security_name:
            continue

        # Apply the holdings filter first, when the column exists.
        if c_considered:
            flag = clean_text(row[c_considered - 1]).casefold()
            if flag not in {"yes", "y", "true", "1"}:
                continue

        try:
            net_asset_value = value_to_percentage(row[c_value - 1])
        except (TypeError, ValueError):
            continue
        if net_asset_value is None or not math.isfinite(net_asset_value):
            continue

        grouped.setdefault(client, []).append(
            (security_name, net_asset_value, source_row)
        )

    result = {}
    for client, holdings in grouped.items():
        # Sort % to Net Assets from largest to smallest. Python's sort is
        # stable, and source_row explicitly preserves top-to-bottom order
        # when two securities have the same percentage.
        holdings.sort(key=lambda item: (-item[1], item[2]))

        # After sorting, read Security Name from top to bottom. Keep only the
        # available rows, up to a maximum of 10. A client with 7 rows returns
        # ranks 1 to 7 only.
        result[client] = [
            (security_name, net_asset_value)
            for security_name, net_asset_value, _source_row in holdings[:10]
        ]

    return result


def extract_scheme_name(ws):
    for r in range(1, min(ws.max_row, 30) + 1):
        for c in range(1, min(ws.max_column, 8) + 1):
            if clean_text(ws.cell(r, c).value).casefold() == "name of the scheme":
                for cc in range(c + 1, min(ws.max_column, c + 4) + 1):
                    value = clean_text(ws.cell(r, cc).value)
                    if value:
                        return value
    return ""


def read_fund_top10(path):
    wb = load_workbook(path, read_only=True, data_only=True)
    for ws in wb.worksheets:
        scheme_name = extract_scheme_name(ws)
        for r in range(1, ws.max_row + 1):
            marker_col = None
            for marker_c in range(1, ws.max_column + 1):
                if clean_text(ws.cell(r, marker_c).value).casefold() == "top 10 holdings":
                    marker_col = marker_c
                    break
            if marker_col is None:
                continue
            header_row = None
            name_col = value_col = None
            for rr in range(r, min(ws.max_row, r + 8) + 1):
                vals = [clean_text(ws.cell(rr, c).value).casefold() for c in range(1, ws.max_column + 1)]
                for i, val in enumerate(vals, 1):
                    if val in {"holding name", "issuer name", "name of security", "security name"}:
                        name_col = i
                    if val in {"% to net assets", "% to net asset", "allocation"}:
                        value_col = i
                if name_col and value_col:
                    header_row = rr
                    break
            if not header_row:
                continue
            items = []
            for rr in range(header_row + 1, min(ws.max_row, header_row + 25) + 1):
                name = clean_text(ws.cell(rr, name_col).value)
                value_cell = ws.cell(rr, value_col)
                raw = value_cell.value
                if not name:
                    if items:
                        break
                    continue
                try:
                    value = value_to_percentage(raw)
                except (TypeError, ValueError):
                    if items:
                        break
                    continue
                if value is None:
                    continue

                # Use the Excel number format to determine whether a numeric
                # value is stored as a decimal percentage. Examples:
                # 0.0499 with format 0.00% becomes 4.99
                # 1.0002 with format 0.00% becomes 100.02
                # A text value such as "4.99%" is already converted to 4.99.
                number_format = clean_text(value_cell.number_format)
                if not isinstance(raw, str) and "%" in number_format:
                    value *= 100.0

                items.append((name, value))
                if len(items) == 10:
                    break
            if items:
                return scheme_name, items
    raise ValueError("Top 10 Holdings section was not found")


def build_fund_index(folder, log):
    index = []
    for path in sorted(Path(folder).iterdir()):
        if path.suffix.lower() not in SUPPORTED_EXTENSIONS or path.name.startswith("~$"):
            continue
        try:
            wb = load_workbook(path, read_only=True, data_only=True)
            scheme = ""
            for ws in wb.worksheets:
                scheme = extract_scheme_name(ws)
                if scheme:
                    break
            index.append({"path": path, "scheme": scheme, "stem": path.stem})
        except Exception as exc:
            log(f"Skipped unreadable workbook {path.name}: {exc}")
    return index


def find_fund_file(client_code, fund_index, client_mapping):
    """Find a fund workbook using only an exact display-name match.

    Partial and fuzzy matching are intentionally not used because similar fund
    names such as Nifty 50, Nifty 100, Nifty 500, Nifty IT, and Nifty Bank can
    otherwise select the wrong workbook.
    """
    display_name = clean_text(client_mapping.get(client_code, ""))
    target = normalize_name(display_name)
    if not target:
        return None

    # Prefer the workbook's internal Name of the Scheme value.
    scheme_matches = [
        rec for rec in fund_index
        if normalize_name(rec["scheme"]) == target
    ]
    if len(scheme_matches) == 1:
        return scheme_matches[0]["path"]

    # If the internal scheme name is missing, use the exact normalized filename.
    filename_matches = [
        rec for rec in fund_index
        if normalize_name(rec["stem"]) == target
    ]
    if len(filename_matches) == 1:
        return filename_matches[0]["path"]

    # Do not guess when no exact match exists or more than one exact match exists.
    return None


def compare_lists(consolidated, factsheet):
    """Compare only the holdings available in the consolidated Top 10 list.

    If a client has fewer than 10 valid consolidated holdings, for example 7,
    only ranks 1 to 7 are audited and written to the report. Ranks 8 to 10 are
    not created. If the fund factsheet has fewer rows than the consolidated
    list, the missing fund rows are reported as FAIL.
    """
    details = []
    comparison_count = len(consolidated)
    all_pass = comparison_count > 0

    for rank in range(1, comparison_count + 1):
        c_name, c_val = consolidated[rank - 1]
        f_name, f_val = factsheet[rank - 1] if rank <= len(factsheet) else ("", None)
        name_ok = names_match(c_name, f_name)
        value_diff = None if c_val is None or f_val is None else round(c_val - f_val, 6)

        # Exact comparison at the two-decimal precision shown in the report.
        value_ok = (
            c_val is not None
            and f_val is not None
            and round(c_val, 2) == round(f_val, 2)
        )
        status = "PASS" if name_ok and value_ok else "FAIL"
        if status == "FAIL":
            all_pass = False

        details.append({
            "rank": rank,
            "consolidated_name": c_name,
            "consolidated_value": c_val,
            "fund_name": f_name,
            "fund_value": f_val,
            "name_match": name_ok,
            "difference": value_diff,
            "status": status,
        })

    return all_pass, details


def create_report(output_path, summary_rows, detail_rows, client_mapping, mapping_source, mapping_sheet_name):
    wb = Workbook()
    ws = wb.active
    ws.title = "Audit Summary"
    headers = ["Client Code", "Fund Name", "Fund File", "Consolidated Count",
               "Fund Count", "Result", "Remarks"]
    ws.append(headers)
    for item in summary_rows:
        ws.append([item.get(h, "") for h in headers])

    wd = wb.create_sheet("Top 10 Comparison")
    detail_headers = ["Client Code", "Fund Name", "Rank", "Consolidated Security Name",
                      "Consolidated %", "Fund Holding Name", "Fund %", "Difference (pp)",
                      "Name Match", "Result"]
    wd.append(detail_headers)
    for item in detail_rows:
        wd.append([item.get(h, "") for h in detail_headers])

    wm = wb.create_sheet("Client Fund Mapping")
    wm.append(["Client Code", "Factsheet Display Name"])
    for client, display_name in sorted(client_mapping.items()):
        wm.append([client, display_name])

    dark = "1F4E78"
    pass_fill = PatternFill("solid", fgColor="C6EFCE")
    fail_fill = PatternFill("solid", fgColor="FFC7CE")
    warn_fill = PatternFill("solid", fgColor="FFEB9C")
    thin_gray = Side(style="thin", color="D9E1F2")
    for sheet in wb.worksheets:
        sheet.freeze_panes = "A2"
        sheet.auto_filter.ref = sheet.dimensions
        sheet.sheet_view.showGridLines = False
        for cell in sheet[1]:
            cell.fill = PatternFill("solid", fgColor=dark)
            cell.font = Font(color="FFFFFF", bold=True)
            cell.alignment = Alignment(horizontal="center", vertical="center", wrap_text=True)
        sheet.row_dimensions[1].height = 34
        for row in sheet.iter_rows(min_row=2):
            for cell in row:
                cell.alignment = Alignment(vertical="top", wrap_text=True)
                cell.border = Border(bottom=thin_gray)
        for col in range(1, sheet.max_column + 1):
            max_len = max(len(clean_text(sheet.cell(r, col).value)) for r in range(1, min(sheet.max_row, 250) + 1))
            sheet.column_dimensions[get_column_letter(col)].width = min(max(max_len + 2, 12), 45)

    for cell in ws["H"][1:]:
        cell.fill = pass_fill if cell.value == "PASS" else fail_fill if cell.value == "FAIL" else warn_fill
    for cell in wd["J"][1:]:
        cell.fill = pass_fill if cell.value == "PASS" else fail_fill
    for row in range(2, wd.max_row + 1):
        for col in (5, 7, 8):
            wd.cell(row, col).number_format = "0.00"
    ms = wb.create_sheet("Mapping Source Audit")
    ms.append(["Mapping Worksheet", "Source Row", "Client Code", "Factsheet Display Name", "Status"])
    for item in mapping_source:
        ms.append([
            mapping_sheet_name,
            item.get("row", ""),
            item.get("client_code", ""),
            item.get("display_name", ""),
            item.get("status", ""),
        ])
    wb.save(output_path)


def run_audit(consolidated_path, mapping_path, fund_folder, output_folder,
              log=lambda x: None, progress=lambda x: None):
    log("Reading Client Code mapping from the second worksheet...")
    client_mapping, mapping_source, mapping_sheet_name = read_client_code_mapping(mapping_path)
    log(f"Loaded {len(client_mapping)} Client Code mappings from worksheet: {mapping_sheet_name}")
    log("Reading consolidated portfolio...")
    top10_by_client = read_consolidated_top10(consolidated_path)
    log(f"Found {len(top10_by_client)} client codes in consolidated portfolio.")
    fund_index = build_fund_index(fund_folder, log)
    log(f"Indexed {len(fund_index)} fund workbooks.")
    summary_rows, detail_rows = [], []
    client_codes = sorted(top10_by_client)
    for pos, client in enumerate(client_codes, 1):
        meta = client_mapping.get(client)
        remarks = ""
        result = "NOT AUDITED"
        fund_count = 0
        fund_path = find_fund_file(client, fund_index, client_mapping) if meta else None
        fund_name = meta if meta else ""
        if not meta:
            remarks = "Client code is not available in the selected mapping workbook second worksheet."
        elif not fund_path:
            remarks = "Matching fund workbook was not found in the selected folder."
        else:
            try:
                extracted_scheme, fund_top10 = read_fund_top10(fund_path)
                fund_name = extracted_scheme or fund_name
                fund_count = len(fund_top10)
                passed, comparisons = compare_lists(top10_by_client[client], fund_top10)
                result = "PASS" if passed else "FAIL"
                remarks = (f"All {len(top10_by_client[client])} available consolidated holdings matched." if passed else "One or more available consolidated holdings differ.")
                for d in comparisons:
                    detail_rows.append({
                        "Client Code": client, "Fund Name": fund_name, "Rank": d["rank"],
                        "Consolidated Security Name": d["consolidated_name"],
                        "Consolidated %": d["consolidated_value"],
                        "Fund Holding Name": d["fund_name"], "Fund %": d["fund_value"],
                        "Difference (pp)": d["difference"],
                        "Name Match": "Yes" if d["name_match"] else "No", "Result": d["status"]
                    })
            except Exception as exc:
                result = "ERROR"
                remarks = str(exc)
        summary_rows.append({
            "Client Code": client,
            "Fund Name": fund_name,
            "Fund File": fund_path.name if fund_path else "",
            "Consolidated Count": len(top10_by_client[client]), "Fund Count": fund_count,
            "Result": result, "Remarks": remarks,
        })
        log(f"{client}: {result} {remarks}")
        progress(int(pos * 100 / max(len(client_codes), 1)))
    output_path = Path(output_folder) / REPORT_FILE_NAME
    create_report(output_path, summary_rows, detail_rows, client_mapping, mapping_source, mapping_sheet_name)
    return output_path


class AuditWorker(QThread):
    log_message = pyqtSignal(str)
    progress_changed = pyqtSignal(int)
    completed = pyqtSignal(str)
    failed = pyqtSignal(str)

    def __init__(self, consolidated, mapping_path, fund_folder, output_folder):
        super().__init__()
        self.consolidated = consolidated
        self.mapping_path = mapping_path
        self.fund_folder = fund_folder
        self.output_folder = output_folder

    def run(self):
        try:
            path = run_audit(self.consolidated, self.mapping_path, self.fund_folder, self.output_folder,
                             self.log_message.emit, self.progress_changed.emit)
            self.completed.emit(str(path))
        except Exception:
            self.failed.emit(traceback.format_exc())


class Top10AuditApp(QWidget):
    APP_STYLE = """
        QWidget {
            background-color: #F4F7FB;
            color: #243447;
            font-family: "Segoe UI";
            font-size: 10pt;
        }
        QLabel#TitleLabel {
            color: #123B63;
            font-size: 24px;
            font-weight: 700;
        }
        QLabel#SubtitleLabel { color: #5D6D7E; font-size: 10pt; }
        QLabel#StatusLabel {
            background: #EAF2F8;
            color: #1F4E78;
            border-radius: 6px;
            padding: 8px 12px;
            font-weight: 600;
        }
        QGroupBox {
            background: white;
            border: 1px solid #D7E1EC;
            border-radius: 10px;
            margin-top: 14px;
            padding: 16px 12px 12px 12px;
            font-weight: 700;
            color: #1F4E78;
        }
        QGroupBox::title { subcontrol-origin: margin; left: 14px; padding: 0 6px; }
        QLineEdit {
            background: #FFFFFF;
            border: 1px solid #C9D5E2;
            border-radius: 6px;
            padding: 9px;
            color: #243447;
        }
        QLineEdit:focus { border: 2px solid #2878B5; }
        QPushButton {
            background: #E9F1F8;
            color: #1F4E78;
            border: 1px solid #B9CDDF;
            border-radius: 6px;
            padding: 8px 14px;
            font-weight: 600;
        }
        QPushButton:hover { background: #D9EAF7; }
        QPushButton:pressed { background: #C8DEEE; }
        QPushButton#RunButton {
            background: #1F4E78;
            color: white;
            border: none;
            padding: 12px 24px;
            font-size: 11pt;
            font-weight: 700;
        }
        QPushButton#RunButton:hover { background: #2878B5; }
        QPushButton#RunButton:disabled { background: #9EB2C4; }
        QPushButton#ClearButton { background: white; color: #5D6D7E; }
        QProgressBar {
            background: #DFE8F0;
            border: none;
            border-radius: 6px;
            height: 12px;
            text-align: center;
            color: transparent;
        }
        QProgressBar::chunk { background: #2E86C1; border-radius: 6px; }
        QPlainTextEdit {
            background: #17202A;
            color: #D5E8F5;
            border: none;
            border-radius: 8px;
            padding: 10px;
            font-family: Consolas;
            font-size: 9pt;
        }
    """

    def __init__(self):
        super().__init__()
        self.worker = None
        self.last_report_path = ""
        self.setWindowTitle("Top 10 Holdings Compare Audit")
        self.setMinimumSize(920, 650)
        self.resize(1020, 720)
        self.setStyleSheet(self.APP_STYLE)

        main = QVBoxLayout(self)
        main.setContentsMargins(28, 24, 28, 24)
        main.setSpacing(14)

        title = QLabel("Top 10 Holdings Compare Audit")
        title.setObjectName("TitleLabel")
        main.addWidget(title)

        subtitle = QLabel(
            "Compare the top 10 Security Name and % to Net Assets values from the "
            "consolidated portfolio with each matching fund factsheet."
        )
        subtitle.setObjectName("SubtitleLabel")
        subtitle.setWordWrap(True)
        main.addWidget(subtitle)

        input_group = QGroupBox("Audit Inputs")
        form = QFormLayout(input_group)
        form.setLabelAlignment(Qt.AlignmentFlag.AlignLeft)
        form.setHorizontalSpacing(18)
        form.setVerticalSpacing(13)
        self.consolidated_edit = QLineEdit()
        self.mapping_edit = QLineEdit()
        self.fund_folder_edit = QLineEdit()
        self.output_folder_edit = QLineEdit()
        self.consolidated_edit.setPlaceholderText("Select the consolidated portfolio workbook")
        self.mapping_edit.setPlaceholderText("Select mapping workbook; second worksheet will be used")
        self.fund_folder_edit.setPlaceholderText("Select the folder containing fund Excel files")
        self.output_folder_edit.setPlaceholderText("Select the folder for the audit report")
        form.addRow("Consolidated Excel", self.path_row(self.consolidated_edit, self.pick_consolidated, "Browse File"))
        form.addRow("Client Mapping Excel", self.path_row(self.mapping_edit, self.pick_mapping, "Browse File"))
        form.addRow("Fund Excel Folder", self.path_row(self.fund_folder_edit, self.pick_fund_folder, "Browse Folder"))
        form.addRow("Save Report Folder", self.path_row(self.output_folder_edit, self.pick_output_folder, "Browse Folder"))
        main.addWidget(input_group)

        action_row = QHBoxLayout()
        self.clear_button = QPushButton("Clear")
        self.clear_button.setObjectName("ClearButton")
        self.clear_button.clicked.connect(self.clear_inputs)
        action_row.addWidget(self.clear_button)
        action_row.addStretch(1)
        self.run_button = QPushButton("Create Audit Report")
        self.run_button.setObjectName("RunButton")
        self.run_button.setMinimumWidth(220)
        self.run_button.clicked.connect(self.start_audit)
        action_row.addWidget(self.run_button)
        main.addLayout(action_row)

        self.status_label = QLabel("Ready to run the audit")
        self.status_label.setObjectName("StatusLabel")
        main.addWidget(self.status_label)

        self.progress = QProgressBar()
        self.progress.setRange(0, 100)
        self.progress.setValue(0)
        main.addWidget(self.progress)

        log_group = QGroupBox("Audit Log")
        log_layout = QVBoxLayout(log_group)
        self.log = QPlainTextEdit()
        self.log.setReadOnly(True)
        self.log.setPlaceholderText("Audit progress and results will appear here...")
        log_layout.addWidget(self.log)
        main.addWidget(log_group, 1)

        footer = QLabel(
            f'Report name: "{REPORT_FILE_NAME}"  |  Mapping: second worksheet | Matching source: Security Name  |  Value comparison: exact to 2 decimals'
        )
        footer.setObjectName("SubtitleLabel")
        main.addWidget(footer)

    def path_row(self, edit, callback, text):
        widget = QWidget()
        widget.setStyleSheet("background: transparent;")
        row = QHBoxLayout(widget)
        row.setContentsMargins(0, 0, 0, 0)
        row.setSpacing(8)
        row.addWidget(edit, 1)
        button = QPushButton(text)
        button.setMinimumWidth(115)
        button.clicked.connect(callback)
        row.addWidget(button)
        return widget

    def pick_consolidated(self):
        path, _ = QFileDialog.getOpenFileName(
            self, "Select Consolidated Portfolio", "", "Excel Files (*.xlsx *.xlsm)"
        )
        if path:
            self.consolidated_edit.setText(path)
            if not self.output_folder_edit.text().strip():
                self.output_folder_edit.setText(str(Path(path).parent))

    def pick_mapping(self):
        path, _ = QFileDialog.getOpenFileName(
            self,
            "Select Client Code Mapping Excel",
            "",
            "Excel Files (*.xlsx *.xlsm)",
        )
        if path:
            self.mapping_edit.setText(path)

    def pick_fund_folder(self):
        path = QFileDialog.getExistingDirectory(self, "Select Fund Excel Folder")
        if path:
            self.fund_folder_edit.setText(path)

    def pick_output_folder(self):
        path = QFileDialog.getExistingDirectory(self, "Select Report Save Folder")
        if path:
            self.output_folder_edit.setText(path)

    def clear_inputs(self):
        if self.worker and self.worker.isRunning():
            return
        self.consolidated_edit.clear()
        self.mapping_edit.clear()
        self.fund_folder_edit.clear()
        self.output_folder_edit.clear()
        self.log.clear()
        self.progress.setValue(0)
        self.status_label.setText("Ready to run the audit")

    def set_busy(self, busy):
        self.run_button.setEnabled(not busy)
        self.clear_button.setEnabled(not busy)
        self.consolidated_edit.setEnabled(not busy)
        self.mapping_edit.setEnabled(not busy)
        self.fund_folder_edit.setEnabled(not busy)
        self.output_folder_edit.setEnabled(not busy)

    def start_audit(self):
        consolidated = self.consolidated_edit.text().strip()
        mapping_path = self.mapping_edit.text().strip()
        fund_folder = self.fund_folder_edit.text().strip()
        output_folder = self.output_folder_edit.text().strip()
        errors = []
        if not Path(consolidated).is_file():
            errors.append("Select a valid consolidated Excel file.")
        if not Path(mapping_path).is_file():
            errors.append("Select a valid Client Code mapping Excel file.")
        if not Path(fund_folder).is_dir():
            errors.append("Select a valid fund Excel folder.")
        if not Path(output_folder).is_dir():
            errors.append("Select a valid report save folder.")
        if errors:
            QMessageBox.warning(self, "Check Audit Inputs", "\n".join(errors))
            return

        self.log.clear()
        self.log.appendPlainText("Starting Top 10 Holdings audit...")
        self.progress.setValue(0)
        self.status_label.setText("Audit is running. Please wait...")
        self.set_busy(True)
        self.worker = AuditWorker(consolidated, mapping_path, fund_folder, output_folder)
        self.worker.log_message.connect(self.log.appendPlainText)
        self.worker.progress_changed.connect(self.progress.setValue)
        self.worker.completed.connect(self.audit_completed)
        self.worker.failed.connect(self.audit_failed)
        self.worker.start()

    def audit_completed(self, path):
        self.last_report_path = path
        self.set_busy(False)
        self.progress.setValue(100)
        self.status_label.setText("Audit completed successfully")
        self.log.appendPlainText(f"Report saved: {path}")
        QMessageBox.information(self, "Audit Complete", f"Report created successfully:\n{path}")

    def audit_failed(self, message):
        self.set_busy(False)
        self.status_label.setText("Audit failed. Review the audit log.")
        self.log.appendPlainText(message)
        QMessageBox.critical(self, "Audit Failed", "The audit failed. See the log for details.")

if __name__ == "__main__":
    app = QApplication(sys.argv)
    window = Top10AuditApp()
    window.show()
    sys.exit(app.exec())
