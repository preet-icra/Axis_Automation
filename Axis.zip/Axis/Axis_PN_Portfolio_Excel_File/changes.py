import os
import re
import sys
import shutil
import traceback
from pathlib import Path
from datetime import datetime

from openpyxl import load_workbook
from openpyxl.cell.cell import MergedCell

from PyQt6.QtCore import QObject, QThread, pyqtSignal
from PyQt6.QtGui import QFont
from PyQt6.QtWidgets import (
    QApplication,
    QCheckBox,
    QComboBox,
    QFileDialog,
    QFormLayout,
    QGroupBox,
    QHBoxLayout,
    QHeaderView,
    QLabel,
    QLineEdit,
    QMainWindow,
    QMessageBox,
    QPlainTextEdit,
    QProgressBar,
    QPushButton,
    QTableWidget,
    QTableWidgetItem,
    QVBoxLayout,
    QWidget,
)


# ============================================================
# Configuration
# ============================================================

INDEX_SHEET_NAMES = {
    "index",
    "summary",
    "contents",
    "table of contents",
    "toc",
}

# Only a cell whose entire value is "Equity" is converted to "EQUITY".
EQUITY_LABELS = {
    "equity",
}

# Recognized variants of the current-assets section heading.
CURRENT_ASSET_VARIANTS = {
    "net current asset",
    "net current assets",
    "cash & other net current asset",
    "cash & other net current assets",
    "cash and other net current asset",
    "cash and other net current assets",
    "cash & other current asset",
    "cash & other current assets",
    "cash and other current asset",
    "cash and other current assets",
    "debt, cash & other current asset",
    "debt, cash & other current assets",
    "debt, cash and other current asset",
    "debt, cash and other current assets",
}

STANDARD_CURRENT_ASSET_LABEL = "Net Current Assets"


# ============================================================
# Text helpers
# ============================================================

def clean_text(value):
    if value is None:
        return ""

    text = str(value)
    text = text.replace("\n", " ")
    text = text.replace("\r", " ")
    text = text.replace("\xa0", " ")
    text = re.sub(r"\s+", " ", text).strip()
    return text


def normalize_text(value):
    text = clean_text(value).casefold()
    text = re.sub(r"\s*&\s*", " & ", text)
    text = re.sub(r"\s+", " ", text).strip()
    text = text.rstrip(":").strip()
    return text


def safe_filename_part(text):
    text = re.sub(r'[<>:"/\\|?*]+', "_", text)
    text = re.sub(r"\s+", "_", text).strip("._")
    return text or "updated"


def is_formula(value):
    return isinstance(value, str) and value.startswith("=")


def is_index_sheet(sheet_name):
    return normalize_text(sheet_name) in INDEX_SHEET_NAMES


def is_equity_heading(value):
    return normalize_text(value) in EQUITY_LABELS


def is_current_asset_heading(value):
    return normalize_text(value) in CURRENT_ASSET_VARIANTS


def find_instrument_table_columns(worksheet):
    """
    Find columns headed by 'Instrument Type/Issuer Name'.

    EQUITY is changed only in these columns and only below the header row.
    This prevents the Equity label in tables such as
    'COMPOSITION BY ASSET (%)' from being changed.
    """
    accepted_headers = {
        "instrument type/issuer name",
        "instrument type / issuer name",
        "instrument type/ issuer name",
        "instrument type /issuer name",
    }

    locations = []

    for cell in iter_real_cells(worksheet):
        if cell.value is None or is_formula(cell.value):
            continue

        if normalize_text(cell.value) in accepted_headers:
            locations.append((cell.column, cell.row))

    return locations


def is_cell_in_instrument_table_column(cell, instrument_table_columns):
    """
    Return True only when the cell is below an Instrument Type/Issuer Name
    header and in the same column as that header.

    This keeps changes out of COMPOSITION BY ASSET (%), sector composition,
    rating composition, and all other tables.
    """
    return any(
        cell.column == header_column and cell.row > header_row
        for header_column, header_row in instrument_table_columns
    )


def is_equity_in_instrument_table(cell, instrument_table_columns):
    """Return True only for an exact Equity cell in the instrument table."""
    return (
        is_equity_heading(cell.value)
        and is_cell_in_instrument_table_column(
            cell,
            instrument_table_columns,
        )
    )


def is_current_asset_in_instrument_table(cell, instrument_table_columns):
    """
    Return True only for a recognized current-assets heading in the
    Instrument Type/Issuer Name table.
    """
    return (
        is_current_asset_heading(cell.value)
        and is_cell_in_instrument_table_column(
            cell,
            instrument_table_columns,
        )
    )


# ============================================================
# Workbook helpers
# ============================================================

def workbook_load_options(file_path):
    suffix = Path(file_path).suffix.lower()

    if suffix not in {".xlsx", ".xlsm"}:
        raise ValueError(
            f"Unsupported file type: {suffix}\n"
            "Please select an .xlsx or .xlsm workbook."
        )

    return {
        "data_only": False,
        "read_only": False,
        "keep_links": True,
        "keep_vba": suffix == ".xlsm",
    }


def load_excel_workbook(file_path):
    return load_workbook(file_path, **workbook_load_options(file_path))


def iter_real_cells(worksheet):
    for row in worksheet.iter_rows():
        for cell in row:
            if not isinstance(cell, MergedCell):
                yield cell


def get_sheet_search_text(worksheet, max_rows=25, max_columns=12):
    """Build searchable text from sheet name and the top area of a sheet."""
    parts = [worksheet.title]

    row_limit = min(worksheet.max_row, max_rows)
    column_limit = min(worksheet.max_column, max_columns)

    for row in worksheet.iter_rows(
        min_row=1,
        max_row=row_limit,
        min_col=1,
        max_col=column_limit,
    ):
        for cell in row:
            if isinstance(cell, MergedCell):
                continue

            if cell.value is not None and not is_formula(cell.value):
                parts.append(clean_text(cell.value))

    return normalize_text(" | ".join(parts))


def find_matching_sheets(workbook, search_term, all_funds):
    """Find sheets by sheet name, fund code, or fund name."""
    result = []

    if all_funds:
        for worksheet in workbook.worksheets:
            if not is_index_sheet(worksheet.title):
                result.append(worksheet.title)
        return result

    term = normalize_text(search_term)

    if not term:
        return []

    for worksheet in workbook.worksheets:
        if is_index_sheet(worksheet.title):
            continue

        if term in get_sheet_search_text(worksheet):
            result.append(worksheet.title)

    return result


def find_corresponding_old_sheet(old_workbook, new_sheet):
    """
    Match the new fund sheet to the old fund sheet using, in order:
    exact sheet name, normalized sheet name, and fund identifiers.
    """
    if new_sheet.title in old_workbook.sheetnames:
        return old_workbook[new_sheet.title]

    normalized_new_title = normalize_text(new_sheet.title)

    for old_sheet in old_workbook.worksheets:
        if normalize_text(old_sheet.title) == normalized_new_title:
            return old_sheet

    new_search_text = get_sheet_search_text(new_sheet)
    candidates = []

    for row in new_sheet.iter_rows(
        min_row=1,
        max_row=min(new_sheet.max_row, 15),
        min_col=1,
        max_col=min(new_sheet.max_column, 8),
    ):
        for cell in row:
            if isinstance(cell, MergedCell):
                continue

            value = clean_text(cell.value)

            if not value or is_formula(cell.value):
                continue

            normalized = normalize_text(value)

            if re.fullmatch(r"[A-Z0-9_-]{4,20}", value):
                candidates.append(normalized)
            elif any(
                word in normalized
                for word in ("fund", "etf", "plan", "scheme")
            ):
                candidates.append(normalized)

    candidates = list(dict.fromkeys(candidates))

    for old_sheet in old_workbook.worksheets:
        if is_index_sheet(old_sheet.title):
            continue

        old_search_text = get_sheet_search_text(old_sheet)

        for candidate in candidates:
            if candidate and candidate in old_search_text:
                return old_sheet

    for old_sheet in old_workbook.worksheets:
        if is_index_sheet(old_sheet.title):
            continue

        old_search_text = get_sheet_search_text(old_sheet)

        if (
            normalized_new_title in old_search_text
            or normalize_text(old_sheet.title) in new_search_text
        ):
            return old_sheet

    return None


def get_old_current_asset_label(old_sheet):
    """
    Return the current-assets heading only from the old sheet's
    Instrument Type/Issuer Name table.

    The same wording in COMPOSITION BY ASSET (%) or another table is ignored.
    """
    if old_sheet is None:
        return None

    instrument_table_columns = find_instrument_table_columns(old_sheet)

    if not instrument_table_columns:
        return None

    for cell in iter_real_cells(old_sheet):
        if cell.value is None or is_formula(cell.value):
            continue

        if is_current_asset_in_instrument_table(
            cell,
            instrument_table_columns,
        ):
            return clean_text(cell.value)

    return None


def create_output_path(new_file_path):
    """
    Save the processed workbook inside an 'output' folder located
    beside the selected new portfolio workbook.

    Example:
        C:/Portfolio/New_Portfolio.xlsx
        -> C:/Portfolio/output/New_Portfolio_Labels_Updated_....xlsx
    """
    path = Path(new_file_path)
    output_folder = path.parent / "output"
    output_folder.mkdir(parents=True, exist_ok=True)

    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    output_name = (
        f"{safe_filename_part(path.stem)}"
        f"_Labels_Updated_{timestamp}{path.suffix}"
    )
    return str(output_folder / output_name)


# ============================================================
# Processing worker
# ============================================================

class WorkbookWorker(QObject):
    progress = pyqtSignal(int)
    log = pyqtSignal(str)
    finished = pyqtSignal(str, list)
    failed = pyqtSignal(str)

    def __init__(
        self,
        old_file,
        new_file,
        search_term,
        all_funds,
        use_old_current_asset_label,
        selected_current_asset_label,
        make_backup,
    ):
        super().__init__()
        self.old_file = old_file
        self.new_file = new_file
        self.search_term = search_term
        self.all_funds = all_funds
        self.use_old_current_asset_label = use_old_current_asset_label
        self.selected_current_asset_label = selected_current_asset_label
        self.make_backup = make_backup

    def run(self):
        old_workbook = None
        new_workbook = None

        try:
            self.progress.emit(2)
            self.log.emit("Loading old portfolio workbook...")
            old_workbook = load_excel_workbook(self.old_file)

            self.progress.emit(8)
            self.log.emit("Loading new portfolio workbook...")
            new_workbook = load_excel_workbook(self.new_file)

            self.progress.emit(15)

            target_sheets = find_matching_sheets(
                workbook=new_workbook,
                search_term=self.search_term,
                all_funds=self.all_funds,
            )

            if not target_sheets:
                raise ValueError(
                    "No matching fund sheet was found.\n\n"
                    "Search using the fund code, fund name, or sheet name, "
                    "or select 'Process all fund sheets'."
                )

            self.log.emit(f"Found {len(target_sheets)} target fund sheet(s).")
            output_path = create_output_path(self.new_file)

            if self.make_backup:
                source = Path(self.new_file)
                output_folder = Path(output_path).parent
                timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
                backup_path = output_folder / (
                    f"{source.stem}_Backup_{timestamp}{source.suffix}"
                )
                shutil.copy2(self.new_file, backup_path)
                self.log.emit(f"Backup created: {backup_path}")

            changes = []
            total_sheets = len(target_sheets)

            for sheet_number, sheet_name in enumerate(target_sheets, start=1):
                new_sheet = new_workbook[sheet_name]
                old_sheet = find_corresponding_old_sheet(old_workbook, new_sheet)

                if old_sheet is not None:
                    self.log.emit(
                        f"[{sheet_name}] Matched old sheet: {old_sheet.title}"
                    )
                else:
                    self.log.emit(
                        f"[{sheet_name}] No corresponding old sheet found. "
                        "Using the selected fallback current-assets heading."
                    )

                old_current_asset_label = get_old_current_asset_label(old_sheet)

                if self.use_old_current_asset_label and old_current_asset_label:
                    target_current_asset_label = old_current_asset_label
                    self.log.emit(
                        f"[{sheet_name}] Current-assets label found in old "
                        f"instrument table: {old_current_asset_label}"
                    )
                else:
                    target_current_asset_label = self.selected_current_asset_label
                    self.log.emit(
                        f"[{sheet_name}] No current-assets label found in the "
                        "old Instrument Type/Issuer Name table. Using fallback: "
                        f"{target_current_asset_label}"
                    )

                self.log.emit(
                    f"[{sheet_name}] Current-assets target: "
                    f"{target_current_asset_label}"
                )

                sheet_change_count = 0
                instrument_table_columns = find_instrument_table_columns(new_sheet)

                if instrument_table_columns:
                    locations = ", ".join(
                        f"column {column}, header row {row}"
                        for column, row in instrument_table_columns
                    )
                    self.log.emit(
                        f"[{sheet_name}] Instrument table found at {locations}."
                    )
                else:
                    self.log.emit(
                        f"[{sheet_name}] Instrument Type/Issuer Name header "
                        "not found; no Equity heading will be changed."
                    )

                for cell in iter_real_cells(new_sheet):
                    value = cell.value

                    if value is None or is_formula(value):
                        continue

                    old_value = clean_text(value)
                    new_value = None
                    reason = None

                    # Change Equity only inside the Instrument Type/Issuer Name table.
                    # Equity in COMPOSITION BY ASSET (%) or any other table is untouched.
                    if is_equity_in_instrument_table(
                        cell,
                        instrument_table_columns,
                    ):
                        new_value = "EQUITY"
                        reason = (
                            "Equity heading converted to uppercase only in "
                            "Instrument Type/Issuer Name table"
                        )

                    # Standardize a current-assets heading only inside the
                    # Instrument Type/Issuer Name table. The same wording in
                    # COMPOSITION BY ASSET (%) or any other table is untouched.
                    elif is_current_asset_in_instrument_table(
                        cell,
                        instrument_table_columns,
                    ):
                        new_value = target_current_asset_label
                        reason = (
                            "Current-assets heading standardized only in "
                            "Instrument Type/Issuer Name table"
                        )

                    # Compare original display text so Equity -> EQUITY is saved.
                    if new_value is not None and old_value != new_value:
                        cell.value = new_value
                        sheet_change_count += 1

                        changes.append(
                            {
                                "sheet": sheet_name,
                                "cell": cell.coordinate,
                                "old": old_value,
                                "new": new_value,
                                "reason": reason,
                            }
                        )

                self.log.emit(f"[{sheet_name}] {sheet_change_count} change(s).")
                progress_value = 15 + int((sheet_number / total_sheets) * 75)
                self.progress.emit(progress_value)

            if not changes:
                self.log.emit(
                    "No recognized headings required a change. "
                    "An output copy will still be created."
                )

            self.progress.emit(92)
            self.log.emit("Saving updated workbook...")
            new_workbook.save(output_path)

            self.progress.emit(100)
            self.log.emit(f"Completed. Total changes: {len(changes)}")
            self.finished.emit(output_path, changes)

        except Exception:
            self.failed.emit(traceback.format_exc())

        finally:
            if old_workbook is not None:
                old_workbook.close()
            if new_workbook is not None:
                new_workbook.close()


# ============================================================
# GUI
# ============================================================

class PortfolioUpdaterWindow(QMainWindow):
    def __init__(self):
        super().__init__()
        self.worker_thread = None
        self.worker = None
        self.last_output_path = None

        self.setWindowTitle("Portfolio Label Updater")
        self.resize(1050, 760)
        self.build_ui()
        self.apply_styles()

    def build_ui(self):
        central_widget = QWidget()
        self.setCentralWidget(central_widget)

        main_layout = QVBoxLayout(central_widget)
        main_layout.setSpacing(12)

        title = QLabel("Portfolio Label Updater")
        title_font = QFont()
        title_font.setPointSize(17)
        title_font.setBold(True)
        title.setFont(title_font)

        description = QLabel(
            "Change Equity and recognized current-assets headings only inside "
            "the Instrument Type/Issuer Name table. Values in asset, sector, "
            "rating, and other tables are untouched. No rows, columns, sheets, "
            "formulas, or holding data are removed. The result and optional "
            "backup are saved in an output folder beside the new portfolio."
        )
        description.setWordWrap(True)

        main_layout.addWidget(title)
        main_layout.addWidget(description)

        file_group = QGroupBox("1. Select portfolio workbooks")
        file_form = QFormLayout(file_group)

        old_file_row = QHBoxLayout()
        self.old_file_edit = QLineEdit()
        self.old_file_edit.setPlaceholderText(
            "Select the old portfolio workbook used as reference"
        )
        old_browse_button = QPushButton("Browse...")
        old_browse_button.clicked.connect(self.select_old_file)
        old_file_row.addWidget(self.old_file_edit)
        old_file_row.addWidget(old_browse_button)

        new_file_row = QHBoxLayout()
        self.new_file_edit = QLineEdit()
        self.new_file_edit.setPlaceholderText(
            "Select the new portfolio workbook to update"
        )
        new_browse_button = QPushButton("Browse...")
        new_browse_button.clicked.connect(self.select_new_file)
        new_file_row.addWidget(self.new_file_edit)
        new_file_row.addWidget(new_browse_button)

        file_form.addRow("Old portfolio:", old_file_row)
        file_form.addRow("New portfolio:", new_file_row)
        main_layout.addWidget(file_group)

        fund_group = QGroupBox("2. Select fund sheets")
        fund_layout = QVBoxLayout(fund_group)

        self.all_funds_checkbox = QCheckBox(
            "Process all fund sheets except INDEX/Summary sheets"
        )
        self.all_funds_checkbox.setChecked(True)
        self.all_funds_checkbox.stateChanged.connect(
            self.handle_all_funds_changed
        )

        search_row = QHBoxLayout()
        search_label = QLabel("Fund search:")
        self.fund_search_edit = QLineEdit()
        self.fund_search_edit.setPlaceholderText(
            "Enter sheet name, fund code, or fund name"
        )
        self.fund_search_edit.setEnabled(False)

        preview_button = QPushButton("Find Sheets")
        preview_button.clicked.connect(self.preview_matching_sheets)

        search_row.addWidget(search_label)
        search_row.addWidget(self.fund_search_edit, 1)
        search_row.addWidget(preview_button)

        fund_layout.addWidget(self.all_funds_checkbox)
        fund_layout.addLayout(search_row)
        main_layout.addWidget(fund_group)

        settings_group = QGroupBox("3. Replacement settings")
        settings_form = QFormLayout(settings_group)

        equity_result = QLabel(
            "<b>Equity</b> -> <b>EQUITY</b> only under "
            "<b>Instrument Type/Issuer Name</b>. Current-assets headings are "
            "also changed only in this same table."
        )
        settings_form.addRow("Equity heading:", equity_result)

        self.use_old_label_checkbox = QCheckBox(
            "Use the corresponding old fund sheet's current-assets heading"
        )
        self.use_old_label_checkbox.setChecked(True)
        self.use_old_label_checkbox.stateChanged.connect(
            self.handle_old_label_changed
        )

        self.current_asset_combo = QComboBox()
        self.current_asset_combo.setEditable(True)
        self.current_asset_combo.addItems(
            [
                "Net Current Assets",
                "Cash & Other Net Current Assets",
                "Debt, Cash & other current assets",
            ]
        )
        self.current_asset_combo.setCurrentText(STANDARD_CURRENT_ASSET_LABEL)
        self.current_asset_combo.setEnabled(False)

        current_label_container = QVBoxLayout()
        current_label_container.addWidget(self.use_old_label_checkbox)
        current_label_container.addWidget(
            QLabel(
                "If no recognized heading exists in the old sheet, use:"
            )
        )
        current_label_container.addWidget(self.current_asset_combo)

        settings_form.addRow(
            "Current-assets heading:",
            current_label_container,
        )

        self.backup_checkbox = QCheckBox(
            "Create a backup copy of the selected new workbook"
        )
        self.backup_checkbox.setChecked(True)
        settings_form.addRow("Backup:", self.backup_checkbox)
        main_layout.addWidget(settings_group)

        controls_layout = QHBoxLayout()

        self.run_button = QPushButton("Run Changes")
        self.run_button.setObjectName("primaryButton")
        self.run_button.clicked.connect(self.start_processing)

        self.open_folder_button = QPushButton("Open Output Folder")
        self.open_folder_button.setEnabled(False)
        self.open_folder_button.clicked.connect(self.open_output_folder)

        controls_layout.addWidget(self.run_button)
        controls_layout.addWidget(self.open_folder_button)
        controls_layout.addStretch()
        main_layout.addLayout(controls_layout)

        self.progress_bar = QProgressBar()
        self.progress_bar.setRange(0, 100)
        self.progress_bar.setValue(0)
        main_layout.addWidget(self.progress_bar)

        self.result_table = QTableWidget(0, 5)
        self.result_table.setHorizontalHeaderLabels(
            ["Sheet", "Cell", "Old value", "New value", "Reason"]
        )
        self.result_table.setAlternatingRowColors(True)
        self.result_table.setEditTriggers(
            QTableWidget.EditTrigger.NoEditTriggers
        )
        self.result_table.horizontalHeader().setSectionResizeMode(
            QHeaderView.ResizeMode.Stretch
        )
        self.result_table.setMinimumHeight(180)

        main_layout.addWidget(QLabel("Changes made"))
        main_layout.addWidget(self.result_table)

        self.log_box = QPlainTextEdit()
        self.log_box.setReadOnly(True)
        self.log_box.setMaximumBlockCount(3000)
        self.log_box.setMinimumHeight(130)

        main_layout.addWidget(QLabel("Processing log"))
        main_layout.addWidget(self.log_box)

    def apply_styles(self):
        self.setStyleSheet(
            """
            QMainWindow { background-color: #f5f7fa; }
            QGroupBox {
                background-color: white;
                border: 1px solid #cfd6df;
                border-radius: 7px;
                margin-top: 10px;
                padding: 12px;
                font-weight: bold;
            }
            QGroupBox::title {
                subcontrol-origin: margin;
                left: 12px;
                padding: 0 5px;
            }
            QLineEdit, QComboBox, QPlainTextEdit, QTableWidget {
                background-color: white;
                border: 1px solid #b8c1cc;
                border-radius: 4px;
                padding: 5px;
            }
            QPushButton {
                padding: 7px 13px;
                border: 1px solid #9aa5b1;
                border-radius: 5px;
                background-color: #ffffff;
            }
            QPushButton:hover { background-color: #edf2f7; }
            QPushButton:disabled {
                color: #8b949e;
                background-color: #e9ecef;
            }
            QPushButton#primaryButton {
                background-color: #1769aa;
                color: white;
                border: 1px solid #1769aa;
                font-weight: bold;
            }
            QPushButton#primaryButton:hover { background-color: #12558a; }
            QProgressBar {
                border: 1px solid #b8c1cc;
                border-radius: 4px;
                text-align: center;
                min-height: 20px;
                background-color: white;
            }
            QProgressBar::chunk { background-color: #2e7d32; }
            """
        )

    def select_old_file(self):
        path, _ = QFileDialog.getOpenFileName(
            self,
            "Select Old Portfolio",
            "",
            "Excel Workbooks (*.xlsx *.xlsm)",
        )
        if path:
            self.old_file_edit.setText(path)

    def select_new_file(self):
        path, _ = QFileDialog.getOpenFileName(
            self,
            "Select New Portfolio",
            "",
            "Excel Workbooks (*.xlsx *.xlsm)",
        )
        if path:
            self.new_file_edit.setText(path)

    def handle_all_funds_changed(self):
        self.fund_search_edit.setEnabled(
            not self.all_funds_checkbox.isChecked()
        )

    def handle_old_label_changed(self):
        # The combo remains the fallback even while old-sheet matching is active.
        self.current_asset_combo.setEnabled(
            not self.use_old_label_checkbox.isChecked()
        )

    def validate_inputs(self):
        old_file = self.old_file_edit.text().strip()
        new_file = self.new_file_edit.text().strip()

        if not old_file or not os.path.isfile(old_file):
            QMessageBox.warning(
                self,
                "Old portfolio required",
                "Please select a valid old portfolio workbook.",
            )
            return False

        if not new_file or not os.path.isfile(new_file):
            QMessageBox.warning(
                self,
                "New portfolio required",
                "Please select a valid new portfolio workbook.",
            )
            return False

        if os.path.abspath(old_file) == os.path.abspath(new_file):
            QMessageBox.warning(
                self,
                "Different files required",
                "The old and new portfolio paths must be different.",
            )
            return False

        if not self.all_funds_checkbox.isChecked():
            if not self.fund_search_edit.text().strip():
                QMessageBox.warning(
                    self,
                    "Fund search required",
                    "Enter a sheet name, fund code, or fund name.",
                )
                return False

        if not self.current_asset_combo.currentText().strip():
            QMessageBox.warning(
                self,
                "Heading required",
                "Enter the fallback current-assets heading.",
            )
            return False

        return True

    def preview_matching_sheets(self):
        new_file = self.new_file_edit.text().strip()

        if not new_file or not os.path.isfile(new_file):
            QMessageBox.warning(
                self,
                "New portfolio required",
                "Select the new portfolio workbook first.",
            )
            return

        workbook = None

        try:
            workbook = load_excel_workbook(new_file)
            sheets = find_matching_sheets(
                workbook=workbook,
                search_term=self.fund_search_edit.text().strip(),
                all_funds=self.all_funds_checkbox.isChecked(),
            )

            if not sheets:
                QMessageBox.information(
                    self,
                    "No matching sheets",
                    "No fund sheet matched the selected search.",
                )
                return

            preview = "\n".join(sheets[:50])
            if len(sheets) > 50:
                preview += f"\n\n...and {len(sheets) - 50} more."

            QMessageBox.information(
                self,
                f"{len(sheets)} matching sheet(s)",
                preview,
            )

        except Exception as error:
            QMessageBox.critical(
                self,
                "Unable to read workbook",
                str(error),
            )

        finally:
            if workbook is not None:
                workbook.close()

    def start_processing(self):
        if not self.validate_inputs():
            return

        self.result_table.setRowCount(0)
        self.log_box.clear()
        self.progress_bar.setValue(0)
        self.open_folder_button.setEnabled(False)
        self.run_button.setEnabled(False)

        self.worker_thread = QThread()
        self.worker = WorkbookWorker(
            old_file=self.old_file_edit.text().strip(),
            new_file=self.new_file_edit.text().strip(),
            search_term=self.fund_search_edit.text().strip(),
            all_funds=self.all_funds_checkbox.isChecked(),
            use_old_current_asset_label=(
                self.use_old_label_checkbox.isChecked()
            ),
            selected_current_asset_label=(
                self.current_asset_combo.currentText().strip()
            ),
            make_backup=self.backup_checkbox.isChecked(),
        )

        self.worker.moveToThread(self.worker_thread)
        self.worker_thread.started.connect(self.worker.run)
        self.worker.progress.connect(self.progress_bar.setValue)
        self.worker.log.connect(self.append_log)
        self.worker.finished.connect(self.processing_finished)
        self.worker.failed.connect(self.processing_failed)
        self.worker.finished.connect(self.worker_thread.quit)
        self.worker.failed.connect(self.worker_thread.quit)
        self.worker_thread.finished.connect(self.worker.deleteLater)
        self.worker_thread.finished.connect(self.worker_thread.deleteLater)
        self.worker_thread.start()

    def append_log(self, message):
        timestamp = datetime.now().strftime("%H:%M:%S")
        self.log_box.appendPlainText(f"[{timestamp}] {message}")

    def processing_finished(self, output_path, changes):
        self.last_output_path = output_path
        self.run_button.setEnabled(True)
        self.open_folder_button.setEnabled(True)

        for change in changes:
            row = self.result_table.rowCount()
            self.result_table.insertRow(row)

            values = [
                change["sheet"],
                change["cell"],
                change["old"],
                change["new"],
                change["reason"],
            ]

            for column, value in enumerate(values):
                item = QTableWidgetItem(str(value))
                item.setToolTip(str(value))
                self.result_table.setItem(row, column, item)

        QMessageBox.information(
            self,
            "Completed",
            f"Workbook updated successfully.\n\n"
            f"Changes made: {len(changes)}\n"
            f"Output file:\n{output_path}",
        )

    def processing_failed(self, error_details):
        self.run_button.setEnabled(True)
        self.progress_bar.setValue(0)
        self.append_log("ERROR")
        self.append_log(error_details)

        final_line = error_details.strip().splitlines()[-1]
        QMessageBox.critical(
            self,
            "Processing failed",
            "The workbook could not be updated.\n\n"
            f"{final_line}\n\n"
            "See the processing log for details.",
        )

    def open_output_folder(self):
        if not self.last_output_path:
            return

        folder = str(Path(self.last_output_path).parent)

        try:
            if sys.platform.startswith("win"):
                os.startfile(folder)
            elif sys.platform == "darwin":
                import subprocess
                subprocess.run(["open", folder], check=False)
            else:
                import subprocess
                subprocess.run(["xdg-open", folder], check=False)
        except Exception as error:
            QMessageBox.warning(
                self,
                "Unable to open folder",
                str(error),
            )


def main():
    app = QApplication(sys.argv)
    app.setApplicationName("Portfolio Label Updater")

    window = PortfolioUpdaterWindow()
    window.show()

    sys.exit(app.exec())


if __name__ == "__main__":
    main()
