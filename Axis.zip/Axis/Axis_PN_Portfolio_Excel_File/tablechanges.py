import os
import sys
import math
import traceback
from copy import copy
from pathlib import Path

from openpyxl import load_workbook
from openpyxl.utils import get_column_letter
from PyQt6.QtCore import Qt, QThread, pyqtSignal
from PyQt6.QtGui import QFont
from PyQt6.QtWidgets import (
    QApplication, QMainWindow, QWidget, QVBoxLayout, QHBoxLayout,
    QPushButton, QFileDialog, QListWidget, QPlainTextEdit, QLabel,
    QMessageBox, QProgressBar, QTableWidget, QTableWidgetItem,
    QHeaderView, QAbstractItemView, QCheckBox
)

TITLE = "COMPOSITION BY RATING"
NCA = "NET CURRENT ASSETS"
PERCENT_HEADER = "% OF NET ASSETS"
OTHER_COMPOSITION_PREFIX = "COMPOSITION BY"


def norm(value):
    if value is None:
        return ""
    return " ".join(str(value).strip().upper().split())


def number_from_cell(cell):
    """Return a decimal value, e.g. 51% -> 0.51."""
    value = cell.value
    if value is None or value == "":
        return None
    if isinstance(value, bool):
        return None
    if isinstance(value, (int, float)):
        if not math.isfinite(float(value)):
            return None
        return float(value)
    text = str(value).strip().replace(",", "")
    try:
        if text.endswith("%"):
            return float(text[:-1].strip()) / 100.0
        return float(text)
    except ValueError:
        return None


def copy_cell_style(source, target):
    if source.has_style:
        target._style = copy(source._style)
    if source.number_format:
        target.number_format = source.number_format
    target.font = copy(source.font)
    target.fill = copy(source.fill)
    target.border = copy(source.border)
    target.alignment = copy(source.alignment)
    target.protection = copy(source.protection)


def get_fund_map(workbook):
    """Read Sheet Name -> Fund Name from an Index sheet when available."""
    result = {}
    index_ws = None
    for ws in workbook.worksheets:
        if norm(ws.title) == "INDEX":
            index_ws = ws
            break
    if index_ws is None:
        return result

    headers = {}
    for row in index_ws.iter_rows(min_row=1, max_row=min(index_ws.max_row, 20)):
        for cell in row:
            n = norm(cell.value)
            if n in ("SHEET NAME", "FUND NAME", "FUND CODE"):
                headers[n] = (cell.row, cell.column)
        if "SHEET NAME" in headers and "FUND NAME" in headers:
            break

    if "SHEET NAME" not in headers or "FUND NAME" not in headers:
        return result
    header_row = headers["SHEET NAME"][0]
    sheet_col = headers["SHEET NAME"][1]
    fund_col = headers["FUND NAME"][1]
    for r in range(header_row + 1, index_ws.max_row + 1):
        sheet_name = index_ws.cell(r, sheet_col).value
        fund_name = index_ws.cell(r, fund_col).value
        if sheet_name:
            result[str(sheet_name).strip()] = str(fund_name).strip() if fund_name else str(sheet_name).strip()
    return result


def find_rating_headers(ws):
    found = []
    for row in ws.iter_rows():
        for cell in row:
            if norm(cell.value) == TITLE:
                value_col = cell.column + 1
                # Normally adjacent. If not, locate the percentage header nearby.
                for c in range(cell.column + 1, min(ws.max_column, cell.column + 3) + 1):
                    if norm(ws.cell(cell.row, c).value) == PERCENT_HEADER:
                        value_col = c
                        break
                found.append((cell.row, cell.column, value_col))
    return found


def find_table_rows(ws, header_row, label_col, value_col):
    """Return rating rows belonging to one rating table.

    Stops at blank space, another table heading, or Net Current Assets.
    Allows occasional blank rows only before data starts.
    """
    rows = []
    max_scan = min(ws.max_row, header_row + 100)
    started = False
    for r in range(header_row + 1, max_scan + 1):
        label = norm(ws.cell(r, label_col).value)
        value = number_from_cell(ws.cell(r, value_col))

        if label == NCA:
            rows.append((r, "existing_nca"))
            break
        if label.startswith(OTHER_COMPOSITION_PREFIX):
            break
        if label in {"GRAND TOTAL", "TOTAL"}:
            break

        if label and value is not None:
            rows.append((r, "rating"))
            started = True
            continue

        if started:
            # The rating tables in these workbooks are contiguous. The first
            # blank/non-numeric row marks the end of the table.
            break
    return rows


def select_target_row(ws, header_row, label_col, value_col, table_rows):
    existing = [r for r, kind in table_rows if kind == "existing_nca"]
    if existing:
        return existing[0], True
    rating_rows = [r for r, kind in table_rows if kind == "rating"]
    target = (max(rating_rows) + 1) if rating_rows else (header_row + 1)
    # Safety: never overwrite unrelated content.
    label_empty = ws.cell(target, label_col).value in (None, "")
    value_empty = ws.cell(target, value_col).value in (None, "")
    if not (label_empty and value_empty):
        raise ValueError(
            f"No empty row available below rating data at "
            f"{get_column_letter(label_col)}{target}:{get_column_letter(value_col)}{target}"
        )
    return target, False


def process_workbook(input_path, overwrite_existing=True):
    input_path = Path(input_path)
    suffix = input_path.suffix.lower()
    if suffix not in (".xlsx", ".xlsm"):
        raise ValueError("Only .xlsx and .xlsm files are supported.")

    keep_vba = suffix == ".xlsm"
    wb = load_workbook(input_path, data_only=False, keep_vba=keep_vba)
    fund_map = get_fund_map(wb)
    results = []

    for ws in wb.worksheets:
        for header_row, label_col, value_col in find_rating_headers(ws):
            table_rows = find_table_rows(ws, header_row, label_col, value_col)
            rating_rows = [r for r, kind in table_rows if kind == "rating"]
            existing_rows = [r for r, kind in table_rows if kind == "existing_nca"]

            if not rating_rows:
                results.append({
                    "sheet": ws.title,
                    "fund": fund_map.get(ws.title, ws.title),
                    "status": "Skipped: no numeric rating rows",
                    "rating_total": None,
                    "nca": None,
                    "cell": ""
                })
                continue

            rating_total = sum(number_from_cell(ws.cell(r, value_col)) or 0.0 for r in rating_rows)
            nca_value = 1.0 - rating_total
            # Prevent floating point noise such as -0.0000000001.
            if abs(nca_value) < 0.0000000005:
                nca_value = 0.0

            target_row, existed = select_target_row(
                ws, header_row, label_col, value_col, table_rows
            )
            if existed and not overwrite_existing:
                status = "Found: existing Net Current Assets kept"
            else:
                style_source_row = rating_rows[-1]
                copy_cell_style(ws.cell(style_source_row, label_col), ws.cell(target_row, label_col))
                copy_cell_style(ws.cell(style_source_row, value_col), ws.cell(target_row, value_col))
                ws.cell(target_row, label_col).value = "Net Current Assets"
                ws.cell(target_row, value_col).value = nca_value
                ws.cell(target_row, value_col).number_format = "0.00%"
                status = "Updated existing row" if existed else "Added"

            results.append({
                "sheet": ws.title,
                "fund": fund_map.get(ws.title, ws.title),
                "status": status,
                "rating_total": rating_total,
                "nca": nca_value,
                "cell": f"{get_column_letter(label_col)}{target_row}:{get_column_letter(value_col)}{target_row}"
            })

    output_path = input_path.with_name(input_path.stem + "_rating_nca" + input_path.suffix)
    counter = 2
    while output_path.exists():
        output_path = input_path.with_name(input_path.stem + f"_rating_nca_{counter}" + input_path.suffix)
        counter += 1
    wb.save(output_path)
    return output_path, results


class Worker(QThread):
    progress = pyqtSignal(int, int, str)
    file_done = pyqtSignal(str, str, object)
    failed = pyqtSignal(str, str)
    finished_all = pyqtSignal()

    def __init__(self, files, overwrite_existing):
        super().__init__()
        self.files = files
        self.overwrite_existing = overwrite_existing

    def run(self):
        total = len(self.files)
        for i, file_path in enumerate(self.files, start=1):
            self.progress.emit(i - 1, total, f"Processing: {file_path}")
            try:
                output_path, rows = process_workbook(file_path, self.overwrite_existing)
                self.file_done.emit(file_path, str(output_path), rows)
            except Exception:
                self.failed.emit(file_path, traceback.format_exc())
            self.progress.emit(i, total, f"Completed {i} of {total}")
        self.finished_all.emit()


class MainWindow(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("Composition by Rating - Net Current Assets")
        self.resize(1100, 720)
        self.files = []
        self.worker = None

        root = QWidget()
        self.setCentralWidget(root)
        layout = QVBoxLayout(root)

        title = QLabel("Add Net Current Assets to COMPOSITION BY RATING tables")
        title.setFont(QFont("Segoe UI", 16, QFont.Weight.Bold))
        layout.addWidget(title)

        info = QLabel(
            "For each rating table, the app sums all rating percentages and writes "
            "Net Current Assets = 100% - rating total. Output is saved as a new workbook."
        )
        info.setWordWrap(True)
        layout.addWidget(info)

        buttons = QHBoxLayout()
        self.add_button = QPushButton("Select Excel file(s)")
        self.remove_button = QPushButton("Remove selected")
        self.clear_button = QPushButton("Clear")
        buttons.addWidget(self.add_button)
        buttons.addWidget(self.remove_button)
        buttons.addWidget(self.clear_button)
        buttons.addStretch()
        layout.addLayout(buttons)

        self.file_list = QListWidget()
        self.file_list.setSelectionMode(QAbstractItemView.SelectionMode.ExtendedSelection)
        layout.addWidget(self.file_list, 1)

        option_row = QHBoxLayout()
        self.overwrite_box = QCheckBox("Recalculate an existing Net Current Assets row")
        self.overwrite_box.setChecked(True)
        option_row.addWidget(self.overwrite_box)
        option_row.addStretch()
        self.run_button = QPushButton("Process files")
        self.run_button.setMinimumHeight(38)
        option_row.addWidget(self.run_button)
        layout.addLayout(option_row)

        self.progress = QProgressBar()
        layout.addWidget(self.progress)
        self.status = QLabel("Ready")
        layout.addWidget(self.status)

        self.table = QTableWidget(0, 8)
        self.table.setHorizontalHeaderLabels([
            "Input file", "Output file", "Sheet", "Fund", "Rating total",
            "Net Current Assets", "Cell", "Status"
        ])
        self.table.horizontalHeader().setSectionResizeMode(QHeaderView.ResizeMode.ResizeToContents)
        self.table.horizontalHeader().setStretchLastSection(True)
        self.table.setEditTriggers(QAbstractItemView.EditTrigger.NoEditTriggers)
        layout.addWidget(self.table, 3)

        self.log = QPlainTextEdit()
        self.log.setReadOnly(True)
        self.log.setMaximumHeight(130)
        layout.addWidget(self.log)

        self.add_button.clicked.connect(self.select_files)
        self.remove_button.clicked.connect(self.remove_selected)
        self.clear_button.clicked.connect(self.clear_files)
        self.run_button.clicked.connect(self.start_processing)

    def select_files(self):
        selected, _ = QFileDialog.getOpenFileNames(
            self, "Select Excel workbooks", "", "Excel workbooks (*.xlsx *.xlsm)"
        )
        for file_path in selected:
            normalized = os.path.abspath(file_path)
            if normalized not in self.files:
                self.files.append(normalized)
                self.file_list.addItem(normalized)

    def remove_selected(self):
        for item in self.file_list.selectedItems():
            path = item.text()
            if path in self.files:
                self.files.remove(path)
            self.file_list.takeItem(self.file_list.row(item))

    def clear_files(self):
        self.files.clear()
        self.file_list.clear()

    def set_busy(self, busy):
        self.add_button.setEnabled(not busy)
        self.remove_button.setEnabled(not busy)
        self.clear_button.setEnabled(not busy)
        self.run_button.setEnabled(not busy)

    def start_processing(self):
        if not self.files:
            QMessageBox.warning(self, "No files", "Select at least one .xlsx or .xlsm file.")
            return
        self.table.setRowCount(0)
        self.log.clear()
        self.progress.setRange(0, len(self.files))
        self.progress.setValue(0)
        self.set_busy(True)
        self.worker = Worker(list(self.files), self.overwrite_box.isChecked())
        self.worker.progress.connect(self.on_progress)
        self.worker.file_done.connect(self.on_file_done)
        self.worker.failed.connect(self.on_failed)
        self.worker.finished_all.connect(self.on_finished)
        self.worker.start()

    def on_progress(self, current, total, text):
        self.progress.setRange(0, total)
        self.progress.setValue(current)
        self.status.setText(text)

    def on_file_done(self, input_file, output_file, rows):
        self.log.appendPlainText(f"Saved: {output_file}")
        if not rows:
            self.add_result(input_file, output_file, "", "", None, None, "", "No rating table found")
        for row in rows:
            self.add_result(
                input_file, output_file, row["sheet"], row["fund"],
                row["rating_total"], row["nca"], row["cell"], row["status"]
            )

    def add_result(self, input_file, output_file, sheet, fund, total, nca, cell, status):
        r = self.table.rowCount()
        self.table.insertRow(r)
        values = [
            os.path.basename(input_file), os.path.basename(output_file), sheet, fund,
            "" if total is None else f"{total:.2%}",
            "" if nca is None else f"{nca:.2%}", cell, status
        ]
        for c, value in enumerate(values):
            item = QTableWidgetItem(str(value))
            if c in (4, 5):
                item.setTextAlignment(Qt.AlignmentFlag.AlignRight | Qt.AlignmentFlag.AlignVCenter)
            item.setToolTip(str(value))
            self.table.setItem(r, c, item)

    def on_failed(self, file_path, error_text):
        self.log.appendPlainText(f"FAILED: {file_path}\n{error_text}")
        self.add_result(file_path, "", "", "", None, None, "", "Failed; see log")

    def on_finished(self):
        self.set_busy(False)
        self.status.setText("Finished")
        QMessageBox.information(
            self, "Completed",
            "Processing finished. Each output workbook was saved beside its source file."
        )


def main():
    app = QApplication(sys.argv)
    app.setStyle("Fusion")
    window = MainWindow()
    window.show()
    sys.exit(app.exec())


if __name__ == "__main__":
    main()
