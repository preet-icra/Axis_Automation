#!/usr/bin/env python3
"""
Update the Industry/Rating column in a new Axis portfolio workbook using the
previous month's workbook as the Industry master.

The script also:

1. Renames fund worksheets using:
       FUND_CODE - FUND_NAME
2. Converts the Index worksheet to:
       Sr No. | Short Name | Scheme Name
3. Adds clickable hyperlinks to fund codes in the Short Name column.
4. Clicking a fund code opens cell A1 of the corresponding fund worksheet.
5. Adds a clickable "Back to INDEX" link on every fund worksheet.
6. Produces an Audit_Log worksheet showing updates, unmatched issuers,
   classification conflicts, renamed worksheets, and hyperlink results.

Default usage:
    python update_portfolio_industry.py

The graphical interface allows the user to select:
    - Previous-month workbook
    - Current-month workbook
    - Output workbook
"""

from __future__ import annotations

import re
import sys
from collections import Counter, defaultdict
from copy import copy
from pathlib import Path
from typing import Dict, List, Optional, Tuple

from openpyxl import load_workbook
from openpyxl.styles import Alignment, Font, PatternFill
from openpyxl.utils import get_column_letter


# ============================================================
# DEFAULT FILE NAMES
# ============================================================

DEFAULT_OLD = "old_Portfolios - September 2026.xlsx"
DEFAULT_NEW = "Portfolios - October 2026.xlsx"
DEFAULT_OUTPUT = "Portfolios - October 2026 - industry updated.xlsx"


# ============================================================
# HOLDINGS TABLE CONFIGURATION
# ============================================================

SECTION_LABELS = {
    "equity",
    "domestic equities",
    "international equities",
    "debt securities",
    "corporate bond",
    "government bond",
    "state government bond",
    "treasury bill",
    "certificate of deposit",
    "commercial paper",
    "floating rate note",
    "zero coupon bond",
    "government bond strips",
    "ptc",
    "pass through certificate",
    "invit",
    "reit",
    "mutual fund units",
    "exchange traded fund",
    "international mutual fund units",
    "international exchange traded funds",
    "international exchange traded fund",
    "american depository receipt",
    "global depository receipt",
    "physical gold",
    "physical silver",
    "commodity future",
    "corporate debt market development fund",
    "net current assets",
    "debt cash other current assets",
    "debt cash other receivables",
    "cash other net current assets",
    "grand total",
    "net assets",
    "hedge equity",
    "unhedge equity",
    "hedged equity",
    "unhedged equity",
}

STOP_MARKERS = {
    "composition by sector",
    "composition by sector%",
    "composition by country",
    "composition by rating",
    "composition by asset",
    "composition by asset (%)",
}

HEADER_NAME_TOKENS = (
    "instrument type/issuer name",
    "issuer",
)

HEADER_CLASS_TOKENS = (
    "industry/rating",
    "industry",
    "rating",
    "sector",
)

HEADER_VALUE_TOKENS = (
    "% of nav",
    "% of net assets",
    "net exposure % of net assets",
)


# ============================================================
# TEXT HELPERS
# ============================================================

def norm(value: object) -> str:
    """
    Normalize text for dependable matching while preserving
    meaningful symbols.
    """
    if value is None:
        return ""

    text = str(value).replace("\u00a0", " ").strip().lower()
    text = re.sub(r"\s+", " ", text)
    text = text.replace("&", " and ")
    text = re.sub(r"[^a-z0-9%+./() -]", "", text)

    return re.sub(r"\s+", " ", text).strip()


def compact(value: object) -> str:
    """
    Create a more tolerant comparison key.

    This key is used only after exact normalized matching fails.
    """
    text = norm(value)

    replacements = {
        " limited": " ltd",
        " private": " pvt",
        " corporation": " corp",
        " company": " co",
        " and ": " ",
        ".": "",
        "-": " ",
    }

    for old, new in replacements.items():
        text = text.replace(old, new)

    return re.sub(r"[^a-z0-9]", "", text)


def clean_fund_code(text: object) -> str:
    """
    Extract an Axis fund code from text.

    Examples:
        AXIS500
        AXIS500 - Nifty 500 Index
        AXIS500 - HOLDING
    """
    value = str(text or "").strip().upper()
    value = re.sub(r"\s*-\s*HOLDING.*$", "", value)

    match = re.search(r"\bAXIS[A-Z0-9]+\b", value)

    return match.group(0) if match else ""


def escape_excel_sheet_name(sheet_name: str) -> str:
    """
    Escape apostrophes inside an Excel worksheet name.

    Example:
        AXISABC - Children's Fund

    becomes:
        AXISABC - Children''s Fund
    """
    return str(sheet_name).replace("'", "''")


# ============================================================
# INDEX AND FUND CODE HELPERS
# ============================================================

def find_index_sheet(workbook):
    """Find the Index worksheet using a case-insensitive comparison."""
    for worksheet in workbook.worksheets:
        if norm(worksheet.title) == "index":
            return worksheet

    return None


def index_sheet_codes(workbook) -> Dict[str, str]:
    """
    Return a dictionary containing:

        worksheet title -> fund code

    The Index worksheet is used wherever possible.
    """
    result: Dict[str, str] = {}

    worksheet = find_index_sheet(workbook)

    if worksheet is None:
        return result

    header_row = None
    headers: Dict[str, int] = {}

    max_header_row = min(worksheet.max_row, 20)
    max_header_column = min(worksheet.max_column, 10)

    for row_number in range(1, max_header_row + 1):
        row_headers = {
            norm(worksheet.cell(row_number, column).value): column
            for column in range(1, max_header_column + 1)
        }

        if any(
            header in row_headers
            for header in ("short name", "fund code")
        ):
            header_row = row_number
            headers = row_headers
            break

    if header_row is None:
        return result

    code_column = (
        headers.get("fund code")
        or headers.get("short name")
    )

    sheet_column = headers.get("sheet name")

    for row_number in range(header_row + 1, worksheet.max_row + 1):
        code = clean_fund_code(
            worksheet.cell(row_number, code_column).value
        )

        if not code:
            continue

        sheet_title = ""

        if sheet_column:
            sheet_title = str(
                worksheet.cell(row_number, sheet_column).value or ""
            ).strip()

        if sheet_title and sheet_title in workbook.sheetnames:
            result[sheet_title] = code
            continue

        for candidate in workbook.sheetnames:
            if clean_fund_code(candidate) == code:
                result[candidate] = code
                break

    return result


def get_fund_code(
    worksheet,
    index_codes: Dict[str, str],
) -> str:
    """
    Determine the fund code for a worksheet.
    """
    if worksheet.title in index_codes:
        return index_codes[worksheet.title]

    code_from_title = clean_fund_code(worksheet.title)

    if code_from_title:
        return code_from_title

    max_row = min(worksheet.max_row, 8)
    max_column = min(worksheet.max_column, 5)

    for row in worksheet.iter_rows(
        min_row=1,
        max_row=max_row,
        min_col=1,
        max_col=max_column,
    ):
        for cell in row:
            code = clean_fund_code(cell.value)

            if code:
                return code

    return ""


# ============================================================
# HOLDINGS TABLE DETECTION
# ============================================================

def locate_holdings_table(
    worksheet,
) -> Optional[Tuple[int, int, int, int]]:
    """
    Return:

        header_row, issuer_column, classification_column, value_column
    """
    max_row = min(worksheet.max_row, 30)
    max_column = min(worksheet.max_column, 10)

    for row_number in range(1, max_row + 1):
        values = [
            norm(worksheet.cell(row_number, column).value)
            for column in range(1, max_column + 1)
        ]

        issuer_column = next(
            (
                index + 1
                for index, value in enumerate(values)
                if any(
                    token == value or token in value
                    for token in HEADER_NAME_TOKENS
                )
            ),
            None,
        )

        classification_column = next(
            (
                index + 1
                for index, value in enumerate(values)
                if any(
                    token == value
                    for token in HEADER_CLASS_TOKENS
                )
            ),
            None,
        )

        value_column = next(
            (
                index + 1
                for index, value in enumerate(values)
                if any(
                    token == value
                    for token in HEADER_VALUE_TOKENS
                )
            ),
            None,
        )

        if (
            issuer_column
            and classification_column
            and value_column
            and issuer_column < classification_column <= value_column
        ):
            return (
                row_number,
                issuer_column,
                classification_column,
                value_column,
            )

    return None


def is_numeric(value: object) -> bool:
    """Return True only for ordinary numeric values."""
    return (
        isinstance(value, (int, float))
        and not isinstance(value, bool)
    )


def iter_holding_rows(
    worksheet,
    table: Tuple[int, int, int, int],
):
    """
    Iterate through instrument and section rows in a holdings table.
    """
    header_row, issuer_column, class_column, value_column = table

    blank_streak = 0

    for row_number in range(
        header_row + 1,
        worksheet.max_row + 1,
    ):
        issuer = worksheet.cell(
            row_number,
            issuer_column,
        ).value

        classification = worksheet.cell(
            row_number,
            class_column,
        ).value

        weight = worksheet.cell(
            row_number,
            value_column,
        ).value

        issuer_key = norm(issuer)

        if (
            not issuer_key
            and classification is None
            and weight is None
        ):
            blank_streak += 1

            if blank_streak >= 8:
                break

            continue

        blank_streak = 0

        if issuer_key == "grand total":
            yield (
                row_number,
                issuer,
                classification,
                weight,
                "section",
            )
            break

        if any(
            marker in issuer_key
            for marker in STOP_MARKERS
        ):
            continue

        row_type = "instrument"

        if (
            issuer_key in SECTION_LABELS
            or issuer_key.startswith("other domestic equity")
            or issuer_key.startswith("other equity")
        ):
            row_type = "section"

        elif not is_numeric(weight):
            row_type = "section"

        yield (
            row_number,
            issuer,
            classification,
            weight,
            row_type,
        )


# ============================================================
# OLD WORKBOOK MAPPING
# ============================================================

def build_old_mappings(old_workbook):
    """
    Build fund-specific and global consensus Industry dictionaries.
    """
    index_codes = index_sheet_codes(old_workbook)

    fund_map: Dict[str, Dict[str, str]] = defaultdict(dict)
    fund_compact: Dict[str, Dict[str, str]] = defaultdict(dict)

    votes: Dict[str, Counter] = defaultdict(Counter)
    display_names: Dict[str, str] = {}

    for worksheet in old_workbook.worksheets:
        if norm(worksheet.title) == "index":
            continue

        code = get_fund_code(
            worksheet,
            index_codes,
        )

        table = locate_holdings_table(worksheet)

        if not code or not table:
            continue

        for (
            _,
            issuer,
            classification,
            _,
            row_type,
        ) in iter_holding_rows(worksheet, table):

            if row_type != "instrument":
                continue

            if not norm(classification):
                continue

            normalized_key = norm(issuer)
            compact_key = compact(issuer)
            label = str(classification).strip()

            fund_map[code][normalized_key] = label

            if compact_key:
                fund_compact[code][compact_key] = label

            votes[normalized_key][label] += 1
            display_names[normalized_key] = str(issuer).strip()

    global_map: Dict[str, str] = {}
    conflicts: List[Tuple[str, str]] = []

    for normalized_key, choices in votes.items():
        ranked_choices = choices.most_common()

        global_map[normalized_key] = ranked_choices[0][0]

        if len(ranked_choices) > 1:
            conflict_details = "; ".join(
                f"{classification} ({count})"
                for classification, count in ranked_choices
            )

            conflicts.append(
                (
                    display_names.get(
                        normalized_key,
                        normalized_key,
                    ),
                    conflict_details,
                )
            )

    global_compact: Dict[str, str] = {}
    compact_votes: Dict[str, Counter] = defaultdict(Counter)

    for normalized_key, label in global_map.items():
        issuer_display_name = display_names.get(
            normalized_key,
            normalized_key,
        )

        compact_key = compact(issuer_display_name)

        if compact_key:
            compact_votes[compact_key][label] += 1

    for compact_key, choices in compact_votes.items():
        if compact_key:
            global_compact[compact_key] = (
                choices.most_common(1)[0][0]
            )

    return (
        fund_map,
        fund_compact,
        global_map,
        global_compact,
        conflicts,
    )


# ============================================================
# WORKSHEET RENAMING
# ============================================================

def safe_sheet_title(
    desired: str,
    used_titles: set[str],
) -> str:
    """
    Return an Excel-safe and unique worksheet title.

    Excel worksheet titles:
        - Cannot exceed 31 characters
        - Cannot contain: \\ / * ? : [ ]
    """
    cleaned = re.sub(
        r'[\\/*?:\[\]]',
        " ",
        str(desired or ""),
    ).strip()

    cleaned = re.sub(
        r"\s+",
        " ",
        cleaned,
    )

    if not cleaned:
        cleaned = "Fund"

    base = cleaned[:31].rstrip()
    candidate = base
    number = 2

    lowered_titles = {
        name.lower()
        for name in used_titles
    }

    while candidate.lower() in lowered_titles:
        suffix = f" ({number})"

        candidate = (
            f"{base[:31 - len(suffix)].rstrip()}{suffix}"
        )

        number += 1

    return candidate


def old_sheet_titles_by_code(
    old_workbook,
) -> Dict[str, str]:
    """
    Return:

        fund code -> previous workbook worksheet title
    """
    mapping: Dict[str, str] = {}
    index_codes = index_sheet_codes(old_workbook)

    for worksheet in old_workbook.worksheets:
        if norm(worksheet.title) == "index":
            continue

        code = get_fund_code(
            worksheet,
            index_codes,
        )

        if code:
            mapping[code] = worksheet.title

    return mapping


def fallback_fund_title(
    code: str,
    fund_name: str,
) -> str:
    """
    Build a readable worksheet title when the previous workbook
    has no matching fund worksheet.
    """
    name = str(fund_name or "").strip()

    name = re.sub(
        r"^Axis\s+",
        "",
        name,
        flags=re.IGNORECASE,
    )

    name = re.sub(
        r"\s+Fund$",
        "",
        name,
        flags=re.IGNORECASE,
    )

    name = re.sub(
        r"\s+",
        " ",
        name,
    ).strip()

    return f"{code} - {name}" if name else code


def rename_fund_sheets_and_format_index(
    new_workbook,
    old_workbook,
) -> Dict[str, str]:
    """
    Rename fund worksheets and format the Index worksheet as:

        Sr No. | Short Name | Scheme Name

    Returns:
        original worksheet title -> renamed worksheet title
    """
    index_worksheet = find_index_sheet(new_workbook)

    if index_worksheet is None:
        raise ValueError(
            "The current workbook does not contain an Index sheet."
        )

    header_row = None
    headers: Dict[str, int] = {}

    max_header_row = min(index_worksheet.max_row, 20)
    max_header_column = min(index_worksheet.max_column, 10)

    for row_number in range(1, max_header_row + 1):
        row_headers = {
            norm(
                index_worksheet.cell(
                    row_number,
                    column,
                ).value
            ): column
            for column in range(
                1,
                max_header_column + 1,
            )
        }

        if (
            "fund code" in row_headers
            and "fund name" in row_headers
        ):
            header_row = row_number
            headers = row_headers
            break

    if header_row is None:
        raise ValueError(
            "The current Index sheet must contain "
            "Fund Code and Fund Name columns."
        )

    sheet_column = headers.get("sheet name")
    code_column = headers["fund code"]
    name_column = headers["fund name"]

    records = []

    for row_number in range(
        header_row + 1,
        index_worksheet.max_row + 1,
    ):
        code = clean_fund_code(
            index_worksheet.cell(
                row_number,
                code_column,
            ).value
        )

        fund_name = str(
            index_worksheet.cell(
                row_number,
                name_column,
            ).value
            or ""
        ).strip()

        source_title = ""

        if sheet_column:
            source_title = str(
                index_worksheet.cell(
                    row_number,
                    sheet_column,
                ).value
                or ""
            ).strip()

        if code:
            records.append(
                (
                    row_number,
                    code,
                    fund_name,
                    source_title,
                )
            )

    old_titles = old_sheet_titles_by_code(old_workbook)

    used_titles = {
        index_worksheet.title
    }

    renamed: Dict[str, str] = {}

    for (
        _,
        code,
        fund_name,
        source_title,
    ) in records:

        worksheet = None

        if source_title in new_workbook.sheetnames:
            worksheet = new_workbook[source_title]

        else:
            worksheet = next(
                (
                    candidate
                    for candidate in new_workbook.worksheets
                    if candidate is not index_worksheet
                    and clean_fund_code(
                        candidate.title
                    ) == code
                ),
                None,
            )

        if worksheet is None:
            continue

        desired_title = (
            old_titles.get(code)
            or fallback_fund_title(
                code,
                fund_name,
            )
        )

        final_title = safe_sheet_title(
            desired_title,
            used_titles,
        )

        original_title = worksheet.title
        worksheet.title = final_title

        used_titles.add(final_title)
        renamed[original_title] = final_title

    # Excel treats "Index" and "INDEX" as the same title.
    # A temporary name is required to change the capitalization.
    index_worksheet.title = "__INDEX_TEMP__"
    index_worksheet.title = "INDEX"

    # Remove the Sheet Name column.
    if sheet_column:
        index_worksheet.delete_cols(
            sheet_column,
            1,
        )

    # Keep only the first three columns.
    if index_worksheet.max_column > 3:
        index_worksheet.delete_cols(
            4,
            index_worksheet.max_column - 3,
        )

    index_worksheet.cell(
        header_row,
        1,
    ).value = "Sr No."

    index_worksheet.cell(
        header_row,
        2,
    ).value = "Short Name"

    index_worksheet.cell(
        header_row,
        3,
    ).value = "Scheme Name"

    for output_row, (
        _,
        code,
        fund_name,
        _,
    ) in enumerate(
        records,
        start=header_row + 1,
    ):
        index_worksheet.cell(
            output_row,
            1,
        ).value = output_row - header_row

        index_worksheet.cell(
            output_row,
            2,
        ).value = code

        index_worksheet.cell(
            output_row,
            3,
        ).value = fund_name

    first_stale_row = (
        header_row
        + 1
        + len(records)
    )

    if first_stale_row <= index_worksheet.max_row:
        index_worksheet.delete_rows(
            first_stale_row,
            index_worksheet.max_row
            - first_stale_row
            + 1,
        )

    index_worksheet.column_dimensions["A"].width = 8
    index_worksheet.column_dimensions["B"].width = 22
    index_worksheet.column_dimensions["C"].width = 55

    index_worksheet.freeze_panes = (
        f"A{header_row + 1}"
    )

    return renamed


# ============================================================
# FUND-CODE HYPERLINK LOGIC
# ============================================================

def add_fund_code_hyperlinks(
    workbook,
) -> Tuple[int, List[Tuple[int, str]]]:
    """
    Convert fund codes in INDEX Column B into internal hyperlinks.

    Matching logic:
        1. Extract the fund code from each worksheet title.
        2. Match it against the fund code in INDEX Column B.
        3. Link the fund code to cell A1 of the matching worksheet.

    Also adds a Back to INDEX hyperlink in cell A1 of each fund
    worksheet when A1 is empty. If A1 already contains content,
    the back link is placed in the first available cell between
    A1 and A5.

    Returns:
        linked_count
        list of unmatched rows as (row_number, fund_code)
    """
    index_worksheet = find_index_sheet(workbook)

    if index_worksheet is None:
        raise ValueError(
            "Cannot create hyperlinks because the INDEX "
            "worksheet was not found."
        )

    # Find the Short Name column rather than assuming a fixed row.
    header_row = None
    code_column = None

    for row_number in range(
        1,
        min(index_worksheet.max_row, 20) + 1,
    ):
        for column in range(
            1,
            min(index_worksheet.max_column, 10) + 1,
        ):
            header_value = norm(
                index_worksheet.cell(
                    row_number,
                    column,
                ).value
            )

            if header_value in {
                "short name",
                "fund code",
            }:
                header_row = row_number
                code_column = column
                break

        if header_row is not None:
            break

    if header_row is None or code_column is None:
        raise ValueError(
            "Cannot create hyperlinks because the INDEX "
            "worksheet does not contain a Short Name or "
            "Fund Code column."
        )

    # Create a code-to-sheet lookup from the renamed worksheets.
    code_to_sheet: Dict[str, str] = {}

    for worksheet in workbook.worksheets:
        if norm(worksheet.title) in {
            "index",
            "audit_log",
        }:
            continue

        code = clean_fund_code(worksheet.title)

        if code and code not in code_to_sheet:
            code_to_sheet[code] = worksheet.title

    hyperlink_font = Font(
        color="0563C1",
        underline="single",
    )

    unmatched_font = Font(
        color="C00000",
        bold=True,
    )

    unmatched_fill = PatternFill(
        fill_type="solid",
        fgColor="FFF2CC",
    )

    linked_count = 0
    unmatched_rows: List[Tuple[int, str]] = []

    for row_number in range(
        header_row + 1,
        index_worksheet.max_row + 1,
    ):
        code_cell = index_worksheet.cell(
            row_number,
            code_column,
        )

        code = clean_fund_code(code_cell.value)

        if not code:
            continue

        matching_sheet = code_to_sheet.get(code)

        # Remove any old hyperlink before assigning a new one.
        code_cell.hyperlink = None

        if matching_sheet:
            escaped_title = escape_excel_sheet_name(
                matching_sheet
            )

            code_cell.hyperlink = (
                f"#'{escaped_title}'!A1"
            )

            code_cell.font = hyperlink_font
            code_cell.fill = PatternFill(
                fill_type=None
            )

            linked_count += 1

        else:
            code_cell.font = unmatched_font
            code_cell.fill = unmatched_fill

            unmatched_rows.append(
                (
                    row_number,
                    code,
                )
            )

    # Add a return link to every fund worksheet.
    for code, sheet_title in code_to_sheet.items():
        worksheet = workbook[sheet_title]

        back_link_cell = None

        # Prefer a blank cell in A1:A5.
        for row_number in range(1, 6):
            candidate = worksheet.cell(
                row_number,
                1,
            )

            if candidate.value in (
                None,
                "",
            ):
                back_link_cell = candidate
                break

        # If A1:A5 are occupied, use the first blank cell in B1:B5.
        if back_link_cell is None:
            for row_number in range(1, 6):
                candidate = worksheet.cell(
                    row_number,
                    2,
                )

                if candidate.value in (
                    None,
                    "",
                ):
                    back_link_cell = candidate
                    break

        # Do not overwrite existing workbook content.
        if back_link_cell is not None:
            back_link_cell.value = "Back to INDEX"
            back_link_cell.hyperlink = "#'INDEX'!A1"

            back_link_cell.font = Font(
                color="0563C1",
                underline="single",
                bold=True,
            )

            back_link_cell.alignment = Alignment(
                horizontal="left",
                vertical="center",
            )

    # Select INDEX when the workbook opens.
    workbook.active = workbook.sheetnames.index(
        index_worksheet.title
    )

    first_data_cell = index_worksheet.cell(
        header_row + 1,
        code_column,
    )

    index_worksheet.sheet_view.selection[0].activeCell = (
        first_data_cell.coordinate
    )

    index_worksheet.sheet_view.selection[0].sqref = (
        first_data_cell.coordinate
    )

    return linked_count, unmatched_rows


# ============================================================
# AUDIT LOG
# ============================================================

def create_audit_log(
    workbook,
    audit: List[List[object]],
    updated: int,
    unmatched: int,
    cleared_sections: int,
    conflicts: List[Tuple[str, str]],
    renamed_sheets: Dict[str, str],
    linked_count: int,
    unmatched_links: List[Tuple[int, str]],
):
    """
    Create the Audit_Log worksheet.
    """
    if "Audit_Log" in workbook.sheetnames:
        del workbook["Audit_Log"]

    log = workbook.create_sheet("Audit_Log")

    headers = [
        "Sheet",
        "Fund Code",
        "Row",
        "Issuer/Instrument",
        "Previous Value",
        "Result",
        "Match Logic",
    ]

    log.append(headers)

    for row in audit:
        log.append(row)

    log.append([])

    log.append(
        [
            "Summary",
            "Updated",
            updated,
            "Unmatched",
            unmatched,
            "Cleared section rows",
            cleared_sections,
        ]
    )

    log.append(
        [
            "Hyperlink Summary",
            "Fund-code links created",
            linked_count,
            "Unmatched fund links",
            len(unmatched_links),
        ]
    )

    log.append([])

    log.append(
        [
            "Renamed fund worksheets",
        ]
    )

    log.append(
        [
            "Original worksheet title",
            "New worksheet title",
        ]
    )

    for original_title, new_title in renamed_sheets.items():
        log.append(
            [
                original_title,
                new_title,
            ]
        )

    log.append([])

    log.append(
        [
            "Unmatched fund-code hyperlinks",
        ]
    )

    log.append(
        [
            "INDEX row",
            "Fund code",
        ]
    )

    if unmatched_links:
        for row_number, fund_code in unmatched_links:
            log.append(
                [
                    row_number,
                    fund_code,
                ]
            )
    else:
        log.append(
            [
                "None",
                "All fund codes were linked successfully",
            ]
        )

    log.append([])

    log.append(
        [
            "Old workbook classification conflicts",
        ]
    )

    log.append(
        [
            "Issuer",
            "Observed classifications and counts",
        ]
    )

    for issuer, details in conflicts:
        log.append(
            [
                issuer,
                details,
            ]
        )

    dark_blue = "1F4E78"

    for cell in log[1]:
        cell.fill = PatternFill(
            "solid",
            fgColor=dark_blue,
        )

        cell.font = Font(
            color="FFFFFF",
            bold=True,
        )

        cell.alignment = Alignment(
            horizontal="center",
        )

    log.freeze_panes = "A2"

    if audit:
        log.auto_filter.ref = (
            f"A1:G{len(audit) + 1}"
        )

    widths = {
        1: 30,
        2: 28,
        3: 12,
        4: 55,
        5: 28,
        6: 22,
        7: 40,
    }

    for column, width in widths.items():
        log.column_dimensions[
            get_column_letter(column)
        ].width = width

    for row in log.iter_rows():
        for cell in row:
            cell.alignment = Alignment(
                vertical="top",
                wrap_text=True,
            )


# ============================================================
# MAIN WORKBOOK PROCESSING
# ============================================================

def update_workbook(
    old_path: Path,
    new_path: Path,
    output_path: Path,
    keep_existing_unmatched: bool = True,
):
    """
    Process the current workbook using classifications from the
    previous workbook.
    """
    old_workbook = load_workbook(
        old_path,
        data_only=False,
        read_only=False,
    )

    new_workbook = load_workbook(
        new_path,
        data_only=False,
        read_only=False,
    )

    (
        fund_map,
        fund_compact,
        global_map,
        global_compact,
        conflicts,
    ) = build_old_mappings(old_workbook)

    # Capture fund codes before renaming.
    new_codes_before_rename = index_sheet_codes(
        new_workbook
    )

    renamed_sheets = rename_fund_sheets_and_format_index(
        new_workbook,
        old_workbook,
    )

    # Rebuild the lookup after worksheet names change.
    new_codes_after_rename = index_sheet_codes(
        new_workbook
    )

    audit: List[List[object]] = []

    updated = 0
    unmatched = 0
    cleared_sections = 0

    for worksheet in new_workbook.worksheets:
        if norm(worksheet.title) in {
            "index",
            "audit_log",
        }:
            continue

        code = get_fund_code(
            worksheet,
            new_codes_after_rename,
        )

        # Fallback to the title because renamed sheets begin with
        # the fund code.
        if not code:
            code = clean_fund_code(
                worksheet.title
            )

        # Additional fallback using the original lookup.
        if not code:
            code = get_fund_code(
                worksheet,
                new_codes_before_rename,
            )

        table = locate_holdings_table(
            worksheet
        )

        if not code or not table:
            audit.append(
                [
                    worksheet.title,
                    code,
                    "",
                    "",
                    "",
                    "SKIPPED",
                    "Holdings table not found",
                ]
            )
            continue

        (
            header_row,
            issuer_column,
            class_column,
            _,
        ) = table

        header_cell = worksheet.cell(
            header_row,
            class_column,
        )

        header_cell.value = "Industry"

        for (
            row_number,
            issuer,
            current,
            weight,
            row_type,
        ) in iter_holding_rows(
            worksheet,
            table,
        ):

            target = worksheet.cell(
                row_number,
                class_column,
            )

            previous_value = target.value

            if row_type == "section":
                if target.value not in (
                    None,
                    "",
                ):
                    target.value = None
                    cleared_sections += 1

                    audit.append(
                        [
                            worksheet.title,
                            code,
                            row_number,
                            issuer,
                            previous_value,
                            "CLEARED_SECTION",
                            "Asset/total row",
                        ]
                    )

                continue

            normalized_key = norm(issuer)
            compact_key = compact(issuer)

            replacement = None
            source = ""

            if normalized_key in fund_map.get(
                code,
                {},
            ):
                replacement = fund_map[code][
                    normalized_key
                ]

                source = (
                    "same fund, exact issuer"
                )

            elif (
                compact_key
                and compact_key
                in fund_compact.get(code, {})
            ):
                replacement = fund_compact[code][
                    compact_key
                ]

                source = (
                    "same fund, normalized issuer"
                )

            elif normalized_key in global_map:
                replacement = global_map[
                    normalized_key
                ]

                source = (
                    "cross-fund consensus, exact issuer"
                )

            elif (
                compact_key
                and compact_key in global_compact
            ):
                replacement = global_compact[
                    compact_key
                ]

                source = (
                    "cross-fund consensus, normalized issuer"
                )

            if replacement:
                target.value = replacement
                updated += 1

                audit.append(
                    [
                        worksheet.title,
                        code,
                        row_number,
                        issuer,
                        previous_value,
                        "UPDATED",
                        source,
                    ]
                )

            else:
                unmatched += 1

                if not keep_existing_unmatched:
                    target.value = None

                unmatched_action = (
                    "Kept current value"
                    if keep_existing_unmatched
                    else "Cleared"
                )

                audit.append(
                    [
                        worksheet.title,
                        code,
                        row_number,
                        issuer,
                        previous_value,
                        "UNMATCHED",
                        unmatched_action,
                    ]
                )

    # Add hyperlinks only after worksheet renaming is complete.
    linked_count, unmatched_links = (
        add_fund_code_hyperlinks(
            new_workbook
        )
    )

    create_audit_log(
        workbook=new_workbook,
        audit=audit,
        updated=updated,
        unmatched=unmatched,
        cleared_sections=cleared_sections,
        conflicts=conflicts,
        renamed_sheets=renamed_sheets,
        linked_count=linked_count,
        unmatched_links=unmatched_links,
    )

    output_path.parent.mkdir(
        parents=True,
        exist_ok=True,
    )

    new_workbook.save(output_path)

    old_workbook.close()
    new_workbook.close()

    return (
        updated,
        unmatched,
        cleared_sections,
        len(conflicts),
        linked_count,
        len(unmatched_links),
    )


# ============================================================
# PYQT6 GRAPHICAL INTERFACE
# ============================================================

def run_gui() -> int:
    try:
        from PyQt6.QtCore import (
            QObject,
            QThread,
            QUrl,
            pyqtSignal,
        )

        from PyQt6.QtGui import (
            QDesktopServices,
            QFont,
        )

        from PyQt6.QtWidgets import (
            QApplication,
            QCheckBox,
            QFileDialog,
            QGridLayout,
            QGroupBox,
            QHBoxLayout,
            QLabel,
            QLineEdit,
            QMainWindow,
            QMessageBox,
            QPushButton,
            QProgressBar,
            QTextEdit,
            QVBoxLayout,
            QWidget,
        )

    except ImportError:
        print(
            "PyQt6 is not installed.\n"
            "Install the required packages using:\n\n"
            "pip install PyQt6 openpyxl",
            file=sys.stderr,
        )

        return 1

    class Worker(QObject):
        finished = pyqtSignal(object)
        failed = pyqtSignal(str)

        def __init__(
            self,
            old_file: str,
            new_file: str,
            output_file: str,
            keep_existing_unmatched: bool,
        ):
            super().__init__()

            self.old_file = old_file
            self.new_file = new_file
            self.output_file = output_file
            self.keep_existing_unmatched = (
                keep_existing_unmatched
            )

        def run(self):
            try:
                result = update_workbook(
                    Path(self.old_file),
                    Path(self.new_file),
                    Path(self.output_file),
                    keep_existing_unmatched=(
                        self.keep_existing_unmatched
                    ),
                )

                self.finished.emit(result)

            except Exception as exception:
                import traceback

                details = (
                    f"{exception}\n\n"
                    f"{traceback.format_exc()}"
                )

                self.failed.emit(details)

    class MainWindow(QMainWindow):
        def __init__(self):
            super().__init__()

            self.worker_thread = None
            self.worker = None
            self.last_output = ""

            self.setWindowTitle(
                "Portfolio Industry Updater"
            )

            self.setMinimumSize(
                840,
                570,
            )

            self.resize(
                920,
                640,
            )

            self.build_ui()

        def build_ui(self):
            root = QWidget()
            self.setCentralWidget(root)

            outer = QVBoxLayout(root)

            outer.setContentsMargins(
                22,
                20,
                22,
                20,
            )

            outer.setSpacing(14)

            title = QLabel(
                "Portfolio Industry Updater"
            )

            title.setFont(
                QFont(
                    "Segoe UI",
                    18,
                    QFont.Weight.Bold,
                )
            )

            subtitle = QLabel(
                "Select the previous-month workbook, "
                "current-month workbook, and output file. "
                "The source workbooks are not overwritten. "
                "The completed INDEX worksheet will contain "
                "clickable fund-code links."
            )

            subtitle.setWordWrap(True)

            outer.addWidget(title)
            outer.addWidget(subtitle)

            files_box = QGroupBox(
                "Excel files"
            )

            grid = QGridLayout(files_box)
            grid.setColumnStretch(1, 1)

            self.old_edit = QLineEdit()

            self.old_edit.setPlaceholderText(
                "Previous-month workbook used as "
                "the Industry master"
            )

            old_button = QPushButton(
                "Browse..."
            )

            old_button.clicked.connect(
                self.browse_old
            )

            self.new_edit = QLineEdit()

            self.new_edit.setPlaceholderText(
                "Current-month workbook to update"
            )

            new_button = QPushButton(
                "Browse..."
            )

            new_button.clicked.connect(
                self.browse_new
            )

            self.output_edit = QLineEdit()

            self.output_edit.setPlaceholderText(
                "New .xlsx file to create"
            )

            output_button = QPushButton(
                "Save as..."
            )

            output_button.clicked.connect(
                self.browse_output
            )

            file_rows = [
                (
                    "Old workbook:",
                    self.old_edit,
                    old_button,
                ),
                (
                    "New workbook:",
                    self.new_edit,
                    new_button,
                ),
                (
                    "Output workbook:",
                    self.output_edit,
                    output_button,
                ),
            ]

            for row_number, (
                label_text,
                line_edit,
                button,
            ) in enumerate(file_rows):

                grid.addWidget(
                    QLabel(label_text),
                    row_number,
                    0,
                )

                grid.addWidget(
                    line_edit,
                    row_number,
                    1,
                )

                grid.addWidget(
                    button,
                    row_number,
                    2,
                )

            outer.addWidget(files_box)

            options_box = QGroupBox(
                "Options"
            )

            options_layout = QVBoxLayout(
                options_box
            )

            self.keep_unmatched = QCheckBox(
                "Keep the current workbook value when an "
                "instrument is not found in the old workbook"
            )

            self.keep_unmatched.setChecked(True)

            options_layout.addWidget(
                self.keep_unmatched
            )

            note = QLabel(
                "Fund-specific matches are preferred. "
                "If a fund-specific match is unavailable, "
                "the program uses the most common classification "
                "found for the same instrument across the old "
                "workbook. Fund codes in the INDEX worksheet "
                "are linked to their corresponding fund sheets."
            )

            note.setWordWrap(True)

            options_layout.addWidget(note)
            outer.addWidget(options_box)

            actions = QHBoxLayout()

            self.process_button = QPushButton(
                "Process Workbook"
            )

            self.process_button.setMinimumHeight(38)

            self.process_button.clicked.connect(
                self.start_processing
            )

            self.open_button = QPushButton(
                "Open Output"
            )

            self.open_button.setEnabled(False)

            self.open_button.clicked.connect(
                self.open_output
            )

            self.folder_button = QPushButton(
                "Open Folder"
            )

            self.folder_button.setEnabled(False)

            self.folder_button.clicked.connect(
                self.open_folder
            )

            actions.addWidget(
                self.process_button
            )

            actions.addStretch()

            actions.addWidget(
                self.open_button
            )

            actions.addWidget(
                self.folder_button
            )

            outer.addLayout(actions)

            self.progress = QProgressBar()

            self.progress.setRange(
                0,
                1,
            )

            self.progress.setValue(0)
            self.progress.setTextVisible(True)

            outer.addWidget(self.progress)

            self.status = QLabel("Ready")
            self.status.setWordWrap(True)

            outer.addWidget(self.status)

            self.log = QTextEdit()
            self.log.setReadOnly(True)

            self.log.setPlaceholderText(
                "Processing results will appear here."
            )

            outer.addWidget(
                self.log,
                1,
            )

        @staticmethod
        def excel_filter():
            return (
                "Excel workbooks (*.xlsx *.xlsm);;"
                "All files (*.*)"
            )

        def browse_old(self):
            path, _ = QFileDialog.getOpenFileName(
                self,
                "Select previous-month workbook",
                "",
                self.excel_filter(),
            )

            if path:
                self.old_edit.setText(path)

        def browse_new(self):
            path, _ = QFileDialog.getOpenFileName(
                self,
                "Select current-month workbook",
                "",
                self.excel_filter(),
            )

            if path:
                self.new_edit.setText(path)

                if not self.output_edit.text().strip():
                    source = Path(path)

                    proposed = source.with_name(
                        f"{source.stem} - industry updated.xlsx"
                    )

                    self.output_edit.setText(
                        str(proposed)
                    )

        def browse_output(self):
            initial = (
                self.output_edit.text().strip()
                or "portfolio_industry_updated.xlsx"
            )

            path, _ = QFileDialog.getSaveFileName(
                self,
                "Choose output workbook",
                initial,
                "Excel workbook (*.xlsx)",
            )

            if path:
                if not path.lower().endswith(
                    ".xlsx"
                ):
                    path += ".xlsx"

                self.output_edit.setText(path)

        def validate_paths(self):
            old_path = Path(
                self.old_edit.text().strip()
            )

            new_path = Path(
                self.new_edit.text().strip()
            )

            output_text = (
                self.output_edit.text().strip()
            )

            if not old_path.is_file():
                return (
                    None,
                    "Select a valid previous-month workbook.",
                )

            if not new_path.is_file():
                return (
                    None,
                    "Select a valid current-month workbook.",
                )

            if not output_text:
                return (
                    None,
                    "Choose an output workbook.",
                )

            output_path = Path(output_text)

            if output_path.suffix.lower() != ".xlsx":
                output_path = output_path.with_suffix(
                    ".xlsx"
                )

                self.output_edit.setText(
                    str(output_path)
                )

            try:
                if output_path.resolve() in {
                    old_path.resolve(),
                    new_path.resolve(),
                }:
                    return (
                        None,
                        "The output must be a new file. "
                        "Source workbooks cannot be overwritten.",
                    )

            except OSError:
                pass

            if output_path.exists():
                reply = QMessageBox.question(
                    self,
                    "Replace output file?",
                    (
                        f"The output already exists:\n"
                        f"{output_path}\n\n"
                        f"Replace it?"
                    ),
                    (
                        QMessageBox.StandardButton.Yes
                        | QMessageBox.StandardButton.No
                    ),
                    QMessageBox.StandardButton.No,
                )

                if (
                    reply
                    != QMessageBox.StandardButton.Yes
                ):
                    return None, ""

            return (
                (
                    old_path,
                    new_path,
                    output_path,
                ),
                "",
            )

        def set_busy(self, busy: bool):
            self.process_button.setEnabled(
                not busy
            )

            self.open_button.setEnabled(
                (not busy)
                and bool(self.last_output)
            )

            self.folder_button.setEnabled(
                (not busy)
                and bool(self.last_output)
            )

            if busy:
                self.progress.setRange(
                    0,
                    0,
                )

            else:
                self.progress.setRange(
                    0,
                    1,
                )

                self.progress.setValue(
                    1 if self.last_output else 0
                )

        def start_processing(self):
            paths, error = self.validate_paths()

            if paths is None:
                if error:
                    QMessageBox.warning(
                        self,
                        "Cannot process",
                        error,
                    )

                return

            (
                old_path,
                new_path,
                output_path,
            ) = paths

            self.last_output = ""
            self.set_busy(True)

            self.status.setText(
                "Processing workbook. Large files may "
                "take a few minutes..."
            )

            self.log.setPlainText(
                f"Old workbook: {old_path}\n"
                f"New workbook: {new_path}\n"
                f"Output: {output_path}\n\n"
                f"Processing..."
            )

            self.worker_thread = QThread(self)

            self.worker = Worker(
                str(old_path),
                str(new_path),
                str(output_path),
                self.keep_unmatched.isChecked(),
            )

            self.worker.moveToThread(
                self.worker_thread
            )

            self.worker_thread.started.connect(
                self.worker.run
            )

            self.worker.finished.connect(
                self.processing_finished
            )

            self.worker.failed.connect(
                self.processing_failed
            )

            self.worker.finished.connect(
                self.worker_thread.quit
            )

            self.worker.failed.connect(
                self.worker_thread.quit
            )

            self.worker_thread.finished.connect(
                self.worker.deleteLater
            )

            self.worker_thread.finished.connect(
                self.worker_thread.deleteLater
            )

            self.worker_thread.start()

        def processing_finished(self, result):
            (
                updated,
                unmatched,
                cleared,
                conflicts,
                linked_count,
                unmatched_links,
            ) = result

            self.last_output = (
                self.output_edit.text().strip()
            )

            self.set_busy(False)

            self.status.setText(
                "Completed successfully."
            )

            self.log.append(
                "\nCompleted successfully.\n"
                f"Updated instrument rows: {updated}\n"
                f"Unmatched instrument rows: {unmatched}\n"
                f"Cleared asset/total classification cells: "
                f"{cleared}\n"
                f"Old-data classification conflicts logged: "
                f"{conflicts}\n"
                f"Fund-code hyperlinks created: "
                f"{linked_count}\n"
                f"Fund codes without matching worksheets: "
                f"{unmatched_links}\n\n"
                f"Click a fund code in the INDEX worksheet "
                f"to open its fund sheet.\n"
                f"See the Audit_Log worksheet for row-level "
                f"details."
            )

            QMessageBox.information(
                self,
                "Finished",
                (
                    "The updated workbook was created "
                    "successfully:\n\n"
                    f"{self.last_output}\n\n"
                    f"Fund-code hyperlinks created: "
                    f"{linked_count}\n"
                    f"Unmatched fund links: "
                    f"{unmatched_links}"
                ),
            )

        def processing_failed(
            self,
            details: str,
        ):
            self.last_output = ""
            self.set_busy(False)

            self.status.setText(
                "Processing failed."
            )

            self.log.append(
                f"\nERROR\n{details}"
            )

            QMessageBox.critical(
                self,
                "Processing failed",
                (
                    "The workbook could not be processed. "
                    "Close the Excel files if they are open, "
                    "verify the selected files, and review "
                    "the detailed error in the log."
                ),
            )

        def open_output(self):
            if (
                self.last_output
                and Path(self.last_output).is_file()
            ):
                QDesktopServices.openUrl(
                    QUrl.fromLocalFile(
                        self.last_output
                    )
                )

        def open_folder(self):
            if self.last_output:
                folder = str(
                    Path(
                        self.last_output
                    ).parent
                )

                QDesktopServices.openUrl(
                    QUrl.fromLocalFile(folder)
                )

        def closeEvent(self, event):
            if (
                self.worker_thread
                and self.worker_thread.isRunning()
            ):
                QMessageBox.information(
                    self,
                    "Processing in progress",
                    (
                        "Wait for workbook processing "
                        "to finish before closing the "
                        "application."
                    ),
                )

                event.ignore()

            else:
                event.accept()

    application = QApplication(sys.argv)

    application.setApplicationName(
        "Portfolio Industry Updater"
    )

    application.setStyle("Fusion")

    window = MainWindow()
    window.show()

    return application.exec()


# ============================================================
# APPLICATION ENTRY POINT
# ============================================================

def main() -> int:
    return run_gui()


if __name__ == "__main__":
    raise SystemExit(main())