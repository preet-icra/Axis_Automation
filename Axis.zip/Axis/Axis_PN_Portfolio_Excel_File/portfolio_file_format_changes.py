#!/usr/bin/env python3
"""
Update the Industry/Rating column in a new Axis portfolio workbook using the
previous month's workbook as the Industry master.

Default usage (files in the same folder as this script):
    python update_portfolio_industry.py

Explicit usage:
    python update_portfolio_industry.py \
      --old "old_Portfolios - September 2026.xlsx" \
      --new "Portfolios - October 2026.xlsx" \
      --output "Portfolios - October 2026 - industry updated.xlsx"

The script:
1. Detects each fund code from the workbook's Index sheet and/or sheet name.
2. Locates the left-hand holdings table from its headers, without fixed row numbers.
3. Builds issuer-to-Industry/Rating mappings from the old workbook.
4. Uses fund-specific mapping first, then a consensus mapping across all funds.
5. Keeps asset-class rows such as EQUITY, Corporate Bond, and Net Current Assets blank.
6. Produces an Audit_Log sheet showing updates, unmatched issuers, and conflicts.
"""

from __future__ import annotations

import argparse
import re
import shutil
import sys
from collections import Counter, defaultdict
from copy import copy
from pathlib import Path
from typing import Dict, Iterable, List, Optional, Tuple

from openpyxl import load_workbook
from openpyxl.styles import Alignment, Font, PatternFill
from openpyxl.utils import get_column_letter

DEFAULT_OLD = "old_Portfolios - September 2026.xlsx"
DEFAULT_NEW = "Portfolios - October 2026.xlsx"
DEFAULT_OUTPUT = "Portfolios - October 2026 - industry updated.xlsx"

# Rows with these labels are sections/totals, not individual instruments.
SECTION_LABELS = {
    "equity", "domestic equities", "international equities", "debt securities",
    "corporate bond", "government bond", "state government bond", "treasury bill",
    "certificate of deposit", "commercial paper", "floating rate note",
    "zero coupon bond", "government bond strips", "ptc", "pass through certificate",
    "invit", "reit", "mutual fund units", "exchange traded fund",
    "international mutual fund units", "international exchange traded funds",
    "international exchange traded fund", "american depository receipt",
    "global depository receipt", "physical gold", "physical silver",
    "commodity future", "corporate debt market development fund",
    "net current assets", "debt cash other current assets",
    "debt cash other receivables", "cash other net current assets",
    "grand total", "net assets", "hedge equity", "unhedge equity",
    "hedged equity", "unhedged equity",
}

STOP_MARKERS = {
    "composition by sector", "composition by sector%", "composition by country",
    "composition by rating", "composition by asset", "composition by asset (%)",
}

HEADER_NAME_TOKENS = ("instrument type/issuer name", "issuer")
HEADER_CLASS_TOKENS = ("industry/rating", "industry", "rating", "sector")
HEADER_VALUE_TOKENS = ("% of nav", "% of net assets", "net exposure % of net assets")


def norm(value: object) -> str:
    """Normalize text for dependable matching while preserving meaningful symbols."""
    if value is None:
        return ""
    text = str(value).replace("\u00a0", " ").strip().lower()
    text = re.sub(r"\s+", " ", text)
    text = text.replace("&", " and ")
    text = re.sub(r"[^a-z0-9%+./() -]", "", text)
    return re.sub(r"\s+", " ", text).strip()


def compact(value: object) -> str:
    """More tolerant key used only after exact normalized matching."""
    text = norm(value)
    replacements = {
        " limited": " ltd", " private": " pvt", " corporation": " corp",
        " company": " co", " and ": " ", ".": "", "-": " ",
    }
    for old, new in replacements.items():
        text = text.replace(old, new)
    return re.sub(r"[^a-z0-9]", "", text)


def clean_fund_code(text: object) -> str:
    s = str(text or "").strip().upper()
    s = re.sub(r"\s*-\s*HOLDING.*$", "", s)
    m = re.search(r"\bAXIS[A-Z0-9]+\b", s)
    return m.group(0) if m else ""


def find_index_sheet(wb):
    for ws in wb.worksheets:
        if norm(ws.title) == "index":
            return ws
    return None


def index_sheet_codes(wb) -> Dict[str, str]:
    """Return worksheet title -> fund code using the Index sheet where possible."""
    result: Dict[str, str] = {}
    ws = find_index_sheet(wb)
    if ws is None:
        return result

    header_row = None
    headers: Dict[str, int] = {}
    for r in range(1, min(ws.max_row, 20) + 1):
        row = {norm(ws.cell(r, c).value): c for c in range(1, min(ws.max_column, 8) + 1)}
        if any(k in row for k in ("short name", "fund code")):
            header_row, headers = r, row
            break
    if not header_row:
        return result

    code_col = headers.get("fund code") or headers.get("short name")
    sheet_col = headers.get("sheet name")
    for r in range(header_row + 1, ws.max_row + 1):
        code = clean_fund_code(ws.cell(r, code_col).value)
        if not code:
            continue
        title = str(ws.cell(r, sheet_col).value).strip() if sheet_col else ""
        if title and title in wb.sheetnames:
            result[title] = code
        else:
            for candidate in wb.sheetnames:
                if clean_fund_code(candidate) == code:
                    result[candidate] = code
                    break
    return result


def get_fund_code(ws, index_codes: Dict[str, str]) -> str:
    if ws.title in index_codes:
        return index_codes[ws.title]
    by_title = clean_fund_code(ws.title)
    if by_title:
        return by_title
    for row in ws.iter_rows(min_row=1, max_row=min(ws.max_row, 8), min_col=1, max_col=min(ws.max_column, 5)):
        for cell in row:
            code = clean_fund_code(cell.value)
            if code:
                return code
    return ""


def locate_holdings_table(ws) -> Optional[Tuple[int, int, int, int]]:
    """Return (header_row, issuer_col, class_col, value_col)."""
    max_r = min(ws.max_row, 30)
    max_c = min(ws.max_column, 10)
    for r in range(1, max_r + 1):
        values = [norm(ws.cell(r, c).value) for c in range(1, max_c + 1)]
        issuer_col = next((c + 1 for c, v in enumerate(values)
                           if any(t == v or t in v for t in HEADER_NAME_TOKENS)), None)
        class_col = next((c + 1 for c, v in enumerate(values)
                          if any(t == v for t in HEADER_CLASS_TOKENS)), None)
        value_col = next((c + 1 for c, v in enumerate(values)
                          if any(t == v for t in HEADER_VALUE_TOKENS)), None)
        if issuer_col and class_col and value_col and issuer_col < class_col <= value_col:
            return r, issuer_col, class_col, value_col
    return None


def is_numeric(value: object) -> bool:
    return isinstance(value, (int, float)) and not isinstance(value, bool)


def iter_holding_rows(ws, table: Tuple[int, int, int, int]):
    header_row, issuer_col, class_col, value_col = table
    blank_streak = 0
    for r in range(header_row + 1, ws.max_row + 1):
        issuer = ws.cell(r, issuer_col).value
        classification = ws.cell(r, class_col).value
        weight = ws.cell(r, value_col).value
        key = norm(issuer)

        if not key and classification is None and weight is None:
            blank_streak += 1
            if blank_streak >= 8:
                break
            continue
        blank_streak = 0

        if key == "grand total":
            yield r, issuer, classification, weight, "section"
            break
        if any(marker in key for marker in STOP_MARKERS):
            # A right-side composition heading can visually overlap the same row.
            # Do not stop unless it is in the issuer column itself.
            continue

        row_type = "instrument"
        if key in SECTION_LABELS or key.startswith("other domestic equity") or key.startswith("other equity"):
            row_type = "section"
        elif not is_numeric(weight):
            row_type = "section"
        yield r, issuer, classification, weight, row_type


def build_old_mappings(old_wb):
    """Build fund-specific and global consensus classification dictionaries."""
    index_codes = index_sheet_codes(old_wb)
    fund_map: Dict[str, Dict[str, str]] = defaultdict(dict)
    fund_compact: Dict[str, Dict[str, str]] = defaultdict(dict)
    votes: Dict[str, Counter] = defaultdict(Counter)
    display_names: Dict[str, str] = {}

    for ws in old_wb.worksheets:
        if norm(ws.title) == "index":
            continue
        code = get_fund_code(ws, index_codes)
        table = locate_holdings_table(ws)
        if not code or not table:
            continue
        for _, issuer, classification, _, row_type in iter_holding_rows(ws, table):
            if row_type != "instrument" or not norm(classification):
                continue
            nk = norm(issuer)
            ck = compact(issuer)
            label = str(classification).strip()
            fund_map[code][nk] = label
            if ck:
                fund_compact[code][ck] = label
            votes[nk][label] += 1
            display_names[nk] = str(issuer).strip()

    global_map: Dict[str, str] = {}
    conflicts: List[Tuple[str, str]] = []
    for nk, choices in votes.items():
        ranked = choices.most_common()
        global_map[nk] = ranked[0][0]
        if len(ranked) > 1:
            conflicts.append((display_names.get(nk, nk), "; ".join(f"{k} ({v})" for k, v in ranked)))

    global_compact: Dict[str, str] = {}
    compact_votes: Dict[str, Counter] = defaultdict(Counter)
    for nk, label in global_map.items():
        compact_votes[compact(display_names.get(nk, nk))][label] += 1
    for ck, choices in compact_votes.items():
        if ck:
            global_compact[ck] = choices.most_common(1)[0][0]

    return fund_map, fund_compact, global_map, global_compact, conflicts


def copy_cell_style(source, target) -> None:
    if source.has_style:
        target._style = copy(source._style)
    if source.number_format:
        target.number_format = source.number_format
    target.alignment = copy(source.alignment)



def safe_sheet_title(desired: str, used_titles: set[str]) -> str:
    """Return an Excel-safe, unique worksheet title (maximum 31 characters)."""
    cleaned = re.sub(r'[\\/*?:\[\]]', ' ', str(desired or '')).strip()
    cleaned = re.sub(r'\s+', ' ', cleaned) or 'Fund'
    base = cleaned[:31].rstrip()
    candidate = base
    number = 2
    lowered = {name.lower() for name in used_titles}
    while candidate.lower() in lowered:
        suffix = f" ({number})"
        candidate = f"{base[:31-len(suffix)].rstrip()}{suffix}"
        number += 1
    return candidate


def old_sheet_titles_by_code(old_wb) -> Dict[str, str]:
    """Use the previous workbook's established Fund Code - Fund Name titles."""
    mapping: Dict[str, str] = {}
    index_codes = index_sheet_codes(old_wb)
    for ws in old_wb.worksheets:
        if norm(ws.title) == 'index':
            continue
        code = get_fund_code(ws, index_codes)
        if code:
            mapping[code] = ws.title
    return mapping


def fallback_fund_title(code: str, fund_name: str) -> str:
    """Build a readable fallback title when the old workbook has no matching fund."""
    name = str(fund_name or '').strip()
    name = re.sub(r'^Axis\s+', '', name, flags=re.IGNORECASE)
    name = re.sub(r'\s+Fund$', '', name, flags=re.IGNORECASE)
    name = re.sub(r'\s+', ' ', name).strip()
    return f"{code} - {name}" if name else code


def rename_fund_sheets_and_format_index(new_wb, old_wb) -> Dict[str, str]:
    """Rename fund sheets and convert the new Index to the three-column old format."""
    index_ws = find_index_sheet(new_wb)
    if index_ws is None:
        raise ValueError('The current workbook does not contain an Index sheet.')

    header_row = None
    headers: Dict[str, int] = {}
    for r in range(1, min(index_ws.max_row, 20) + 1):
        row_headers = {norm(index_ws.cell(r, c).value): c for c in range(1, min(index_ws.max_column, 10) + 1)}
        if 'fund code' in row_headers and 'fund name' in row_headers:
            header_row, headers = r, row_headers
            break
    if header_row is None:
        raise ValueError('The current Index sheet must contain Fund Code and Fund Name columns.')

    sheet_col = headers.get('sheet name')
    code_col = headers['fund code']
    name_col = headers['fund name']
    records = []
    for r in range(header_row + 1, index_ws.max_row + 1):
        code = clean_fund_code(index_ws.cell(r, code_col).value)
        fund_name = str(index_ws.cell(r, name_col).value or '').strip()
        source_title = str(index_ws.cell(r, sheet_col).value or '').strip() if sheet_col else ''
        if code:
            records.append((r, code, fund_name, source_title))

    old_titles = old_sheet_titles_by_code(old_wb)
    used = {index_ws.title}
    renamed: Dict[str, str] = {}
    for _, code, fund_name, source_title in records:
        ws = None
        if source_title in new_wb.sheetnames:
            ws = new_wb[source_title]
        else:
            ws = next((candidate for candidate in new_wb.worksheets
                       if candidate is not index_ws and clean_fund_code(candidate.title) == code), None)
        if ws is None:
            continue
        desired = old_titles.get(code) or fallback_fund_title(code, fund_name)
        title = safe_sheet_title(desired, used)
        old_title = ws.title
        ws.title = title
        used.add(title)
        renamed[old_title] = title

    # Convert Index from: Sr No. | Sheet Name | Fund Code | Fund Name
    # to the old format: Sr No. | Short Name | Scheme Name.
    # A temporary title is required because Excel treats 'Index' and 'INDEX' as the same name.
    index_ws.title = '__INDEX_TEMP__'
    index_ws.title = 'INDEX'
    if sheet_col:
        index_ws.delete_cols(sheet_col, 1)
    if index_ws.max_column > 3:
        index_ws.delete_cols(4, index_ws.max_column - 3)
    index_ws.cell(header_row, 1).value = 'Sr No.'
    index_ws.cell(header_row, 2).value = 'Short Name'
    index_ws.cell(header_row, 3).value = 'Scheme Name'
    for output_row, (_, code, fund_name, _) in enumerate(records, start=header_row + 1):
        index_ws.cell(output_row, 1).value = output_row - header_row
        index_ws.cell(output_row, 2).value = code
        index_ws.cell(output_row, 3).value = fund_name
    # Remove stale rows, if any.
    first_stale = header_row + 1 + len(records)
    if first_stale <= index_ws.max_row:
        index_ws.delete_rows(first_stale, index_ws.max_row - first_stale + 1)
    index_ws.column_dimensions['A'].width = 8
    index_ws.column_dimensions['B'].width = 22
    index_ws.column_dimensions['C'].width = 55
    index_ws.freeze_panes = f'A{header_row + 1}'
    return renamed

def update_workbook(old_path: Path, new_path: Path, output_path: Path, keep_existing_unmatched: bool = True):
    old_wb = load_workbook(old_path, data_only=False, read_only=False)
    new_wb = load_workbook(new_path, data_only=False, read_only=False)

    fund_map, fund_compact, global_map, global_compact, conflicts = build_old_mappings(old_wb)
    new_codes = index_sheet_codes(new_wb)
    rename_fund_sheets_and_format_index(new_wb, old_wb)
    audit: List[List[object]] = []
    updated = unmatched = cleared_sections = 0

    for ws in new_wb.worksheets:
        if norm(ws.title) in {"index", "audit_log"}:
            continue
        code = get_fund_code(ws, new_codes)
        table = locate_holdings_table(ws)
        if not code or not table:
            audit.append([ws.title, code, "", "", "", "SKIPPED", "Holdings table not found"])
            continue

        header_row, issuer_col, class_col, _ = table
        header_cell = ws.cell(header_row, class_col)
        header_cell.value = "Industry"

        for r, issuer, current, weight, row_type in iter_holding_rows(ws, table):
            target = ws.cell(r, class_col)
            old_value = target.value
            if row_type == "section":
                # The circled area in the sample is intentionally blank for asset headings like EQUITY.
                if target.value not in (None, ""):
                    target.value = None
                    cleared_sections += 1
                    audit.append([ws.title, code, r, issuer, old_value, "CLEARED_SECTION", "Asset/total row"])
                continue

            nk, ck = norm(issuer), compact(issuer)
            replacement = None
            source = ""
            if nk in fund_map.get(code, {}):
                replacement, source = fund_map[code][nk], "same fund, exact issuer"
            elif ck and ck in fund_compact.get(code, {}):
                replacement, source = fund_compact[code][ck], "same fund, normalized issuer"
            elif nk in global_map:
                replacement, source = global_map[nk], "cross-fund consensus, exact issuer"
            elif ck and ck in global_compact:
                replacement, source = global_compact[ck], "cross-fund consensus, normalized issuer"

            if replacement:
                target.value = replacement
                updated += 1
                audit.append([ws.title, code, r, issuer, old_value, "UPDATED", source])
            else:
                unmatched += 1
                if not keep_existing_unmatched:
                    target.value = None
                audit.append([ws.title, code, r, issuer, old_value, "UNMATCHED", "Kept current value" if keep_existing_unmatched else "Cleared"])

    if "Audit_Log" in new_wb.sheetnames:
        del new_wb["Audit_Log"]
    log = new_wb.create_sheet("Audit_Log")
    headers = ["Sheet", "Fund Code", "Row", "Issuer/Instrument", "Previous Value", "Result", "Match Logic"]
    log.append(headers)
    for row in audit:
        log.append(row)
    log.append([])
    log.append(["Summary", "Updated", updated, "Unmatched", unmatched, "Cleared section rows", cleared_sections])
    log.append([])
    log.append(["Old workbook classification conflicts"])
    log.append(["Issuer", "Observed classifications and counts"])
    for issuer, detail in conflicts:
        log.append([issuer, detail])

    dark_blue = "1F4E78"
    for cell in log[1]:
        cell.fill = PatternFill("solid", fgColor=dark_blue)
        cell.font = Font(color="FFFFFF", bold=True)
        cell.alignment = Alignment(horizontal="center")
    log.freeze_panes = "A2"
    log.auto_filter.ref = f"A1:G{max(1, len(audit) + 1)}"
    widths = {1: 25, 2: 14, 3: 9, 4: 55, 5: 28, 6: 20, 7: 38}
    for col, width in widths.items():
        log.column_dimensions[get_column_letter(col)].width = width
    for row in log.iter_rows():
        for cell in row:
            cell.alignment = Alignment(vertical="top", wrap_text=True)

    output_path.parent.mkdir(parents=True, exist_ok=True)
    new_wb.save(output_path)
    return updated, unmatched, cleared_sections, len(conflicts)



# ----------------------------- PyQt6 GUI -----------------------------

def run_gui() -> int:
    try:
        from PyQt6.QtCore import QObject, QThread, pyqtSignal, QUrl
        from PyQt6.QtGui import QDesktopServices, QFont
        from PyQt6.QtWidgets import (
            QApplication, QCheckBox, QFileDialog, QFormLayout, QGridLayout,
            QGroupBox, QHBoxLayout, QLabel, QLineEdit, QMainWindow,
            QMessageBox, QPushButton, QProgressBar, QTextEdit, QVBoxLayout,
            QWidget,
        )
    except ImportError:
        print("PyQt6 is not installed. Run: pip install PyQt6 openpyxl", file=sys.stderr)
        return 1

    class Worker(QObject):
        finished = pyqtSignal(object)
        failed = pyqtSignal(str)

        def __init__(self, old_file: str, new_file: str, output_file: str,
                     keep_existing_unmatched: bool):
            super().__init__()
            self.old_file = old_file
            self.new_file = new_file
            self.output_file = output_file
            self.keep_existing_unmatched = keep_existing_unmatched

        def run(self):
            try:
                result = update_workbook(
                    Path(self.old_file),
                    Path(self.new_file),
                    Path(self.output_file),
                    keep_existing_unmatched=self.keep_existing_unmatched,
                )
                self.finished.emit(result)
            except Exception as exc:
                import traceback
                self.failed.emit(f"{exc}\n\n{traceback.format_exc()}")

    class MainWindow(QMainWindow):
        def __init__(self):
            super().__init__()
            self.worker_thread = None
            self.worker = None
            self.last_output = ""
            self.setWindowTitle("Portfolio Industry Updater")
            self.setMinimumSize(840, 570)
            self.resize(920, 640)
            self._build_ui()

        def _build_ui(self):
            root = QWidget()
            self.setCentralWidget(root)
            outer = QVBoxLayout(root)
            outer.setContentsMargins(22, 20, 22, 20)
            outer.setSpacing(14)

            title = QLabel("Portfolio Industry Updater")
            title.setFont(QFont("Segoe UI", 18, QFont.Weight.Bold))
            subtitle = QLabel(
                "Select the previous-month workbook, current-month workbook, and the output file. "
                "The source workbooks are never overwritten."
            )
            subtitle.setWordWrap(True)
            outer.addWidget(title)
            outer.addWidget(subtitle)

            files_box = QGroupBox("Excel files")
            grid = QGridLayout(files_box)
            grid.setColumnStretch(1, 1)

            self.old_edit = QLineEdit()
            self.old_edit.setPlaceholderText("Previous-month workbook used as the Industry master")
            old_btn = QPushButton("Browse...")
            old_btn.clicked.connect(self.browse_old)

            self.new_edit = QLineEdit()
            self.new_edit.setPlaceholderText("Current-month workbook to update")
            new_btn = QPushButton("Browse...")
            new_btn.clicked.connect(self.browse_new)

            self.output_edit = QLineEdit()
            self.output_edit.setPlaceholderText("New .xlsx file to create")
            output_btn = QPushButton("Save as...")
            output_btn.clicked.connect(self.browse_output)

            rows = [
                ("Old workbook:", self.old_edit, old_btn),
                ("New workbook:", self.new_edit, new_btn),
                ("Output workbook:", self.output_edit, output_btn),
            ]
            for row, (label, edit, button) in enumerate(rows):
                grid.addWidget(QLabel(label), row, 0)
                grid.addWidget(edit, row, 1)
                grid.addWidget(button, row, 2)
            outer.addWidget(files_box)

            options_box = QGroupBox("Options")
            options_layout = QVBoxLayout(options_box)
            self.keep_unmatched = QCheckBox(
                "Keep the current workbook value when an instrument is not found in the old workbook"
            )
            self.keep_unmatched.setChecked(True)
            options_layout.addWidget(self.keep_unmatched)
            note = QLabel(
                "Fund-specific matches are preferred. If unavailable, the program uses the most common "
                "classification found for the same instrument across old-workbook funds."
            )
            note.setWordWrap(True)
            options_layout.addWidget(note)
            outer.addWidget(options_box)

            actions = QHBoxLayout()
            self.process_btn = QPushButton("Process Workbook")
            self.process_btn.setMinimumHeight(38)
            self.process_btn.clicked.connect(self.start_processing)
            self.open_btn = QPushButton("Open Output")
            self.open_btn.setEnabled(False)
            self.open_btn.clicked.connect(self.open_output)
            self.folder_btn = QPushButton("Open Folder")
            self.folder_btn.setEnabled(False)
            self.folder_btn.clicked.connect(self.open_folder)
            actions.addWidget(self.process_btn)
            actions.addStretch()
            actions.addWidget(self.open_btn)
            actions.addWidget(self.folder_btn)
            outer.addLayout(actions)

            self.progress = QProgressBar()
            self.progress.setRange(0, 1)
            self.progress.setValue(0)
            self.progress.setTextVisible(True)
            outer.addWidget(self.progress)

            self.status = QLabel("Ready")
            self.status.setWordWrap(True)
            outer.addWidget(self.status)

            self.log = QTextEdit()
            self.log.setReadOnly(True)
            self.log.setPlaceholderText("Processing results will appear here.")
            outer.addWidget(self.log, 1)

        @staticmethod
        def _excel_filter():
            return "Excel workbooks (*.xlsx *.xlsm);;All files (*.*)"

        def browse_old(self):
            path, _ = QFileDialog.getOpenFileName(
                self, "Select previous-month workbook", "", self._excel_filter()
            )
            if path:
                self.old_edit.setText(path)

        def browse_new(self):
            path, _ = QFileDialog.getOpenFileName(
                self, "Select current-month workbook", "", self._excel_filter()
            )
            if path:
                self.new_edit.setText(path)
                if not self.output_edit.text().strip():
                    source = Path(path)
                    proposed = source.with_name(f"{source.stem} - industry updated.xlsx")
                    self.output_edit.setText(str(proposed))

        def browse_output(self):
            initial = self.output_edit.text().strip() or "portfolio_industry_updated.xlsx"
            path, _ = QFileDialog.getSaveFileName(
                self, "Choose output workbook", initial, "Excel workbook (*.xlsx)"
            )
            if path:
                if not path.lower().endswith(".xlsx"):
                    path += ".xlsx"
                self.output_edit.setText(path)

        def validate_paths(self):
            old_path = Path(self.old_edit.text().strip())
            new_path = Path(self.new_edit.text().strip())
            output_text = self.output_edit.text().strip()
            if not old_path.is_file():
                return None, "Select a valid previous-month workbook."
            if not new_path.is_file():
                return None, "Select a valid current-month workbook."
            if not output_text:
                return None, "Choose an output workbook."
            output_path = Path(output_text)
            if output_path.suffix.lower() != ".xlsx":
                output_path = output_path.with_suffix(".xlsx")
                self.output_edit.setText(str(output_path))
            try:
                if output_path.resolve() in {old_path.resolve(), new_path.resolve()}:
                    return None, "The output must be a new file. Source workbooks cannot be overwritten."
            except OSError:
                pass
            if output_path.exists():
                reply = QMessageBox.question(
                    self, "Replace output file?",
                    f"The output already exists:\n{output_path}\n\nReplace it?",
                    QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No,
                    QMessageBox.StandardButton.No,
                )
                if reply != QMessageBox.StandardButton.Yes:
                    return None, ""
            return (old_path, new_path, output_path), ""

        def set_busy(self, busy: bool):
            self.process_btn.setEnabled(not busy)
            self.open_btn.setEnabled((not busy) and bool(self.last_output))
            self.folder_btn.setEnabled((not busy) and bool(self.last_output))
            if busy:
                self.progress.setRange(0, 0)
            else:
                self.progress.setRange(0, 1)
                self.progress.setValue(1 if self.last_output else 0)

        def start_processing(self):
            paths, error = self.validate_paths()
            if paths is None:
                if error:
                    QMessageBox.warning(self, "Cannot process", error)
                return
            old_path, new_path, output_path = paths
            self.last_output = ""
            self.set_busy(True)
            self.status.setText("Processing workbook. Large files may take a few minutes...")
            self.log.setPlainText(
                f"Old workbook: {old_path}\n"
                f"New workbook: {new_path}\n"
                f"Output: {output_path}\n\nProcessing..."
            )

            self.worker_thread = QThread(self)
            self.worker = Worker(
                str(old_path), str(new_path), str(output_path), self.keep_unmatched.isChecked()
            )
            self.worker.moveToThread(self.worker_thread)
            self.worker_thread.started.connect(self.worker.run)
            self.worker.finished.connect(self.processing_finished)
            self.worker.failed.connect(self.processing_failed)
            self.worker.finished.connect(self.worker_thread.quit)
            self.worker.failed.connect(self.worker_thread.quit)
            self.worker_thread.finished.connect(self.worker.deleteLater)
            self.worker_thread.finished.connect(self.worker_thread.deleteLater)
            self.worker_thread.start()

        def processing_finished(self, result):
            updated, unmatched, cleared, conflicts = result
            self.last_output = self.output_edit.text().strip()
            self.set_busy(False)
            self.status.setText("Completed successfully.")
            self.log.append(
                "\nCompleted successfully.\n"
                f"Updated instrument rows: {updated}\n"
                f"Unmatched instrument rows: {unmatched}\n"
                f"Cleared asset/total classification cells: {cleared}\n"
                f"Old-data classification conflicts logged: {conflicts}\n\n"
                "See the Audit_Log worksheet for row-level details."
            )
            QMessageBox.information(
                self, "Finished",
                f"The updated workbook was created successfully:\n\n{self.last_output}"
            )

        def processing_failed(self, details: str):
            self.last_output = ""
            self.set_busy(False)
            self.status.setText("Processing failed.")
            self.log.append(f"\nERROR\n{details}")
            QMessageBox.critical(
                self, "Processing failed",
                "The workbook could not be processed. Close the Excel files if they are open, "
                "verify the selected files, and review the detailed error in the log."
            )

        def open_output(self):
            if self.last_output and Path(self.last_output).is_file():
                QDesktopServices.openUrl(QUrl.fromLocalFile(self.last_output))

        def open_folder(self):
            if self.last_output:
                QDesktopServices.openUrl(QUrl.fromLocalFile(str(Path(self.last_output).parent)))

        def closeEvent(self, event):
            if self.worker_thread and self.worker_thread.isRunning():
                QMessageBox.information(
                    self, "Processing in progress",
                    "Wait for workbook processing to finish before closing the application."
                )
                event.ignore()
            else:
                event.accept()

    app = QApplication(sys.argv)
    app.setApplicationName("Portfolio Industry Updater")
    app.setStyle("Fusion")
    window = MainWindow()
    window.show()
    return app.exec()


def main() -> int:
    return run_gui()


if __name__ == "__main__":
    raise SystemExit(main())
