from __future__ import annotations

import re
import sys
import traceback
from copy import deepcopy
from dataclasses import dataclass
from pathlib import Path
from typing import Iterable, Optional

try:
    import wordninja
except ImportError:
    wordninja = None

from docx import Document
from docx.document import Document as DocType
from docx.enum.text import WD_ALIGN_PARAGRAPH, WD_TAB_ALIGNMENT, WD_TAB_LEADER
from docx.oxml import OxmlElement
from docx.oxml.ns import qn
from docx.shared import Inches, Pt, RGBColor
from docx.table import Table
from docx.text.paragraph import Paragraph
from PyQt6.QtCore import QObject, QThread, pyqtSignal
from PyQt6.QtGui import QFont
from PyQt6.QtWidgets import (
    QApplication, QCheckBox, QFileDialog, QGridLayout, QGroupBox, QHBoxLayout,
    QLabel, QLineEdit, QMainWindow, QMessageBox, QPlainTextEdit, QProgressBar,
    QPushButton, QStatusBar, QVBoxLayout, QWidget,
)

APP_TITLE = "Mutual Fund Risk Factor Extractor"
CONTENT_FONT_NAME = "Times New Roman"
CONTENT_FONT_SIZE = 10
INDEX_FONT_NAME = "Times New Roman"
INDEX_FONT_SIZE = 10
FOOTER_FONT_NAME = "Times New Roman"
FOOTER_FONT_SIZE = 9

EQUITY_FUNDS = [
    "Axis Large Cap Fund", "Axis Focused Fund", "Axis ELSS- Tax Saver Fund",
    "Axis Large & Mid Cap Fund", "Axis Flexi Cap Fund", "Axis Multicap Fund",
    "Axis Midcap Fund", "Axis Innovation Fund", "Axis Small Cap Fund",
    "Axis ESG Integration Strategy Fund", "Axis Quant Fund", "Axis Value Fund",
    "Axis Business Cycles Fund", "Axis India Manufacturing Fund", "Axis Consumption Fund",
    "Axis Momentum Fund", "Axis Services Opportunities Fund", "Axis NIFTY 50 ETF",
    "Axis NIFTY Bank ETF", "Axis NIFTY IT ETF", "Axis NIFTY Healthcare ETF",
    "Axis NIFTY India Consumption ETF", "Axis BSE SENSEX ETF", "Axis Nifty500 Value 50 ETF",
    "Axis Nifty Energy ETF", "Axis Nifty 100 Index Fund", "Axis Nifty 50 Index Fund",
    "Axis BSE Sensex Index Fund", "Axis Nifty Next 50 Index Fund",
    "Axis Nifty Smallcap 50 Index Fund", "Axis Nifty Midcap 50 Index Fund",
    "Axis Nifty IT Index Fund", "Axis Nifty Bank Index Fund", "Axis Nifty 500 Index Fund",
    "Axis Nifty500 Value 50 Index Fund", "Axis Nifty500 Momentum 50 Index Fund",
    "Axis Nifty500 Quality 50 Index Fund", "Axis BSE India Sector Leaders Index Fund",
    "Axis Nifty India Defence Index Fund", "Axis Nifty Capital Markets Index Fund",
    "Axis Nifty50 Equal Weight Index Fund", "Axis Nifty Energy Index Fund",
    "Axis Nifty500 Low Volatility 50 Index Fund", "Axis Nifty EV & New Age Automotive Index Fund",
    "Axis Multi Factor Passive FoF", "Axis Global Equity Alpha Fund of Fund",
    "Axis Greater China Equity Fund of Fund", "Axis Global Innovation Fund of Fund",
    "Axis NASDAQ 100 US Specific Equity Passive FOF",
]
DEBT_FUNDS = [
    "Axis Overnight Fund", "Axis Liquid Fund", "Axis Ultra Short Term fund",
    "Axis Floating Interest Rates Fund", "Axis Ultra Short to Short Term Fund",
    "Axis Money Market Fund", "Axis Corporate Bond Fund", "Axis Banking and PSU Debt Fund",
    "Axis Short Term Fund", "Axis Credit Risk Fund", "Axis Dynamic Term Fund",
    "Axis Medium Term Fund", "Axis Long Term Fund", "Axis Gilt Fund",
    "Axis US Specific Treasury Dynamic Debt Passive FOF",
    "Axis CRISIL IBX SDL May 2027 Index Fund", "Axis Nifty SDL September 2026 Debt Index Fund",
    "Axis CRISIL IBX 50:50 Gilt Plus SDL June 2028 Index Fund",
    "Axis CRISIL IBX 50:50 Gilt Plus SDL September 2027 Index Fund",
    "Axis CRISIL-IBX AAA Bond NBFC - Jun 2027 Index Fund",
    "Axis CRISIL-IBX Financial Services 3-6 Months Debt Index Fund",
]
HYBRID_FUNDS = [
    "Axis Conservative Hybrid Fund", "Axis Equity Savings Fund",
    "Axis Multi Asset Allocation Fund", "Axis Aggressive Hybrid Fund",
    "Axis Children's Fund", "Axis Balanced Advantage Fund", "Axis Arbitrage Fund",
    "Axis Retirement Fund - Aggressive Plan", "Axis Retirement Fund - Dynamic Plan",
    "Axis Retirement Fund - Conservative Plan", "Axis Income Plus Arbitrage Omni FOF",
    "Axis Income Plus Arbitrage Passive FOF", "Axis Multi-Asset Omni FoF",
    "Axis Gold and Silver Passive FoF", "Axis Gold Fund", "Axis Silver ETF",
    "Axis Gold ETF", "Axis Silver Fund of Fund",
]
FUND_ORDER = EQUITY_FUNDS + DEBT_FUNDS + HYBRID_FUNDS


def norm(value: str) -> str:
    value = value.casefold().replace("&", " and ").replace("’", "'")
    value = re.sub(r"\bfund\s+of\s+funds?\b|\bfof\b", " fof ", value)
    value = re.sub(r"\bnifty\s*500\b", " nifty500 ", value)
    return re.sub(r"\s+", " ", re.sub(r"[^a-z0-9]+", " ", value)).strip()


ALIASES = {
    "axis childrens fund": "axis children s fund",
    "axis large and midcap fund": "axis large and mid cap fund",
    "axis esg integration fund": "axis esg integration strategy fund",
    "axis healthcare etf": "axis nifty healthcare etf",
    "axis india consumption etf": "axis nifty india consumption etf",
    "axis ultra short duration fund": "axis ultra short term fund",
    "axis short duration fund": "axis short term fund",
    "axis long duration fund": "axis long term fund",
    "axis dynamic bond fund": "axis dynamic term fund",
    "axis floater fund": "axis floating interest rates fund",
    "axis strategic bond fund": "axis medium term fund",
    "axis treasury advantage fund": "axis ultra short to short term fund",
    "axis banking psu debt fund": "axis banking and psu debt fund",
    "axis income plus arbitrage active fof": "axis income plus arbitrage omni fof",
    "axis multi asset active fof": "axis multi asset omni fof",
}


def key(value: str) -> str:
    value = norm(value)
    seen = set()
    while value in ALIASES and value not in seen:
        seen.add(value)
        value = ALIASES[value]
    return value


ORDER = {key(name): i for i, name in enumerate(FUND_ORDER)}
DISPLAY = {key(name): name for name in FUND_ORDER}
CATEGORY = {key(name): "Equity Funds" for name in EQUITY_FUNDS}
CATEGORY.update({key(name): "Debt Funds" for name in DEBT_FUNDS})
CATEGORY.update({key(name): "Hybrid Funds" for name in HYBRID_FUNDS})


def file_fund(path: Path) -> str:
    name = path.stem.strip()
    prefix = r"^(?:(?:NF|SID|KIM)\b\s*[-_:]*\s*)+"
    old = None
    while name != old:
        old = name
        name = re.sub(prefix, "", name, flags=re.I).strip()
    name = re.sub(r"(?:\s*[-_:]\s*|\s+)(?:clean|fac)(?:\s+(?:clean|fac))*\s*$", "", name, flags=re.I)
    return re.sub(r"\s+", " ", name).strip(" -_:") or path.stem


def display_name(path: Path) -> str:
    raw = file_fund(path)
    return DISPLAY.get(key(raw), raw)


def clean_text(value: str) -> str:
    return re.sub(r"\s+", " ", value.replace("\xa0", " ").replace("\u200b", " ")).strip()


def heading_text(value: str) -> str:
    return re.sub(r"\s+", " ", re.sub(r"[^a-z0-9]+", " ", clean_text(value).casefold().replace("&", " and "))).strip()


def is_start(value: str) -> bool:
    value = heading_text(value)
    if value in {"risk factor", "risk factors"}:
        return True
    if re.fullmatch(r"(?:section\s+)?(?:[a-z]|[ivxlcdm]+|\d+)\s+risk\s+factors?", value):
        return True
    return value.endswith((" risk factor", " risk factors")) and len(re.sub(r"\s+risk\s+factors?$", "", value).split()) <= 4


def is_scheme_specific_start(value: str) -> bool:
    return bool(re.match(r"^scheme specific risk factors?(?:\s|$)", heading_text(value)))


def is_end(value: str) -> bool:
    value = heading_text(value)
    return bool(value and (
        re.search(r"\brisk\s+mitigation\s+strateg(?:y|ies)\b", value) or
        re.search(r"\brisk\s+mitigations?\b", value) or
        re.search(r"\brisk\s+control\s+(?:and\s+)?risk\s+mitigation\b", value) or
        value.startswith("information about the scheme")
    ))


def descendants(element, tag: str) -> list:
    wanted = qn(tag)
    return [node for node in element.iter() if node.tag == wanted]


def xml_text(element) -> str:
    chunks = []
    for node in element.iter():
        if node.tag in {qn("w:t"), qn("w:delText")} and node.text:
            chunks.append(node.text)
        elif node.tag in {qn("w:tab"), qn("w:br")}:
            chunks.append(" ")
    return clean_text("".join(chunks))


def table_has(table, predicate) -> bool:
    return any(predicate(xml_text(p)) for p in descendants(table, "w:p"))


def iter_blocks(parent) -> Iterable[Paragraph | Table]:
    root = parent.element.body if isinstance(parent, DocType) else parent._tc
    for child in root.iterchildren():
        if child.tag == qn("w:p"):
            yield Paragraph(child, parent)
        elif child.tag == qn("w:tbl"):
            yield Table(child, parent)


@dataclass
class Extraction:
    elements: list
    start: str
    end: str


@dataclass
class FundResult:
    path: Path
    name: str
    extraction: Optional[Extraction]
    warning: str = ""


def extract_legacy(doc: DocType) -> Extraction:
    blocks = list(iter_blocks(doc))
    starts = [i for i, block in enumerate(blocks) if isinstance(block, Paragraph) and is_start(block.text)]
    if not starts:
        raise ValueError("Risk factors was not found in a top-level paragraph")
    start = starts[-1]
    for end in range(start + 1, len(blocks)):
        block = blocks[end]
        if (isinstance(block, Paragraph) and is_end(block.text)) or (isinstance(block, Table) and table_has(block._element, is_end)):
            return Extraction([deepcopy(item._element) for item in blocks[start:end]], "paragraph", "top-level block")
    raise ValueError("Risk factors was found, but its ending was not found")


def _run_text(run) -> str:
    chunks = []
    for node in run.iter():
        if node.tag in {qn("w:t"), qn("w:delText")} and node.text:
            chunks.append(node.text)
        elif node.tag in {qn("w:tab"), qn("w:br")}:
            chunks.append(" ")
    return "".join(chunks)


def _first_text_node(run):
    return next(
        (node for node in run.iter() if node.tag == qn("w:t") and node.text),
        None,
    )


def _needs_boundary_space(left: str, right: str) -> bool:
    """Return True when two adjacent Word runs represent separate words."""
    if not left or not right or left[-1].isspace() or right[0].isspace():
        return False

    left_char = left[-1]
    right_char = right[0]

    # These characters normally join text without an added blank.
    no_space_before = ",.;:!?%)]}’'\"/-–—"
    no_space_after = "([{’'\"/-–—"
    if right_char in no_space_before or left_char in no_space_after:
        return False

    # A boundary between two separate runs from PDF-to-Word conversion is
    # generally a missing word space. This also covers letter/number joins.
    return (
        left_char.isalnum() or left_char in ")]%"
    ) and (
        right_char.isalnum() or right_char in "(["
    )


JOINED_WORD_EXCLUSIONS = {
    "notwithstanding", "counterparty", "counterparties", "infrastructure",
    "international", "characteristics", "underperformance", "diversification",
    "telecommunication", "telecommunications", "capitalisation", "capitalization",
    "securitisation", "securitization", "intermediaries", "responsibilities",
}

# Financial and scheme terms that should remain recognizable during segmentation.
SEGMENT_REPLACEMENTS = {
    "bseindia": "BSE India",
    "niftyindia": "Nifty India",
    "fundmanager": "fund manager",
    "riskfactors": "risk factors",
    "schemespecific": "Scheme Specific",
    "trackingerror": "Tracking Error",
    "underlyingindex": "underlying index",
    "passiveinvestments": "Passive Investments",
    "circuitfilters": "circuit filters",
    "corporateactions": "corporate actions",
    "nonavailability": "non-availability",
    "thefundmanager": "The fund manager",
    "thescheme": "The Scheme",
    "schemeproviding": "Scheme providing",
    "sectorleaders": "Sector Leaders",
    "entirecorpusexactly": "entire corpus exactly",
    "sameproportionasinthe": "same proportion as in the",
    "delayinpurchase": "delay in purchase",
    "delayinliquidation": "delay in liquidation",
    "securitiestrading": "securities trading",
    "temporarilydueto": "temporarily due to",
    "rightsissuances": "rights issuances",
    "changeinconstituents": "change in constituents",
    "roundingoff": "rounding-off",
    "interestreceived": "interest received",
    "stockdividendpayout": "stock dividend payout",
}


def split_camel_boundaries(value: str) -> str:
    value = re.sub(r"(?<=[a-z])(?=[A-Z])", " ", value)
    value = re.sub(r"(?<=[A-Za-z])(?=\d)|(?<=\d)(?=[A-Za-z])", " ", value)
    return value


def split_suspicious_token(token: str) -> str:
    """Split a likely PDF-conversion word chain without touching normal words."""
    if not token or token.casefold() in JOINED_WORD_EXCLUSIONS:
        return token

    # Apply high-confidence domain replacements first.
    working = token
    for joined, spaced in sorted(SEGMENT_REPLACEMENTS.items(), key=lambda item: len(item[0]), reverse=True):
        working = re.sub(re.escape(joined), spaced, working, flags=re.I)

    pieces = re.split(r"(\s+|[-/])", working)
    output = []
    for piece in pieces:
        if not piece or piece.isspace() or piece in {"-", "/"}:
            output.append(piece)
            continue

        camel_split = split_camel_boundaries(piece)
        camel_parts = camel_split.split()
        repaired_parts = []
        for part in camel_parts:
            lower = part.casefold()
            suspicious = len(part) >= 9 and part.isalpha() and lower not in JOINED_WORD_EXCLUSIONS
            if suspicious and wordninja is not None:
                words = wordninja.split(part)

                # wordninja legitimately returns one-letter words such as
                # "a" and "I". The previous all(len(w) >= 2) condition rejected
                # the complete repair whenever a merged sentence contained "a",
                # which is why long strings remained joined in the output.
                joined_length = sum(len(w) for w in words)
                one_letter_count = sum(1 for w in words if len(w) == 1)
                meaningful = (
                    len(words) >= 2
                    and joined_length == len(part)
                    and one_letter_count <= max(2, len(words) // 4)
                )

                if meaningful:
                    # Preserve initial capitalization for sentence starts and
                    # headings. Known acronyms are restored separately below.
                    if part[:1].isupper() and words:
                        words[0] = words[0][:1].upper() + words[0][1:]
                    restored = " ".join(words)
                    acronym_map = {
                        "bse": "BSE", "nifty": "Nifty", "sebi": "SEBI",
                        "nav": "NAV", "reit": "REIT", "reits": "REITs",
                        "etf": "ETF", "fof": "FoF", "sdl": "SDL",
                        "ibx": "IBX", "nbfc": "NBFC", "psu": "PSU",
                    }
                    restored = re.sub(
                        r"\b(?:bse|nifty|sebi|nav|reit|reits|etf|fof|sdl|ibx|nbfc|psu)\b",
                        lambda m: acronym_map[m.group(0).casefold()],
                        restored,
                        flags=re.I,
                    )
                    repaired_parts.append(restored)
                else:
                    repaired_parts.append(part)
            else:
                repaired_parts.append(part)
        output.append(" ".join(repaired_parts))
    return "".join(output)


def repair_joined_words_in_paragraph(paragraph) -> None:
    """Repair words already concatenated inside a single Word text node."""
    for node in paragraph.iter():
        if node.tag != qn("w:t") or not node.text:
            continue
        original = node.text
        repaired = re.sub(
            r"[A-Za-z][A-Za-z0-9’'/-]{8,}",
            lambda match: split_suspicious_token(match.group(0)),
            original,
        )
        if repaired != original:
            node.text = repaired
            if repaired.startswith(" ") or repaired.endswith(" ") or "  " in repaired:
                node.set(qn("xml:space"), "preserve")


def repair_paragraph_word_boundaries(paragraph) -> None:
    """
    Restore spaces omitted by PDF-to-Word conversion.

    Runs are collected recursively, not only as direct paragraph children.
    This is important because converted documents frequently place runs inside
    hyperlinks, smart tags, tracked-change wrappers, or other XML containers.
    """
    runs = [node for node in paragraph.iter() if node.tag == qn("w:r")]
    previous_text = ""

    for run in runs:
        current_text = _run_text(run)
        if not current_text:
            continue

        if previous_text and _needs_boundary_space(previous_text, current_text):
            first_text = _first_text_node(run)
            if first_text is not None and not first_text.text.startswith(" "):
                first_text.text = " " + first_text.text
                first_text.set(qn("xml:space"), "preserve")
                current_text = " " + current_text

        previous_text = current_text


def table_risk_paragraphs(table, already_started: bool) -> tuple[list, bool, bool]:
    output = []
    started = already_started
    finished = False
    for row in table.findall(qn("w:tr")):
        for cell in row.findall(qn("w:tc")):
            for paragraph in descendants(cell, "w:p"):
                value = xml_text(paragraph)
                if not started:
                    if not is_scheme_specific_start(value):
                        continue
                    started = True
                if is_end(value):
                    finished = True
                    break
                if heading_text(value) in {"risk factor", "risk factors"} or not value:
                    continue
                clone = deepcopy(paragraph)
                repair_paragraph_word_boundaries(clone)
                output.append(clone)
            if finished:
                break
        if finished:
            break
    return output, started, finished


def extract_table_aware(doc: DocType) -> Extraction:
    output = []
    started = finished = False
    start_place = ""
    end_place = "document end"
    for child in doc.element.body.iterchildren():
        if finished:
            break
        if child.tag == qn("w:p"):
            value = xml_text(child)
            if not started and is_scheme_specific_start(value):
                started = True
                start_place = "paragraph"
            if started and is_end(value):
                finished = True
                end_place = "paragraph"
                break
            if started and value:
                clone = deepcopy(child)
                repair_paragraph_word_boundaries(clone)
                output.append(clone)
        elif child.tag == qn("w:tbl"):
            paragraphs, now_started, table_finished = table_risk_paragraphs(child, started)
            if not started and now_started:
                start_place = "table converted to paragraphs"
            started = now_started
            output.extend(paragraphs)
            if table_finished:
                finished = True
                end_place = "table cell"
    if not started:
        raise ValueError("Scheme Specific Risk Factors was not found in paragraphs or table cells")
    if not output:
        raise ValueError("Scheme Specific Risk Factors heading was found, but no content followed it")
    return Extraction(output, start_place, end_place)


def extract(doc: DocType) -> Extraction:
    try:
        return extract_legacy(doc)
    except ValueError as first:
        try:
            return extract_table_aware(doc)
        except ValueError as second:
            raise ValueError(f"Old logic: {first}. Table logic: {second}") from second


def unwrap(node) -> None:
    parent = node.getparent()
    if parent is None:
        return
    position = parent.index(node)
    for child in list(node):
        parent.insert(position, child)
        position += 1
    parent.remove(node)


def clean_element(element, first=False) -> None:
    for node in list(descendants(element, "w:hyperlink")) + list(descendants(element, "w:fldSimple")):
        unwrap(node)
    remove_tags = (
        "w:footnoteReference", "w:endnoteReference", "w:commentReference", "w:commentRangeStart",
        "w:commentRangeEnd", "w:instrText", "w:fldChar", "w:bookmarkStart", "w:bookmarkEnd",
        "w:drawing", "w:pict", "w:object", "w:sectPr", "w:proofErr",
        "w:lastRenderedPageBreak", "w:del", "w:moveFrom", "w:rPrChange", "w:pPrChange",
    )
    for tag in remove_tags:
        for node in list(descendants(element, tag)):
            if node.getparent() is not None:
                node.getparent().remove(node)
    for tag in ("w:ins", "w:moveTo"):
        for node in list(descendants(element, tag)):
            unwrap(node)
    paragraphs = ([element] if element.tag == qn("w:p") else []) + descendants(element, "w:p")
    for paragraph in paragraphs:
        ppr = paragraph.find(qn("w:pPr"))
        if ppr is None:
            ppr = OxmlElement("w:pPr")
            paragraph.insert(0, ppr)
        outline = ppr.find(qn("w:outlineLvl"))
        if outline is None:
            outline = OxmlElement("w:outlineLvl")
            ppr.append(outline)
        outline.set(qn("w:val"), "9")
    # Remove source-document pagination from every extracted block.
    # The combined document controls pagination itself with one page break
    # before each fund. Keeping pageBreakBefore or manual page breaks copied
    # from source files can create completely blank pages between funds or at
    # the end of the document.
    for node in list(descendants(element, "w:pageBreakBefore")):
        if node.getparent() is not None:
            node.getparent().remove(node)
    for node in list(descendants(element, "w:br")):
        if node.get(qn("w:type")) == "page" and node.getparent() is not None:
            node.getparent().remove(node)


def professionalize(element) -> None:
    for rpr in descendants(element, "w:rPr"):
        for tag in ("w:spacing", "w:w", "w:position", "w:kern", "w:fitText"):
            node = rpr.find(qn(tag))
            if node is not None:
                rpr.remove(node)
    paragraphs = ([element] if element.tag == qn("w:p") else []) + descendants(element, "w:p")
    for paragraph in paragraphs:
        ppr = paragraph.find(qn("w:pPr"))
        if ppr is None:
            ppr = OxmlElement("w:pPr")
            paragraph.insert(0, ppr)
        for tag in ("w:keepLines", "w:pageBreakBefore"):
            node = ppr.find(qn(tag))
            if node is not None:
                ppr.remove(node)
        spacing = ppr.find(qn("w:spacing"))
        if spacing is None:
            spacing = OxmlElement("w:spacing")
            ppr.append(spacing)
        spacing.set(qn("w:before"), "0")
        spacing.set(qn("w:after"), "80")
        spacing.set(qn("w:line"), "276")
        spacing.set(qn("w:lineRule"), "auto")
        jc = ppr.find(qn("w:jc"))
        if jc is None:
            jc = OxmlElement("w:jc")
            ppr.append(jc)
        if jc.get(qn("w:val")) in (None, "both", "distribute", "thaiDistribute"):
            jc.set(qn("w:val"), "left")


def apply_content_font(element) -> None:
    runs = ([element] if element.tag == qn("w:r") else []) + descendants(element, "w:r")
    for run in runs:
        rpr = run.find(qn("w:rPr"))
        if rpr is None:
            rpr = OxmlElement("w:rPr")
            run.insert(0, rpr)
        fonts = rpr.find(qn("w:rFonts"))
        if fonts is None:
            fonts = OxmlElement("w:rFonts")
            rpr.insert(0, fonts)
        for attribute in ("w:ascii", "w:hAnsi", "w:eastAsia", "w:cs"):
            fonts.set(qn(attribute), CONTENT_FONT_NAME)
        size = rpr.find(qn("w:sz"))
        if size is None:
            size = OxmlElement("w:sz")
            rpr.append(size)
        size.set(qn("w:val"), str(CONTENT_FONT_SIZE * 2))
        size_cs = rpr.find(qn("w:szCs"))
        if size_cs is None:
            size_cs = OxmlElement("w:szCs")
            rpr.append(size_cs)
        size_cs.set(qn("w:val"), str(CONTENT_FONT_SIZE * 2))


def append_clean(doc: DocType, element, first=False) -> None:
    clone = deepcopy(element)

    # Apply the boundary repair to every paragraph, including legacy extracts
    # and paragraphs inside copied tables. Running it here makes the repair
    # consistent across both extraction paths without using slow Word COM loops.
    paragraphs = ([clone] if clone.tag == qn("w:p") else []) + descendants(clone, "w:p")
    for paragraph in paragraphs:
        repair_paragraph_word_boundaries(paragraph)
        repair_joined_words_in_paragraph(paragraph)

    clean_element(clone, first)
    professionalize(clone)
    apply_content_font(clone)
    doc.element.body.insert(len(doc.element.body) - 1, clone)


def clear_body(doc: DocType) -> None:
    for child in list(doc.element.body):
        if child.tag != qn("w:sectPr"):
            doc.element.body.remove(child)


def set_outline(paragraph: Paragraph, level: int) -> None:
    ppr = paragraph._p.get_or_add_pPr()
    outline = ppr.find(qn("w:outlineLvl"))
    if outline is None:
        outline = OxmlElement("w:outlineLvl")
        ppr.append(outline)
    outline.set(qn("w:val"), str(level))


def shade(paragraph: Paragraph, color: str) -> None:
    ppr = paragraph._p.get_or_add_pPr()
    shd = ppr.find(qn("w:shd"))
    if shd is None:
        shd = OxmlElement("w:shd")
        ppr.append(shd)
    shd.set(qn("w:fill"), color)


def clean_headers_footers(doc: DocType) -> None:
    for section in doc.sections:
        section.different_first_page_header_footer = False
        section.odd_and_even_pages_header_footer = False
        containers = (
            section.header, section.first_page_header, section.even_page_header,
            section.footer, section.first_page_footer, section.even_page_footer,
        )
        seen_parts = set()
        for container in containers:
            container.is_linked_to_previous = False
            part_id = id(container.part)
            if part_id in seen_parts:
                continue
            seen_parts.add(part_id)
            for child in list(container._element):
                container._element.remove(child)
            container._element.append(OxmlElement("w:p"))


def add_field(paragraph: Paragraph, instruction: str, result="1", font_name=None, font_size=None) -> None:
    field_runs = []
    run = paragraph.add_run(); field_runs.append(run)
    begin = OxmlElement("w:fldChar"); begin.set(qn("w:fldCharType"), "begin"); begin.set(qn("w:dirty"), "true"); run._r.append(begin)
    run = paragraph.add_run(); field_runs.append(run)
    code = OxmlElement("w:instrText"); code.set(qn("xml:space"), "preserve"); code.text = instruction; run._r.append(code)
    run = paragraph.add_run(); field_runs.append(run)
    separate = OxmlElement("w:fldChar"); separate.set(qn("w:fldCharType"), "separate"); run._r.append(separate)
    run = paragraph.add_run(result); field_runs.append(run)
    run = paragraph.add_run(); field_runs.append(run)
    end = OxmlElement("w:fldChar"); end.set(qn("w:fldCharType"), "end"); run._r.append(end)
    for field_run in field_runs:
        if font_name:
            field_run.font.name = font_name
            rfonts = field_run._element.get_or_add_rPr().get_or_add_rFonts()
            for attr in ("w:ascii", "w:hAnsi", "w:eastAsia", "w:cs"):
                rfonts.set(qn(attr), font_name)
        if font_size:
            field_run.font.size = Pt(font_size)


def add_footer_pages(doc: DocType) -> None:
    for section_index, section in enumerate(doc.sections):
        section.different_first_page_header_footer = False
        section.odd_and_even_pages_header_footer = False
        section.footer_distance = Inches(0.25)
        footer = section.footer
        footer.is_linked_to_previous = section_index > 0
        if section_index > 0:
            continue
        for child in list(footer._element):
            footer._element.remove(child)
        paragraph_element = OxmlElement("w:p")
        footer._element.append(paragraph_element)
        paragraph = Paragraph(paragraph_element, footer)
        paragraph.alignment = WD_ALIGN_PARAGRAPH.CENTER
        paragraph.paragraph_format.space_before = Pt(0)
        paragraph.paragraph_format.space_after = Pt(0)
        add_field(paragraph, " PAGE ", "1", FOOTER_FONT_NAME, FOOTER_FONT_SIZE)


def add_index(doc: DocType, funds: list[FundResult]) -> list[Paragraph]:
    title = doc.add_paragraph()
    title.alignment = WD_ALIGN_PARAGRAPH.RIGHT
    title.paragraph_format.space_after = Pt(3)
    shade(title, "A70F4D")
    run = title.add_run("  I N D E X  ")
    run.bold = True; run.font.name = INDEX_FONT_NAME; run.font.size = Pt(18); run.font.color.rgb = RGBColor(255, 255, 255)
    set_outline(title, 9)
    section = doc.sections[-1]
    right_tab_position = section.page_width - section.left_margin - section.right_margin - Pt(6)
    groups = {name: [] for name in ("Equity Funds", "Debt Funds", "Hybrid Funds", "Other Funds")}
    for fund in funds:
        groups[CATEGORY.get(key(fund.name), "Other Funds")].append(fund)
    colors = {"Equity Funds": "008C95", "Debt Funds": "5F6995", "Hybrid Funds": "EE8394", "Other Funds": "7F7F7F"}
    entries = []
    serial_number = 1
    for group, members in groups.items():
        if not members:
            continue
        heading = doc.add_paragraph(); heading.paragraph_format.keep_with_next = True; heading.paragraph_format.space_after = Pt(1); shade(heading, colors[group])
        r = heading.add_run("  " + group); r.bold = True; r.font.name = INDEX_FONT_NAME; r.font.size = Pt(INDEX_FONT_SIZE); r.font.color.rgb = RGBColor(255, 255, 255)
        set_outline(heading, 9)
        for fund in members:
            p = doc.add_paragraph()
            p.paragraph_format.space_before = Pt(0); p.paragraph_format.space_after = Pt(1); p.paragraph_format.line_spacing = 1
            p.paragraph_format.tab_stops.add_tab_stop(right_tab_position, WD_TAB_ALIGNMENT.RIGHT, WD_TAB_LEADER.DOTS)
            r = p.add_run(f"{serial_number}.  "); r.font.name = INDEX_FONT_NAME; r.font.size = Pt(INDEX_FONT_SIZE)
            r = p.add_run(fund.name); r.font.name = INDEX_FONT_NAME; r.font.size = Pt(INDEX_FONT_SIZE)
            set_outline(p, 9)
            entries.append(p)
            serial_number += 1
    doc.add_page_break()
    return entries


def add_bookmark(paragraph: Paragraph, name: str, number: int) -> None:
    start = OxmlElement("w:bookmarkStart"); start.set(qn("w:id"), str(number)); start.set(qn("w:name"), name)
    end = OxmlElement("w:bookmarkEnd"); end.set(qn("w:id"), str(number))
    paragraph._p.insert(0, start); paragraph._p.append(end)


def add_title(doc: DocType, name: str) -> Paragraph:
    p = doc.add_paragraph(); p.alignment = WD_ALIGN_PARAGRAPH.CENTER; p.paragraph_format.keep_with_next = True; set_outline(p, 0)
    r = p.add_run(name); r.bold = True; r.font.size = Pt(20); r.font.color.rgb = RGBColor(31, 78, 121)
    return p


def request_update(doc: DocType) -> None:
    settings = doc.settings._element
    update = settings.find(qn("w:updateFields"))
    if update is None:
        update = OxmlElement("w:updateFields")
        settings.append(update)
    update.set(qn("w:val"), "true")


def remove_trailing_blank_page(document) -> bool:
    """Remove a genuinely empty final Word page without deleting content."""
    wd_statistic_pages = 2
    wd_go_to_page = 1
    wd_go_to_absolute = 1

    try:
        document.Repaginate()
        page_count = document.ComputeStatistics(wd_statistic_pages)
        if page_count <= 1:
            return False

        last_page_start = document.GoTo(
            What=wd_go_to_page,
            Which=wd_go_to_absolute,
            Count=page_count,
        ).Start
        last_page = document.Range(last_page_start, document.Content.End)

        visible = str(last_page.Text).replace("\r", "").replace("\x07", "").replace("\f", "").strip()
        if visible:
            return False
        if last_page.Tables.Count or last_page.InlineShapes.Count or last_page.ShapeRange.Count:
            return False

        # Delete only the empty page range. If Word leaves a terminal paragraph,
        # remove a preceding manual page break as a second safe cleanup.
        last_page.Delete()
        end_probe_start = max(0, document.Content.End - 4)
        end_probe = document.Range(end_probe_start, document.Content.End)
        if "\f" in str(end_probe.Text):
            end_probe.Text = str(end_probe.Text).replace("\f", "")
        document.Repaginate()
        return True
    except Exception:
        return False


def configure_word_footer(document) -> None:
    for section_number in range(1, document.Sections.Count + 1):
        section = document.Sections.Item(section_number)
        section.PageSetup.DifferentFirstPageHeaderFooter = False
        section.PageSetup.OddAndEvenPagesHeaderFooter = False
        footer = section.Footers.Item(1)
        if section_number == 1:
            footer.LinkToPrevious = False
            footer.Range.Text = ""
            paragraph = footer.Range.Paragraphs.Item(1)
            paragraph.Alignment = 1
            paragraph.Format.SpaceBefore = 0
            paragraph.Format.SpaceAfter = 0
            field_range = paragraph.Range
            field_range.Collapse(0)
            document.Fields.Add(Range=field_range, Type=33, PreserveFormatting=True)
            footer.Range.Font.Name = FOOTER_FONT_NAME
            footer.Range.Font.Size = FOOTER_FONT_SIZE
        else:
            footer.LinkToPrevious = True


def materialize(path: Path, report, base_step: int, total_steps: int, cancelled) -> bool:
    if sys.platform != "win32":
        return False
    pythoncom = word = document = None
    try:
        import pythoncom
        import win32com.client
        report(base_step, total_steps, path.name, "Formatting 1/7: Starting Microsoft Word")
        if cancelled(): raise InterruptedError("Cancelled")
        pythoncom.CoInitialize()
        word = win32com.client.DispatchEx("Word.Application")
        word.Visible = False; word.DisplayAlerts = 0; word.ScreenUpdating = False
        try:
            word.Options.CheckSpellingAsYouType = False
            word.Options.CheckGrammarAsYouType = False
            word.Options.CheckGrammarWithSpelling = False
            word.Options.Pagination = False
        except Exception:
            pass
        document = word.Documents.Open(str(path.resolve()), ReadOnly=False, AddToRecentFiles=False, Visible=False, OpenAndRepair=True)
        report(base_step + 1, total_steps, path.name, "Formatting 2/7: Output opened and repaired")
        if cancelled(): raise InterruptedError("Cancelled")
        try: document.TrackRevisions = False
        except Exception: pass
        try: document.DeleteAllComments()
        except Exception: pass
        report(base_step + 2, total_steps, path.name, "Formatting 3/7: Comments removed")
        if cancelled(): raise InterruptedError("Cancelled")
        main_range = document.StoryRanges.Item(1)
        try:
            main_range.Font.Spacing = 0; main_range.Font.Scaling = 100; main_range.Font.Position = 0; main_range.Font.Kerning = 0
        except Exception:
            pass
        report(base_step + 3, total_steps, path.name, "Formatting 4/7: Character spacing normalized in bulk")
        if cancelled(): raise InterruptedError("Cancelled")
        try: word.Options.Pagination = True
        except Exception: pass
        document.Repaginate()
        report(base_step + 4, total_steps, path.name, "Formatting 5/7: Calculating index page numbers")
        if cancelled(): raise InterruptedError("Cancelled")
        try:
            fields = document.StoryRanges.Item(1).Fields
            for field_number in range(fields.Count, 0, -1):
                try:
                    field = fields.Item(field_number)
                    if field.Type == 37:
                        field.Update(); field.Unlink()
                except Exception:
                    pass
        except Exception:
            pass
        report(base_step + 5, total_steps, path.name, "Formatting 6/7: Creating centered page-number footer")
        if cancelled(): raise InterruptedError("Cancelled")
        configure_word_footer(document)
        remove_trailing_blank_page(document)
        try:
            for section_number in range(1, document.Sections.Count + 1):
                document.Sections.Item(section_number).Footers.Item(1).Range.Fields.Update()
        except Exception:
            pass
        report(base_step + 6, total_steps, path.name, "Formatting 7/7: Saving final professional document")
        if cancelled(): raise InterruptedError("Cancelled")
        document.Repaginate()
        document.SaveAs2(str(path.resolve()), FileFormat=16, AddToRecentFiles=False)
        report(total_steps, total_steps, path.name, "Complete: extraction, index, serial numbers, page references, formatting, and footer finished")
        return True
    except InterruptedError:
        raise
    except Exception:
        return False
    finally:
        if document is not None:
            try: document.Close(SaveChanges=False)
            except Exception: pass
        if word is not None:
            try: word.ScreenUpdating = True
            except Exception: pass
            try: word.Quit()
            except Exception: pass
        if pythoncom is not None:
            try: pythoncom.CoUninitialize()
            except Exception: pass


def build(files: list[Path], output: Path, report, cancelled):
    funds = []
    warnings = []
    file_count = len(files)
    formatting_steps = 7
    total_steps = file_count * 2 + formatting_steps
    report(0, total_steps, "Batch", f"Phase 1/3: Extracting Risk Factors from {file_count} documents")
    for i, path in enumerate(files, 1):
        if cancelled(): raise InterruptedError("Cancelled")
        report(i - 1, total_steps, path.name, f"Extracting {i}/{file_count}: Reading document")
        try:
            section = extract(Document(path))
            funds.append(FundResult(path, display_name(path), section))
            report(i, total_steps, path.name, f"Extracting {i}/{file_count}: Risk Factors extracted; {len(section.elements)} block(s) found")
        except Exception as error:
            message = str(error)
            funds.append(FundResult(path, display_name(path), None, message))
            warnings.append(f"{path.name}: blank page added because {message}")
            report(i, total_steps, path.name, f"Extracting {i}/{file_count}: No extractable Risk Factors; blank page queued")
    if not funds:
        raise RuntimeError("No Word files were available")
    report(file_count, total_steps, output.name, "Phase 2/3: Creating index with serial numbers and minimal page margins")
    doc = Document(funds[0].path)
    clear_body(doc)
    clean_headers_footers(doc)
    for section in doc.sections:
        section.left_margin = Inches(0.45); section.right_margin = Inches(0.45)
        section.top_margin = Inches(0.45); section.bottom_margin = Inches(0.55)
        section.header_distance = Inches(0.2); section.footer_distance = Inches(0.25)
    entries = add_index(doc, funds)
    titles = []
    for i, fund in enumerate(funds, 1):
        if cancelled(): raise InterruptedError("Cancelled")
        report(file_count + i - 1, total_steps, fund.name, f"Pasting {i}/{file_count}: Creating fund page")
        if i > 1:
            doc.add_page_break()
        title = add_title(doc, fund.name)
        titles.append(title)
        if fund.extraction is not None:
            for n, element in enumerate(fund.extraction.elements):
                append_clean(doc, element, n == 0)
            detail = f"Pasting {i}/{file_count}: Added {len(fund.extraction.elements)} formatted paragraph block(s)"
        else:
            detail = f"Pasting {i}/{file_count}: Added titled blank page"
        report(file_count + i, total_steps, fund.name, detail)
    report(file_count * 2, total_steps, output.name, "Phase 3/3: Preparing index fields and centered footer")
    clean_headers_footers(doc)
    add_footer_pages(doc)
    for i, (entry, title) in enumerate(zip(entries, titles), 1):
        bookmark = f"Fund_{i:03d}"
        add_bookmark(title, bookmark, i)
        tab_run = entry.add_run("\t"); tab_run.font.name = INDEX_FONT_NAME; tab_run.font.size = Pt(INDEX_FONT_SIZE)
        add_field(entry, f" PAGEREF {bookmark} \\h ", "0", INDEX_FONT_NAME, INDEX_FONT_SIZE)
    request_update(doc)
    output.parent.mkdir(parents=True, exist_ok=True)
    doc.save(output)
    report(file_count * 2, total_steps, output.name, "Combined draft saved; starting Microsoft Word formatting")
    if cancelled():
        raise InterruptedError("Cancelled")
    formatted = materialize(output, report, file_count * 2, total_steps, cancelled)
    if not formatted:
        raise RuntimeError("Microsoft Word formatting failed. Close the output document, confirm Microsoft Word is installed, and run again.")
    return len(funds), warnings


class Worker(QObject):
    progress = pyqtSignal(int, int, str, str)
    log = pyqtSignal(str)
    done = pyqtSignal(int, int, str, list, list)
    failed = pyqtSignal(str)

    def __init__(self, folder, output, recursive):
        super().__init__(); self.folder = folder; self.output = output; self.recursive = recursive; self.cancelled = False

    def cancel(self):
        self.cancelled = True

    def run(self):
        try:
            pattern = "**/*.docx" if self.recursive else "*.docx"
            files = [p for p in self.folder.glob(pattern) if not p.name.startswith("~$") and p.resolve() != self.output.resolve()]
            files.sort(key=lambda p: (ORDER.get(key(file_fund(p)), len(FUND_ORDER)), p.name.casefold()))
            by_key = {}
            for p in files:
                by_key.setdefault(key(file_fund(p)), []).append(p)
            missing = [name for name in FUND_ORDER if key(name) not in by_key]
            self.log.emit(f"Required funds: {len(FUND_ORDER)}\nWord files found: {len(files)}\nMissing required funds: {len(missing)}")
            count, warnings = build(files, self.output, lambda a, b, c, d: self.progress.emit(a, b, c, d), lambda: self.cancelled)
            self.done.emit(count, len(files), str(self.output), warnings, missing)
        except InterruptedError:
            self.failed.emit("The operation was cancelled.")
        except Exception:
            self.failed.emit(traceback.format_exc())


class MainWindow(QMainWindow):
    def __init__(self):
        super().__init__(); self.thread = None; self.worker = None; self.setWindowTitle(APP_TITLE); self.resize(900, 650); self.ui(); self.style()

    def ui(self):
        central = QWidget(); self.setCentralWidget(central); root = QVBoxLayout(central)
        title = QLabel(APP_TITLE); title.setObjectName("title"); root.addWidget(title)
        subtitle = QLabel("Creates a serial-numbered grouped index, centered footer page numbers, and a blank titled page when Risk factors cannot be extracted."); subtitle.setWordWrap(True); root.addWidget(subtitle)
        box = QGroupBox("Input and output"); grid = QGridLayout(box); grid.setColumnStretch(1, 1)
        self.folder = QLineEdit(); self.output = QLineEdit(); self.recursive = QCheckBox("Include subfolders")
        browse = QPushButton("Browse folder"); save = QPushButton("Choose output"); browse.clicked.connect(self.pick_folder); save.clicked.connect(self.pick_output)
        grid.addWidget(QLabel("Source folder"), 0, 0); grid.addWidget(self.folder, 0, 1); grid.addWidget(browse, 0, 2)
        grid.addWidget(QLabel("Output file"), 1, 0); grid.addWidget(self.output, 1, 1); grid.addWidget(save, 1, 2); grid.addWidget(self.recursive, 2, 1); root.addWidget(box)
        self.current = QLabel("Ready"); self.phase = QLabel("Select a folder"); self.bar = QProgressBar(); self.counter = QLabel("0 / 0")
        for widget in (self.current, self.phase, self.bar, self.counter): root.addWidget(widget)
        self.logs = QPlainTextEdit(); self.logs.setReadOnly(True); root.addWidget(self.logs, 1)
        buttons = QHBoxLayout(); buttons.addStretch(); self.stop = QPushButton("Cancel"); self.start = QPushButton("Extract Risk Factors"); self.start.setObjectName("primary"); self.stop.setEnabled(False)
        self.start.clicked.connect(self.run); self.stop.clicked.connect(self.cancel); buttons.addWidget(self.stop); buttons.addWidget(self.start); root.addLayout(buttons); self.setStatusBar(QStatusBar())

    def style(self):
        self.setFont(QFont("Segoe UI", 10))
        self.setStyleSheet("QMainWindow{background:#f5f7fb} QLabel#title{font-size:24px;font-weight:700;color:#17365d} QGroupBox{background:white;border:1px solid #d9e1ec;border-radius:8px;margin-top:10px;padding:12px;font-weight:600} QLineEdit,QPlainTextEdit{background:white;border:1px solid #cbd5e1;border-radius:6px;padding:7px} QPushButton{background:#e8eef7;color:#17365d;border:0;border-radius:6px;padding:8px 14px;font-weight:600} QPushButton#primary{background:#1565c0;color:white} QProgressBar{text-align:center;min-height:22px} QProgressBar::chunk{background:#2e7d32}")

    def pick_folder(self):
        path = QFileDialog.getExistingDirectory(self, "Select Word folder")
        if path:
            self.folder.setText(path); self.output.setText(str(Path(path) / "Combined Risk Factors.docx"))

    def pick_output(self):
        path, _ = QFileDialog.getSaveFileName(self, "Save output", self.output.text(), "Word (*.docx)")
        if path:
            self.output.setText(path if path.lower().endswith(".docx") else path + ".docx")

    def run(self):
        folder = Path(self.folder.text().strip()); output = Path(self.output.text().strip() or folder / "Combined Risk Factors.docx")
        if not folder.is_dir():
            QMessageBox.warning(self, "Invalid folder", "Select a valid folder"); return
        self.logs.clear(); self.start.setEnabled(False); self.stop.setEnabled(True); self.thread = QThread(self); self.worker = Worker(folder, output, self.recursive.isChecked()); self.worker.moveToThread(self.thread)
        self.thread.started.connect(self.worker.run); self.worker.progress.connect(self.progress); self.worker.log.connect(self.logs.appendPlainText); self.worker.done.connect(self.finished); self.worker.failed.connect(self.failure); self.worker.done.connect(self.thread.quit); self.worker.failed.connect(self.thread.quit); self.thread.finished.connect(self.cleanup); self.thread.start()

    def progress(self, a, b, c, d):
        percent = round(a * 100 / b) if b else 0
        self.bar.setValue(percent); self.current.setText(c); self.phase.setText(d); self.counter.setText(f"{a} / {b}  ({percent}%)")
        self.logs.appendPlainText(f"[{a}/{b}] [{percent:3d}%] {c}: {d}")

    def cancel(self):
        if self.worker:
            self.worker.cancel(); self.stop.setEnabled(False)

    def finished(self, count, total, output, warnings, missing):
        self.bar.setValue(100); self.logs.appendPlainText(f"\nSaved: {output}")
        if warnings:
            self.logs.appendPlainText("\nBLANK PAGES ADDED:\n" + "\n".join(warnings))
        QMessageBox.information(self, "Complete", f"Funds included: {count}\nBlank pages: {len(warnings)}\nMissing files: {len(missing)}\n\n{output}")

    def failure(self, error):
        self.logs.appendPlainText(error); QMessageBox.critical(self, "Failed", error.strip().splitlines()[-1])

    def cleanup(self):
        self.start.setEnabled(True); self.stop.setEnabled(False)
        if self.worker: self.worker.deleteLater()
        if self.thread: self.thread.deleteLater()
        self.worker = self.thread = None


def main():
    app = QApplication(sys.argv)
    if wordninja is None:
        QMessageBox.critical(
            None,
            "Missing dependency",
            "The wordninja package is required to repair words joined by PDF-to-Word conversion.\n\n"
            "Install it with:\n    pip install wordninja",
        )
        sys.exit(1)
    window = MainWindow()
    window.show()
    sys.exit(app.exec())


if __name__ == "__main__":
    main()
