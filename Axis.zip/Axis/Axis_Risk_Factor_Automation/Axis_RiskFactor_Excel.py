"""Major Risk Factor Uploader.

Reads red and blue highlighted rich-text risk statements from Risk Factors_Risk.xlsx,
matches funds to the Uploader sheet, previews the exact values, and saves a
new copy of the uploader workbook.

Output rules:
- Existing uploader workbook sheets, formulas, widths, heights, filters, tables,
  styles, number formats and print settings are preserved by editing a copy.
- Only the Major Risk Factors values for selected matched funds are replaced.
- Uploader rows that are not updated are highlighted light red for review.
- Updated rows retain the uploader's original formatting.

Install:
    pip install PyQt6 openpyxl

Run:
    python major_risk_factor_uploader_preserve_format.py
"""
from __future__ import annotations

import re
import shutil
import sys
import traceback
from copy import copy
from dataclasses import dataclass
from difflib import SequenceMatcher
from pathlib import Path
from typing import Optional

from openpyxl import load_workbook
from openpyxl.cell.rich_text import CellRichText, TextBlock
from openpyxl.styles import Alignment, PatternFill
from PyQt6.QtCore import Qt
from PyQt6.QtGui import QColor
from PyQt6.QtWidgets import (
    QApplication,
    QAbstractItemView,
    QCheckBox,
    QComboBox,
    QFileDialog,
    QGridLayout,
    QGroupBox,
    QHBoxLayout,
    QHeaderView,
    QLabel,
    QLineEdit,
    QMainWindow,
    QMessageBox,
    QPlainTextEdit,
    QPushButton,
    QSplitter,
    QStatusBar,
    QTableWidget,
    QTableWidgetItem,
    QVBoxLayout,
    QWidget,
)

APP_TITLE = "Major Risk Factor Uploader"
SOURCE_SHEETS = [
    "Equity",
    "Debt",
    "Hybrid",
    "ETF",
    "Index-Debt",
    "Index - Equity",
    "FOF",
    "FOF-Overseas",
]
SOURCE_FUND_ROW = 1
SOURCE_RISK_ROW = 2
UPLOADER_SHEET = "Uploader"
UPLOADER_FUND_HEADER = "Factsheet Display Name"
UPLOADER_TARGET_HEADER = "Major Risk Factors"
NOT_UPDATED_FILL = PatternFill(
    fill_type="solid",
    fgColor="FFF2CC",
)

ALIASES = {
    "axis largecap fund": "axis large cap fund",
    "axis service opportunities fund": "axis services opportunities fund",
    "axis childrens fund": "axis children s fund",
    "axis conservative hybrid": "axis conservative hybrid fund",
    "axis retirement fund aggressive": "axis retirement fund aggressive plan",
    "axis retirement fund dynamic": "axis retirement fund dynamic plan",
    "axis retirement fund conserva": "axis retirement fund conservative plan",
    "axis floater fund": "axis floating interest rates fund",
    "axis dynamic bond fund": "axis dynamic term fund",
    "axis long duration fund": "axis long term fund",
    "axis short duration fund": "axis short term fund",
    "axis treasury advantage fund": "axis ultra short to short term fund",
    "axis ultra short duration": "axis ultra short term fund",
    "axis strategic bond fund": "axis medium term fund",
    "axis banking and psu debt": "axis banking and psu debt fund",
    "axis multi asset active fof": "axis multi asset omni fof",
    "nifty india cons etf": "axis nifty india consumption etf",
    "axis nifty500 value 50 index": "axis nifty500 value 50 index fund",
    "axis nifty smallcap 50 index": "axis nifty smallcap 50 index fund",
    "axis nasdaq 100 fof": "axis nasdaq 100 us specific equity passive fof",
    "axis us treasury": "axis us specific treasury dynamic debt passive fof",
    "axis global innovation fof": "axis global innovation fund of fund",
    "axis global equity alpha fof": "axis global equity alpha fund of fund",
    "axis greater china equity fof": "axis greater china equity fund of fund",
    "crisil aaa bond nbfc hfc june 2027":
        "axis crisil ibx aaa bond nbfc hfc june 2027 index fund",
    "crisil aaa bond nbfc june 2027":
        "axis crisil ibx aaa bond nbfc june 2027 index fund",
    "axis crisil ibx50 50 gilt plus sdl september 2027 index fund":
        "axis crisil ibx 50 50 gilt plus sdl september 2027 index fund",
    "axis crisil ibx sdl may 2027":
        "axis crisil ibx sdl may 2027 index fund",
    "axis nifty sdl september 2026":
        "axis nifty sdl september 2026 debt index fund",
    "axis crisil 50 50 june 2028":
        "axis crisil ibx 50 50 gilt plus sdl june 2028 index fund",
    "axis crisil ibx aaa bond fin ser september27 index fund":
        "axis crisil ibx aaa bond financial services september 2027 index fund",
}

# Additional source-to-uploader aliases. Keys and values are normalized.
ALIASES.update({
    "axis multi asset active fof": "axis multi asset omni fof",
    "axis multi asset active fund of funds": "axis multi asset omni fof",
    "axis income plus arbitrage active fof": "axis income plus arbitrage omni fof",
    "axis income plus arbitrage active fund of funds": "axis income plus arbitrage omni fof",
    "axis childens fund": "axis children s fund",
    "axis childre ns fund": "axis children s fund",
    "axis conservative hybrid": "axis conservative hybrid fund",
    "axis multi asset allocation": "axis multi asset allocation fund",
    "axis banking psu debt": "axis banking and psu debt fund",
    "axis banking and psu debt": "axis banking and psu debt fund",
    "axis nifty 50 etf": "axis nifty 50 etf",
    "axis nifty healthcare etf": "axis nifty healthcare etf",
    "axis nifty india consumption etf": "axis nifty india consumption etf",
    "axis bse sensex etf": "axis bse sensex etf",
    "axis nifty500 value 50 index": "axis nifty500 value 50 index fund",
    "axis nifty smallcap 50 index": "axis nifty smallcap 50 index fund",
    "axis nifty midcap 50 index": "axis nifty midcap 50 index fund",
    "axis crisil ibx sdl may 2027": "axis crisil ibx sdl may 2027 index fund",
    "axis nifty sdl september 2026": "axis nifty sdl september 2026 debt index fund",
})

NUMBERED_ITEM = re.compile(r"(?<!\w)(\d{1,2})\s*\.(?!\d)")
PREFIX_PATTERN = re.compile(
    r"^\s*(?:"
    r"risks?\s+(?:factors?\s+)?associated\s+with|"
    r"risks?\s+associated\s+with|"
    r"risks?\s+factors?\s+(?:related|relating)\s+to|"
    r"risks?\s+factors?\s+pertaining\s+to|"
    r"risks?\s+(?:related|relating)\s+to|"
    r"risks?\s+pertaining\s+to"
    r")\s*[:\-–—]?\s*",
    flags=re.IGNORECASE,
)


@dataclass
class SourceRisk:
    sheet: str
    source_fund: str
    source_cell: str
    original_items: list[str]
    cleaned_items: list[str]
    highlighted_count: int


@dataclass
class PreviewRow:
    include: bool
    source: SourceRisk
    uploader_fund: str
    uploader_row: Optional[int]
    match_method: str
    confidence: float
    final_text: str
    status: str


def as_text(value) -> str:
    return "" if value is None else str(value)


def normalize_name(value: str) -> str:
    value = as_text(value).casefold().replace("&", " and ").replace("’", "'")
    value = re.sub(r"\bfund\s+of\s+funds?\b|\bfof\b", " fof ", value)
    value = re.sub(r"\bnifty\s*500\b", " nifty500 ", value)
    value = re.sub(r"\bsep\b", " september ", value)
    value = re.sub(r"\bjun\b", " june ", value)
    value = re.sub(r"\bfin\s+ser\b", " financial services ", value)
    value = re.sub(r"\breg(?:ular)?\b|\bdir(?:ect)?\b|\bgrowth\b", " ", value)
    value = re.sub(r"[^a-z0-9]+", " ", value)
    value = re.sub(r"\s+", " ", value).strip()

    seen = set()
    while value in ALIASES and value not in seen:
        seen.add(value)
        replacement = ALIASES[value]
        if replacement == value:
            break
        value = replacement
    return value


def font_is_red_or_blue(font) -> bool:
    """Detect explicit red/blue RGB, indexed colors, and Excel blue themes."""
    color = getattr(font, "color", None)
    if color is None:
        return False

    color_type = getattr(color, "type", None)
    if color_type == "rgb":
        rgb = str(getattr(color, "rgb", "") or "").upper()
        if len(rgb) == 8:
            rgb = rgb[2:]
        if len(rgb) != 6:
            return False
        try:
            red = int(rgb[0:2], 16)
            green = int(rgb[2:4], 16)
            blue = int(rgb[4:6], 16)
        except ValueError:
            return False
        is_red = red >= 140 and red >= green * 1.30 and red >= blue * 1.15
        is_blue = blue >= 110 and blue >= red * 1.08 and blue >= green * 1.02
        return is_red or is_blue

    if color_type == "indexed":
        return getattr(color, "indexed", None) in {2, 3, 4, 5, 10, 12}

    if color_type == "theme":
        # Themes 4 through 7 are accent colors used for blue/cyan highlighted text.
        # Theme 1 is normal dark text and must not be selected.
        return getattr(color, "theme", None) in {4, 5, 6, 7}

    return False


def run_is_highlighted(run) -> bool:
    return font_is_red_or_blue(getattr(run, "font", None))


def rich_text_with_flags(value, cell_font=None) -> tuple[str, list[bool]]:
    if isinstance(value, CellRichText):
        pieces: list[str] = []
        flags: list[bool] = []
        for run in value:
            run_text = str(run)
            if isinstance(run, TextBlock):
                highlighted = run_is_highlighted(run)
            else:
                # Plain fragments inherit the cell font.
                highlighted = font_is_red_or_blue(cell_font)
            pieces.append(run_text)
            flags.extend([highlighted] * len(run_text))
        return "".join(pieces), flags

    plain = as_text(value)
    highlighted = font_is_red_or_blue(cell_font)
    return plain, [highlighted] * len(plain)


def split_numbered_items(full_text: str, flags: list[bool]) -> list[tuple[str, bool]]:
    matches = list(NUMBERED_ITEM.finditer(full_text))
    if not matches:
        value = re.sub(r"\s+", " ", full_text).strip()
        return [(value, any(flags))] if value else []

    items = []
    for index, match in enumerate(matches):
        start = match.start()
        end = matches[index + 1].start() if index + 1 < len(matches) else len(full_text)
        statement = full_text[start:end]
        statement = NUMBERED_ITEM.sub("", statement, count=1)
        statement = re.sub(r"\s+", " ", statement).strip(" \t\r\n.;")
        if statement:
            items.append((statement, any(flags[start:end])))
    return items


def clean_risk_heading(statement: str) -> str:
    value = PREFIX_PATTERN.sub("", statement).strip()
    value = re.sub(r"\s+", " ", value).strip(" .;:-–—")
    return value[:1].upper() + value[1:] if value else ""


def extract_source_risks(path: Path, top_n: int) -> list[SourceRisk]:
    workbook = load_workbook(path, rich_text=True, data_only=False)
    results = []

    for sheet_name in SOURCE_SHEETS:
        if sheet_name not in workbook.sheetnames:
            continue
        sheet = workbook[sheet_name]

        for column in range(2, sheet.max_column + 1):
            fund_name = as_text(sheet.cell(SOURCE_FUND_ROW, column).value).strip()
            if not fund_name:
                continue

            risk_cell = sheet.cell(SOURCE_RISK_ROW, column)
            full_text, flags = rich_text_with_flags(risk_cell.value, risk_cell.font)
            statements = split_numbered_items(full_text, flags)
            highlighted = [statement for statement, selected in statements if selected]
            selected = highlighted[:top_n]
            cleaned = [clean_risk_heading(statement) for statement in selected]
            cleaned = [statement for statement in cleaned if statement]

            results.append(
                SourceRisk(
                    sheet=sheet_name,
                    source_fund=fund_name,
                    source_cell=risk_cell.coordinate,
                    original_items=selected,
                    cleaned_items=cleaned,
                    highlighted_count=len(highlighted),
                )
            )
    return results


def header_map(sheet) -> dict[str, int]:
    return {
        as_text(cell.value).strip(): cell.column
        for cell in sheet[1]
        if cell.value is not None
    }


def uploader_funds(path: Path):
    workbook = load_workbook(path, data_only=False)
    if UPLOADER_SHEET not in workbook.sheetnames:
        raise ValueError(f"Worksheet '{UPLOADER_SHEET}' was not found")

    sheet = workbook[UPLOADER_SHEET]
    headers = header_map(sheet)
    for expected in (UPLOADER_FUND_HEADER, UPLOADER_TARGET_HEADER):
        if expected not in headers:
            raise ValueError(f"Column '{expected}' was not found")

    fund_column = headers[UPLOADER_FUND_HEADER]
    exact = {}
    rows = []
    for row_number in range(2, sheet.max_row + 1):
        fund_name = as_text(sheet.cell(row_number, fund_column).value).strip()
        if not fund_name:
            continue
        rows.append((row_number, fund_name))
        exact[normalize_name(fund_name)] = (row_number, fund_name)
    return exact, rows


def match_source(source_name: str, exact_map, uploader_rows):
    normalized = normalize_name(source_name)
    if normalized in exact_map:
        row, name = exact_map[normalized]
        return row, name, "Exact/alias", 1.0

    candidates = []
    for row, name in uploader_rows:
        confidence = SequenceMatcher(None, normalized, normalize_name(name)).ratio()
        candidates.append((confidence, row, name))
    candidates.sort(reverse=True)

    if not candidates:
        return None, "", "Unmatched", 0.0

    best, row, name = candidates[0]
    second = candidates[1][0] if len(candidates) > 1 else 0.0
    if best >= 0.88 and best - second >= 0.04:
        return row, name, "Fuzzy", best
    return None, name, "Review", best


def build_preview(source_path: Path, uploader_path: Path, top_n: int) -> list[PreviewRow]:
    source_risks = extract_source_risks(source_path, top_n)
    exact_map, uploader_rows = uploader_funds(uploader_path)
    preview = []

    for source in source_risks:
        target_row, target_name, method, confidence = match_source(
            source.source_fund,
            exact_map,
            uploader_rows,
        )
        final_text = "\n".join(
            f"{number}. {statement}"
            for number, statement in enumerate(source.cleaned_items, 1)
        )

        if target_row is None:
            status = "Not updated: fund match requires review"
        elif not source.cleaned_items:
            status = "Not updated: no highlighted risks"
        elif len(source.cleaned_items) < top_n:
            status = f"Ready with {len(source.cleaned_items)} highlighted risk(s)"
        else:
            status = "Ready"

        preview.append(
            PreviewRow(
                include=status.startswith("Ready"),
                source=source,
                uploader_fund=target_name,
                uploader_row=target_row,
                match_method=method,
                confidence=confidence,
                final_text=final_text,
                status=status,
            )
        )
    return preview


def preserve_target_alignment(cell) -> None:
    """Retain the target cell alignment and enable readable wrapped text."""
    updated_alignment = copy(cell.alignment)
    updated_alignment.wrap_text = True
    if not updated_alignment.vertical:
        updated_alignment.vertical = "top"
    cell.alignment = updated_alignment


def save_output(
    uploader_path: Path,
    output_path: Path,
    preview_rows: list[PreviewRow],
) -> tuple[int, int]:
    """Edit a file copy and retain the uploader's established formatting."""
    shutil.copy2(uploader_path, output_path)
    workbook = load_workbook(output_path, data_only=False)
    sheet = workbook[UPLOADER_SHEET]
    headers = header_map(sheet)
    target_column = headers[UPLOADER_TARGET_HEADER]
    fund_column = headers[UPLOADER_FUND_HEADER]

    selected_by_uploader_row = {
        item.uploader_row: item
        for item in preview_rows
        if item.uploader_row is not None
    }

    updated_rows = set()
    for item in preview_rows:
        if not item.include or item.uploader_row is None or not item.final_text.strip():
            continue
        target = sheet.cell(item.uploader_row, target_column)
        target.value = item.final_text.strip()
        preserve_target_alignment(target)
        updated_rows.add(item.uploader_row)

    highlighted_rows = 0
    for row_number in range(2, sheet.max_row + 1):
        fund_name = as_text(sheet.cell(row_number, fund_column).value).strip()
        if not fund_name or row_number in updated_rows:
            continue

        # Highlight only uploader rows that were not updated. All other formatting
        # properties remain unchanged; only the row cells' fill is intentionally set.
        for column in range(1, sheet.max_column + 1):
            sheet.cell(row_number, column).fill = copy(NOT_UPDATED_FILL)
        highlighted_rows += 1

        # Keep unavailable source rows identifiable in the application preview.
        if row_number not in selected_by_uploader_row:
            continue

    workbook.save(output_path)
    return len(updated_rows), highlighted_rows


class MainWindow(QMainWindow):
    def __init__(self):
        super().__init__()
        self.preview_rows: list[PreviewRow] = []
        self.setWindowTitle(APP_TITLE)
        self.resize(1500, 850)
        self.build_ui()
        self.apply_style()

    def build_ui(self):
        central = QWidget()
        self.setCentralWidget(central)
        root = QVBoxLayout(central)

        title = QLabel(APP_TITLE)
        title.setObjectName("title")
        root.addWidget(title)

        inputs = QGroupBox("Input and output")
        grid = QGridLayout(inputs)
        grid.setColumnStretch(1, 1)

        self.source_edit = QLineEdit()
        self.source_edit.setPlaceholderText("Risk Factors_Risk.xlsx")
        self.uploader_edit = QLineEdit()
        self.uploader_edit.setPlaceholderText("SebiFactsheetUploaderUpdated.xlsx")
        self.output_edit = QLineEdit()
        self.output_edit.setPlaceholderText("Updated uploader copy.xlsx")
        self.top_count = QComboBox()
        self.top_count.addItems(["1", "2", "3", "4", "5"])
        self.top_count.setCurrentText("3")

        source_button = QPushButton("Browse")
        uploader_button = QPushButton("Browse")
        output_button = QPushButton("Choose output")
        source_button.clicked.connect(lambda: self.pick_input(self.source_edit))
        uploader_button.clicked.connect(lambda: self.pick_input(self.uploader_edit))
        output_button.clicked.connect(self.pick_output)

        grid.addWidget(QLabel("Risk source"), 0, 0)
        grid.addWidget(self.source_edit, 0, 1)
        grid.addWidget(source_button, 0, 2)
        grid.addWidget(QLabel("Uploader"), 1, 0)
        grid.addWidget(self.uploader_edit, 1, 1)
        grid.addWidget(uploader_button, 1, 2)
        grid.addWidget(QLabel("Output copy"), 2, 0)
        grid.addWidget(self.output_edit, 2, 1)
        grid.addWidget(output_button, 2, 2)
        grid.addWidget(QLabel("Highlighted statements per fund"), 3, 0)
        grid.addWidget(self.top_count, 3, 1)
        root.addWidget(inputs)

        actions = QHBoxLayout()
        self.preview_button = QPushButton("Build Preview")
        self.preview_button.setObjectName("primary")
        self.preview_button.clicked.connect(self.build_preview_clicked)
        self.show_not_updated = QCheckBox("Show only rows not updated")
        self.show_not_updated.stateChanged.connect(self.apply_filter)
        actions.addWidget(self.preview_button)
        actions.addWidget(self.show_not_updated)
        actions.addStretch()
        root.addLayout(actions)

        splitter = QSplitter(Qt.Orientation.Vertical)
        self.table = QTableWidget(0, 9)
        self.table.setHorizontalHeaderLabels(
            [
                "Update",
                "Source sheet",
                "Source fund",
                "Matched uploader fund",
                "Uploader row",
                "Method",
                "Confidence",
                "Final Major Risk Factors",
                "Status",
            ]
        )
        self.table.setSelectionBehavior(QAbstractItemView.SelectionBehavior.SelectRows)
        self.table.setAlternatingRowColors(True)
        self.table.verticalHeader().setVisible(False)
        header = self.table.horizontalHeader()
        header.setSectionResizeMode(QHeaderView.ResizeMode.ResizeToContents)
        header.setSectionResizeMode(7, QHeaderView.ResizeMode.Stretch)
        self.table.itemSelectionChanged.connect(self.show_details)
        self.table.itemChanged.connect(self.table_item_changed)
        splitter.addWidget(self.table)

        details = QWidget()
        details_layout = QGridLayout(details)
        self.original_view = QPlainTextEdit()
        self.original_view.setReadOnly(True)
        self.cleaned_view = QPlainTextEdit()
        self.cleaned_view.setPlaceholderText("Edit final Major Risk Factors text")
        self.cleaned_view.textChanged.connect(self.detail_text_changed)
        details_layout.addWidget(QLabel("Original highlighted statements"), 0, 0)
        details_layout.addWidget(QLabel("Final value to paste"), 0, 1)
        details_layout.addWidget(self.original_view, 1, 0)
        details_layout.addWidget(self.cleaned_view, 1, 1)
        splitter.addWidget(details)
        splitter.setSizes([560, 220])
        root.addWidget(splitter, 1)

        bottom = QHBoxLayout()
        self.summary = QLabel("Select both workbooks and build a preview.")
        self.save_button = QPushButton("Write Updated Uploader")
        self.save_button.setObjectName("primary")
        self.save_button.setEnabled(False)
        self.save_button.clicked.connect(self.save_clicked)
        bottom.addWidget(self.summary)
        bottom.addStretch()
        bottom.addWidget(self.save_button)
        root.addLayout(bottom)
        self.setStatusBar(QStatusBar())

    def apply_style(self):
        self.setStyleSheet(
            """
            QMainWindow { background: #f5f7fb; }
            QLabel#title { font-size: 24px; font-weight: 700; color: #17365d; padding: 8px; }
            QGroupBox { background: white; border: 1px solid #d7deea; border-radius: 8px;
                        margin-top: 8px; padding: 12px; font-weight: 600; }
            QLineEdit, QPlainTextEdit, QTableWidget, QComboBox {
                background: white; border: 1px solid #cbd5e1; border-radius: 5px; padding: 5px;
            }
            QPushButton { background: #e7eef8; color: #17365d; border: 0;
                          border-radius: 6px; padding: 8px 14px; font-weight: 600; }
            QPushButton#primary { background: #1565c0; color: white; }
            QPushButton:disabled { background: #e5e7eb; color: #9ca3af; }
            QHeaderView::section { background: #17365d; color: white; padding: 7px; border: 0; }
            """
        )

    def pick_input(self, target: QLineEdit):
        path, _ = QFileDialog.getOpenFileName(
            self,
            "Select Excel workbook",
            "",
            "Excel workbooks (*.xlsx)",
        )
        if path:
            target.setText(path)
            if target is self.uploader_edit and not self.output_edit.text().strip():
                uploader = Path(path)
                output = uploader.with_name(
                    uploader.stem + "_Major_Risks_Updated.xlsx"
                )
                self.output_edit.setText(str(output))

    def pick_output(self):
        path, _ = QFileDialog.getSaveFileName(
            self,
            "Save updated uploader copy",
            self.output_edit.text(),
            "Excel workbooks (*.xlsx)",
        )
        if path:
            if not path.lower().endswith(".xlsx"):
                path += ".xlsx"
            self.output_edit.setText(path)

    def build_preview_clicked(self):
        source_path = Path(self.source_edit.text().strip())
        uploader_path = Path(self.uploader_edit.text().strip())
        if not source_path.is_file() or not uploader_path.is_file():
            QMessageBox.warning(
                self,
                "Missing files",
                "Select a valid risk source workbook and uploader workbook.",
            )
            return

        try:
            QApplication.setOverrideCursor(Qt.CursorShape.WaitCursor)
            self.preview_rows = build_preview(
                source_path,
                uploader_path,
                int(self.top_count.currentText()),
            )
            self.populate_table()
            self.save_button.setEnabled(True)
            ready = sum(item.status.startswith("Ready") for item in self.preview_rows)
            not_updated = len(self.preview_rows) - ready
            self.summary.setText(
                f"Source funds: {len(self.preview_rows)} | "
                f"Ready: {ready} | Not updated: {not_updated}"
            )
            self.statusBar().showMessage(
                "Preview ready. Yellow rows will not be updated unless reviewed and selected."
            )
        except Exception:
            QMessageBox.critical(self, "Preview failed", traceback.format_exc())
        finally:
            QApplication.restoreOverrideCursor()

    def populate_table(self):
        self.table.blockSignals(True)
        self.table.setRowCount(len(self.preview_rows))

        for row_index, item in enumerate(self.preview_rows):
            update_item = QTableWidgetItem()
            update_item.setFlags(update_item.flags() | Qt.ItemFlag.ItemIsUserCheckable)
            update_item.setCheckState(
                Qt.CheckState.Checked if item.include else Qt.CheckState.Unchecked
            )
            self.table.setItem(row_index, 0, update_item)

            values = [
                item.source.sheet,
                item.source.source_fund,
                item.uploader_fund,
                str(item.uploader_row or ""),
                item.match_method,
                f"{item.confidence:.1%}",
                item.final_text,
                item.status,
            ]
            for column, value in enumerate(values, 1):
                table_item = QTableWidgetItem(value)
                if column != 7:
                    table_item.setFlags(
                        table_item.flags() & ~Qt.ItemFlag.ItemIsEditable
                    )
                self.table.setItem(row_index, column, table_item)

            background = (
                QColor("#E8F5E9")
                if item.status.startswith("Ready")
                else QColor("#FFF2CC")
            )
            for column in range(self.table.columnCount()):
                self.table.item(row_index, column).setBackground(background)

        self.table.blockSignals(False)
        self.apply_filter()
        if self.preview_rows:
            self.table.selectRow(0)

    def apply_filter(self):
        show_only_not_updated = self.show_not_updated.isChecked()
        for row_index, item in enumerate(self.preview_rows):
            self.table.setRowHidden(
                row_index,
                show_only_not_updated and item.include,
            )

    def current_row_index(self) -> Optional[int]:
        selection = self.table.selectionModel().selectedRows()
        return selection[0].row() if selection else None

    def show_details(self):
        index = self.current_row_index()
        self.cleaned_view.blockSignals(True)
        if index is None:
            self.original_view.clear()
            self.cleaned_view.clear()
        else:
            item = self.preview_rows[index]
            self.original_view.setPlainText(
                "\n".join(
                    f"{number}. {statement}"
                    for number, statement in enumerate(item.source.original_items, 1)
                )
            )
            self.cleaned_view.setPlainText(item.final_text)
        self.cleaned_view.blockSignals(False)

    def detail_text_changed(self):
        index = self.current_row_index()
        if index is None:
            return
        value = self.cleaned_view.toPlainText().strip()
        self.preview_rows[index].final_text = value
        self.table.blockSignals(True)
        self.table.item(index, 7).setText(value)
        self.table.blockSignals(False)

    def table_item_changed(self, item: QTableWidgetItem):
        row_index = item.row()
        if row_index >= len(self.preview_rows):
            return
        if item.column() == 0:
            self.preview_rows[row_index].include = (
                item.checkState() == Qt.CheckState.Checked
            )
        elif item.column() == 7:
            self.preview_rows[row_index].final_text = item.text().strip()

    def save_clicked(self):
        uploader_path = Path(self.uploader_edit.text().strip())
        output_path = Path(self.output_edit.text().strip())
        if not output_path.name:
            self.pick_output()
            output_path = Path(self.output_edit.text().strip())
        if not output_path.name:
            return
        if output_path.resolve() == uploader_path.resolve():
            QMessageBox.warning(
                self,
                "Choose a new file",
                "The source uploader will not be overwritten. Choose a new output path.",
            )
            return

        try:
            QApplication.setOverrideCursor(Qt.CursorShape.WaitCursor)
            output_path.parent.mkdir(parents=True, exist_ok=True)
            updated, highlighted = save_output(
                uploader_path,
                output_path,
                self.preview_rows,
            )
            QMessageBox.information(
                self,
                "Saved",
                f"Updated Major Risk Factors rows: {updated}\n"
                f"Highlighted rows not updated: {highlighted}\n\n"
                f"{output_path}",
            )
            self.statusBar().showMessage(
                f"Saved {updated} updates; highlighted {highlighted} rows for review."
            )
        except Exception:
            QMessageBox.critical(self, "Save failed", traceback.format_exc())
        finally:
            QApplication.restoreOverrideCursor()


def main():
    app = QApplication(sys.argv)
    app.setApplicationName(APP_TITLE)
    window = MainWindow()
    window.show()
    sys.exit(app.exec())


if __name__ == "__main__":
    main()
