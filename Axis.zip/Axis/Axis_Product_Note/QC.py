from __future__ import annotations

import math
import sys
import traceback
from pathlib import Path
from typing import Any

import pandas as pd
from PyQt6.QtCore import QThread, pyqtSignal
from PyQt6.QtGui import QColor, QFont
from PyQt6.QtWidgets import (
    QApplication,
    QFileDialog,
    QHBoxLayout,
    QHeaderView,
    QLabel,
    QMainWindow,
    QMessageBox,
    QProgressBar,
    QPushButton,
    QTabWidget,
    QTableWidget,
    QTableWidgetItem,
    QVBoxLayout,
    QWidget,
)

# -----------------------------------------------------------------------------
# COLUMN MAPPING
# Left side: column name in the OLD uploader
# Right side: corresponding column name in the NEW uploader
# -----------------------------------------------------------------------------
COLUMN_MAPPING = [
    (
        "Benchmark_Display Name in Factsheet",
        "Display Benchmark",
    ),
    (
        "Benchmark Name as per MFI Explorer",
        "Benchmark tag",
    ),
    (
        "Custom Benchmark Name in MFI Explorer",
        "IAL Benchmark",
    ),
    (
        "Additonal Benchmark_Display Name in Factsheet",
        "Display Additional Benchmark",
    ),
    (
        "Additional Benchmark Name as per MFI Explorer V6",
        "Additional Benchmark tag",
    ),
    (
        "Custom Additional Benchmark Name in MFI Explorer",
        "IAL Additional Benchmark",
    ),
]

GUI_ROW_LIMIT = 10000
HEADER_SCAN_LIMIT = 50


def is_blank(value: Any) -> bool:
    if value is None:
        return True
    if isinstance(value, str):
        return value.strip() == ""
    try:
        result = pd.isna(value)
        return bool(result) if isinstance(result, bool) else False
    except (TypeError, ValueError):
        return False


def display_value(value: Any) -> str:
    if is_blank(value):
        return ""
    if isinstance(value, pd.Timestamp):
        return value.strftime("%Y-%m-%d %H:%M:%S").removesuffix(" 00:00:00")
    if isinstance(value, float) and math.isfinite(value) and value.is_integer():
        return str(int(value))
    return str(value)


def normalized_value(value: Any) -> tuple[str, Any]:
    """
    Normalize values for QC.

    Text comparison ignores leading/trailing spaces and letter case.
    Blank, NaN and empty strings are treated as the same blank value.
    """
    if is_blank(value):
        return ("blank", "")
    if isinstance(value, pd.Timestamp):
        return ("date", value.isoformat())
    if isinstance(value, str):
        return ("text", value.strip().casefold())
    if isinstance(value, float) and math.isfinite(value) and value.is_integer():
        return ("number", int(value))
    if isinstance(value, (int, float)) and not isinstance(value, bool):
        return ("number", value)
    return (type(value).__name__, str(value))


def normalized_header(value: Any) -> str:
    return " ".join(display_value(value).strip().casefold().split())


def make_unique_headers(headers: list[str]) -> list[str]:
    counts: dict[str, int] = {}
    result: list[str] = []
    for index, header in enumerate(headers):
        base = header.strip() or f"Unnamed Column {index + 1}"
        counts[base] = counts.get(base, 0) + 1
        if counts[base] == 1:
            result.append(base)
        else:
            result.append(f"{base} ({counts[base]})")
    return result


def find_header_row(raw_frame: pd.DataFrame, required_headers: list[str]) -> int | None:
    """Find the row containing the greatest number of required column names."""
    wanted = {normalized_header(header) for header in required_headers}
    best_row: int | None = None
    best_matches = 0

    for row_index in range(min(len(raw_frame), HEADER_SCAN_LIMIT)):
        row_headers = {normalized_header(value) for value in raw_frame.iloc[row_index].tolist()}
        matches = len(wanted & row_headers)
        if matches > best_matches:
            best_matches = matches
            best_row = row_index

    return best_row if best_matches > 0 else None


def read_workbook_with_detected_headers(
    path: str,
    expected_headers: list[str],
) -> list[dict[str, Any]]:
    """
    Read every worksheet and automatically locate its header row.

    A worksheet is included when at least one expected QC column is found.
    """
    raw_workbook = pd.read_excel(
        path,
        sheet_name=None,
        header=None,
        dtype=object,
        engine="openpyxl",
    )

    sheets: list[dict[str, Any]] = []
    for sheet_name, raw_frame in raw_workbook.items():
        header_row = find_header_row(raw_frame, expected_headers)
        if header_row is None:
            sheets.append(
                {
                    "name": sheet_name,
                    "header_row": None,
                    "frame": pd.DataFrame(),
                    "available_headers": [],
                }
            )
            continue

        headers = make_unique_headers(
            [display_value(value) for value in raw_frame.iloc[header_row].tolist()]
        )
        data = raw_frame.iloc[header_row + 1 :].copy().reset_index(drop=True)
        data.columns = headers
        data = data.dropna(how="all").reset_index(drop=True)

        sheets.append(
            {
                "name": sheet_name,
                "header_row": header_row,
                "frame": data,
                "available_headers": headers,
            }
        )

    return sheets


def find_actual_column(frame: pd.DataFrame, requested_name: str) -> str | None:
    wanted = normalized_header(requested_name)
    for column in frame.columns:
        if normalized_header(column) == wanted:
            return str(column)
    return None


def safe_sheet_name(name: str, used: set[str]) -> str:
    for character in "\\/*[]:?":
        name = name.replace(character, "_")
    base = (name or "Sheet")[:31]
    candidate = base
    number = 1
    used_lower = {item.casefold() for item in used}
    while candidate.casefold() in used_lower:
        suffix = f"_{number}"
        candidate = base[: 31 - len(suffix)] + suffix
        number += 1
    used.add(candidate)
    return candidate


class UploaderQC:
    def __init__(self, old_path: str, new_path: str) -> None:
        self.old_path = old_path
        self.new_path = new_path

    def compare(self) -> dict[str, Any]:
        old_expected = [old_column for old_column, _ in COLUMN_MAPPING]
        new_expected = [new_column for _, new_column in COLUMN_MAPPING]

        old_sheets = read_workbook_with_detected_headers(self.old_path, old_expected)
        new_sheets = read_workbook_with_detected_headers(self.new_path, new_expected)

        result_rows: list[dict[str, Any]] = []
        total_sheet_positions = max(len(old_sheets), len(new_sheets))

        for sheet_position in range(total_sheet_positions):
            old_sheet = (
                old_sheets[sheet_position]
                if sheet_position < len(old_sheets)
                else {"name": "", "header_row": None, "frame": pd.DataFrame()}
            )
            new_sheet = (
                new_sheets[sheet_position]
                if sheet_position < len(new_sheets)
                else {"name": "", "header_row": None, "frame": pd.DataFrame()}
            )

            old_frame: pd.DataFrame = old_sheet["frame"]
            new_frame: pd.DataFrame = new_sheet["frame"]
            maximum_rows = max(len(old_frame), len(new_frame))

            # Always create column-level results, even when no data rows exist.
            if maximum_rows == 0:
                maximum_rows = 1

            for old_requested, new_requested in COLUMN_MAPPING:
                old_actual = find_actual_column(old_frame, old_requested)
                new_actual = find_actual_column(new_frame, new_requested)

                for data_row in range(maximum_rows):
                    old_row_exists = data_row < len(old_frame)
                    new_row_exists = data_row < len(new_frame)

                    old_value = (
                        old_frame.at[data_row, old_actual]
                        if old_actual is not None and old_row_exists
                        else None
                    )
                    new_value = (
                        new_frame.at[data_row, new_actual]
                        if new_actual is not None and new_row_exists
                        else None
                    )

                    old_excel_row = (
                        old_sheet["header_row"] + data_row + 2
                        if old_sheet["header_row"] is not None and old_row_exists
                        else ""
                    )
                    new_excel_row = (
                        new_sheet["header_row"] + data_row + 2
                        if new_sheet["header_row"] is not None and new_row_exists
                        else ""
                    )

                    if old_actual is None and new_actual is None:
                        status = "FAIL"
                        remark = "Both mapped columns are missing."
                    elif old_actual is None:
                        status = "FAIL"
                        remark = "Old uploader column is missing."
                    elif new_actual is None:
                        status = "FAIL"
                        remark = "New uploader column is missing."
                    elif not old_row_exists and new_row_exists:
                        status = "FAIL"
                        remark = "Row exists only in the new uploader."
                    elif old_row_exists and not new_row_exists:
                        status = "FAIL"
                        remark = "Row exists only in the old uploader."
                    elif normalized_value(old_value) == normalized_value(new_value):
                        status = "PASS"
                        remark = "Values match."
                    else:
                        status = "FAIL"
                        remark = "Values do not match."

                    result_rows.append(
                        {
                            "Sheet No.": sheet_position + 1,
                            "Old Sheet": old_sheet["name"] or "[missing sheet]",
                            "New Sheet": new_sheet["name"] or "[missing sheet]",
                            "Old Excel Row": old_excel_row,
                            "New Excel Row": new_excel_row,
                            "Old Column": old_requested,
                            "New Column": new_requested,
                            "Old Value": display_value(old_value),
                            "New Value": display_value(new_value),
                            "QC Result": status,
                            "Remark": remark,
                        }
                    )

        report = pd.DataFrame(result_rows)
        failed_report = report[report["QC Result"] == "FAIL"].copy()
        passed = int((report["QC Result"] == "PASS").sum())
        failed = int((report["QC Result"] == "FAIL").sum())

        summary_rows = []
        for old_column, new_column in COLUMN_MAPPING:
            subset = report[
                (report["Old Column"] == old_column)
                & (report["New Column"] == new_column)
            ]
            summary_rows.append(
                {
                    "Old Uploader Column": old_column,
                    "New Uploader Column": new_column,
                    "Checks": len(subset),
                    "PASS": int((subset["QC Result"] == "PASS").sum()),
                    "FAIL": int((subset["QC Result"] == "FAIL").sum()),
                }
            )

        return {
            "report": report,
            "failed_report": failed_report,
            "summary": pd.DataFrame(summary_rows),
            "old_sheets": old_sheets,
            "new_sheets": new_sheets,
            "passed": passed,
            "failed": failed,
        }


class QCWorker(QThread):
    completed = pyqtSignal(dict)
    failed = pyqtSignal(str)

    def __init__(self, old_path: str, new_path: str) -> None:
        super().__init__()
        self.old_path = old_path
        self.new_path = new_path

    def run(self) -> None:
        try:
            self.completed.emit(UploaderQC(self.old_path, self.new_path).compare())
        except Exception:
            self.failed.emit(traceback.format_exc())


class QCWindow(QMainWindow):
    def __init__(self) -> None:
        super().__init__()
        self.old_path: str | None = None
        self.new_path: str | None = None
        self.result: dict[str, Any] | None = None
        self.worker: QCWorker | None = None

        self.setWindowTitle("Old vs New Uploader - Selected Columns QC")
        self.resize(1600, 860)
        self.build_ui()
        self.apply_style()
        self.update_buttons()

    def build_ui(self) -> None:
        root = QWidget()
        self.setCentralWidget(root)
        layout = QVBoxLayout(root)
        layout.setContentsMargins(10, 10, 10, 10)
        layout.setSpacing(8)

        button_layout = QHBoxLayout()
        self.old_button = QPushButton("1. Select Old Uploader")
        self.new_button = QPushButton("2. Select New Uploader")
        self.run_button = QPushButton("3. Run QC")
        self.export_button = QPushButton("4. Export QC Report")
        for button in (
            self.old_button,
            self.new_button,
            self.run_button,
            self.export_button,
        ):
            button_layout.addWidget(button)
        layout.addLayout(button_layout)

        self.old_button.clicked.connect(self.select_old)
        self.new_button.clicked.connect(self.select_new)
        self.run_button.clicked.connect(self.run_qc)
        self.export_button.clicked.connect(self.export_report)

        self.old_label = QLabel("Old uploader: Not selected")
        self.new_label = QLabel("New uploader: Not selected")
        self.old_label.setObjectName("fileLabel")
        self.new_label.setObjectName("fileLabel")
        layout.addWidget(self.old_label)
        layout.addWidget(self.new_label)

        mapping_text = "QC column mapping: " + " | ".join(
            f"{old}  ->  {new}" for old, new in COLUMN_MAPPING
        )
        self.mapping_label = QLabel(mapping_text)
        self.mapping_label.setObjectName("mappingLabel")
        self.mapping_label.setWordWrap(True)
        layout.addWidget(self.mapping_label)

        self.summary_label = QLabel("Checks: 0 | PASS: 0 | FAIL: 0")
        self.summary_label.setObjectName("summaryLabel")
        layout.addWidget(self.summary_label)

        self.status_label = QLabel(
            "Select both uploader files. QC compares only the six mapped columns row by row."
        )
        self.status_label.setObjectName("statusLabel")
        self.status_label.setWordWrap(True)
        layout.addWidget(self.status_label)

        self.progress = QProgressBar()
        self.progress.setRange(0, 0)
        self.progress.hide()
        layout.addWidget(self.progress)

        self.tabs = QTabWidget()
        self.summary_table = self.make_table()
        self.results_table = self.make_table()
        self.failed_table = self.make_table()
        self.tabs.addTab(self.summary_table, "QC Summary")
        self.tabs.addTab(self.results_table, "All QC Results")
        self.tabs.addTab(self.failed_table, "Failed Only")
        layout.addWidget(self.tabs, 1)

    @staticmethod
    def make_table() -> QTableWidget:
        table = QTableWidget()
        table.setAlternatingRowColors(True)
        table.setEditTriggers(QTableWidget.EditTrigger.NoEditTriggers)
        table.setSelectionBehavior(QTableWidget.SelectionBehavior.SelectRows)
        table.setSortingEnabled(True)
        table.verticalHeader().setDefaultSectionSize(25)
        return table

    def apply_style(self) -> None:
        self.setStyleSheet(
            """
            QMainWindow { background: #f3f4f6; }
            QPushButton {
                min-height: 38px; background: white; border: 1px solid #aeb6c2;
                border-radius: 4px; padding: 5px 14px; font-size: 13px;
            }
            QPushButton:hover { background: #e9f1fb; border-color: #2f6fad; }
            QPushButton:disabled { color: #888; background: #e8e8e8; }
            QLabel#fileLabel {
                background: white; border: 1px solid #d7dce3;
                border-radius: 5px; padding: 10px 14px; font-weight: 600;
            }
            QLabel#mappingLabel { color: #5f3b00; padding: 7px; }
            QLabel#summaryLabel {
                background: #173d68; color: white; border-radius: 6px;
                padding: 13px 15px; font-weight: 700; font-size: 14px;
            }
            QLabel#statusLabel { color: #9a4e00; padding: 5px; }
            QTabWidget::pane { border: 1px solid #b8bec8; background: white; }
            QTabBar::tab {
                background: #e8e9ec; border: 1px solid #b8bec8;
                padding: 8px 16px; min-width: 160px;
            }
            QTabBar::tab:selected { background: white; }
            QTableWidget {
                background: white; alternate-background-color: #f5f5f5;
                gridline-color: #c9c9c9; selection-background-color: #cfe5ff;
                selection-color: #111;
            }
            QHeaderView::section {
                background: #eef0f3; border: 1px solid #c3c7ce;
                padding: 6px; font-weight: 600;
            }
            """
        )

    def select_old(self) -> None:
        path, _ = QFileDialog.getOpenFileName(
            self,
            "Select Old Uploader",
            "",
            "Excel workbooks (*.xlsx *.xlsm)",
        )
        if path:
            self.old_path = path
            self.old_label.setText(f"Old uploader: {Path(path).name}")
            self.old_label.setToolTip(path)
            self.result = None
            self.update_buttons()

    def select_new(self) -> None:
        path, _ = QFileDialog.getOpenFileName(
            self,
            "Select New Uploader",
            "",
            "Excel workbooks (*.xlsx *.xlsm)",
        )
        if path:
            self.new_path = path
            self.new_label.setText(f"New uploader: {Path(path).name}")
            self.new_label.setToolTip(path)
            self.result = None
            self.update_buttons()

    def run_qc(self) -> None:
        if not self.old_path or not self.new_path:
            QMessageBox.warning(
                self,
                "Files required",
                "Select both the old uploader and new uploader.",
            )
            return

        if Path(self.old_path).resolve() == Path(self.new_path).resolve():
            QMessageBox.warning(
                self,
                "Same file selected",
                "Select two different uploader workbooks.",
            )
            return

        self.result = None
        self.worker = QCWorker(self.old_path, self.new_path)
        self.worker.completed.connect(self.qc_completed)
        self.worker.failed.connect(self.qc_failed)
        self.progress.show()
        self.status_label.setText(
            "Running row-by-row QC for the six mapped old/new uploader columns..."
        )
        self.update_buttons()
        self.worker.start()

    def qc_completed(self, result: dict[str, Any]) -> None:
        self.result = result
        self.worker = None
        self.progress.hide()

        self.populate_table(self.summary_table, result["summary"], False)
        self.populate_table(self.results_table, result["report"], True)
        self.populate_table(self.failed_table, result["failed_report"], True)

        total = len(result["report"])
        self.summary_label.setText(
            f"Checks: {total} | PASS: {result['passed']} | FAIL: {result['failed']}"
        )
        self.status_label.setText(
            "QC completed. Only the six configured column mappings were checked."
        )
        self.tabs.setCurrentWidget(
            self.failed_table if result["failed"] else self.summary_table
        )
        self.update_buttons()

    def qc_failed(self, error: str) -> None:
        self.worker = None
        self.progress.hide()
        self.status_label.setText("QC failed.")
        self.update_buttons()
        QMessageBox.critical(self, "QC failed", error)

    def update_buttons(self) -> None:
        running = self.worker is not None and self.worker.isRunning()
        self.old_button.setEnabled(not running)
        self.new_button.setEnabled(not running)
        self.run_button.setEnabled(bool(self.old_path and self.new_path) and not running)
        self.export_button.setEnabled(self.result is not None and not running)

    def populate_table(
        self,
        table: QTableWidget,
        frame: pd.DataFrame,
        color_results: bool,
    ) -> None:
        table.setSortingEnabled(False)
        table.clear()

        if frame.empty:
            table.setRowCount(1)
            table.setColumnCount(1)
            table.setHorizontalHeaderLabels(["QC Result"])
            table.setItem(0, 0, QTableWidgetItem("No failed QC records."))
            table.setSortingEnabled(True)
            return

        shown = frame.head(GUI_ROW_LIMIT)
        table.setRowCount(len(shown))
        table.setColumnCount(len(shown.columns))
        table.setHorizontalHeaderLabels([str(column) for column in shown.columns])
        result_index = (
            list(shown.columns).index("QC Result")
            if "QC Result" in shown.columns
            else -1
        )

        for row_number, (_, row) in enumerate(shown.iterrows()):
            qc_result = (
                display_value(row.iloc[result_index]) if result_index >= 0 else ""
            )
            for column_number, value in enumerate(row):
                item = QTableWidgetItem(display_value(value))
                item.setToolTip(display_value(value))
                if color_results:
                    if qc_result == "PASS":
                        item.setBackground(QColor("#ddf4e4"))
                    elif qc_result == "FAIL":
                        item.setBackground(QColor("#ffd7d7"))
                table.setItem(row_number, column_number, item)

        header = table.horizontalHeader()
        header.setSectionResizeMode(QHeaderView.ResizeMode.Interactive)
        for index, column in enumerate(shown.columns):
            name = str(column)
            if name in {"Old Column", "New Column"}:
                width = 310
            elif name in {"Old Value", "New Value", "Remark"}:
                width = 230
            elif name in {"Old Sheet", "New Sheet"}:
                width = 170
            else:
                width = 110
            header.resizeSection(index, width)
        table.setSortingEnabled(True)

    def export_report(self) -> None:
        if not self.result:
            return

        default_name = f"Selected_Columns_QC_{Path(self.new_path or 'New').stem}.xlsx"
        path, _ = QFileDialog.getSaveFileName(
            self,
            "Export QC Report",
            default_name,
            "Excel workbook (*.xlsx)",
        )
        if not path:
            return
        if not path.lower().endswith(".xlsx"):
            path += ".xlsx"

        try:
            with pd.ExcelWriter(path, engine="openpyxl") as writer:
                self.result["summary"].to_excel(
                    writer,
                    sheet_name="QC Summary",
                    index=False,
                )
                self.result["report"].to_excel(
                    writer,
                    sheet_name="All QC Results",
                    index=False,
                )
                self.result["failed_report"].to_excel(
                    writer,
                    sheet_name="Failed Only",
                    index=False,
                )

                used = {"QC Summary", "All QC Results", "Failed Only"}
                for number, sheet in enumerate(self.result["old_sheets"], start=1):
                    sheet["frame"].to_excel(
                        writer,
                        sheet_name=safe_sheet_name(
                            f"Old{number}_{sheet['name']}", used
                        ),
                        index=False,
                    )
                for number, sheet in enumerate(self.result["new_sheets"], start=1):
                    sheet["frame"].to_excel(
                        writer,
                        sheet_name=safe_sheet_name(
                            f"New{number}_{sheet['name']}", used
                        ),
                        index=False,
                    )

                self.format_workbook(writer.book)

            self.status_label.setText(f"QC report exported: {path}")
            QMessageBox.information(
                self,
                "Export complete",
                f"QC report saved successfully:\n\n{path}",
            )
        except PermissionError:
            QMessageBox.critical(
                self,
                "Export error",
                "Close the output workbook in Excel and try again.",
            )
        except Exception:
            QMessageBox.critical(self, "Export error", traceback.format_exc())

    @staticmethod
    def format_workbook(workbook: Any) -> None:
        from openpyxl.styles import Alignment, Font, PatternFill
        from openpyxl.utils import get_column_letter

        header_fill = PatternFill("solid", fgColor="173D68")
        pass_fill = PatternFill("solid", fgColor="DDF4E4")
        fail_fill = PatternFill("solid", fgColor="FFD7D7")

        for worksheet in workbook.worksheets:
            worksheet.freeze_panes = "A2"
            worksheet.auto_filter.ref = worksheet.dimensions

            for cell in worksheet[1]:
                cell.fill = header_fill
                cell.font = Font(color="FFFFFF", bold=True)
                cell.alignment = Alignment(horizontal="center", vertical="center")

            result_column = next(
                (
                    cell.column
                    for cell in worksheet[1]
                    if cell.value == "QC Result"
                ),
                None,
            )

            for row_number in range(2, worksheet.max_row + 1):
                qc_result = (
                    worksheet.cell(row_number, result_column).value
                    if result_column
                    else None
                )
                for cell in worksheet[row_number]:
                    if qc_result == "PASS":
                        cell.fill = pass_fill
                    elif qc_result == "FAIL":
                        cell.fill = fail_fill
                    cell.alignment = Alignment(vertical="top", wrap_text=True)

            for column_cells in worksheet.iter_cols():
                cells = list(column_cells)
                maximum_length = max(
                    (
                        len(str(cell.value)) if cell.value is not None else 0
                        for cell in cells[:500]
                    ),
                    default=0,
                )
                column_letter = get_column_letter(cells[0].column)
                worksheet.column_dimensions[column_letter].width = min(
                    max(maximum_length + 2, 12),
                    50,
                )


def main() -> None:
    app = QApplication(sys.argv)
    app.setApplicationName("Selected Columns Uploader QC")
    app.setStyle("Fusion")
    app.setFont(QFont("Segoe UI", 9))

    window = QCWindow()
    window.show()
    sys.exit(app.exec())


if __name__ == "__main__":
    main()
