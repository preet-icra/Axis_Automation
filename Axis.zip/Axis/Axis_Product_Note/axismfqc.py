#!/usr/bin/env python3
"""
Fund Factsheet vs PowerPoint QC Tool

Desktop GUI built with PyQt6. It extracts text/tables from a reference PDF and
compares them with one or more PPTX fund decks. Results can be exported to XLSX,
CSV, and JSON.

Recommended Python: 3.11+
"""

from __future__ import annotations

import csv
import json
import math
import re
import sys
import traceback
from dataclasses import asdict, dataclass
from datetime import datetime
from pathlib import Path
from typing import Callable, Iterable, Optional

import fitz  # PyMuPDF
import pandas as pd
from pptx import Presentation
from rapidfuzz import fuzz, process

from PyQt6.QtCore import QObject, QSettings, Qt, QThread, pyqtSignal
from PyQt6.QtGui import QAction, QFont
from PyQt6.QtWidgets import (
    QApplication,
    QAbstractItemView,
    QCheckBox,
    QComboBox,
    QFileDialog,
    QFormLayout,
    QGroupBox,
    QHBoxLayout,
    QHeaderView,
    QLabel,
    QLineEdit,
    QListWidget,
    QListWidgetItem,
    QMainWindow,
    QMessageBox,
    QPlainTextEdit,
    QProgressBar,
    QPushButton,
    QSpinBox,
    QDoubleSpinBox,
    QSplitter,
    QStatusBar,
    QTableWidget,
    QTableWidgetItem,
    QTabWidget,
    QVBoxLayout,
    QWidget,
)

APP_NAME = "Fund Factsheet QC"
ORG_NAME = "FundQCTool"


# ----------------------------- Data models -----------------------------

@dataclass
class TextBlock:
    source_file: str
    source_type: str
    location: str
    text: str
    fund_hint: str = ""


@dataclass
class QCResult:
    ppt_file: str
    slide: int
    fund_name: str
    check_type: str
    field: str
    ppt_value: str
    pdf_value: str
    status: str
    severity: str
    similarity: float
    note: str
    pdf_location: str = ""


@dataclass
class QCConfig:
    text_threshold: float = 88.0
    numeric_tolerance: float = 0.02
    rounding_tolerance: float = 0.05
    ignore_case: bool = True
    normalize_whitespace: bool = True
    compare_numbers: bool = True
    compare_dates: bool = True
    compare_labels: bool = True
    detect_missing: bool = True


# ----------------------------- Normalization -----------------------------

NUMBER_RE = re.compile(
    r"(?<![A-Za-z0-9])(?:₹|Rs\.?|INR|US\$|\$)?\s*"
    r"[-+]?\d{1,3}(?:,\d{2,3})*(?:\.\d+)?(?:\s*%|\s*(?:cr|crore|lakh|mn|bn))?",
    re.IGNORECASE,
)
DATE_RE = re.compile(
    r"\b(?:\d{1,2}[-/.]\d{1,2}[-/.]\d{2,4}|"
    r"\d{1,2}\s+(?:Jan(?:uary)?|Feb(?:ruary)?|Mar(?:ch)?|Apr(?:il)?|May|Jun(?:e)?|"
    r"Jul(?:y)?|Aug(?:ust)?|Sep(?:tember)?|Oct(?:ober)?|Nov(?:ember)?|Dec(?:ember)?)\s+\d{2,4}|"
    r"(?:Jan(?:uary)?|Feb(?:ruary)?|Mar(?:ch)?|Apr(?:il)?|May|Jun(?:e)?|Jul(?:y)?|"
    r"Aug(?:ust)?|Sep(?:tember)?|Oct(?:ober)?|Nov(?:ember)?|Dec(?:ember)?)\s+\d{1,2},?\s+\d{4})\b",
    re.IGNORECASE,
)

KNOWN_LABELS = [
    "fund name", "scheme name", "category", "benchmark", "fund manager",
    "inception date", "allotment date", "nav", "aum", "average aum",
    "expense ratio", "exit load", "minimum investment", "riskometer",
    "standard deviation", "sharpe ratio", "beta", "alpha", "portfolio turnover",
    "modified duration", "yield to maturity", "macaulay duration",
    "1 year", "3 years", "5 years", "since inception",
]


def clean_text(value: object, cfg: QCConfig) -> str:
    text = "" if value is None else str(value)
    text = text.replace("\u00a0", " ").replace("\u2013", "-").replace("\u2014", "-")
    if cfg.normalize_whitespace:
        text = re.sub(r"\s+", " ", text).strip()
    if cfg.ignore_case:
        text = text.casefold()
    return text


def canonical_number(token: str) -> Optional[float]:
    raw = token.casefold().strip()
    multiplier = 1.0
    if "crore" in raw or re.search(r"\bcr\b", raw):
        multiplier = 10_000_000.0
    elif "lakh" in raw:
        multiplier = 100_000.0
    elif re.search(r"\bmn\b", raw):
        multiplier = 1_000_000.0
    elif re.search(r"\bbn\b", raw):
        multiplier = 1_000_000_000.0
    is_percent = "%" in raw
    raw = re.sub(r"(?:₹|rs\.?|inr|us\$|\$|crore|lakh|\bcr\b|\bmn\b|\bbn\b|%)", "", raw)
    raw = raw.replace(",", "").strip()
    try:
        value = float(raw) * multiplier
        return value / 100.0 if is_percent else value
    except ValueError:
        return None


def extract_numbers(text: str) -> list[tuple[str, float]]:
    found = []
    for match in NUMBER_RE.finditer(text):
        token = match.group(0).strip()
        value = canonical_number(token)
        if value is not None and math.isfinite(value):
            found.append((token, value))
    return found


def numeric_close(a: float, b: float, cfg: QCConfig) -> tuple[bool, str]:
    abs_diff = abs(a - b)
    scale = max(abs(a), abs(b), 1.0)
    rel_diff = abs_diff / scale
    if abs_diff <= cfg.numeric_tolerance or rel_diff <= cfg.numeric_tolerance:
        return True, "within tolerance"
    if abs_diff <= cfg.rounding_tolerance or rel_diff <= cfg.rounding_tolerance:
        return True, "possible rounding difference"
    return False, f"difference={abs_diff:.6g}; relative={rel_diff:.2%}"


def infer_fund_name(text: str, fallback: str) -> str:
    lines = [re.sub(r"\s+", " ", x).strip() for x in text.splitlines() if x.strip()]
    candidates = [x for x in lines[:12] if 4 <= len(x) <= 150]
    fundish = [x for x in candidates if re.search(r"\b(fund|scheme|etf|fof|plan)\b", x, re.I)]
    return (fundish[0] if fundish else (candidates[0] if candidates else fallback))[:150]


# ----------------------------- Extractors -----------------------------

def extract_pdf(pdf_path: Path, log: Callable[[str], None]) -> list[TextBlock]:
    blocks: list[TextBlock] = []
    with fitz.open(pdf_path) as doc:
        if doc.needs_pass:
            raise ValueError("The reference PDF is password protected.")
        for page_no, page in enumerate(doc, start=1):
            text = page.get_text("text", sort=True) or ""
            if not text.strip():
                log(f"Warning: PDF page {page_no} has no extractable text; OCR may be required.")
            blocks.append(TextBlock(pdf_path.name, "PDF", f"Page {page_no}", text, infer_fund_name(text, "")))
    return blocks


def iter_shape_text(shape) -> Iterable[str]:
    if getattr(shape, "has_text_frame", False):
        text = shape.text or ""
        if text.strip():
            yield text
    if getattr(shape, "has_table", False):
        for row in shape.table.rows:
            yield " | ".join(cell.text.strip() for cell in row.cells)
    # Grouped shapes
    if hasattr(shape, "shapes"):
        for child in shape.shapes:
            yield from iter_shape_text(child)


def extract_pptx(ppt_path: Path) -> list[TextBlock]:
    prs = Presentation(str(ppt_path))
    blocks: list[TextBlock] = []
    for slide_no, slide in enumerate(prs.slides, start=1):
        pieces = []
        for shape in slide.shapes:
            pieces.extend(iter_shape_text(shape))
        text = "\n".join(pieces)
        blocks.append(TextBlock(ppt_path.name, "PPTX", f"Slide {slide_no}", text,
                                infer_fund_name(text, ppt_path.stem)))
    return blocks


# ----------------------------- Comparison engine -----------------------------
def best_pdf_block(ppt_block: TextBlock, pdf_blocks: list[TextBlock], cfg: QCConfig) -> tuple[TextBlock, float]:
    query = clean_text(ppt_block.fund_hint or ppt_block.text[:300], cfg)
    choices = {i: clean_text((b.fund_hint + " " + b.text[:600]), cfg) for i, b in enumerate(pdf_blocks)}
    result = process.extractOne(query, choices, scorer=fuzz.token_set_ratio)
    if not result:
        return pdf_blocks[0], 0.0
    _, score, index = result
    return pdf_blocks[index], float(score)


def find_best_context(needle: str, haystack: str, cfg: QCConfig) -> tuple[str, float]:
    target = clean_text(needle, cfg)
    lines = [x.strip() for x in haystack.splitlines() if x.strip()]
    if not lines:
        return "", 0.0
    match = process.extractOne(target, lines, scorer=fuzz.token_set_ratio)
    if not match:
        return "", 0.0
    return match[0], float(match[1])


def compare_block(ppt: TextBlock, pdf: TextBlock, cfg: QCConfig) -> list[QCResult]:
    results: list[QCResult] = []
    slide_no = int(re.search(r"\d+", ppt.location).group())
    fund = ppt.fund_hint
    ppt_clean = clean_text(ppt.text, cfg)
    pdf_clean = clean_text(pdf.text, cfg)

    # Whole-slide semantic/text coverage
    similarity = float(fuzz.token_set_ratio(ppt_clean, pdf_clean)) if ppt_clean and pdf_clean else 0.0
    results.append(QCResult(
        ppt.source_file, slide_no, fund, "Text coverage", "Overall slide-to-page match",
        ppt.text[:250].replace("\n", " | "), pdf.text[:250].replace("\n", " | "),
        "PASS" if similarity >= cfg.text_threshold else "REVIEW",
        "Low" if similarity >= cfg.text_threshold else "Medium",
        similarity, f"Matched against {pdf.location}", pdf.location
    ))

    # Numeric values in PPT must be discoverable in the mapped PDF page.
    if cfg.compare_numbers:
        ppt_numbers = extract_numbers(ppt.text)
        pdf_numbers = extract_numbers(pdf.text)
        pdf_vals = [v for _, v in pdf_numbers]
        for token, value in ppt_numbers:
            if not pdf_vals:
                ok, note, matched = False, "No numeric values found in mapped PDF page", ""
            else:
                closest_i = min(range(len(pdf_vals)), key=lambda i: abs(pdf_vals[i] - value))
                matched_token, matched_value = pdf_numbers[closest_i]
                ok, note = numeric_close(value, matched_value, cfg)
                matched = matched_token
            results.append(QCResult(
                ppt.source_file, slide_no, fund, "Numeric", "Numeric value",
                token, matched, "PASS" if ok else "FAIL", "Low" if ok else "High",
                100.0 if ok else 0.0, note, pdf.location
            ))

    # Date presence
    if cfg.compare_dates:
        for date_token in dict.fromkeys(DATE_RE.findall(ppt.text)):
            context, score = find_best_context(date_token, pdf.text, cfg)
            ok = clean_text(date_token, cfg) in pdf_clean or score >= 95
            results.append(QCResult(
                ppt.source_file, slide_no, fund, "Date", "Date",
                date_token, context, "PASS" if ok else "FAIL", "Low" if ok else "High",
                score, "Date found in mapped page" if ok else "Date not found in mapped page", pdf.location
            ))

    # Known business labels: if present in PPT, verify label/context exists in PDF.
    if cfg.compare_labels:
        for label in KNOWN_LABELS:
            if clean_text(label, cfg) in ppt_clean:
                context, score = find_best_context(label, pdf.text, cfg)
                ok = score >= cfg.text_threshold
                results.append(QCResult(
                    ppt.source_file, slide_no, fund, "Field label", label.title(),
                    label, context, "PASS" if ok else "REVIEW", "Low" if ok else "Medium",
                    score, "Label/context comparison", pdf.location
                ))

    # Detect meaningful PPT lines absent from PDF.
    if cfg.detect_missing:
        lines = [re.sub(r"\s+", " ", x).strip() for x in ppt.text.splitlines()]
        lines = [x for x in lines if 12 <= len(x) <= 300 and not NUMBER_RE.fullmatch(x)]
        unique_lines = list(dict.fromkeys(lines))[:100]
        for line in unique_lines:
            context, score = find_best_context(line, pdf.text, cfg)
            if score < cfg.text_threshold:
                results.append(QCResult(
                    ppt.source_file, slide_no, fund, "Missing/mismatch", "Text line",
                    line, context, "REVIEW", "Medium", score,
                    "PPT text was not closely matched in the mapped PDF page", pdf.location
                ))
    return results


def run_qc(pdf_path: Path, ppt_paths: list[Path], cfg: QCConfig,
           progress: Callable[[int, str], None], log: Callable[[str], None]) -> list[QCResult]:
    log(f"Reading PDF: {pdf_path.name}")
    pdf_blocks = extract_pdf(pdf_path, log)
    if not pdf_blocks:
        raise ValueError("No pages were extracted from the PDF.")

    all_results: list[QCResult] = []
    total_files = max(len(ppt_paths), 1)
    for file_index, ppt_path in enumerate(ppt_paths, start=1):
        log(f"Reading PowerPoint: {ppt_path.name}")
        ppt_blocks = extract_pptx(ppt_path)
        for slide_index, ppt_block in enumerate(ppt_blocks, start=1):
            pdf_block, map_score = best_pdf_block(ppt_block, pdf_blocks, cfg)
            log(f"  Slide {slide_index} -> {pdf_block.location} (mapping score {map_score:.1f})")
            all_results.extend(compare_block(ppt_block, pdf_block, cfg))
        progress(int(file_index / total_files * 100), f"Processed {ppt_path.name}")
    return all_results


# ----------------------------- Exports -----------------------------
def results_frame(results: list[QCResult]) -> pd.DataFrame:
    columns = list(QCResult.__dataclass_fields__)
    return pd.DataFrame([asdict(x) for x in results], columns=columns)


def export_xlsx(path: Path, results: list[QCResult], metadata: dict) -> None:
    df = results_frame(results)
    summary = (
        df.groupby(["ppt_file", "status", "severity"], dropna=False)
        .size().reset_index(name="count") if not df.empty else pd.DataFrame()
    )
    with pd.ExcelWriter(path, engine="openpyxl") as writer:
        df.to_excel(writer, sheet_name="QC Results", index=False)
        summary.to_excel(writer, sheet_name="Summary", index=False)
        pd.DataFrame([metadata]).to_excel(writer, sheet_name="Run Info", index=False)
        for sheet in writer.book.worksheets:
            sheet.freeze_panes = "A2"
            sheet.auto_filter.ref = sheet.dimensions
            for col_cells in sheet.columns:
                letter = col_cells[0].column_letter
                width = min(max((len(str(c.value or "")) for c in col_cells), default=10) + 2, 60)
                sheet.column_dimensions[letter].width = width
                for cell in col_cells:
                    cell.alignment = cell.alignment.copy(vertical="top", wrap_text=True)


def export_csv(path: Path, results: list[QCResult]) -> None:
    results_frame(results).to_csv(path, index=False, encoding="utf-8-sig", quoting=csv.QUOTE_MINIMAL)


def export_json(path: Path, results: list[QCResult], metadata: dict) -> None:
    payload = {"run_info": metadata, "results": [asdict(x) for x in results]}
    path.write_text(json.dumps(payload, indent=2, ensure_ascii=False), encoding="utf-8")


# ----------------------------- Worker -----------------------------
class QCWorker(QObject):
    progress = pyqtSignal(int, str)
    log = pyqtSignal(str)
    finished = pyqtSignal(object)
    failed = pyqtSignal(str)

    def __init__(self, pdf_path: Path, ppt_paths: list[Path], cfg: QCConfig):
        super().__init__()
        self.pdf_path = pdf_path
        self.ppt_paths = ppt_paths
        self.cfg = cfg

    def run(self):
        try:
            results = run_qc(self.pdf_path, self.ppt_paths, self.cfg,
                             self.progress.emit, self.log.emit)
            self.finished.emit(results)
        except Exception:
            self.failed.emit(traceback.format_exc())


# ----------------------------- GUI -----------------------------
class MainWindow(QMainWindow):
    def __init__(self):
        super().__init__()
        self.settings = QSettings(ORG_NAME, APP_NAME)
        self.results: list[QCResult] = []
        self.worker_thread: Optional[QThread] = None
        self.setWindowTitle(APP_NAME)
        self.resize(1400, 850)
        self._build_ui()
        self._restore_settings()

    def _build_ui(self):
        self.setStatusBar(QStatusBar())
        self._build_menu()
        root = QWidget()
        self.setCentralWidget(root)
        layout = QVBoxLayout(root)

        splitter = QSplitter(Qt.Orientation.Horizontal)
        layout.addWidget(splitter, 1)

        left = QWidget()
        left_layout = QVBoxLayout(left)
        splitter.addWidget(left)

        file_group = QGroupBox("Input files")
        fg = QVBoxLayout(file_group)
        pdf_row = QHBoxLayout()
        self.pdf_edit = QLineEdit()
        self.pdf_edit.setPlaceholderText("Select the master factsheet PDF")
        pdf_btn = QPushButton("Browse PDF")
        pdf_btn.clicked.connect(self.choose_pdf)
        pdf_row.addWidget(self.pdf_edit, 1)
        pdf_row.addWidget(pdf_btn)
        fg.addLayout(pdf_row)

        fg.addWidget(QLabel("Individual fund PowerPoint files"))
        self.ppt_list = QListWidget()
        self.ppt_list.setSelectionMode(QAbstractItemView.SelectionMode.ExtendedSelection)
        fg.addWidget(self.ppt_list, 1)
        ppt_buttons = QHBoxLayout()
        add_btn = QPushButton("Add PPTX files")
        add_btn.clicked.connect(self.add_ppts)
        remove_btn = QPushButton("Remove selected")
        remove_btn.clicked.connect(self.remove_selected_ppts)
        clear_btn = QPushButton("Clear")
        clear_btn.clicked.connect(self.ppt_list.clear)
        ppt_buttons.addWidget(add_btn)
        ppt_buttons.addWidget(remove_btn)
        ppt_buttons.addWidget(clear_btn)
        fg.addLayout(ppt_buttons)
        left_layout.addWidget(file_group, 2)

        options = QGroupBox("QC options")
        form = QFormLayout(options)
        self.threshold = QDoubleSpinBox()
        self.threshold.setRange(50, 100)
        self.threshold.setValue(88)
        self.threshold.setSuffix(" %")
        self.num_tol = QDoubleSpinBox()
        self.num_tol.setDecimals(4)
        self.num_tol.setRange(0, 1000000)
        self.num_tol.setValue(0.02)
        self.round_tol = QDoubleSpinBox()
        self.round_tol.setDecimals(4)
        self.round_tol.setRange(0, 1000000)
        self.round_tol.setValue(0.05)
        self.chk_numbers = QCheckBox("Check numeric values")
        self.chk_numbers.setChecked(True)
        self.chk_dates = QCheckBox("Check dates")
        self.chk_dates.setChecked(True)
        self.chk_labels = QCheckBox("Check common fund labels")
        self.chk_labels.setChecked(True)
        self.chk_missing = QCheckBox("Flag unmatched PPT text")
        self.chk_missing.setChecked(True)
        form.addRow("Text match threshold", self.threshold)
        form.addRow("Numeric tolerance", self.num_tol)
        form.addRow("Rounding tolerance", self.round_tol)
        form.addRow(self.chk_numbers)
        form.addRow(self.chk_dates)
        form.addRow(self.chk_labels)
        form.addRow(self.chk_missing)
        left_layout.addWidget(options)

        action_row = QHBoxLayout()
        self.run_btn = QPushButton("Run QC")
        self.run_btn.setDefault(True)
        self.run_btn.clicked.connect(self.start_qc)
        self.export_btn = QPushButton("Export report")
        self.export_btn.setEnabled(False)
        self.export_btn.clicked.connect(self.export_report)
        action_row.addWidget(self.run_btn)
        action_row.addWidget(self.export_btn)
        left_layout.addLayout(action_row)

        self.progress = QProgressBar()
        self.progress.setRange(0, 100)
        left_layout.addWidget(self.progress)

        tabs = QTabWidget()
        splitter.addWidget(tabs)
        splitter.setSizes([430, 970])

        results_tab = QWidget()
        rt_layout = QVBoxLayout(results_tab)
        filter_row = QHBoxLayout()
        self.status_filter = QComboBox()
        self.status_filter.addItems(["All", "FAIL", "REVIEW", "PASS"])
        self.status_filter.currentTextChanged.connect(self.populate_table)
        self.search_edit = QLineEdit()
        self.search_edit.setPlaceholderText("Filter by fund, file, field, value, or note")
        self.search_edit.textChanged.connect(self.populate_table)
        filter_row.addWidget(QLabel("Status"))
        filter_row.addWidget(self.status_filter)
        filter_row.addWidget(self.search_edit, 1)
        rt_layout.addLayout(filter_row)

        self.table = QTableWidget()
        headers = ["File", "Slide", "Fund", "Check", "Field", "PPT value", "PDF value",
                   "Status", "Severity", "Similarity", "PDF location", "Note"]
        self.table.setColumnCount(len(headers))
        self.table.setHorizontalHeaderLabels(headers)
        self.table.setSortingEnabled(True)
        self.table.setAlternatingRowColors(True)
        self.table.setSelectionBehavior(QAbstractItemView.SelectionBehavior.SelectRows)
        self.table.verticalHeader().setVisible(False)
        self.table.horizontalHeader().setSectionResizeMode(QHeaderView.ResizeMode.Interactive)
        self.table.horizontalHeader().setStretchLastSection(True)
        rt_layout.addWidget(self.table, 1)
        tabs.addTab(results_tab, "QC results")

        log_tab = QWidget()
        lg = QVBoxLayout(log_tab)
        self.log_box = QPlainTextEdit()
        self.log_box.setReadOnly(True)
        self.log_box.setFont(QFont("Consolas", 9))
        lg.addWidget(self.log_box)
        tabs.addTab(log_tab, "Run log")

    def _build_menu(self):
        menu = self.menuBar().addMenu("File")
        open_pdf = QAction("Open PDF...", self)
        open_pdf.triggered.connect(self.choose_pdf)
        menu.addAction(open_pdf)
        add_ppt = QAction("Add PPTX files...", self)
        add_ppt.triggered.connect(self.add_ppts)
        menu.addAction(add_ppt)
        menu.addSeparator()
        export = QAction("Export report...", self)
        export.triggered.connect(self.export_report)
        menu.addAction(export)
        menu.addSeparator()
        quit_action = QAction("Exit", self)
        quit_action.triggered.connect(self.close)
        menu.addAction(quit_action)

    def choose_pdf(self):
        start = self.settings.value("last_dir", str(Path.home()))
        path, _ = QFileDialog.getOpenFileName(self, "Select factsheet PDF", start, "PDF files (*.pdf)")
        if path:
            self.pdf_edit.setText(path)
            self.settings.setValue("last_dir", str(Path(path).parent))

    def add_ppts(self):
        start = self.settings.value("last_dir", str(Path.home()))
        files, _ = QFileDialog.getOpenFileNames(
            self, "Select fund PowerPoint files", start, "PowerPoint files (*.pptx)"
        )
        existing = {self.ppt_list.item(i).text() for i in range(self.ppt_list.count())}
        for path in files:
            if path not in existing:
                self.ppt_list.addItem(QListWidgetItem(path))
        if files:
            self.settings.setValue("last_dir", str(Path(files[0]).parent))

    def remove_selected_ppts(self):
        for item in self.ppt_list.selectedItems():
            self.ppt_list.takeItem(self.ppt_list.row(item))

    def config(self) -> QCConfig:
        return QCConfig(
            text_threshold=self.threshold.value(),
            numeric_tolerance=self.num_tol.value(),
            rounding_tolerance=self.round_tol.value(),
            compare_numbers=self.chk_numbers.isChecked(),
            compare_dates=self.chk_dates.isChecked(),
            compare_labels=self.chk_labels.isChecked(),
            detect_missing=self.chk_missing.isChecked(),
        )

    def validate_inputs(self) -> tuple[Optional[Path], list[Path]]:
        pdf_path = Path(self.pdf_edit.text().strip())
        ppts = [Path(self.ppt_list.item(i).text()) for i in range(self.ppt_list.count())]
        if not pdf_path.is_file() or pdf_path.suffix.lower() != ".pdf":
            QMessageBox.warning(self, APP_NAME, "Please select a valid factsheet PDF.")
            return None, []
        invalid = [str(p) for p in ppts if not p.is_file() or p.suffix.lower() != ".pptx"]
        if not ppts or invalid:
            QMessageBox.warning(self, APP_NAME, "Please add one or more valid .pptx files.")
            return None, []
        return pdf_path, ppts

    def start_qc(self):
        pdf_path, ppts = self.validate_inputs()
        if not pdf_path:
            return
        self.results = []
        self.populate_table()
        self.log_box.clear()
        self.progress.setValue(0)
        self.run_btn.setEnabled(False)
        self.export_btn.setEnabled(False)
        self.statusBar().showMessage("QC is running...")

        self.worker_thread = QThread(self)
        worker = QCWorker(pdf_path, ppts, self.config())
        worker.moveToThread(self.worker_thread)
        self.worker_thread.worker = worker  # maintain reference
        self.worker_thread.started.connect(worker.run)
        worker.log.connect(self.append_log)
        worker.progress.connect(self.on_progress)
        worker.finished.connect(self.on_finished)
        worker.failed.connect(self.on_failed)
        worker.finished.connect(self.worker_thread.quit)
        worker.failed.connect(self.worker_thread.quit)
        self.worker_thread.finished.connect(worker.deleteLater)
        self.worker_thread.finished.connect(self.worker_thread.deleteLater)
        self.worker_thread.start()

    def append_log(self, message: str):
        self.log_box.appendPlainText(message)

    def on_progress(self, value: int, message: str):
        self.progress.setValue(value)
        self.statusBar().showMessage(message)

    def on_finished(self, results):
        self.results = list(results)
        self.run_btn.setEnabled(True)
        self.export_btn.setEnabled(bool(self.results))
        self.progress.setValue(100)
        self.populate_table()
        counts = {s: sum(1 for r in self.results if r.status == s) for s in ("FAIL", "REVIEW", "PASS")}
        message = f"Completed: {counts['FAIL']} fail, {counts['REVIEW']} review, {counts['PASS']} pass"
        self.statusBar().showMessage(message)
        self.append_log(message)

    def on_failed(self, details: str):
        self.run_btn.setEnabled(True)
        self.statusBar().showMessage("QC failed")
        self.append_log(details)
        QMessageBox.critical(self, APP_NAME, "QC could not complete. See the Run log for details.")

    def filtered_results(self) -> list[QCResult]:
        status = self.status_filter.currentText()
        query = self.search_edit.text().casefold().strip()
        output = []
        for r in self.results:
            if status != "All" and r.status != status:
                continue
            haystack = " ".join(str(v) for v in asdict(r).values()).casefold()
            if query and query not in haystack:
                continue
            output.append(r)
        return output

    def populate_table(self, *_):
        rows = self.filtered_results()
        self.table.setSortingEnabled(False)
        self.table.setRowCount(len(rows))
        for row, r in enumerate(rows):
            values = [r.ppt_file, r.slide, r.fund_name, r.check_type, r.field,
                      r.ppt_value, r.pdf_value, r.status, r.severity,
                      f"{r.similarity:.1f}", r.pdf_location, r.note]
            for col, value in enumerate(values):
                item = QTableWidgetItem(str(value))
                if col == 1:
                    item.setData(Qt.ItemDataRole.DisplayRole, int(value))
                self.table.setItem(row, col, item)
        self.table.setSortingEnabled(True)
        self.table.resizeColumnsToContents()
        for col in range(self.table.columnCount()):
            if self.table.columnWidth(col) > 320:
                self.table.setColumnWidth(col, 320)

    def metadata(self) -> dict:
        return {
            "generated_at": datetime.now().isoformat(timespec="seconds"),
            "reference_pdf": self.pdf_edit.text(),
            "pptx_count": self.ppt_list.count(),
            "result_count": len(self.results),
            "text_threshold": self.threshold.value(),
            "numeric_tolerance": self.num_tol.value(),
            "rounding_tolerance": self.round_tol.value(),
        }

    def export_report(self):
        if not self.results:
            QMessageBox.information(self, APP_NAME, "Run QC before exporting a report.")
            return
        start = str(Path(self.settings.value("last_dir", str(Path.home()))) / "fund_qc_report.xlsx")
        path, selected = QFileDialog.getSaveFileName(
            self, "Export QC report", start,
            "Excel workbook (*.xlsx);;CSV file (*.csv);;JSON file (*.json)"
        )
        if not path:
            return
        target = Path(path)
        try:
            if "CSV" in selected:
                if target.suffix.lower() != ".csv": target = target.with_suffix(".csv")
                export_csv(target, self.results)
            elif "JSON" in selected:
                if target.suffix.lower() != ".json": target = target.with_suffix(".json")
                export_json(target, self.results, self.metadata())
            else:
                if target.suffix.lower() != ".xlsx": target = target.with_suffix(".xlsx")
                export_xlsx(target, self.results, self.metadata())
            self.settings.setValue("last_dir", str(target.parent))
            QMessageBox.information(self, APP_NAME, f"Report exported to:\n{target}")
        except Exception as exc:
            QMessageBox.critical(self, APP_NAME, f"Could not export the report:\n{exc}")

    def _restore_settings(self):
        self.pdf_edit.setText(self.settings.value("pdf_path", ""))

    def closeEvent(self, event):
        self.settings.setValue("pdf_path", self.pdf_edit.text())
        if self.worker_thread and self.worker_thread.isRunning():
            QMessageBox.warning(self, APP_NAME, "Please wait for the current QC run to finish.")
            event.ignore()
            return
        super().closeEvent(event)


def main() -> int:
    app = QApplication(sys.argv)
    app.setApplicationName(APP_NAME)
    app.setOrganizationName(ORG_NAME)
    app.setStyle("Fusion")
    window = MainWindow()
    window.show()
    return app.exec()


if __name__ == "__main__":
    raise SystemExit(main())
