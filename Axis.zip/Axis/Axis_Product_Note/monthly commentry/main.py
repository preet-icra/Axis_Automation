from __future__ import annotations
import re, shutil, sys, traceback
from dataclasses import dataclass, field
from pathlib import Path
from PyQt6.QtCore import QThread, pyqtSignal
from PyQt6.QtWidgets import (QApplication,QFileDialog,QFormLayout,QHBoxLayout,QLabel,QLineEdit,QMainWindow,QMessageBox,QPushButton,QPlainTextEdit,QVBoxLayout,QWidget)
from docx import Document
try:
 import pythoncom, win32com.client as win32
except ImportError:
 pythoncom=win32=None

PAGE1='Market commentary'; PAGE2='Market commentary (2)'; FINAL='Market commentary (3)'
SHAPES={PAGE1:'TextBox 13',PAGE2:'TextBox 11',FINAL:'TextBox 4'}
BODY_SIZE=11.0; HEADING_SIZE=15.0; FONT='Arial'
XL_NONE=-4142; XL_SINGLE=2; MSO_TRUE=-1; MSO_NONE=0; MSO_FIT=1

@dataclass
class Run:
 text:str; bold:bool=False; italic:bool=False; underline:bool=False
@dataclass
class Para:
 runs:list[Run]=field(default_factory=list); heading:bool=False
 @property
 def text(self): return ''.join(r.text for r in self.runs)
@dataclass
class Content:
 economy:list[Para]; strategy:list[Para]; table:list[list[Para]]; date:str

def bval(run, attr):
 v=getattr(run,attr)
 if v is not None:return bool(v)
 st=run.style
 while st:
  v=getattr(st.font,attr,None)
  if v is not None:return bool(v)
  st=st.base_style
 return False

def runs_from_paragraph(p, heading=False):
 rr=[Run(r.text.replace('\r',''),bval(r,'bold'),bval(r,'italic'),bval(r,'underline')) for r in p.runs if r.text]
 if not rr and p.text:rr=[Run(p.text)]
 if heading:
  for r in rr:r.bold=True
 return Para(rr,heading)

def report_date(path,doc):
 text='\n'.join(p.text for p in doc.paragraphs)
 m=re.search(r'\b(January|February|March|April|May|June|July|August|September|October|November|December)\s+20\d{2}\b',text,re.I)
 if m:return m.group(0).title()
 m=re.search(r'\b(Jan|Feb|Mar|Apr|May|Jun|Jul|Aug|Sep|Oct|Nov|Dec)[a-z]*[ _-]+(\d{2,4})\b',path.stem,re.I)
 if not m:return 'Completed'
 months={x[:3].lower():x for x in 'January February March April May June July August September October November December'.split()}
 y=int(m.group(2)); y=y+2000 if y<100 else y
 return f'{months[m.group(1)[:3].lower()]} {y}'

def extract(path):
 doc=Document(str(path)); eco=[]; strat=[]; group=None
 headings=('economy - india','economy - global','bond outlook and strategy','equity outlook and strategy','equity ulip returns in the recent past')
 for p in doc.paragraphs:
  t=p.text.replace('\xa0',' ').strip()
  if not t:continue
  low=t.casefold()
  if low.startswith('a consolidated view of the ulip'):continue
  if low.startswith('economy - india'):group='eco'
  elif low.startswith('bond outlook and strategy'):group='strat'
  heading=any(low.startswith(h) for h in headings)
  q=runs_from_paragraph(p,heading)
  (eco if group=='eco' else strat if group=='strat' else []).append(q)
 if not eco or not strat:raise ValueError('Required commentary headings were not found in the Word file.')
 table=[]
 if doc.tables:
  for row in doc.tables[0].rows:
   out=[]
   for cell in row.cells:
    rr=[]
    for pi,p in enumerate(cell.paragraphs):
     if pi and rr:rr.append(Run('\n'))
     rr.extend(runs_from_paragraph(p).runs)
    out.append(Para(rr or [Run(cell.text.strip())]))
   table.append(out)
 return Content(eco,strat,table,report_date(path,doc))

def shape(ws,name):
 try:return ws.Shapes(name)
 except Exception:
  boxes=[]
  for i in range(1,ws.Shapes.Count+1):
   x=ws.Shapes(i)
   try:
    if x.Type==17:boxes.append(x)
   except Exception:pass
  if not boxes:raise KeyError(f'No text box on {ws.Name}')
  return max(boxes,key=lambda x:float(x.Width)*float(x.Height))

def safe(font,prop,val):
 try:setattr(font,prop,val)
 except Exception:pass

def fmt(chars,size,bold=False,italic=False,underline=False,font=FONT):
 f=chars.Font; safe(f,'Name',font); safe(f,'Size',float(size)); safe(f,'Bold',bool(bold)); safe(f,'Italic',bool(italic)); safe(f,'Underline',XL_SINGLE if underline else XL_NONE)

def text_spans(paras):
 parts=[]; spans=[]; pos=0
 for i,p in enumerate(paras):
  for r in p.runs:
   parts.append(r.text);spans.append((pos,len(r.text),r,p.heading));pos+=len(r.text)
  if i<len(paras)-1:parts.append('\n\n');pos+=2
 return ''.join(parts),spans

def write_textbox(x,paras):
 text,spans=text_spans(paras); w=float(x.Width);h=float(x.Height)
 x.TextFrame2.AutoSize=MSO_NONE;x.TextFrame2.WordWrap=MSO_TRUE;x.TextFrame2.TextRange.Text=text
 fmt(x.TextFrame.Characters(),BODY_SIZE)
 for start,n,r,heading in spans:
  if not n:continue
  try:c=x.TextFrame.Characters(Start=start+1,Length=n)
  except Exception:
   try:c=x.TextFrame.Characters(start+1,n)
   except Exception:continue
  fmt(c,HEADING_SIZE if heading else BODY_SIZE,r.bold or heading,r.italic,r.underline)
 x.Width=w;x.Height=h;x.TextFrame2.AutoSize=MSO_NONE

def fits(x,paras):
 text,_=text_spans(paras); old=x.TextFrame2.TextRange.Text;w=float(x.Width);h=float(x.Height);l=float(x.Left);t=float(x.Top)
 try:
  x.TextFrame2.AutoSize=MSO_NONE;x.Width=w;x.Height=h;x.TextFrame2.TextRange.Text=text;x.TextFrame2.TextRange.Font.Size=BODY_SIZE;x.TextFrame2.AutoSize=MSO_FIT
  return float(x.Height)<=h+2
 finally:
  x.TextFrame2.AutoSize=MSO_NONE;x.Left=l;x.Top=t;x.Width=w;x.Height=h;x.TextFrame2.TextRange.Text=old

def pages(x,paras):
 out=[];cur=[]
 for p in paras:
  if cur and not fits(x,cur+[p]):out.append(cur);cur=[p]
  else:cur.append(p)
 if cur:out.append(cur)
 return out or [[]]

def update_date(ws,date):
 for i in range(1,ws.Shapes.Count+1):
  x=ws.Shapes(i)
  try:
   if x.Name.casefold()=='txtdate' and '2023' not in str(x.TextFrame2.TextRange.Text):x.TextFrame2.TextRange.Text=date
  except Exception:pass

def clear_fixed(ws):
 try:ws.Range('B67:N83').ClearContents()
 except Exception:pass

def copy_page(wb,source,before,name):
 source.Copy(Before=before); ws=wb.Worksheets(before.Index-1)
 base=name;i=2;used={wb.Worksheets(j).Name for j in range(1,wb.Worksheets.Count+1)}
 while name in used:name=f'{base} {i}';i+=1
 ws.Name=name;clear_fixed(ws);return ws

def borders(rng):
 # Minimal, light table grid: continuous hairline-style borders in light gray.
 # Excel's Weight=1 is xlHairline. RGB(217,217,217) is passed as BGR integer.
 light_gray=0xD9D9D9
 for edge in (7,8,9,10,11,12):
  try:
   b=rng.Borders(edge)
   b.LineStyle=1
   b.Color=light_gray
   b.Weight=1
  except Exception:
   pass

def compact_cell_alignment(cell, center=False):
 # Excel worksheet cells have no true internal margin property. Zero indent and
 # top alignment provide the minimum native cell padding without text boxes.
 cell.WrapText=True
 cell.ShrinkToFit=False
 cell.IndentLevel=0
 cell.VerticalAlignment=-4160  # xlTop
 cell.HorizontalAlignment=-4108 if center else -4131  # center / left
 try:cell.ReadingOrder=-5002  # xlContext
 except Exception:pass

def write_cell(cell,p,size=8):
 cell.Value=p.text;compact_cell_alignment(cell,False);fmt(cell,size)
 pos=0
 for r in p.runs:
  if r.text:
   try:fmt(cell.Characters(Start=pos+1,Length=len(r.text)),size,r.bold,r.italic,r.underline)
   except Exception:pass
   pos+=len(r.text)

def unmerge_intersecting(ws, address):
    """Unmerge cells in a target range without using unsupported MergeAreas."""
    target = ws.Range(address)
    try:
        # Range.UnMerge is supported by Excel COM and safely unmerges merged
        # cells contained in or intersecting the selected table area.
        target.UnMerge()
        return
    except Exception:
        pass

    # Compatibility fallback: inspect each cell's single MergeArea. Excel COM
    # exposes MergeArea (singular), not a MergeAreas collection on Range.
    seen = set()
    for row in range(1, target.Rows.Count + 1):
        for column in range(1, target.Columns.Count + 1):
            try:
                cell = target.Cells(row, column)
                if bool(cell.MergeCells):
                    area = cell.MergeArea
                    key = str(area.Address)
                    if key not in seen:
                        seen.add(key)
                        area.UnMerge()
            except Exception:
                pass

def merge_value(ws,address,value,font_size=11,bold=False,center=False,fill=None,color=None):
 r=ws.Range(address);r.Merge();r.Value=value;r.WrapText=True;r.VerticalAlignment=-4108
 r.HorizontalAlignment=-4108 if center else -4131
 r.Font.Name='Source Sans Pro';r.Font.Size=font_size;r.Font.Bold=bold
 r.IndentLevel=0;r.ShrinkToFit=False
 if fill is not None:r.Interior.Color=fill
 if color is not None:r.Font.Color=color
 borders(r);return r

def estimate_row_span(row):
 """Estimate fixed Excel rows needed without resizing any worksheet row."""
 # Approximate Source Sans Pro 11 wrapping for the fixed Excel column groups.
 capacities=(25,24,23,13,14,12,13)
 line_counts=[]
 for i,cell in enumerate(row):
  cap=capacities[i] if i<len(capacities) else 13
  lines=0
  for part in (cell.text or '').split('\n'):
   lines+=max(1,(len(part)+cap-1)//cap)
  line_counts.append(lines)
 # Existing rows are about 16.5 points. One text line needs about one row.
 return max(4,max(line_counts,default=1)+1)

def split_table_pages(body_rows,capacity=51):
 """Split complete Word rows across sheets; never enlarge the page boundary."""
 pages=[];current=[];used=0
 for row in body_rows:
  span=min(capacity,estimate_row_span(row))
  if current and used+span>capacity:
   pages.append(current);current=[];used=0
  current.append((row,span));used+=span
 if current:pages.append(current)
 return pages or [[]]

def prepare_table_page(ws,placeholder):
 try:placeholder.Delete()
 except Exception:pass
 unmerge_intersecting(ws,'B6:N65')
 ws.Range('B6:N65').Clear()
 # Match the commentary-page top spacing exactly:
 # rows 6-7 blank, a thin green separator on row 8, rows 9-10 blank,
 # caption on row 11, header on rows 12-14, and data from row 15.
 # Row 66 remains the single blank row above final-page fixed content.
 ws.Range('B6:N10').ClearContents()
 ws.Range('B66:N66').ClearContents()

 # Recreate the same thin green horizontal separator visible on commentary pages.
 separator=ws.Range('B8:N8')
 for edge in (8,):  # xlEdgeBottom
  try:
   line=separator.Borders(edge)
   line.LineStyle=1
   line.Color=0x70AD47  # subtle green
   line.Weight=1       # xlHairline
  except Exception:
   pass

 cap=ws.Range('B11:N11');cap.Merge()
 cap.Value='A consolidated view of the ULIP funds and their risk-return characteristics:'
 cap.Font.Name='Source Sans Pro';cap.Font.Size=11;cap.Font.Bold=True
 cap.HorizontalAlignment=-4131;cap.VerticalAlignment=-4108
 cap.IndentLevel=0;cap.ShrinkToFit=False

 purple=0x400040;white=0xFFFFFF
 merge_value(ws,'B12:C14','Fund Category',11,True,True,purple,white)
 merge_value(ws,'D12:E14','Category positioning',11,True,True,purple,white)
 merge_value(ws,'F12:G14','For whom they may be\nsuitable?',11,True,True,purple,white)
 merge_value(ws,'H12:L12','Equity',11,True,True,purple,white)
 merge_value(ws,'H13:I14','Allocation\n(Max)',11,True,True,purple,white)
 merge_value(ws,'J13:K14','Market\nCap',11,True,True,purple,white)
 merge_value(ws,'L13:L14','Themes/\nSectors',11,True,True,purple,white)
 merge_value(ws,'M12:N14','Risk',11,True,True,purple,white)
 borders(ws.Range('B12:N14'))

def native_table_page(ws,placeholder,page_rows):
 """Build one fixed-boundary table page matching the commentary-page top spacing."""
 prepare_table_page(ws,placeholder)
 logical=((2,3),(4,5),(6,7),(8,9),(10,11),(12,12),(13,14))
 top=15
 for index,(row,requested_span) in enumerate(page_rows):
  remaining=65-top+1
  if remaining<=0:break
  span=min(requested_span,remaining)
  bottom=64 if index==len(page_rows)-1 else top+span-1
  for ci,(lc,rc) in enumerate(logical):
   rg=ws.Range(ws.Cells(top,lc),ws.Cells(bottom,rc));rg.Merge()
   para=row[ci] if ci<len(row) else Para([Run('')])
   cell=rg.Cells(1,1);write_cell(cell,para,11)
   cell.Font.Name='Source Sans Pro';cell.Font.Size=11
   # Minimum native cell margin: zero indent, no shrink-to-fit, and top
   # alignment. Short value columns remain centered horizontally.
   compact_cell_alignment(rg,ci>=3)
   borders(rg)
  borders(ws.Range(ws.Cells(top,2),ws.Cells(bottom,14)))
  top=bottom+1
 ws.Range('B12:N65').Font.Name='Source Sans Pro';ws.Range('B12:N65').Font.Size=11;ws.Range('B12:N65').WrapText=True

def unique_name(wb,base):
 used={str(wb.Worksheets(i).Name) for i in range(1,wb.Worksheets.Count+1)};name=base;n=2
 while name in used:name=f'{base} {n}';n+=1
 return name

def duplicate_table_page(wb,source,before,page_number):
 source.Copy(Before=before)
 ws=wb.Worksheets(before.Index-1);ws.Name=unique_name(wb,f'Market commentary (3) Page {page_number}')
 # Fixed funds-managed and footnote blocks are only allowed on the last page.
 try:ws.Range('B67:N83').ClearContents()
 except Exception:pass
 return ws

def output_path(template,folder,date):
 d=re.sub(r'[<>:"/\\|?*]','-',date).strip('. ') or 'Completed';p=folder/f'{template.stem}_{d}.xlsx'
 return folder/f'{template.stem}_{d}_Output.xlsx' if p.resolve()==template.resolve() else p

def automate(word_file,template,folder,log):
 if win32 is None:raise RuntimeError('Install pywin32: py -m pip install pywin32')
 word_file=word_file.resolve();template=template.resolve();folder=folder.resolve();folder.mkdir(parents=True,exist_ok=True)
 log('Reading the Word table...');data=extract(word_file);out=output_path(template,folder,data.date)
 if out.exists():
  try:out.unlink()
  except PermissionError:raise PermissionError(f'Close the existing output workbook:\n{out}')
 shutil.copy2(template,out);pythoncom.CoInitialize();excel=wb=None
 try:
  log('Opening the Excel template...');excel=win32.DispatchEx('Excel.Application');excel.Visible=False;excel.DisplayAlerts=False;excel.ScreenUpdating=False
  wb=excel.Workbooks.Open(str(out),UpdateLinks=0,ReadOnly=False)
  final_ws=wb.Worksheets(FINAL)
  body=data.table[1:] if len(data.table)>1 else []
  table_pages=split_table_pages(body,51)
  log(f'Creating the table across {len(table_pages)} fixed-size sheet(s)...')
  created=[]
  # Continuation sheets are exact duplicates of sheet 3 and are inserted before
  # the original final sheet. No page size, print area, rows, or columns change.
  for page_number,page_rows in enumerate(table_pages[:-1],1):
   ws=duplicate_table_page(wb,final_ws,final_ws,page_number)
   native_table_page(ws,shape(ws,SHAPES[FINAL]),page_rows);update_date(ws,data.date);created.append(ws)
  native_table_page(final_ws,shape(final_ws,SHAPES[FINAL]),table_pages[-1]);update_date(final_ws,data.date)
  # Original sheet 3 remains last and retains the fixed funds-managed block.
  wb.Save();log(f'Completed: {out}');return out
 except Exception:
  try:
   if wb:wb.Close(SaveChanges=False)
  except Exception:pass
  try:out.unlink(missing_ok=True)
  except Exception:pass
  raise
 finally:
  try:
   if wb:wb.Close(SaveChanges=True)
  except Exception:pass
  try:
   if excel:excel.Quit()
  except Exception:pass
  pythoncom.CoUninitialize()

class Worker(QThread):
 log_message=pyqtSignal(str);completed=pyqtSignal(str);failed=pyqtSignal(str)
 def __init__(self,w,t,o):super().__init__();self.w=Path(w);self.t=Path(t);self.o=Path(o)
 def run(self):
  try:self.completed.emit(str(automate(self.w,self.t,self.o,self.log_message.emit)))
  except Exception as e:self.failed.emit(f'{e}\n\n{traceback.format_exc()}')
class Window(QMainWindow):
 def __init__(self):
  super().__init__();self.setWindowTitle('Monthly Commentary to Market Review');self.resize(820,500);self.worker=None;root=QWidget();lay=QVBoxLayout(root);lay.addWidget(QLabel('Select the Word commentary, manual Excel template, and output folder.'));form=QFormLayout();self.w=QLineEdit();self.t=QLineEdit();self.o=QLineEdit();form.addRow('Word commentary:',self.pickrow(self.w,self.pickword));form.addRow('Manual Excel template:',self.pickrow(self.t,self.pickexcel));form.addRow('Output folder:',self.pickrow(self.o,self.pickfolder));lay.addLayout(form);self.go=QPushButton('Generate Market Review');self.go.clicked.connect(self.start);lay.addWidget(self.go);self.log=QPlainTextEdit();self.log.setReadOnly(True);lay.addWidget(self.log);self.setCentralWidget(root)
 def pickrow(self,e,fn):
  w=QWidget();l=QHBoxLayout(w);l.setContentsMargins(0,0,0,0);l.addWidget(e);b=QPushButton('Browse...');b.clicked.connect(fn);l.addWidget(b);return w
 def pickword(self):
  p,_=QFileDialog.getOpenFileName(self,'Word','','Word (*.docx)');self.w.setText(p or self.w.text())
 def pickexcel(self):
  p,_=QFileDialog.getOpenFileName(self,'Excel','','Excel (*.xlsx)');self.t.setText(p or self.t.text())
 def pickfolder(self):
  p=QFileDialog.getExistingDirectory(self,'Output folder');self.o.setText(p or self.o.text())
 def start(self):
  vals=[self.w.text().strip(),self.t.text().strip(),self.o.text().strip()]
  if not all(vals):QMessageBox.warning(self,'Missing','Select all three paths.');return
  if not Path(vals[0]).is_file() or not Path(vals[1]).is_file():QMessageBox.warning(self,'Invalid','Input file not found.');return
  self.log.clear();self.go.setEnabled(False);self.worker=Worker(*vals);self.worker.log_message.connect(self.log.appendPlainText);self.worker.completed.connect(self.done);self.worker.failed.connect(self.error);self.worker.start()
 def done(self,p):self.go.setEnabled(True);self.log.appendPlainText('\n'+p);QMessageBox.information(self,'Completed',p)
 def error(self,e):self.go.setEnabled(True);self.log.appendPlainText('\nERROR\n'+e);QMessageBox.critical(self,'Error',e.split('\n\n')[0])
if __name__=='__main__':
 app=QApplication(sys.argv);w=Window();w.show();raise SystemExit(app.exec())
