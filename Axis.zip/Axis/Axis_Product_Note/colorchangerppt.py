import colorsys
import os
import shutil
import sys
import tempfile
import traceback
import zipfile
from pathlib import Path

from lxml import etree
from PyQt6.QtCore import QObject, QThread, Qt, pyqtSignal
from PyQt6.QtWidgets import (
    QApplication, QFileDialog, QHBoxLayout, QLabel, QLineEdit, QMainWindow,
    QMessageBox, QProgressBar, QPushButton, QTextEdit, QVBoxLayout, QWidget,
)

APP_TITLE = "PowerPoint Color Normalizer - PerformanceTable"
A_NS = "http://schemas.openxmlformats.org/drawingml/2006/main"
P_NS = "http://schemas.openxmlformats.org/presentationml/2006/main"
NS = {"a": A_NS}
COLOR_TAGS = {
    f"{{{A_NS}}}srgbClr", f"{{{A_NS}}}scrgbClr",
    f"{{{A_NS}}}schemeClr", f"{{{A_NS}}}sysClr",
    f"{{{A_NS}}}prstClr",
}

BLACK = (0, 0, 0)
LIGHT_GREY = (230, 230, 230)
DARK_GREY = (200, 200, 200)
MAROON = (151, 27, 78)
PERFORMANCE_TABLE_NAME = "PerformanceTable"
PERFORMANCE_TABLE_ALIASES = {"performancetable", "performanetable"}

# Never change these colors anywhere in the presentation.
PROTECTED_COLORS = {
    (244, 81, 30),
    (112, 48, 160),
    (0, 98, 79),
}

EXACT_MAP = {
    (191, 191, 191): LIGHT_GREY,
    (35, 31, 32): BLACK,
    (151, 28, 79): MAROON,
    (164, 163, 164): LIGHT_GREY,
    (90, 90, 93): DARK_GREY,
    (108, 105, 105): LIGHT_GREY,
    (128, 130, 133): LIGHT_GREY,
    (88, 89, 91): DARK_GREY,
    (75, 23, 38): MAROON,
    (237, 25, 102): MAROON,
    (177, 180, 182): LIGHT_GREY,
    (184, 186, 188): LIGHT_GREY,
    (235, 30, 103): MAROON,
    (230, 231, 232): LIGHT_GREY,
    (151, 20, 76): MAROON,
    (188, 190, 192): LIGHT_GREY,
    (161, 163, 166): DARK_GREY,
    (236, 28, 102): MAROON,
}

DEFAULT_THEME = {
    "dk1": (0, 0, 0), "lt1": (255, 255, 255),
    "dk2": (31, 73, 125), "lt2": (238, 236, 225),
    "accent1": (79, 129, 189), "accent2": (192, 80, 77),
    "accent3": (155, 187, 89), "accent4": (128, 100, 162),
    "accent5": (75, 172, 198), "accent6": (247, 150, 70),
    "hlink": (0, 0, 255), "folHlink": (128, 0, 128),
}
ALIASES = {"tx1": "dk1", "bg1": "lt1", "tx2": "dk2", "bg2": "lt2", "phClr": "dk1"}
PRESET = {
    "black": BLACK, "white": (255, 255, 255), "gray": (128, 128, 128),
    "grey": (128, 128, 128), "darkGray": (169, 169, 169),
    "lightGray": (211, 211, 211), "maroon": (128, 0, 0),
    "red": (255, 0, 0), "silver": (192, 192, 192),
    "purple": (128, 0, 128), "fuchsia": (255, 0, 255),
}


def clamp(value):
    return max(0, min(255, int(round(value))))


def rgb_hex(rgb):
    return "".join(f"{value:02X}" for value in rgb)


def hex_rgb(value):
    if not value:
        return None
    value = value.strip().replace("#", "")[-6:]
    if len(value) != 6:
        return None
    try:
        return tuple(int(value[i:i + 2], 16) for i in (0, 2, 4))
    except ValueError:
        return None


def apply_transforms(rgb, node):
    r, g, b = map(float, rgb)
    for child in node:
        name = etree.QName(child).localname
        try:
            ratio = int(child.get("val")) / 100000.0
        except (TypeError, ValueError):
            continue
        if name == "tint":
            r, g, b = r + (255-r)*ratio, g + (255-g)*ratio, b + (255-b)*ratio
        elif name in ("shade", "lumMod"):
            r, g, b = r*ratio, g*ratio, b*ratio
        elif name == "lumOff":
            r, g, b = r+255*ratio, g+255*ratio, b+255*ratio
        elif name == "redMod": r *= ratio
        elif name == "greenMod": g *= ratio
        elif name == "blueMod": b *= ratio
        elif name == "redOff": r += 255*ratio
        elif name == "greenOff": g += 255*ratio
        elif name == "blueOff": b += 255*ratio
        elif name in ("comp", "inv"):
            r, g, b = 255-r, 255-g, 255-b
        elif name == "gray":
            r = g = b = 0.299*r + 0.587*g + 0.114*b
    return clamp(r), clamp(g), clamp(b)


def read_theme(folder):
    result = dict(DEFAULT_THEME)
    theme_files = sorted((Path(folder) / "ppt" / "theme").glob("theme*.xml"))
    if not theme_files:
        return result
    try:
        tree = etree.parse(str(theme_files[0]), etree.XMLParser(recover=True, huge_tree=True))
        schemes = tree.xpath(".//a:themeElements/a:clrScheme", namespaces=NS)
        if schemes:
            for entry in schemes[0]:
                if not len(entry):
                    continue
                name = etree.QName(entry).localname
                color_node = entry[0]
                rgb = hex_rgb(color_node.get("val")) or hex_rgb(color_node.get("lastClr"))
                if rgb:
                    result[name] = rgb
    except Exception:
        pass
    return result


def resolve_color(node, theme):
    kind = etree.QName(node).localname
    rgb = None
    if kind == "srgbClr":
        rgb = hex_rgb(node.get("val"))
    elif kind == "scrgbClr":
        try:
            rgb = tuple(clamp(255 * int(node.get(channel, "0")) / 100000) for channel in "rgb")
        except ValueError:
            pass
    elif kind == "schemeClr":
        key = node.get("val", "")
        rgb = theme.get(ALIASES.get(key, key))
    elif kind == "sysClr":
        rgb = hex_rgb(node.get("lastClr")) or PRESET.get(node.get("val", ""))
    elif kind == "prstClr":
        rgb = PRESET.get(node.get("val", ""))
    return apply_transforms(rgb, node) if rgb else None


def replace_color_node(node, target_rgb):
    node.tag = f"{{{A_NS}}}srgbClr"
    node.attrib.clear()
    node.set("val", rgb_hex(target_rgb))
    for child in list(node):
        node.remove(child)


def is_inside_picture(node):
    current = node
    while current is not None:
        if current.tag == f"{{{P_NS}}}pic":
            return True
        current = current.getparent()
    return False


def containing_graphic_frame(node):
    current = node
    while current is not None:
        if etree.QName(current).localname == "graphicFrame":
            return current
        current = current.getparent()
    return None


def object_name_from_frame(frame):
    if frame is None:
        return ""
    candidates = frame.xpath('.//*[local-name()="cNvPr"]')
    if not candidates:
        return ""
    return candidates[0].get("name", "")


def is_performance_table(node):
    frame = containing_graphic_frame(node)
    name = object_name_from_frame(frame)
    normalized = "".join(name.lower().split())
    return any(alias == normalized or alias in normalized for alias in PERFORMANCE_TABLE_ALIASES)


def nearest_property(node):
    current = node.getparent()
    while current is not None:
        name = etree.QName(current).localname
        if name in {"solidFill", "gs", "ln", "lnL", "lnR", "lnT", "lnB", "lnTlToBr", "lnBlToTr",
                    "rPr", "defRPr", "endParaRPr", "tcPr", "bgPr", "outerShdw", "innerShdw", "glow"}:
            return name
        current = current.getparent()
    return "color"


def is_table_border(node):
    current = node.getparent()
    border_tags = {"ln", "lnL", "lnR", "lnT", "lnB", "lnTlToBr", "lnBlToTr"}
    while current is not None:
        if etree.QName(current).localname in border_tags:
            return True
        if etree.QName(current).localname in {"tc", "tbl", "graphicFrame"}:
            # Continue until graphicFrame so line elements can be found.
            pass
        current = current.getparent()
    return False


def is_table_fill(node):
    current = node.getparent()
    found_fill = False
    while current is not None:
        name = etree.QName(current).localname
        if name in {"solidFill", "gs"}:
            found_fill = True
        if name in {"ln", "lnL", "lnR", "lnT", "lnB", "lnTlToBr", "lnBlToTr"}:
            return False
        if name == "tcPr":
            return found_fill
        current = current.getparent()
    return False


def neutral(rgb, tolerance=22):
    return max(rgb) - min(rgb) <= tolerance


def performance_table_target(node, old_rgb):
    """Choose the correct PerformanceTable palette with light-grey borders.

    The supplied source shades are honored first. In particular, RGB
    191,191,191 is a LIGHT header shade, not a dark shade. This prevents the
    top header band from becoming too dark. White body cells and table text
    remain unchanged.
    """
    if not is_performance_table(node):
        return None
    if not neutral(old_rgb):
        return None

    luminance = 0.2126*old_rgb[0] + 0.7152*old_rgb[1] + 0.0722*old_rgb[2]

    # Explicit PerformanceTable shade roles based on the supplied design.
    table_light_shades = {
        (191, 191, 191),
        (164, 163, 164),
        (108, 105, 105),
        (128, 130, 133),
        (177, 180, 182),
        (184, 186, 188),
        (230, 231, 232),
        (188, 190, 192),
    }
    table_dark_shades = {
        (90, 90, 93),
        (88, 89, 91),
        (161, 163, 166),
    }

    if is_table_border(node):
        # Every border in PerformanceTable uses the requested light grey.
        # This includes outer borders, inner grid lines and diagonal cell lines.
        return LIGHT_GREY

    if is_table_fill(node):
        # Preserve white body cells. Header shades follow the supplied roles.
        if luminance >= 245:
            return None
        if old_rgb in table_light_shades:
            return LIGHT_GREY
        if old_rgb in table_dark_shades:
            return DARK_GREY
        return DARK_GREY if luminance < 175 else LIGHT_GREY

    # Table text and other table properties are preserved.
    return None


def classify_general(rgb):
    if rgb in PROTECTED_COLORS:
        return None
    if rgb in EXACT_MAP:
        return EXACT_MAP[rgb]

    r, g, b = rgb
    spread = max(rgb) - min(rgb)
    luminance = 0.2126*r + 0.7152*g + 0.0722*b
    hue, saturation, _ = colorsys.rgb_to_hsv(r/255, g/255, b/255)
    hue *= 360

    if spread <= 18 or saturation <= 0.10:
        if luminance <= 50:
            return BLACK
        if luminance >= 245:
            return None
        if luminance >= 150:
            return LIGHT_GREY
        return DARK_GREY

    if saturation >= 0.28 and r >= g*1.25 and r >= b*1.10 and (hue <= 25 or hue >= 325):
        return MAROON
    return None


def processable_xml(relative_path):
    path = relative_path.replace("\\", "/")
    return path.startswith("ppt/") and path.endswith(".xml") and not path.startswith("ppt/theme/")


def make_index_path(node):
    indexes = []
    current = node
    while current.getparent() is not None:
        parent = current.getparent()
        indexes.append(parent.index(current))
        current = parent
    indexes.reverse()
    return "/".join(str(index) for index in indexes)


def find_by_index_path(root, path):
    current = root
    if not path:
        return current
    for part in path.split("/"):
        if not part:
            continue
        index = int(part)
        if index < 0 or index >= len(current):
            return None
        current = current[index]
    return current


def describe_color(rgb):
    if rgb in PROTECTED_COLORS:
        return "Protected color"
    r, g, b = rgb
    spread = max(rgb) - min(rgb)
    luminance = 0.2126*r + 0.7152*g + 0.0722*b
    hue, saturation, _ = colorsys.rgb_to_hsv(r/255, g/255, b/255)
    hue *= 360
    if luminance >= 245 and spread <= 15: return "White / near-white"
    if luminance <= 45 and spread <= 20: return "Black / near-black"
    if spread <= 18 or saturation <= .10:
        if luminance >= 190: return "Light neutral grey"
        if luminance >= 115: return "Medium neutral grey"
        return "Dark neutral grey"
    if hue < 15 or hue >= 345: return "Red"
    if hue < 35: return "Orange"
    if hue < 65: return "Yellow"
    if hue < 90: return "Yellow-green"
    if hue < 155: return "Green"
    if hue < 190: return "Teal / cyan"
    if hue < 250: return "Blue"
    if hue < 285: return "Violet"
    if hue < 325: return "Purple / magenta"
    return "Pink / maroon"


def get_object_details(node, relative):
    frame = containing_graphic_frame(node)
    table_name = object_name_from_frame(frame)
    owners = {"sp", "cxnSp", "graphicFrame", "grpSp", "shape", "wsp", "ser", "dPt",
              "legend", "title", "plotArea", "txBody", "tbl", "tr", "tc", "marker", "dataLbl"}
    owner = None
    current = node.getparent()
    while current is not None:
        if etree.QName(current).localname in owners:
            owner = current
            break
        current = current.getparent()
    object_type = etree.QName(owner).localname if owner is not None else Path(relative).parent.name
    object_name = table_name or "Unnamed object"
    text_preview = ""
    if owner is not None:
        names = owner.xpath('.//*[local-name()="cNvPr"]')
        if names and not table_name:
            object_name = names[0].get("name", object_name)
        texts = owner.xpath('.//*[local-name()="t"]/text()')
        if texts:
            text_preview = " ".join(str(t).strip() for t in texts if str(t).strip())[:100]
    return object_type, object_name, nearest_property(node), text_preview


def auto_target(node, old_rgb):
    if old_rgb in PROTECTED_COLORS:
        return None, "Protected; never changed"
    if is_performance_table(node):
        target = performance_table_target(node, old_rgb)
        if target is not None:
            return target, "PerformanceTable fill rule / light-grey border rule"
        return None, "PerformanceTable color preserved"
    target = classify_general(old_rgb)
    if target is None:
        return None, describe_color(old_rgb) + " preserved"
    if old_rgb in EXACT_MAP:
        return target, "Exact supplied mapping"
    return target, "Automatic color-family mapping"


class Engine:
    def __init__(self, progress, log):
        self.progress = progress
        self.log = log

    def scan(self, source):
        folder = tempfile.mkdtemp(prefix="ppt_scan_")
        records = []
        try:
            with zipfile.ZipFile(source, "r") as archive:
                archive.extractall(folder)
            theme = read_theme(folder)
            files = []
            for path in Path(folder).rglob("*.xml"):
                relative = str(path.relative_to(folder)).replace("\\", "/")
                if processable_xml(relative):
                    files.append((path, relative))
            files.sort(key=lambda item: item[1])
            for index, (path, relative) in enumerate(files, 1):
                try:
                    tree = etree.parse(str(path), etree.XMLParser(recover=True, huge_tree=True))
                    for node in tree.getroot().iter():
                        if node.tag not in COLOR_TAGS or is_inside_picture(node):
                            continue
                        old_rgb = resolve_color(node, theme)
                        if old_rgb is None:
                            continue
                        obj_type, obj_name, prop, text = get_object_details(node, relative)
                        target, reason = auto_target(node, old_rgb)
                        records.append({
                            "locator": relative + "||" + make_index_path(node),
                            "file": relative,
                            "type": obj_type,
                            "name": obj_name,
                            "text": text,
                            "property": prop,
                            "old": old_rgb,
                            "category": describe_color(old_rgb),
                            "target": target,
                            "reason": reason,
                            "protected": old_rgb in PROTECTED_COLORS,
                            "performance_table": is_performance_table(node),
                        })
                except Exception as error:
                    self.log.emit(f"Skipped {relative}: {error}")
                self.progress.emit(int(index / max(1, len(files)) * 100))
            return records
        finally:
            shutil.rmtree(folder, ignore_errors=True)

    def replace(self, source, output, mapping):
        folder = tempfile.mkdtemp(prefix="ppt_replace_")
        changed = 0
        protected_skipped = 0
        try:
            with zipfile.ZipFile(source, "r") as archive:
                archive.extractall(folder)
            theme = read_theme(folder)
            grouped = {}
            for locator, target in mapping.items():
                relative, index_path = locator.split("||", 1)
                grouped.setdefault(relative, []).append((index_path, target))
            for file_index, (relative, selections) in enumerate(sorted(grouped.items()), 1):
                path = Path(folder) / relative
                tree = etree.parse(str(path), etree.XMLParser(remove_blank_text=False, recover=True, huge_tree=True))
                dirty = False
                for index_path, target in selections:
                    node = find_by_index_path(tree.getroot(), index_path)
                    if node is None or node.tag not in COLOR_TAGS or is_inside_picture(node):
                        continue
                    current_rgb = resolve_color(node, theme)
                    if current_rgb in PROTECTED_COLORS:
                        protected_skipped += 1
                        continue
                    replace_color_node(node, target)
                    changed += 1
                    dirty = True
                if dirty:
                    tree.write(str(path), xml_declaration=True, encoding="UTF-8", standalone=True)
                self.progress.emit(int(file_index / max(1, len(grouped)) * 90))
            if os.path.exists(output):
                os.remove(output)
            with zipfile.ZipFile(output, "w", zipfile.ZIP_DEFLATED, compresslevel=6) as archive:
                for path in Path(folder).rglob("*"):
                    if path.is_file():
                        archive.write(path, str(path.relative_to(folder)).replace("\\", "/"))
            with zipfile.ZipFile(output, "r") as archive:
                bad = archive.testzip()
                if bad:
                    raise ValueError(f"Corrupt generated PPTX entry: {bad}")
            self.progress.emit(100)
            return {"changed": changed, "protected_skipped": protected_skipped}
        finally:
            shutil.rmtree(folder, ignore_errors=True)


class Worker(QObject):
    progress = pyqtSignal(int)
    log = pyqtSignal(str)
    done = pyqtSignal(object)
    failed = pyqtSignal(str)

    def __init__(self, mode, source, output=None, mapping=None):
        super().__init__()
        self.mode = mode
        self.source = source
        self.output = output
        self.mapping = mapping or {}

    def run(self):
        try:
            engine = Engine(self.progress, self.log)
            if self.mode == "scan":
                result = engine.scan(self.source)
            else:
                result = engine.replace(self.source, self.output, self.mapping)
            self.done.emit(result)
        except Exception:
            self.failed.emit(traceback.format_exc())


class MainWindow(QMainWindow):
    PAGE_SIZE = 200

    def __init__(self):
        super().__init__()
        self.thread = None
        self.worker = None
        self.records = []
        self.selections = {}
        self.page = 0
        self.setWindowTitle(APP_TITLE)
        self.resize(1500, 820)

        root = QWidget()
        self.setCentralWidget(root)
        layout = QVBoxLayout(root)
        title = QLabel("Scan, detect, auto-assign and replace PowerPoint colors")
        title.setStyleSheet("font-size: 21px; font-weight: 700;")
        info = QLabel(
            "Every explicit color declaration is listed. PerformanceTable fills and borders use the dedicated "
            "dark/light grey rule. Protected RGB values 244,81,30; 112,48,160; and 0,98,79 cannot be changed."
        )
        info.setWordWrap(True)
        layout.addWidget(title)
        layout.addWidget(info)

        row = QHBoxLayout()
        self.input_edit = QLineEdit()
        button = QPushButton("Input PPTX")
        button.clicked.connect(self.pick_input)
        row.addWidget(self.input_edit)
        row.addWidget(button)
        layout.addLayout(row)

        row = QHBoxLayout()
        self.output_edit = QLineEdit()
        button = QPushButton("Output PPTX")
        button.clicked.connect(self.pick_output)
        row.addWidget(self.output_edit)
        row.addWidget(button)
        layout.addLayout(row)

        buttons = QHBoxLayout()
        self.scan_button = QPushButton("1. Scan every object")
        self.scan_button.clicked.connect(self.scan)
        self.auto_button = QPushButton("2. Auto assign colors")
        self.auto_button.clicked.connect(self.auto_assign)
        self.auto_button.setEnabled(False)
        self.replace_button = QPushButton("3. Replace selected colors")
        self.replace_button.clicked.connect(self.replace)
        self.replace_button.setEnabled(False)
        buttons.addWidget(self.scan_button)
        buttons.addWidget(self.auto_button)
        buttons.addWidget(self.replace_button)
        layout.addLayout(buttons)

        from PyQt6.QtWidgets import QTableWidget, QTableWidgetItem, QComboBox, QHeaderView
        self.QTableWidgetItem = QTableWidgetItem
        self.QComboBox = QComboBox
        self.table = QTableWidget(0, 11)
        self.table.setHorizontalHeaderLabels([
            "Change", "File/slide", "Object type", "Object name", "Text preview",
            "Property", "Old RGB", "Detected category", "Rule", "Replace with", "New RGB"
        ])
        self.table.horizontalHeader().setSectionResizeMode(QHeaderView.ResizeMode.Interactive)
        self.table.horizontalHeader().setSectionResizeMode(4, QHeaderView.ResizeMode.Stretch)
        widths = (65, 175, 85, 150, 250, 105, 110, 145, 190, 180, 110)
        for column, width in enumerate(widths):
            self.table.setColumnWidth(column, width)
        layout.addWidget(self.table)

        pager = QHBoxLayout()
        self.previous_button = QPushButton("Previous")
        self.previous_button.clicked.connect(self.previous_page)
        self.page_label = QLabel("Page 0 of 0")
        self.next_button = QPushButton("Next")
        self.next_button.clicked.connect(self.next_page)
        pager.addStretch()
        pager.addWidget(self.previous_button)
        pager.addWidget(self.page_label)
        pager.addWidget(self.next_button)
        pager.addStretch()
        layout.addLayout(pager)

        self.progress = QProgressBar()
        layout.addWidget(self.progress)
        self.log_box = QTextEdit()
        self.log_box.setReadOnly(True)
        self.log_box.setMaximumHeight(90)
        layout.addWidget(self.log_box)

    def pick_input(self):
        path, _ = QFileDialog.getOpenFileName(self, "Select input PPTX", "", "PowerPoint (*.pptx)")
        if path:
            self.input_edit.setText(path)
            source = Path(path)
            self.output_edit.setText(str(source.with_name(source.stem + "_normalized.pptx")))

    def pick_output(self):
        path, _ = QFileDialog.getSaveFileName(self, "Select output PPTX", self.output_edit.text(), "PowerPoint (*.pptx)")
        if path:
            self.output_edit.setText(path if path.lower().endswith(".pptx") else path + ".pptx")

    def valid_input(self):
        source = self.input_edit.text().strip()
        if not os.path.isfile(source) or not zipfile.is_zipfile(source):
            QMessageBox.warning(self, "Invalid input", "Select a valid PPTX file.")
            return False
        return True

    def start_worker(self, mode, output=None, mapping=None):
        self.scan_button.setEnabled(False)
        self.auto_button.setEnabled(False)
        self.replace_button.setEnabled(False)
        self.progress.setValue(0)
        self.thread = QThread(self)
        self.worker = Worker(mode, self.input_edit.text().strip(), output, mapping)
        self.worker.moveToThread(self.thread)
        self.thread.started.connect(self.worker.run)
        self.worker.progress.connect(self.progress.setValue)
        self.worker.log.connect(self.log_box.append)
        self.worker.done.connect(lambda result: self.finished(mode, result))
        self.worker.failed.connect(self.failed)
        self.worker.done.connect(self.thread.quit)
        self.worker.failed.connect(self.thread.quit)
        self.thread.finished.connect(self.worker.deleteLater)
        self.thread.finished.connect(self.thread.deleteLater)
        self.thread.start()

    def scan(self):
        if self.valid_input():
            self.log_box.clear()
            self.start_worker("scan")

    def finished(self, mode, result):
        self.scan_button.setEnabled(True)
        if mode == "scan":
            self.records = result
            self.selections = {}
            self.page = 0
            self.render_page()
            self.auto_button.setEnabled(bool(result))
            self.replace_button.setEnabled(bool(result))
            table_count = sum(1 for item in result if item["performance_table"])
            QMessageBox.information(
                self, "Scan complete",
                f"Detected {len(result)} individual color declarations.\n"
                f"PerformanceTable declarations: {table_count}.\n\n"
                "Click Auto assign colors, review the Replace with column, then replace selected colors."
            )
        else:
            self.auto_button.setEnabled(bool(self.records))
            self.replace_button.setEnabled(bool(self.records))
            QMessageBox.information(
                self, "Completed",
                f"Changed {result['changed']} selected color declarations.\n"
                f"Protected declarations skipped: {result['protected_skipped']}.\n\n"
                f"Saved to:\n{self.output_edit.text()}"
            )

    def save_visible_page(self):
        for row in range(self.table.rowCount()):
            check = self.table.item(row, 0)
            locator = check.data(Qt.ItemDataRole.UserRole)
            record = next((item for item in self.records if item["locator"] == locator), None)
            if record and record["protected"]:
                self.selections.pop(locator, None)
                continue
            target_item = self.table.item(row, 10)
            if check.checkState() == Qt.CheckState.Checked and target_item and target_item.text().strip():
                self.selections[locator] = tuple(int(x.strip()) for x in target_item.text().split(","))
            else:
                self.selections.pop(locator, None)

    def auto_assign(self):
        self.save_visible_page()
        self.selections = {
            item["locator"]: item["target"]
            for item in self.records
            if item["target"] is not None and not item["protected"]
        }
        self.render_page()
        table_assigned = sum(
            1 for item in self.records
            if item["locator"] in self.selections and item["performance_table"]
        )
        QMessageBox.information(
            self, "Auto assignment complete",
            f"Assigned {len(self.selections)} declarations.\n"
            f"PerformanceTable fill/light-border assignments: {table_assigned}.\n\n"
            "Protected colors and preserved PerformanceTable text/body colors remain unchanged."
        )

    def render_page(self):
        self.table.setUpdatesEnabled(False)
        self.table.setRowCount(0)
        total_pages = max(1, (len(self.records) + self.PAGE_SIZE - 1) // self.PAGE_SIZE)
        self.page = max(0, min(self.page, total_pages - 1))
        start = self.page * self.PAGE_SIZE
        end = min(len(self.records), start + self.PAGE_SIZE)
        presets = [
            ("Do not change", None), ("Black", BLACK), ("Light grey", LIGHT_GREY),
            ("Dark grey", DARK_GREY), ("Maroon", MAROON),
        ]
        for record in self.records[start:end]:
            row = self.table.rowCount()
            self.table.insertRow(row)
            check = self.QTableWidgetItem()
            check.setFlags(check.flags() | Qt.ItemFlag.ItemIsUserCheckable)
            check.setData(Qt.ItemDataRole.UserRole, record["locator"])
            selected = self.selections.get(record["locator"])
            check.setCheckState(Qt.CheckState.Checked if selected else Qt.CheckState.Unchecked)
            self.table.setItem(row, 0, check)
            values = (
                record["file"], record["type"], record["name"], record["text"],
                record["property"], str(record["old"])[1:-1], record["category"], record["reason"]
            )
            for column, value in enumerate(values, 1):
                self.table.setItem(row, column, self.QTableWidgetItem(value))
            combo = self.QComboBox()
            for label, value in presets:
                combo.addItem(label, value)
            self.table.setCellWidget(row, 9, combo)
            target_item = self.QTableWidgetItem("")
            self.table.setItem(row, 10, target_item)
            combo.currentIndexChanged.connect(lambda index, current_row=row: self.target_changed(current_row, index))
            if record["protected"]:
                check.setFlags(check.flags() & ~Qt.ItemFlag.ItemIsUserCheckable)
                combo.setEnabled(False)
                target_item.setText("PROTECTED")
            elif selected:
                index = next((i for i in range(combo.count()) if combo.itemData(i) == selected), 0)
                combo.blockSignals(True)
                combo.setCurrentIndex(index)
                combo.blockSignals(False)
                target_item.setText(str(selected)[1:-1])
        self.table.setUpdatesEnabled(True)
        self.page_label.setText(
            f"Page {self.page + 1} of {total_pages} | {start + 1 if self.records else 0}-{end} "
            f"of {len(self.records)} | Selected: {len(self.selections)}"
        )
        self.previous_button.setEnabled(self.page > 0)
        self.next_button.setEnabled(self.page + 1 < total_pages)

    def target_changed(self, row, index):
        combo = self.table.cellWidget(row, 9)
        check = self.table.item(row, 0)
        target_item = self.table.item(row, 10)
        locator = check.data(Qt.ItemDataRole.UserRole)
        record = next((item for item in self.records if item["locator"] == locator), None)
        if record and record["protected"]:
            return
        value = combo.itemData(index)
        if value is None:
            check.setCheckState(Qt.CheckState.Unchecked)
            target_item.setText("")
            self.selections.pop(locator, None)
        else:
            check.setCheckState(Qt.CheckState.Checked)
            target_item.setText(str(value)[1:-1])
            self.selections[locator] = value

    def previous_page(self):
        self.save_visible_page()
        if self.page > 0:
            self.page -= 1
            self.render_page()

    def next_page(self):
        self.save_visible_page()
        total_pages = max(1, (len(self.records) + self.PAGE_SIZE - 1) // self.PAGE_SIZE)
        if self.page + 1 < total_pages:
            self.page += 1
            self.render_page()

    def replace(self):
        if not self.valid_input():
            return
        self.save_visible_page()
        output = self.output_edit.text().strip()
        if not output:
            QMessageBox.warning(self, "Output required", "Select an output PPTX file.")
            return
        if not output.lower().endswith(".pptx"):
            output += ".pptx"
            self.output_edit.setText(output)
        if os.path.abspath(output) == os.path.abspath(self.input_edit.text().strip()):
            QMessageBox.warning(self, "Different output required", "Use a different output filename.")
            return
        if not self.selections:
            QMessageBox.warning(self, "Nothing selected", "Click Auto assign colors or choose replacements manually.")
            return
        self.start_worker("replace", output, dict(self.selections))

    def failed(self, error):
        self.scan_button.setEnabled(True)
        self.auto_button.setEnabled(bool(self.records))
        self.replace_button.setEnabled(bool(self.records))
        self.log_box.setPlainText(error)
        QMessageBox.critical(self, "Processing failed", "Processing failed. See the log.")


def main():
    app = QApplication(sys.argv)
    app.setStyle("Fusion")
    window = MainWindow()
    window.show()
    sys.exit(app.exec())


if __name__ == "__main__":
    main()
