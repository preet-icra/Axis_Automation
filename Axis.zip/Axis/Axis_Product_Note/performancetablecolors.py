import os
import shutil
import sys
import tempfile
import traceback
import zipfile
from collections import Counter, defaultdict
from pathlib import Path

from lxml import etree
from PyQt6.QtCore import QObject, QThread, Qt, pyqtSignal
from PyQt6.QtGui import QColor
from PyQt6.QtWidgets import (
    QApplication, QFileDialog, QHBoxLayout, QHeaderView, QLabel, QLineEdit,
    QMainWindow, QMessageBox, QProgressBar, QPushButton, QTableWidget,
    QTableWidgetItem, QTextEdit, QVBoxLayout, QWidget,
)

APP_TITLE = "PerformanceTable Text 35,31,32 to Black"
A_NS = "http://schemas.openxmlformats.org/drawingml/2006/main"
BLACK = (0, 0, 0)
SOURCE_COLOR = (35, 31, 32)
TARGET_NAMES = {"performancetable", "performanetable"}
COLOR_LOCAL_NAMES = {"srgbClr", "scrgbClr", "schemeClr", "sysClr", "prstClr"}
DEFAULT_THEME = {
    "dk1": (0, 0, 0), "lt1": (255, 255, 255),
    "dk2": (31, 73, 125), "lt2": (238, 236, 225),
    "accent1": (79, 129, 189), "accent2": (192, 80, 77),
    "accent3": (155, 187, 89), "accent4": (128, 100, 162),
    "accent5": (75, 172, 198), "accent6": (247, 150, 70),
    "hlink": (0, 0, 255), "folHlink": (128, 0, 128),
}
THEME_ALIASES = {"tx1": "dk1", "bg1": "lt1", "tx2": "dk2", "bg2": "lt2", "phClr": "dk1"}
PRESET = {
    "black": (0, 0, 0), "white": (255, 255, 255), "gray": (128, 128, 128),
    "grey": (128, 128, 128), "maroon": (128, 0, 0), "red": (255, 0, 0),
    "blue": (0, 0, 255), "green": (0, 128, 0), "purple": (128, 0, 128),
}


def normalize_name(value):
    return "".join(value.lower().split())


def is_target_name(value):
    normalized = normalize_name(value)
    return any(alias == normalized or alias in normalized for alias in TARGET_NAMES)


def clamp(value):
    return max(0, min(255, int(round(value))))


def rgb_hex(rgb):
    return "".join(f"{channel:02X}" for channel in rgb)


def hex_rgb(value):
    if not value:
        return None
    value = value.strip().replace("#", "")[-6:]
    if len(value) != 6:
        return None
    try:
        return tuple(int(value[index:index + 2], 16) for index in (0, 2, 4))
    except ValueError:
        return None


def read_theme(folder):
    result = dict(DEFAULT_THEME)
    files = sorted((Path(folder) / "ppt" / "theme").glob("theme*.xml"))
    if not files:
        return result
    try:
        tree = etree.parse(str(files[0]), etree.XMLParser(recover=True, huge_tree=True))
        schemes = tree.xpath('.//*[local-name()="clrScheme"]')
        if schemes:
            for entry in schemes[0]:
                if not len(entry):
                    continue
                name = etree.QName(entry).localname
                node = entry[0]
                rgb = hex_rgb(node.get("val")) or hex_rgb(node.get("lastClr"))
                if rgb:
                    result[name] = rgb
    except Exception:
        pass
    return result


def apply_transforms(rgb, color_node):
    r, g, b = map(float, rgb)
    for transform in color_node:
        name = etree.QName(transform).localname
        try:
            ratio = int(transform.get("val")) / 100000.0
        except (TypeError, ValueError):
            continue
        if name == "tint":
            r, g, b = r+(255-r)*ratio, g+(255-g)*ratio, b+(255-b)*ratio
        elif name in ("shade", "lumMod"):
            r, g, b = r*ratio, g*ratio, b*ratio
        elif name == "lumOff":
            r, g, b = r+255*ratio, g+255*ratio, b+255*ratio
    return clamp(r), clamp(g), clamp(b)


def resolve_color_node(node, theme):
    kind = etree.QName(node).localname
    rgb = None
    if kind == "srgbClr":
        rgb = hex_rgb(node.get("val"))
    elif kind == "scrgbClr":
        try:
            rgb = tuple(clamp(255 * int(node.get(channel, "0")) / 100000) for channel in "rgb")
        except ValueError:
            pass
    elif kind == "schemeClr":
        key = node.get("val", "")
        rgb = theme.get(THEME_ALIASES.get(key, key))
    elif kind == "sysClr":
        rgb = hex_rgb(node.get("lastClr")) or PRESET.get(node.get("val", ""))
    elif kind == "prstClr":
        rgb = PRESET.get(node.get("val", ""))
    return apply_transforms(rgb, node) if rgb else None


def first_color_under(element, theme):
    if element is None:
        return None
    fills = element.xpath('./*[local-name()="solidFill"]')
    if not fills:
        return None
    for child in fills[0]:
        if etree.QName(child).localname in COLOR_LOCAL_NAMES:
            return resolve_color_node(child, theme)
    return None


def effective_run_color(run, theme):
    """Resolve the visible run color, including inherited/default black text."""
    properties = run.xpath('./*[local-name()="rPr"]')
    if properties:
        color = first_color_under(properties[0], theme)
        if color is not None:
            return color, "Run color"

    paragraph = run.getparent()
    if paragraph is not None:
        defaults = paragraph.xpath('./*[local-name()="pPr"]/*[local-name()="defRPr"]')
        if defaults:
            color = first_color_under(defaults[0], theme)
            if color is not None:
                return color, "Paragraph default"
        end_properties = paragraph.xpath('./*[local-name()="endParaRPr"]')
        if end_properties:
            color = first_color_under(end_properties[0], theme)
            if color is not None:
                return color, "Paragraph end default"

    # PowerPoint table text with no explicit color normally renders from the
    # text-style/theme. For this task the safe listed current value is black.
    return BLACK, "Inherited/default black"


def ensure_black_run_color(run):
    properties = run.xpath('./*[local-name()="rPr"]')
    if properties:
        rpr = properties[0]
    else:
        rpr = etree.Element(f"{{{A_NS}}}rPr")
        run.insert(0, rpr)

    for child in list(rpr):
        if etree.QName(child).localname in {
            "solidFill", "gradFill", "noFill", "pattFill", "blipFill", "grpFill"
        }:
            rpr.remove(child)

    solid_fill = etree.Element(f"{{{A_NS}}}solidFill")
    rgb_node = etree.SubElement(solid_fill, f"{{{A_NS}}}srgbClr")
    rgb_node.set("val", "000000")
    rpr.insert(0, solid_fill)


def frame_name(frame):
    names = frame.xpath('.//*[local-name()="cNvPr"]')
    return names[0].get("name", "Unnamed object") if names else "Unnamed object"


def frame_is_table(frame):
    return bool(frame.xpath('.//*[local-name()="tbl"]'))


def make_index_path(node):
    indexes = []
    current = node
    while current.getparent() is not None:
        parent = current.getparent()
        indexes.append(parent.index(current))
        current = parent
    indexes.reverse()
    return "/".join(str(index) for index in indexes)


def find_by_index_path(root, index_path):
    current = root
    for part in index_path.split("/"):
        if not part:
            continue
        index = int(part)
        if index < 0 or index >= len(current):
            return None
        current = current[index]
    return current


def run_text(run):
    texts = run.xpath('.//*[local-name()="t"]/text()')
    return " ".join(str(text) for text in texts).strip()


def scan_all_performance_tables(source, progress, log):
    folder = tempfile.mkdtemp(prefix="performance_table_scan_")
    try:
        with zipfile.ZipFile(source, "r") as archive:
            archive.extractall(folder)
        theme = read_theme(folder)
        files = []
        for path in Path(folder).rglob("*.xml"):
            relative = str(path.relative_to(folder)).replace("\\", "/")
            if relative.startswith("ppt/") and relative.endswith(".xml") and not relative.startswith("ppt/theme/"):
                files.append((path, relative))
        files.sort(key=lambda item: item[1])

        records = []
        object_number = 0
        for file_index, (path, relative) in enumerate(files, 1):
            try:
                tree = etree.parse(str(path), etree.XMLParser(recover=True, huge_tree=True))
                for frame in tree.xpath('.//*[local-name()="graphicFrame"]'):
                    name = frame_name(frame)
                    if not frame_is_table(frame) or not is_target_name(name):
                        continue
                    object_number += 1
                    color_counts = Counter()
                    color_sources = defaultdict(Counter)
                    color_previews = defaultdict(list)
                    total_runs = 0
                    for run in frame.xpath('.//*[local-name()="r" or local-name()="fld"]'):
                        text = run_text(run)
                        if not text:
                            continue
                        total_runs += 1
                        rgb, source = effective_run_color(run, theme)
                        color_counts[rgb] += 1
                        color_sources[rgb][source] += 1
                        if text not in color_previews[rgb] and len(color_previews[rgb]) < 4:
                            color_previews[rgb].append(text[:70])

                    # Always list the object. If no text runs exist, show a
                    # diagnostic row rather than an empty table.
                    if not color_counts:
                        records.append({
                            "object_id": object_number,
                            "file": relative,
                            "name": name,
                            "frame_path": make_index_path(frame),
                            "old_rgb": BLACK,
                            "occurrences": 0,
                            "source": "No text runs found",
                            "preview": "",
                            "total_runs": 0,
                        })
                    else:
                        for rgb, count in sorted(color_counts.items(), key=lambda item: (-item[1], item[0])):
                            source_label = ", ".join(
                                f"{source}: {number}" for source, number in color_sources[rgb].most_common()
                            )
                            records.append({
                                "object_id": object_number,
                                "file": relative,
                                "name": name,
                                "frame_path": make_index_path(frame),
                                "old_rgb": rgb,
                                "occurrences": count,
                                "source": source_label,
                                "preview": " | ".join(color_previews[rgb]),
                                "total_runs": total_runs,
                            })
            except Exception as error:
                log.emit(f"Skipped {relative}: {error}")
            progress.emit(int(file_index / max(1, len(files)) * 100))
        return records
    finally:
        shutil.rmtree(folder, ignore_errors=True)


def replace_selected_rows(source, output, selected_rows, progress, log):
    folder = tempfile.mkdtemp(prefix="performance_table_replace_")
    changed = 0
    try:
        with zipfile.ZipFile(source, "r") as archive:
            archive.extractall(folder)
        theme = read_theme(folder)

        grouped = defaultdict(list)
        for item in selected_rows:
            grouped[item["file"]].append(item)

        for file_index, (relative, selections) in enumerate(sorted(grouped.items()), 1):
            path = Path(folder) / relative
            tree = etree.parse(str(path), etree.XMLParser(remove_blank_text=False, recover=True, huge_tree=True))
            dirty = False
            for selection in selections:
                frame = find_by_index_path(tree.getroot(), selection["frame_path"])
                if frame is None or not is_target_name(frame_name(frame)):
                    log.emit(f"Could not locate {selection['name']} in {relative}")
                    continue
                old_rgb = selection["old_rgb"]
                if old_rgb != SOURCE_COLOR:
                    continue
                for run in frame.xpath('.//*[local-name()="r" or local-name()="fld"]'):
                    if not run_text(run):
                        continue
                    current_rgb, _ = effective_run_color(run, theme)
                    if current_rgb != old_rgb:
                        continue
                    ensure_black_run_color(run)
                    changed += 1
                    dirty = True
            if dirty:
                tree.write(str(path), xml_declaration=True, encoding="UTF-8", standalone=True)
            progress.emit(int(file_index / max(1, len(grouped)) * 85))

        if os.path.exists(output):
            os.remove(output)
        with zipfile.ZipFile(output, "w", zipfile.ZIP_DEFLATED, compresslevel=6) as archive:
            for path in Path(folder).rglob("*"):
                if path.is_file():
                    archive.write(path, str(path.relative_to(folder)).replace("\\", "/"))
        with zipfile.ZipFile(output, "r") as archive:
            bad = archive.testzip()
            if bad:
                raise ValueError(f"Generated PPTX has a corrupt entry: {bad}")
        progress.emit(100)
        return changed
    finally:
        shutil.rmtree(folder, ignore_errors=True)


class Worker(QObject):
    progress = pyqtSignal(int)
    log = pyqtSignal(str)
    done = pyqtSignal(object)
    failed = pyqtSignal(str)

    def __init__(self, mode, source, output=None, selected_rows=None):
        super().__init__()
        self.mode = mode
        self.source = source
        self.output = output
        self.selected_rows = selected_rows or []

    def run(self):
        try:
            if self.mode == "scan":
                result = scan_all_performance_tables(self.source, self.progress, self.log)
            else:
                result = replace_selected_rows(
                    self.source, self.output, self.selected_rows, self.progress, self.log
                )
            self.done.emit(result)
        except Exception:
            self.failed.emit(traceback.format_exc())


class MainWindow(QMainWindow):
    def __init__(self):
        super().__init__()
        self.records = []
        self.thread = None
        self.worker = None
        self.setWindowTitle(APP_TITLE)
        self.resize(1350, 760)

        root = QWidget()
        self.setCentralWidget(root)
        layout = QVBoxLayout(root)

        title = QLabel("List all PerformanceTable objects and replace only RGB 35,31,32 with black")
        title.setStyleSheet("font-size: 21px; font-weight: 700;")
        description = QLabel(
            "All objects named PerformanceTable or PerformaneTable are listed below with their current text colors. "
            "Only text with the exact source RGB 35,31,32 can be selected and replaced with black RGB 0,0,0. "
            "Every other text color is displayed but locked and preserved."
        )
        description.setWordWrap(True)
        layout.addWidget(title)
        layout.addWidget(description)

        row = QHBoxLayout()
        self.input_edit = QLineEdit()
        input_button = QPushButton("Input PPTX")
        input_button.clicked.connect(self.pick_input)
        row.addWidget(self.input_edit)
        row.addWidget(input_button)
        layout.addLayout(row)

        row = QHBoxLayout()
        self.output_edit = QLineEdit()
        output_button = QPushButton("Output PPTX")
        output_button.clicked.connect(self.pick_output)
        row.addWidget(self.output_edit)
        row.addWidget(output_button)
        layout.addLayout(row)

        row = QHBoxLayout()
        self.scan_button = QPushButton("1. Scan all PerformanceTable objects")
        self.scan_button.clicked.connect(self.scan)
        self.select_all_button = QPushButton("Select all RGB 35,31,32 rows")
        self.select_all_button.clicked.connect(self.select_all_source_color)
        self.select_all_button.setEnabled(False)
        self.clear_button = QPushButton("Clear selections")
        self.clear_button.clicked.connect(self.clear_selections)
        self.clear_button.setEnabled(False)
        row.addWidget(self.scan_button)
        row.addWidget(self.select_all_button)
        row.addWidget(self.clear_button)
        layout.addLayout(row)

        self.table = QTableWidget(0, 10)
        self.table.setHorizontalHeaderLabels([
            "Change", "Object #", "Slide/XML", "Object name", "Current text RGB",
            "HEX", "Occurrences", "Color source", "Text preview", "Replace with"
        ])
        self.table.horizontalHeader().setSectionResizeMode(QHeaderView.ResizeMode.Interactive)
        self.table.horizontalHeader().setSectionResizeMode(8, QHeaderView.ResizeMode.Stretch)
        widths = (70, 75, 190, 150, 135, 90, 95, 190, 320, 125)
        for column, width in enumerate(widths):
            self.table.setColumnWidth(column, width)
        layout.addWidget(self.table)

        self.replace_button = QPushButton("2. Replace RGB 35,31,32 with BLACK (0,0,0)")
        self.replace_button.setMinimumHeight(42)
        self.replace_button.clicked.connect(self.replace)
        self.replace_button.setEnabled(False)
        layout.addWidget(self.replace_button)

        self.progress = QProgressBar()
        layout.addWidget(self.progress)
        self.status_label = QLabel("No scan performed.")
        layout.addWidget(self.status_label)
        self.log_box = QTextEdit()
        self.log_box.setReadOnly(True)
        self.log_box.setMaximumHeight(90)
        layout.addWidget(self.log_box)

    def pick_input(self):
        path, _ = QFileDialog.getOpenFileName(self, "Select input PPTX", "", "PowerPoint (*.pptx)")
        if path:
            self.input_edit.setText(path)
            source = Path(path)
            self.output_edit.setText(str(source.with_name(source.stem + "_black_text.pptx")))

    def pick_output(self):
        path, _ = QFileDialog.getSaveFileName(
            self, "Select output PPTX", self.output_edit.text(), "PowerPoint (*.pptx)"
        )
        if path:
            self.output_edit.setText(path if path.lower().endswith(".pptx") else path + ".pptx")

    def valid_input(self):
        source = self.input_edit.text().strip()
        if not os.path.isfile(source) or not zipfile.is_zipfile(source):
            QMessageBox.warning(self, "Invalid input", "Select a valid PPTX file.")
            return False
        return True

    def run_worker(self, mode, output=None, selections=None):
        self.scan_button.setEnabled(False)
        self.replace_button.setEnabled(False)
        self.select_all_button.setEnabled(False)
        self.clear_button.setEnabled(False)
        self.progress.setValue(0)
        self.thread = QThread(self)
        self.worker = Worker(mode, self.input_edit.text().strip(), output, selections)
        self.worker.moveToThread(self.thread)
        self.thread.started.connect(self.worker.run)
        self.worker.progress.connect(self.progress.setValue)
        self.worker.log.connect(self.log_box.append)
        self.worker.done.connect(lambda result: self.finished(mode, result))
        self.worker.failed.connect(self.failed)
        self.worker.done.connect(self.thread.quit)
        self.worker.failed.connect(self.thread.quit)
        self.thread.finished.connect(self.worker.deleteLater)
        self.thread.finished.connect(self.thread.deleteLater)
        self.thread.start()

    def scan(self):
        if self.valid_input():
            self.log_box.clear()
            self.run_worker("scan")

    def finished(self, mode, result):
        self.scan_button.setEnabled(True)
        if mode == "scan":
            self.records = result
            self.populate_table()
            enabled = bool(result)
            self.replace_button.setEnabled(enabled)
            self.select_all_button.setEnabled(enabled)
            self.clear_button.setEnabled(enabled)
            object_count = len({(item["file"], item["frame_path"]) for item in result})
            total_declarations = sum(item["occurrences"] for item in result)
            matching_runs = sum(item["occurrences"] for item in result if item["old_rgb"] == SOURCE_COLOR)
            matching_rows = sum(1 for item in result if item["old_rgb"] == SOURCE_COLOR)
            self.status_label.setText(
                f"Found {object_count} PerformanceTable objects and {total_declarations} text runs. "
                f"RGB 35,31,32 appears in {matching_rows} rows / {matching_runs} runs."
            )
            QMessageBox.information(
                self, "Scan complete",
                f"Found {object_count} PerformanceTable/PerformaneTable objects.\n"
                f"Listed {len(result)} current text-color rows.\n"
                f"Detected {total_declarations} text runs.\n"
                f"RGB 35,31,32 matching runs: {matching_runs}."
            )
        else:
            self.replace_button.setEnabled(True)
            self.select_all_button.setEnabled(True)
            self.clear_button.setEnabled(True)
            QMessageBox.information(
                self, "Completed",
                f"Changed {result} text runs from RGB 35,31,32 to black RGB 0,0,0.\n\n"
                f"Saved to:\n{self.output_edit.text()}"
            )

    def populate_table(self):
        self.table.setUpdatesEnabled(False)
        self.table.setRowCount(0)
        for record in self.records:
            row = self.table.rowCount()
            self.table.insertRow(row)
            check = QTableWidgetItem()
            check.setFlags(check.flags() | Qt.ItemFlag.ItemIsUserCheckable)
            check.setCheckState(Qt.CheckState.Unchecked)
            check.setData(Qt.ItemDataRole.UserRole, row)
            if record["occurrences"] == 0 or record["old_rgb"] != SOURCE_COLOR:
                check.setFlags(check.flags() & ~Qt.ItemFlag.ItemIsUserCheckable)
            self.table.setItem(row, 0, check)
            self.table.setItem(row, 1, QTableWidgetItem(str(record["object_id"])))
            self.table.setItem(row, 2, QTableWidgetItem(record["file"]))
            self.table.setItem(row, 3, QTableWidgetItem(record["name"]))
            color_item = QTableWidgetItem(str(record["old_rgb"])[1:-1])
            color_item.setBackground(QColor(*record["old_rgb"]))
            self.table.setItem(row, 4, color_item)
            self.table.setItem(row, 5, QTableWidgetItem("#" + rgb_hex(record["old_rgb"])))
            self.table.setItem(row, 6, QTableWidgetItem(str(record["occurrences"])))
            self.table.setItem(row, 7, QTableWidgetItem(record["source"]))
            self.table.setItem(row, 8, QTableWidgetItem(record["preview"]))
            if record["occurrences"] == 0:
                replacement = QTableWidgetItem("No text runs")
            elif record["old_rgb"] == SOURCE_COLOR:
                replacement = QTableWidgetItem("Black (0, 0, 0)")
                replacement.setBackground(QColor(0, 0, 0))
                replacement.setForeground(QColor(255, 255, 255))
                check.setCheckState(Qt.CheckState.Checked)
            else:
                replacement = QTableWidgetItem("Preserve original")
                replacement.setBackground(QColor(235, 235, 235))
            self.table.setItem(row, 9, replacement)
        self.table.setUpdatesEnabled(True)

    def select_all_source_color(self):
        for row, record in enumerate(self.records):
            check = self.table.item(row, 0)
            if record["occurrences"] and record["old_rgb"] == SOURCE_COLOR:
                check.setCheckState(Qt.CheckState.Checked)
            else:
                check.setCheckState(Qt.CheckState.Unchecked)

    def clear_selections(self):
        for row in range(self.table.rowCount()):
            self.table.item(row, 0).setCheckState(Qt.CheckState.Unchecked)

    def replace(self):
        if not self.valid_input():
            return
        output = self.output_edit.text().strip()
        if not output:
            QMessageBox.warning(self, "Output required", "Select an output PPTX file.")
            return
        if not output.lower().endswith(".pptx"):
            output += ".pptx"
            self.output_edit.setText(output)
        if os.path.abspath(output) == os.path.abspath(self.input_edit.text().strip()):
            QMessageBox.warning(self, "Different output required", "Use a different output filename.")
            return

        selections = []
        for row, record in enumerate(self.records):
            if record["old_rgb"] != SOURCE_COLOR:
                continue
            if self.table.item(row, 0).checkState() == Qt.CheckState.Checked:
                selections.append(record)
        if not selections:
            QMessageBox.warning(
                self, "Nothing selected",
                "No RGB 35,31,32 rows are selected. Click Select all RGB 35,31,32 rows."
            )
            return
        self.run_worker("replace", output, selections)

    def failed(self, error):
        self.scan_button.setEnabled(True)
        enabled = bool(self.records)
        self.replace_button.setEnabled(enabled)
        self.select_all_button.setEnabled(enabled)
        self.clear_button.setEnabled(enabled)
        self.log_box.setPlainText(error)
        QMessageBox.critical(self, "Processing failed", "Processing failed. See the log.")


def main():
    app = QApplication(sys.argv)
    app.setStyle("Fusion")
    window = MainWindow()
    window.show()
    sys.exit(app.exec())


if __name__ == "__main__":
    main()
