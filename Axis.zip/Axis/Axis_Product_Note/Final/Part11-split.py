import os
import re
import sys
import traceback
from dataclasses import dataclass
from datetime import datetime

from PyQt6.QtCore import QObject, QThread, pyqtSignal
from PyQt6.QtWidgets import (
    QApplication, QCheckBox, QComboBox, QFileDialog, QFormLayout,
    QHBoxLayout, QLabel, QLineEdit, QMainWindow, QMessageBox,
    QPlainTextEdit, QPushButton, QProgressBar, QSpinBox, QVBoxLayout, QWidget
)

try:
    import pythoncom
    import win32com.client
except ImportError:
    pythoncom = None
    win32com = None

FUND_OBJECT_NAMES = {"fundname"}
PERFORMANCE_OBJECT_NAMES = {"performancetable", "performanetable"}
MONTHS = [
    ("January", "Jan"), ("February", "Feb"), ("March", "Mar"),
    ("April", "Apr"), ("May", "May"), ("June", "Jun"),
    ("July", "Jul"), ("August", "Aug"), ("September", "Sep"),
    ("October", "Oct"), ("November", "Nov"), ("December", "Dec")
]


def normalize(value):
    value = str(value or "").replace("\r", " ").replace("\n", " ")
    value = value.replace("’", "'").replace("–", "-").replace("—", "-")
    return re.sub(r"\s+", " ", value).strip()


def remove_exact_repetition(value):
    """Collapse exact repeated halves, e.g. 'Axis Fund Axis Fund'."""
    value = normalize(value)
    words = value.split()
    if len(words) >= 2 and len(words) % 2 == 0:
        half = len(words) // 2
        if [w.casefold() for w in words[:half]] == [w.casefold() for w in words[half:]]:
            return " ".join(words[:half])
    return value


def safe_filename(value):
    value = re.sub(r'[<>:"/\\|?*]', " ", normalize(value))
    return re.sub(r"\s+", " ", value).strip(" .") or "Unnamed Fund"


def clean_fund_name(value):
    """Return one fund name even when PowerPoint exposes the text two times."""
    value = normalize(value)
    value = re.sub(r"^A\s+XIS\b", "AXIS", value, flags=re.I)
    value = re.sub(r"\s*\*+\s*$", "", value).strip()
    value = re.sub(
        r"\s*[-:]?\s*\b(?:Regular|Direct)\b\s*(?:Plan)?\s*$",
        "", value, flags=re.I
    )

    # Primary protection: an Axis scheme title ends at its first standalone FUND.
    # Example input from COM:
    #   Axis Children's Fund Axis Children's Fund
    # Result:
    #   Axis Children's Fund
    first_fund = re.match(r"^(.+?\bFUND\b)", value, flags=re.I)
    if first_fund:
        value = first_fund.group(1)
    else:
        value = remove_exact_repetition(value)

    value = normalize(value).strip(" -:,*")
    if value.isupper():
        value = value.title().replace("Elss", "ELSS")
    return value


def shape_text(shape):
    """Read a named shape once. TextFrame2 is only a fallback, not a duplicate source."""
    parts = []
    try:
        if int(shape.Type) == 6:  # msoGroup
            for i in range(1, shape.GroupItems.Count + 1):
                child = shape_text(shape.GroupItems.Item(i))
                if child:
                    parts.append(child)
            return normalize(" ".join(parts))
    except Exception:
        pass

    try:
        if shape.HasTable:
            table = shape.Table
            for r in range(1, table.Rows.Count + 1):
                for c in range(1, table.Columns.Count + 1):
                    try:
                        text = table.Cell(r, c).Shape.TextFrame.TextRange.Text
                        if normalize(text):
                            parts.append(text)
                    except Exception:
                        pass
            return normalize(" ".join(parts))
    except Exception:
        pass

    # TextFrame and TextFrame2 expose the same content in many PowerPoint shapes.
    # Reading both caused the fund name to be duplicated in the old version.
    try:
        if shape.HasTextFrame and shape.TextFrame.HasText:
            return normalize(shape.TextFrame.TextRange.Text)
    except Exception:
        pass
    try:
        if shape.TextFrame2.HasText:
            return normalize(shape.TextFrame2.TextRange.Text)
    except Exception:
        pass
    return ""


def named_shape_text(shapes, accepted_names):
    """Return text and actual object name, searching recursively in groups."""
    for i in range(1, shapes.Count + 1):
        shape = shapes.Item(i)
        try:
            name = normalize(shape.Name).lower()
        except Exception:
            name = ""
        if name in accepted_names:
            return shape_text(shape), name
        try:
            if int(shape.Type) == 6:
                text, found_name = named_shape_text(shape.GroupItems, accepted_names)
                if found_name:
                    return text, found_name
        except Exception:
            pass
    return "", ""


def identify_plan(performance_text):
    regular = bool(re.search(r"\bRegular\b", performance_text, re.I))
    direct = bool(re.search(r"\bDirect\b", performance_text, re.I))
    if regular and not direct:
        return "Regular"
    if direct and not regular:
        return "Direct"
    return None


def fund_from_performance(performance_text):
    """Fallback for a missing FundName object: parse the scheme row in the named table."""
    patterns = [
        r"((?:Axis)\s+.+?\s+Fund)\s*-\s*(?:Regular|Direct)\b",
        r"((?:Axis)\s+.+?\s+Fund)\s+(?:Regular|Direct)\b",
    ]
    for pattern in patterns:
        match = re.search(pattern, performance_text, re.I)
        if match:
            return clean_fund_name(match.group(1))
    return ""


@dataclass
class Anchor:
    slide: int
    plan: str | None
    performance_text: str
    fund_slide: int | None = None
    fund_name: str = ""


@dataclass
class Block:
    start: int
    end: int
    anchor: int
    fund_name: str
    plan: str
    warning: str = ""


def analyse_presentation(presentation, repair_pairs=False):
    """
    Treat each named performance table as the anchor of one complete leaflet block.
    A block starts at the nearest preceding FundName after the previous performance
    anchor. Its end is immediately before the next block start.
    """
    slide_count = presentation.Slides.Count
    fund_markers = {}
    anchors = []

    for number in range(1, slide_count + 1):
        slide = presentation.Slides.Item(number)
        fund_text, _ = named_shape_text(slide.Shapes, FUND_OBJECT_NAMES)
        perf_text, perf_object = named_shape_text(slide.Shapes, PERFORMANCE_OBJECT_NAMES)
        if fund_text:
            fund_markers[number] = clean_fund_name(fund_text)
        if perf_object:
            anchors.append(Anchor(number, identify_plan(perf_text), perf_text))

    if not anchors:
        raise RuntimeError(
            "No PerformanceTable or PerformaneTable objects were found. "
            "Check the names in PowerPoint's Selection Pane."
        )

    previous_anchor = 0
    for anchor in anchors:
        candidates = [n for n in fund_markers if previous_anchor < n <= anchor.slide]
        if candidates:
            anchor.fund_slide = max(candidates)
            anchor.fund_name = fund_markers[anchor.fund_slide]
        else:
            anchor.fund_name = fund_from_performance(anchor.performance_text)
        previous_anchor = anchor.slide

    # Block starts normally come from FundName. If a template accidentally omits
    # FundName (observed in one repeated plan), infer the start from neighbouring
    # anchor spacing rather than attaching the slides to the previous fund.
    starts = []
    last_start = 0
    typical_offset = 2
    offsets = [a.slide - a.fund_slide for a in anchors if a.fund_slide]
    if offsets:
        typical_offset = max(0, round(sum(offsets) / len(offsets)))
    for i, anchor in enumerate(anchors):
        if anchor.fund_slide:
            start = anchor.fund_slide
        elif i == 0:
            start = max(1, anchor.slide - typical_offset)
        else:
            gap = anchor.slide - anchors[i - 1].slide
            start = max(last_start + 1, anchor.slide - min(typical_offset, max(0, gap - 1)))
        starts.append(start)
        last_start = start

    blocks = []
    for i, anchor in enumerate(anchors):
        start = starts[i]
        end = starts[i + 1] - 1 if i + 1 < len(starts) else slide_count
        fund = anchor.fund_name
        plan = anchor.plan
        warning = ""
        if not fund:
            warning = "Fund name could not be read from FundName or performance table."
        if not plan:
            warning = (warning + " " if warning else "") + \
                      "Named performance object contains both/neither Regular and Direct."
        blocks.append(Block(start, end, anchor.slide, fund, plan or "", warning))

    # Optional template-error recovery: if exactly two consecutive blocks have the
    # same fund and same detected plan, use the standard Regular-then-Direct pair.
    if repair_pairs:
        i = 0
        while i + 1 < len(blocks):
            first, second = blocks[i], blocks[i + 1]
            if (first.fund_name and second.fund_name and
                    first.fund_name.casefold() == second.fund_name.casefold() and
                    first.plan == second.plan):
                first.plan, second.plan = "Regular", "Direct"
                second.warning = (second.warning + " " if second.warning else "") + \
                    "Duplicate plan label repaired as the second (Direct) block."
                i += 2
            else:
                i += 1
    return blocks


def unique_path(folder, base):
    path = os.path.join(folder, base + ".pptx")
    counter = 2
    while os.path.exists(path):
        path = os.path.join(folder, f"{base} ({counter}).pptx")
        counter += 1
    return path


class Worker(QObject):
    log = pyqtSignal(str)
    progress = pyqtSignal(int)
    finished = pyqtSignal(int, int, str)
    failed = pyqtSignal(str)

    def __init__(self, source, output, month, year, repair_pairs):
        super().__init__()
        self.source, self.output = source, output
        self.month, self.year = month, year
        self.repair_pairs = repair_pairs

    def run(self):
        if pythoncom is None or win32com is None:
            self.failed.emit("Install dependencies first: pip install PyQt6 pywin32")
            return
        pythoncom.CoInitialize()
        app = source_ppt = None
        created = skipped = 0
        try:
            os.makedirs(self.output, exist_ok=True)
            app = win32com.client.DispatchEx("PowerPoint.Application")
            app.Visible = True
            app.DisplayAlerts = 0
            source_path = os.path.abspath(self.source)
            source_ppt = app.Presentations.Open(source_path, True, False, False)
            blocks = analyse_presentation(source_ppt, self.repair_pairs)

            self.log.emit(f"Found {len(blocks)} leaflet blocks.")
            for i, block in enumerate(blocks, 1):
                label = f"slides {block.start}-{block.end}, anchor {block.anchor}"
                if block.warning:
                    self.log.emit(f"WARNING {label}: {block.warning}")
                if not block.fund_name or not block.plan:
                    self.log.emit(f"SKIPPED {label}")
                    skipped += 1
                    continue

                self.log.emit(f"{label}: {block.fund_name} | {block.plan}")
                suffix = "WDP-Leaflet" if block.plan == "Regular" else "DP-Leaflet"
                final_fund_name = clean_fund_name(block.fund_name)
                base = safe_filename(
                    f"{final_fund_name} ({self.month}_{self.year}) {suffix}"
                )
                output_path = unique_path(self.output, base)

                # IMPORTANT: clone the complete source presentation first.
                # Creating a blank presentation and inserting slides changes the
                # destination page size/master relationship and can scale or move
                # objects. SaveCopyAs preserves the exact source slide dimensions,
                # masters, layouts, themes, embedded fonts and linked resources.
                source_ppt.SaveCopyAs(os.path.abspath(output_path), 24)

                destination = None
                try:
                    destination = app.Presentations.Open(
                        os.path.abspath(output_path),
                        ReadOnly=False,
                        Untitled=False,
                        WithWindow=False
                    )

                    # Delete unwanted slides in reverse order. Keeping the original
                    # slides inside a cloned file avoids re-creating or re-scaling them.
                    for slide_no in range(destination.Slides.Count, 0, -1):
                        if slide_no < block.start or slide_no > block.end:
                            destination.Slides.Item(slide_no).Delete()

                    destination.Save()
                    created += 1
                    self.log.emit(
                        f"Created: {os.path.basename(output_path)} "
                        f"({destination.Slides.Count} original slide(s), layout preserved)"
                    )
                except Exception:
                    # Do not leave an incomplete output file after a failed edit.
                    try:
                        if destination is not None:
                            destination.Close()
                    finally:
                        destination = None
                    try:
                        if os.path.exists(output_path):
                            os.remove(output_path)
                    except Exception:
                        pass
                    raise
                finally:
                    if destination is not None:
                        destination.Close()
                self.progress.emit(int(i * 100 / len(blocks)))

            self.finished.emit(created, skipped, self.output)
        except Exception:
            self.failed.emit(traceback.format_exc())
        finally:
            try:
                if source_ppt:
                    source_ppt.Close()
            except Exception:
                pass
            try:
                if app:
                    app.Quit()
            except Exception:
                pass
            pythoncom.CoUninitialize()


class MainWindow(QMainWindow):
    def __init__(self):
        super().__init__()
        self.thread = self.worker = None
        self.setWindowTitle("Axis Product Note PPT Splitter v5 Final")
        self.resize(780, 590)
        root = QWidget(); self.setCentralWidget(root)
        layout = QVBoxLayout(root)
        title = QLabel("Axis Product Note PPT Splitter v5 Final")
        title.setStyleSheet("font-size:20px;font-weight:600")
        layout.addWidget(title)
        note = QLabel(
            "Clones the original PowerPoint first and deletes unwanted slides. "
            "This preserves the exact input slide size, master, theme and object positions."
        )
        note.setWordWrap(True); layout.addWidget(note)
        form = QFormLayout()

        self.source = QLineEdit(); b1 = QPushButton("Browse...")
        b1.clicked.connect(self.choose_source)
        row1 = QHBoxLayout(); row1.addWidget(self.source, 1); row1.addWidget(b1)
        form.addRow("Source PPT/PPTX:", row1)

        self.output = QLineEdit(); b2 = QPushButton("Browse...")
        b2.clicked.connect(self.choose_output)
        row2 = QHBoxLayout(); row2.addWidget(self.output, 1); row2.addWidget(b2)
        form.addRow("Output folder:", row2)

        self.month = QComboBox()
        for full, abbr in MONTHS: self.month.addItem(full, abbr)
        self.month.setCurrentIndex(datetime.now().month - 1)
        form.addRow("Month:", self.month)
        self.year = QSpinBox(); self.year.setRange(2000, 2100)
        self.year.setValue(datetime.now().year); form.addRow("Year:", self.year)

        self.repair = QCheckBox("Repair a repeated Regular/Regular pair as Regular/Direct")
        self.repair.setChecked(True)
        self.repair.setToolTip(
            "Useful when the second performance table was accidentally left labelled "
            "Regular. The repair applies only to two consecutive blocks of the same fund."
        )
        form.addRow("Template-error handling:", self.repair)
        layout.addLayout(form)

        self.run_button = QPushButton("Examine and Split Presentation")
        self.run_button.setMinimumHeight(40); self.run_button.clicked.connect(self.start)
        layout.addWidget(self.run_button)
        self.progress = QProgressBar(); layout.addWidget(self.progress)
        self.logbox = QPlainTextEdit(); self.logbox.setReadOnly(True); layout.addWidget(self.logbox, 1)

    def choose_source(self):
        path, _ = QFileDialog.getOpenFileName(self, "Select PowerPoint", "", "PowerPoint (*.pptx *.ppt)")
        if path:
            self.source.setText(path)
            if not self.output.text().strip(): self.output.setText(os.path.dirname(path))

    def choose_output(self):
        path = QFileDialog.getExistingDirectory(self, "Select output folder")
        if path: self.output.setText(path)

    def start(self):
        source, output = self.source.text().strip(), self.output.text().strip()
        if not os.path.isfile(source):
            QMessageBox.warning(self, "Invalid source", "Select a valid PPT or PPTX file."); return
        if not output:
            QMessageBox.warning(self, "Missing output", "Select an output folder."); return
        self.run_button.setEnabled(False); self.progress.setValue(0); self.logbox.clear()
        self.thread = QThread(self)
        self.worker = Worker(source, output, self.month.currentData(), self.year.value(), self.repair.isChecked())
        self.worker.moveToThread(self.thread)
        self.thread.started.connect(self.worker.run)
        self.worker.log.connect(self.logbox.appendPlainText)
        self.worker.progress.connect(self.progress.setValue)
        self.worker.finished.connect(self.done)
        self.worker.failed.connect(self.failed)
        self.worker.finished.connect(self.thread.quit); self.worker.failed.connect(self.thread.quit)
        self.thread.finished.connect(self.worker.deleteLater); self.thread.finished.connect(self.thread.deleteLater)
        self.thread.start()

    def done(self, created, skipped, folder):
        self.run_button.setEnabled(True); self.progress.setValue(100)
        QMessageBox.information(self, "Completed", f"Created: {created}\nSkipped: {skipped}\n\n{folder}")

    def failed(self, details):
        self.run_button.setEnabled(True); self.logbox.appendPlainText("\nERROR\n" + details)
        QMessageBox.critical(self, "Failed", "See the log for technical details.")


def main():
    app = QApplication(sys.argv)
    window = MainWindow(); window.show()
    sys.exit(app.exec())


if __name__ == "__main__":
    main()
