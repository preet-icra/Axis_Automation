from __future__ import annotations

import logging
import os
import re
import sys
from collections import defaultdict
from pathlib import Path

import pythoncom
import win32com.client as win32
from openpyxl import load_workbook
from PyQt6.QtCore import QObject, QThread, pyqtSignal
from PyQt6.QtGui import QFont
from PyQt6.QtWidgets import (
    QApplication,
    QFileDialog,
    QFormLayout,
    QHBoxLayout,
    QLabel,
    QLineEdit,
    QMainWindow,
    QMessageBox,
    QPlainTextEdit,
    QProgressBar,
    QPushButton,
    QVBoxLayout,
    QWidget,
)


# ============================================================================
# HARDCODED PATHS - CHANGE ONLY THESE PATHS WHEN NEEDED
# The GUI will initially display these paths, and lets you change them.
# ============================================================================
PPT_INPUT_PATH = Path(
    r"C:\monil\Axis_preet\New Template - Axis Equity Funds WDP_DP - Leaflet - Final.pptx"
)
EXCEL_INPUT_PATH = Path(
    r"C:\monil\Axis_preet\Entry Exit Data.xlsx"
)
PPT_OUTPUT_PATH = Path(
    r"C:\monil\Axis_preet\New Template - Axis Equity Funds WDP_DP - Leaflet - Entry Exit Updated.pptx"
)
LOG_FILE_PATH = Path(
    r"C:\monil\Axis_preet\entry_exit_update.log"
)

# PowerPoint object names
FUND_NAME_OBJECT = "FundName"
ENTRY_TABLE_OBJECT = "new_entry"
EXIT_TABLE_OBJECT = "new_exit"

# Formatting and layout controls
FONT_NAME = "Lato"
FONT_SIZE = 8
MIN_TABLE_ROWS = 4
TWO_COLUMN_THRESHOLD = 6
FUND_BLOCK_SLIDES = 4

# Office constants used through COM
MSO_TRUE = -1
MSO_FALSE = 0
PP_ALIGN_LEFT = 1
PP_ALIGN_CENTER = 2
PP_ALIGN_RIGHT = 3
PP_ALIGN_JUSTIFY = 4
MSO_ANCHOR_MIDDLE = 3


# ============================================================================
# LOGGING
# ============================================================================
class QtLogHandler(logging.Handler):
    """Send Python logging messages to a PyQt signal."""

    def __init__(self, signal):
        super().__init__()
        self.signal = signal

    def emit(self, record) -> None:
        try:
            self.signal.emit(self.format(record))
        except Exception:
            self.handleError(record)


def setup_logging(gui_log_signal=None) -> None:
    LOG_FILE_PATH.parent.mkdir(parents=True, exist_ok=True)
    formatter = logging.Formatter("%(asctime)s | %(levelname)s | %(message)s")

    file_handler = logging.FileHandler(LOG_FILE_PATH, mode="w", encoding="utf-8")
    file_handler.setFormatter(formatter)

    console_handler = logging.StreamHandler(sys.stdout)
    console_handler.setFormatter(formatter)

    handlers = [file_handler, console_handler]
    if gui_log_signal is not None:
        gui_handler = QtLogHandler(gui_log_signal)
        gui_handler.setFormatter(formatter)
        handlers.append(gui_handler)

    logging.basicConfig(level=logging.INFO, handlers=handlers, force=True)


# ============================================================================
# NORMALIZATION AND EXCEL READING
# ============================================================================
def clean_text(value) -> str:
    """Convert a cell/object value into clean single-spaced text."""
    if value is None:
        return ""
    return re.sub(r"\s+", " ", str(value).replace("\xa0", " ")).strip()


def normalize_name(value) -> str:
    """Normalize fund names for safe case-insensitive matching."""
    text = clean_text(value).casefold()
    text = text.replace("&", " and ")
    text = re.sub(r"[^a-z0-9]+", " ", text)
    return re.sub(r"\s+", " ", text).strip()


def is_na(value: str) -> bool:
    return clean_text(value).casefold() in {"", "na", "n/a", "nil", "none", "-"}


def read_entry_exit_data(excel_path: Path):
    """Return normalized fund mapping and the original Excel fund names."""
    workbook = load_workbook(excel_path, data_only=True, read_only=True)
    worksheet = workbook[workbook.sheetnames[0]]

    data = defaultdict(lambda: {"display_name": "", "entry": [], "exit": []})

    for row_number, row in enumerate(worksheet.iter_rows(min_row=2, values_only=True), start=2):
        fund_name = clean_text(row[0] if len(row) > 0 else None)
        entry_value = clean_text(row[1] if len(row) > 1 else None)
        exit_value = clean_text(row[2] if len(row) > 2 else None)

        if not fund_name:
            logging.warning("Excel row %s skipped because fund name is blank.", row_number)
            continue

        key = normalize_name(fund_name)
        data[key]["display_name"] = fund_name

        if not is_na(entry_value) and entry_value not in data[key]["entry"]:
            data[key]["entry"].append(entry_value)
        if not is_na(exit_value) and exit_value not in data[key]["exit"]:
            data[key]["exit"].append(exit_value)

    workbook.close()
    logging.info("Excel loaded: %s unique funds.", len(data))
    return dict(data)


# ============================================================================
# POWERPOINT HELPERS
# ============================================================================
def get_shape_by_name(slide, wanted_name: str):
    """Find a shape by exact name, case-insensitively."""
    wanted = wanted_name.casefold()
    for index in range(1, slide.Shapes.Count + 1):
        shape = slide.Shapes(index)
        if clean_text(shape.Name).casefold() == wanted:
            return shape
    return None


def get_text_from_shape(shape) -> str:
    """Read text from a PowerPoint shape."""
    try:
        if shape.HasTextFrame == MSO_TRUE and shape.TextFrame.HasText == MSO_TRUE:
            return clean_text(shape.TextFrame.TextRange.Text)
    except Exception:
        pass
    try:
        if shape.HasTextFrame == MSO_TRUE:
            return clean_text(shape.TextFrame.TextRange.Text)
    except Exception:
        pass
    return ""


def find_fund_tables(presentation, fund_slide_number: int):
    """Locate new_entry and new_exit within the current four-slide fund block."""
    candidate_numbers = []
    preferred = fund_slide_number + 1
    if preferred <= presentation.Slides.Count:
        candidate_numbers.append(preferred)

    block_end = min(presentation.Slides.Count, fund_slide_number + FUND_BLOCK_SLIDES - 1)
    for slide_number in range(fund_slide_number, block_end + 1):
        if slide_number not in candidate_numbers:
            candidate_numbers.append(slide_number)

    for slide_number in candidate_numbers:
        slide = presentation.Slides(slide_number)
        entry_shape = get_shape_by_name(slide, ENTRY_TABLE_OBJECT)
        exit_shape = get_shape_by_name(slide, EXIT_TABLE_OBJECT)
        if entry_shape is not None or exit_shape is not None:
            return slide_number, entry_shape, exit_shape

    return None, None, None


def copy_cell_style(source_cell, target_cell) -> None:
    """Copy relevant visual formatting from one PowerPoint table cell to another."""
    try:
        target_cell.Shape.Fill.ForeColor.RGB = source_cell.Shape.Fill.ForeColor.RGB
        target_cell.Shape.Fill.Transparency = source_cell.Shape.Fill.Transparency
        target_cell.Shape.Fill.Visible = source_cell.Shape.Fill.Visible
    except Exception:
        pass

    for border_id in (1, 2, 3, 4):
        try:
            target_line = target_cell.Borders(border_id)
            source_line = source_cell.Borders(border_id)
            target_line.ForeColor.RGB = source_line.ForeColor.RGB
            target_line.Weight = source_line.Weight
            target_line.DashStyle = source_line.DashStyle
            target_line.Visible = source_line.Visible
        except Exception:
            pass

    try:
        source_shape = source_cell.Shape
        target_shape = target_cell.Shape
        target_shape.TextFrame.MarginLeft = source_shape.TextFrame.MarginLeft
        target_shape.TextFrame.MarginRight = source_shape.TextFrame.MarginRight
        target_shape.TextFrame.MarginTop = source_shape.TextFrame.MarginTop
        target_shape.TextFrame.MarginBottom = source_shape.TextFrame.MarginBottom
        target_shape.TextFrame.VerticalAnchor = source_shape.TextFrame.VerticalAnchor
    except Exception:
        pass


def ensure_table_size(table_shape, required_rows: int, required_columns: int) -> None:
    """Add or remove rows/columns while retaining the table's original styling."""
    table = table_shape.Table
    style_row = min(table.Rows.Count, MIN_TABLE_ROWS)
    style_col = 1

    while table.Columns.Count < required_columns:
        table.Columns.Add()
        new_col = table.Columns.Count
        for row_index in range(1, table.Rows.Count + 1):
            copy_cell_style(
                table.Cell(min(row_index, style_row), style_col),
                table.Cell(row_index, new_col),
            )

    while table.Columns.Count > required_columns:
        table.Columns(table.Columns.Count).Delete()

    while table.Rows.Count < required_rows:
        table.Rows.Add()
        new_row = table.Rows.Count
        try:
            table.Rows(new_row).Height = table.Rows(style_row).Height
        except Exception:
            pass
        for col_index in range(1, table.Columns.Count + 1):
            copy_cell_style(
                table.Cell(style_row, min(col_index, table.Columns.Count)),
                table.Cell(new_row, col_index),
            )

    while table.Rows.Count > required_rows:
        table.Rows(table.Rows.Count).Delete()

    if required_columns == 2:
        each_width = table_shape.Width / 2
        table.Columns(1).Width = each_width
        table.Columns(2).Width = table_shape.Width - each_width
    else:
        table.Columns(1).Width = table_shape.Width


def format_cell(cell, text: str) -> None:
    """Write text and force Lato 8 regular/unbold formatting."""
    text_frame = cell.Shape.TextFrame
    text_frame.TextRange.Text = text
    text_frame.VerticalAnchor = MSO_ANCHOR_MIDDLE

    text_range = text_frame.TextRange
    text_range.Font.Name = FONT_NAME
    text_range.Font.Size = FONT_SIZE
    text_range.Font.Bold = MSO_FALSE
    text_range.Font.Italic = MSO_FALSE
    text_range.ParagraphFormat.Alignment = PP_ALIGN_LEFT

    for paragraph_index in range(1, text_range.Paragraphs().Count + 1):
        paragraph = text_range.Paragraphs(paragraph_index)
        paragraph.Font.Name = FONT_NAME
        paragraph.Font.Size = FONT_SIZE
        paragraph.Font.Bold = MSO_FALSE
        paragraph.Font.Italic = MSO_FALSE
        paragraph.ParagraphFormat.Alignment = PP_ALIGN_LEFT


def build_numbered_grid(values: list[str]):
    """Return a row-major grid with sequential numbering and balanced columns."""
    clean_values = [clean_text(item) for item in values if not is_na(clean_text(item))]

    if not clean_values:
        return [["NA"]], 1

    numbered = [f"{index}. {value}" for index, value in enumerate(clean_values, start=1)]

    if len(numbered) <= TWO_COLUMN_THRESHOLD:
        return [[item] for item in numbered], 1

    rows_per_column = (len(numbered) + 1) // 2
    left_values = numbered[:rows_per_column]
    right_values = numbered[rows_per_column:]

    grid = []
    for row_index in range(rows_per_column):
        left_text = left_values[row_index] if row_index < len(left_values) else ""
        right_text = right_values[row_index] if row_index < len(right_values) else ""
        grid.append([left_text, right_text])
    return grid, 2


def update_named_table(table_shape, values: list[str], label: str) -> None:
    """Resize, clear, and populate one named Entry/Exit table."""
    if table_shape is None:
        raise RuntimeError(f'Object "{label}" was not found.')
    if table_shape.HasTable != MSO_TRUE:
        raise RuntimeError(f'Object "{label}" exists but is not a PowerPoint table.')

    grid, required_columns = build_numbered_grid(values)
    required_rows = max(MIN_TABLE_ROWS, len(grid))
    ensure_table_size(table_shape, required_rows, required_columns)

    table = table_shape.Table
    for row_index in range(1, table.Rows.Count + 1):
        for col_index in range(1, table.Columns.Count + 1):
            format_cell(table.Cell(row_index, col_index), "")

    for row_index, row_values in enumerate(grid, start=1):
        for col_index, value in enumerate(row_values, start=1):
            format_cell(table.Cell(row_index, col_index), value)


def update_presentation(ppt_path: Path, output_path: Path, excel_data) -> None:
    """Open PowerPoint, update all matched funds, and save a new PPTX."""
    pythoncom.CoInitialize()
    powerpoint = None
    presentation = None

    try:
        powerpoint = win32.DispatchEx("PowerPoint.Application")
        powerpoint.Visible = True
        presentation = powerpoint.Presentations.Open(str(ppt_path), WithWindow=False)

        matched_funds = set()
        updated_blocks = 0

        for slide_number in range(1, presentation.Slides.Count + 1):
            slide = presentation.Slides(slide_number)
            fund_shape = get_shape_by_name(slide, FUND_NAME_OBJECT)
            if fund_shape is None:
                continue

            ppt_fund_name = get_text_from_shape(fund_shape)
            fund_key = normalize_name(ppt_fund_name)
            if not fund_key:
                logging.warning('Slide %s: object "%s" is blank.', slide_number, FUND_NAME_OBJECT)
                continue

            if fund_key not in excel_data:
                logging.warning('Slide %s: no Excel match for fund "%s".', slide_number, ppt_fund_name)
                continue

            table_slide_number, entry_shape, exit_shape = find_fund_tables(
                presentation, slide_number
            )
            if table_slide_number is None:
                logging.warning(
                    'Slide %s: fund "%s" matched Excel, but new_entry/new_exit '
                    "were not found in its block.",
                    slide_number,
                    ppt_fund_name,
                )
                continue

            fund_data = excel_data[fund_key]
            try:
                update_named_table(entry_shape, fund_data["entry"], ENTRY_TABLE_OBJECT)
                update_named_table(exit_shape, fund_data["exit"], EXIT_TABLE_OBJECT)
                matched_funds.add(fund_key)
                updated_blocks += 1
                logging.info(
                    'Updated "%s" | Fund slide %s | Table slide %s | Entry=%s | Exit=%s',
                    ppt_fund_name,
                    slide_number,
                    table_slide_number,
                    len(fund_data["entry"]),
                    len(fund_data["exit"]),
                )
            except Exception:
                logging.exception('Failed to update fund "%s".', ppt_fund_name)

        output_path.parent.mkdir(parents=True, exist_ok=True)
        if output_path.exists():
            output_path.unlink()
        presentation.SaveAs(str(output_path))

        missing_in_ppt = sorted(
            excel_data[key]["display_name"] for key in excel_data if key not in matched_funds
        )
        for fund_name in missing_in_ppt:
            logging.warning(
                'Excel fund not updated because no matching FundName block was found: "%s".',
                fund_name,
            )

        logging.info("Completed. Updated %s fund block(s).", updated_blocks)
        logging.info("Output saved to: %s", output_path)

    finally:
        if presentation is not None:
            try:
                presentation.Close()
            except Exception:
                pass
        if powerpoint is not None:
            try:
                powerpoint.Quit()
            except Exception:
                pass
        pythoncom.CoUninitialize()


# ============================================================================
# PYQT6 BACKGROUND WORKER
# ============================================================================
class UpdateWorker(QObject):
    log_message = pyqtSignal(str)
    completed = pyqtSignal(str)
    failed = pyqtSignal(str)
    finished = pyqtSignal()

    def __init__(self, ppt_input_path, excel_input_path, ppt_output_path, log_file_path):
        super().__init__()
        self.ppt_input_path = ppt_input_path
        self.excel_input_path = excel_input_path
        self.ppt_output_path = ppt_output_path
        self.log_file_path = log_file_path

    def run(self) -> None:
        global PPT_INPUT_PATH, EXCEL_INPUT_PATH, PPT_OUTPUT_PATH, LOG_FILE_PATH
        try:
            PPT_INPUT_PATH = self.ppt_input_path
            EXCEL_INPUT_PATH = self.excel_input_path
            PPT_OUTPUT_PATH = self.ppt_output_path
            LOG_FILE_PATH = self.log_file_path

            setup_logging(self.log_message)
            logging.info("Starting Entry/Exit update.")
            logging.info("PPT input: %s", PPT_INPUT_PATH)
            logging.info("Excel input: %s", EXCEL_INPUT_PATH)
            logging.info("PPT output: %s", PPT_OUTPUT_PATH)
            logging.info("Log file: %s", LOG_FILE_PATH)

            if not PPT_INPUT_PATH.exists():
                raise FileNotFoundError(f"PowerPoint file not found: {PPT_INPUT_PATH}")
            if not EXCEL_INPUT_PATH.exists():
                raise FileNotFoundError(f"Excel file not found: {EXCEL_INPUT_PATH}")
            if PPT_INPUT_PATH.resolve() == PPT_OUTPUT_PATH.resolve():
                raise ValueError("Input and output PowerPoint paths must be different.")

            excel_data = read_entry_exit_data(EXCEL_INPUT_PATH)
            update_presentation(PPT_INPUT_PATH, PPT_OUTPUT_PATH, excel_data)

            self.completed.emit(
                "Entry/Exit update completed successfully.\n\n"
                f"Output:\n{PPT_OUTPUT_PATH}\n\nLog:\n{LOG_FILE_PATH}"
            )
        except Exception as exc:
            logging.exception("Entry/Exit update failed.")
            self.failed.emit(f"{type(exc).__name__}: {exc}")
        finally:
            logging.shutdown()
            self.finished.emit()


# ============================================================================
# PYQT6 GUI
# ============================================================================
class EntryExitUpdaterWindow(QMainWindow):
    def __init__(self):
        super().__init__()
        self.worker_thread = None
        self.worker = None
        self.setWindowTitle("PowerPoint Entry / Exit Updater")
        self.setMinimumSize(900, 650)
        self.build_interface()
        self.load_default_paths()

    def build_interface(self) -> None:
        central_widget = QWidget()
        self.setCentralWidget(central_widget)
        main_layout = QVBoxLayout(central_widget)
        main_layout.setContentsMargins(24, 24, 24, 24)
        main_layout.setSpacing(14)

        title_label = QLabel("PowerPoint Entry / Exit Updater")
        title_font = QFont()
        title_font.setPointSize(17)
        title_font.setBold(True)
        title_label.setFont(title_font)

        description_label = QLabel(
            "Select the source PowerPoint and Excel files, choose an output "
            "location, and run the update."
        )
        description_label.setWordWrap(True)
        main_layout.addWidget(title_label)
        main_layout.addWidget(description_label)

        form_layout = QFormLayout()
        form_layout.setHorizontalSpacing(15)
        form_layout.setVerticalSpacing(12)

        self.ppt_input_edit = QLineEdit()
        self.excel_input_edit = QLineEdit()
        self.ppt_output_edit = QLineEdit()
        self.log_file_edit = QLineEdit()

        form_layout.addRow("Input PowerPoint:", self.create_path_row(self.ppt_input_edit, self.browse_ppt_input))
        form_layout.addRow("Entry/Exit Excel:", self.create_path_row(self.excel_input_edit, self.browse_excel_input))
        form_layout.addRow("Output PowerPoint:", self.create_path_row(self.ppt_output_edit, self.browse_ppt_output))
        form_layout.addRow("Log file:", self.create_path_row(self.log_file_edit, self.browse_log_file))
        main_layout.addLayout(form_layout)

        action_layout = QHBoxLayout()
        self.run_button = QPushButton("Run Update")
        self.run_button.setMinimumHeight(40)
        self.run_button.clicked.connect(self.start_update)
        self.clear_log_button = QPushButton("Clear Log")
        self.clear_log_button.setMinimumHeight(40)
        self.clear_log_button.clicked.connect(self.log_console_clear)
        self.open_output_folder_button = QPushButton("Open Output Folder")
        self.open_output_folder_button.setMinimumHeight(40)
        self.open_output_folder_button.clicked.connect(self.open_output_folder)

        action_layout.addWidget(self.run_button)
        action_layout.addWidget(self.clear_log_button)
        action_layout.addWidget(self.open_output_folder_button)
        action_layout.addStretch()
        main_layout.addLayout(action_layout)

        self.progress_bar = QProgressBar()
        self.progress_bar.setRange(0, 100)
        self.progress_bar.setValue(0)
        main_layout.addWidget(self.progress_bar)

        self.status_label = QLabel("Ready")
        main_layout.addWidget(self.status_label)

        log_label = QLabel("Processing log")
        log_font = QFont()
        log_font.setBold(True)
        log_label.setFont(log_font)
        main_layout.addWidget(log_label)

        self.log_console = QPlainTextEdit()
        self.log_console.setReadOnly(True)
        self.log_console.setLineWrapMode(QPlainTextEdit.LineWrapMode.NoWrap)
        self.log_console.setPlaceholderText("Processing messages will appear here.")
        self.log_console.setFont(QFont("Consolas", 9))
        main_layout.addWidget(self.log_console, stretch=1)

    def create_path_row(self, line_edit, browse_function) -> QWidget:
        container = QWidget()
        layout = QHBoxLayout(container)
        layout.setContentsMargins(0, 0, 0, 0)
        layout.setSpacing(8)
        browse_button = QPushButton("Browse")
        browse_button.setMinimumWidth(90)
        browse_button.clicked.connect(browse_function)
        layout.addWidget(line_edit, stretch=1)
        layout.addWidget(browse_button)
        return container

    def load_default_paths(self) -> None:
        self.ppt_input_edit.setText(str(PPT_INPUT_PATH))
        self.excel_input_edit.setText(str(EXCEL_INPUT_PATH))
        self.ppt_output_edit.setText(str(PPT_OUTPUT_PATH))
        self.log_file_edit.setText(str(LOG_FILE_PATH))

    def browse_ppt_input(self) -> None:
        selected, _ = QFileDialog.getOpenFileName(
            self, "Select Input PowerPoint", self.ppt_input_edit.text().strip(),
            "PowerPoint Presentations (*.pptx *.pptm);;All Files (*.*)"
        )
        if selected:
            self.ppt_input_edit.setText(selected)

    def browse_excel_input(self) -> None:
        selected, _ = QFileDialog.getOpenFileName(
            self, "Select Entry Exit Excel File", self.excel_input_edit.text().strip(),
            "Excel Workbooks (*.xlsx *.xlsm);;All Files (*.*)"
        )
        if selected:
            self.excel_input_edit.setText(selected)

    def browse_ppt_output(self) -> None:
        selected, _ = QFileDialog.getSaveFileName(
            self, "Select Output PowerPoint", self.ppt_output_edit.text().strip(),
            "PowerPoint Presentation (*.pptx)"
        )
        if selected:
            if not selected.lower().endswith(".pptx"):
                selected += ".pptx"
            self.ppt_output_edit.setText(selected)

    def browse_log_file(self) -> None:
        selected, _ = QFileDialog.getSaveFileName(
            self, "Select Log File", self.log_file_edit.text().strip(),
            "Log Files (*.log);;Text Files (*.txt);;All Files (*.*)"
        )
        if selected:
            if not Path(selected).suffix:
                selected += ".log"
            self.log_file_edit.setText(selected)

    def validate_paths(self):
        values = [
            self.ppt_input_edit.text().strip(),
            self.excel_input_edit.text().strip(),
            self.ppt_output_edit.text().strip(),
            self.log_file_edit.text().strip(),
        ]
        if not all(values):
            raise ValueError("All four paths are required.")

        ppt_input, excel_input, ppt_output, log_file = map(Path, values)
        if not ppt_input.is_file():
            raise FileNotFoundError(f"Input PowerPoint does not exist:\n{ppt_input}")
        if not excel_input.is_file():
            raise FileNotFoundError(f"Excel file does not exist:\n{excel_input}")
        if ppt_input.suffix.casefold() not in {".pptx", ".pptm"}:
            raise ValueError("The input PowerPoint must be a .pptx or .pptm file.")
        if excel_input.suffix.casefold() not in {".xlsx", ".xlsm"}:
            raise ValueError("The Excel input must be an .xlsx or .xlsm file.")
        if ppt_output.suffix.casefold() != ".pptx":
            raise ValueError("The output PowerPoint must have a .pptx extension.")
        if ppt_input.resolve() == ppt_output.resolve():
            raise ValueError("Input and output PowerPoint paths must be different.")
        return ppt_input, excel_input, ppt_output, log_file

    def start_update(self) -> None:
        try:
            paths = self.validate_paths()
        except Exception as exc:
            QMessageBox.warning(self, "Invalid Input", str(exc))
            return

        self.set_running_state(True)
        self.log_console.clear()
        self.append_log("Starting PowerPoint Entry/Exit update...")

        self.worker_thread = QThread(self)
        self.worker = UpdateWorker(*paths)
        self.worker.moveToThread(self.worker_thread)
        self.worker_thread.started.connect(self.worker.run)
        self.worker.log_message.connect(self.append_log)
        self.worker.completed.connect(self.update_completed)
        self.worker.failed.connect(self.update_failed)
        self.worker.finished.connect(self.worker_thread.quit)
        self.worker.finished.connect(self.worker.deleteLater)
        self.worker_thread.finished.connect(self.worker_thread.deleteLater)
        self.worker_thread.finished.connect(self.worker_thread_finished)
        self.worker_thread.start()

    def set_running_state(self, running: bool) -> None:
        self.run_button.setDisabled(running)
        self.ppt_input_edit.setDisabled(running)
        self.excel_input_edit.setDisabled(running)
        self.ppt_output_edit.setDisabled(running)
        self.log_file_edit.setDisabled(running)
        if running:
            self.status_label.setText("Processing. Do not close PowerPoint manually.")
            self.progress_bar.setRange(0, 0)
        else:
            self.status_label.setText("Ready")
            self.progress_bar.setRange(0, 100)
            self.progress_bar.setValue(0)

    def append_log(self, message: str) -> None:
        self.log_console.appendPlainText(message)
        bar = self.log_console.verticalScrollBar()
        bar.setValue(bar.maximum())

    def log_console_clear(self) -> None:
        self.log_console.clear()

    def update_completed(self, message: str) -> None:
        self.status_label.setText("Update completed successfully.")
        QMessageBox.information(self, "Update Completed", message)

    def update_failed(self, error_message: str) -> None:
        self.status_label.setText("Update failed.")
        self.append_log(f"ERROR: {error_message}")
        QMessageBox.critical(
            self, "Update Failed",
            "The PowerPoint update could not be completed.\n\n"
            f"{error_message}\n\nReview the processing log for more details."
        )

    def worker_thread_finished(self) -> None:
        self.set_running_state(False)
        self.worker = None
        self.worker_thread = None

    def open_output_folder(self) -> None:
        output_text = self.ppt_output_edit.text().strip()
        if not output_text:
            QMessageBox.warning(self, "Output Folder", "No output path has been selected.")
            return
        folder = Path(output_text).parent
        if not folder.exists():
            QMessageBox.warning(self, "Output Folder", f"Folder does not exist:\n{folder}")
            return
        try:
            os.startfile(str(folder))
        except Exception as exc:
            QMessageBox.critical(self, "Output Folder", f"Unable to open folder.\n\n{exc}")

    def closeEvent(self, event) -> None:
        if self.worker_thread is not None and self.worker_thread.isRunning():
            QMessageBox.warning(
                self, "Update in Progress",
                "The update is still running. Wait for it to finish before closing."
            )
            event.ignore()
            return
        event.accept()


# ============================================================================
# GUI MAIN
# ============================================================================
def main() -> None:
    app = QApplication(sys.argv)
    app.setApplicationName("PowerPoint Entry Exit Updater")
    window = EntryExitUpdaterWindow()
    window.show()
    sys.exit(app.exec())


if __name__ == "__main__":
    main()
