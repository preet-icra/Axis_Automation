# -*- coding: utf-8 -*-
"""Update Annexure links in PowerPoint with bold Lato text and no underline.

The visible URL contains no PowerPoint text hyperlink. A transparent clickable
rectangle is positioned over the URL instead, preventing hyperlink underline.

Install: py -m pip install PyQt6 pywin32
Run:     py annexure_link_updater_clickable_fixed.py
"""
from __future__ import annotations

import html
import re
import sys
import traceback
from datetime import datetime
from pathlib import Path
from typing import Any, Callable, Iterator, Optional

import pythoncom
import win32com.client as win32
from PyQt6.QtCore import QObject, QThread, pyqtSignal
from PyQt6.QtGui import QCloseEvent
from PyQt6.QtWidgets import (
    QApplication, QFileDialog, QFormLayout, QHBoxLayout, QLabel, QLineEdit,
    QMainWindow, QMessageBox, QPlainTextEdit, QProgressBar, QPushButton,
    QVBoxLayout, QWidget,
)

PERFORMANCE_TABLE_OBJECT = "PerformaneTable"
TARGET_OBJECT = "ManagerNoteandDate"
FUND_NAME_OBJECT = "FundName"
FUND_BLOCK_SLIDES = 4

REGULAR_LINK = "https://www.axismf.com/1/5/464/627/WDP_Annexure_Oct_2026_9a85fe247d.pdf"
DIRECT_LINK = "https://www.axismf.com/1/5/464/627/ALL_Annexure_Oct_2026_44fa7fc91e.pdf"

LINK_FONT_NAME = "Lato"
LINK_OVERLAY_PREFIX = "AnnexureLinkOverlay_"
MSO_GROUP = 6
MSO_TRUE = -1
MSO_FALSE = 0
MSO_SHAPE_RECTANGLE = 1
PP_SAVE_PPTX = 24
PP_SAVE_PPTM = 25
PP_WINDOW_MINIMIZED = 2
PP_MOUSE_CLICK = 1
PP_ACTION_HYPERLINK = 7
MSO_BRING_TO_FRONT = 0
URL_PATTERN = re.compile(r"https?://[^\s\r\n]+", re.IGNORECASE)
LINK_SENTENCE_MARKER = "please click on link"


def clean_text(value: Any) -> str:
    if value is None:
        return ""
    return re.sub(r"\s+", " ", str(value).replace("\r", " ").replace("\n", " ").replace("\t", " ")).strip()


def normalized_name(value: Any) -> str:
    return clean_text(value).casefold()


def iter_shapes(collection: Any) -> Iterator[Any]:
    for index in range(1, int(collection.Count) + 1):
        shape = collection.Item(index)
        yield shape
        try:
            if int(shape.Type) == MSO_GROUP:
                yield from iter_shapes(shape.GroupItems)
        except Exception:
            pass


def shape_name(shape: Any) -> str:
    try:
        return clean_text(shape.Name)
    except Exception:
        return ""


def find_named_shapes(slide: Any, required_name: str) -> list[Any]:
    target = normalized_name(required_name)
    return [s for s in iter_shapes(slide.Shapes) if normalized_name(shape_name(s)) == target]


def get_shape_text(shape: Any) -> str:
    try:
        if shape.HasTextFrame == MSO_TRUE:
            return str(shape.TextFrame.TextRange.Text or "")
    except Exception:
        pass
    return ""


def get_fund_name(slide: Any) -> str:
    for shape in find_named_shapes(slide, FUND_NAME_OBJECT):
        text = clean_text(get_shape_text(shape))
        if text:
            return text
    return ""


def table_text(shape: Any) -> str:
    try:
        if shape.HasTable != MSO_TRUE:
            return ""
    except Exception:
        return ""
    values: list[str] = []
    table = shape.Table
    for row in range(1, int(table.Rows.Count) + 1):
        for col in range(1, int(table.Columns.Count) + 1):
            try:
                text = table.Cell(row, col).Shape.TextFrame.TextRange.Text
            except Exception:
                text = ""
            if clean_text(text):
                values.append(clean_text(text))
    return "\n".join(values)


def detect_plan_type(shape: Any) -> str:
    text = table_text(shape)
    if not text:
        raise RuntimeError(f"'{PERFORMANCE_TABLE_OBJECT}' is not a readable table.")
    regular = re.search(r"\bregular\b", text, re.I) is not None
    direct = re.search(r"\bdirect\b", text, re.I) is not None
    if regular and direct:
        raise RuntimeError("Performance table contains both Regular and Direct.")
    if regular:
        return "regular"
    if direct:
        return "direct"
    raise RuntimeError("Neither Regular nor Direct was found in the performance table.")


def contains_marker(text_range: Any) -> bool:
    try:
        return LINK_SENTENCE_MARKER in clean_text(text_range.Text).casefold()
    except Exception:
        return False


def target_text_ranges(shape: Any) -> list[tuple[Any, Any]]:
    """Return (text-container shape, legacy TextRange) pairs containing the URL.

    TextRange2 does not expose Characters as a collection through pywin32 on
    all Office versions. It is acquired later with GetCharacters().
    """
    result: list[tuple[Any, Any]] = []
    try:
        if shape.HasTable == MSO_TRUE:
            table = shape.Table
            for row in range(1, int(table.Rows.Count) + 1):
                for col in range(1, int(table.Columns.Count) + 1):
                    cell_shape = table.Cell(row, col).Shape
                    legacy = cell_shape.TextFrame.TextRange
                    if contains_marker(legacy):
                        result.append((cell_shape, legacy))
            return result
    except Exception:
        pass
    try:
        if shape.HasTextFrame == MSO_TRUE:
            legacy = shape.TextFrame.TextRange
            if contains_marker(legacy):
                result.append((shape, legacy))
    except Exception:
        pass
    return result


def locate_url(text: str) -> Optional[tuple[int, int, str]]:
    marker = text.casefold().find(LINK_SENTENCE_MARKER)
    if marker < 0:
        return None
    match = URL_PATTERN.search(text, marker)
    if match is None:
        return None
    raw = match.group(0)
    trimmed = raw.rstrip(".,;:)]}")
    return match.start(), match.start() + len(trimmed), trimmed


def clear_text_hyperlink(text_range: Any) -> None:
    """Remove any prior character-level hyperlink that causes theme underlining."""
    try:
        hyperlink = text_range.ActionSettings(PP_MOUSE_CLICK).Hyperlink
        hyperlink.Address = ""
        hyperlink.SubAddress = ""
    except Exception:
        pass


def format_visible_url(text_range: Any) -> None:
    text_range.Font.Name = LINK_FONT_NAME
    text_range.Font.Bold = MSO_TRUE
    text_range.Font.Underline = MSO_FALSE


def delete_old_overlays(slide: Any, overlay_name: str) -> None:
    for index in range(int(slide.Shapes.Count), 0, -1):
        shape = slide.Shapes.Item(index)
        if normalized_name(shape_name(shape)) == normalized_name(overlay_name):
            shape.Delete()


def get_text_range2(container_shape: Any, start: int, length: int) -> Any:
    """Get a TextRange2 substring using the Office method, not a collection."""
    full_range2 = container_shape.TextFrame2.TextRange
    return full_range2.GetCharacters(start, length)


def add_click_overlay(
    slide: Any,
    container_shape: Any,
    start: int,
    length: int,
    address: str,
    overlay_name: str,
) -> None:
    """Add a transparent clickable rectangle over the visible URL."""
    url_range2 = get_text_range2(container_shape, start, length)
    left = float(url_range2.BoundLeft)
    top = float(url_range2.BoundTop)
    width = max(float(url_range2.BoundWidth), 2.0)
    height = max(float(url_range2.BoundHeight), 2.0)

    delete_old_overlays(slide, overlay_name)
    overlay = slide.Shapes.AddShape(MSO_SHAPE_RECTANGLE, left, top, width, height)
    overlay.Name = overlay_name
    overlay.Fill.Visible = MSO_TRUE
    overlay.Fill.Transparency = 0.99
    overlay.Line.Visible = MSO_FALSE
    click_action = overlay.ActionSettings(PP_MOUSE_CLICK)
    click_action.Action = PP_ACTION_HYPERLINK
    click_action.Hyperlink.Address = address
    click_action.Hyperlink.SubAddress = ""
    overlay.ZOrder(MSO_BRING_TO_FRONT)

    # Verify the hyperlink was actually stored on the overlay.
    written_address = clean_text(
        overlay.ActionSettings(PP_MOUSE_CLICK).Hyperlink.Address
    )
    if written_address != address:
        raise RuntimeError(
            f"Overlay hyperlink verification failed. Expected '{address}', "
            f"found '{written_address}'."
        )


def replace_url_and_add_overlay(
    slide: Any,
    container_shape: Any,
    legacy_range: Any,
    new_url: str,
    overlay_name: str,
) -> tuple[str, str]:
    existing = str(legacy_range.Text or "")
    found = locate_url(existing)
    if found is None:
        raise RuntimeError("Link sentence was found, but no URL followed it.")
    start_zero, end_zero, old_url = found
    start = start_zero + 1
    old_length = end_zero - start_zero

    # Remove old text hyperlink before changing the text.
    old_range = legacy_range.Characters(start, old_length)
    clear_text_hyperlink(old_range)
    old_range.Text = new_url

    # Format URL as plain text: Lato, bold, and explicitly no underline.
    visible_range = legacy_range.Characters(start, len(new_url))
    clear_text_hyperlink(visible_range)
    format_visible_url(visible_range)
    visible_range = legacy_range.Characters(start, len(new_url))
    format_visible_url(visible_range)

    written = str(legacy_range.Characters(start, len(new_url)).Text or "")
    if written != new_url:
        raise RuntimeError(f"URL verification failed: expected '{new_url}', found '{written}'.")

    # TextRange2.GetCharacters gives accurate slide coordinates. Using
    # TextRange2.Characters caused COM error -2147352559 on some Office builds.
    add_click_overlay(
        slide, container_shape, start, len(new_url), new_url, overlay_name
    )

    # Final formatting pass after overlay creation.
    final_range = legacy_range.Characters(start, len(new_url))
    clear_text_hyperlink(final_range)
    format_visible_url(final_range)
    return old_url, new_url


def find_target_slide_and_shapes(presentation: Any, performance_slide: int) -> tuple[int, list[Any]]:
    block_end = min(int(presentation.Slides.Count), performance_slide + FUND_BLOCK_SLIDES - 1)
    for number in range(performance_slide + 1, block_end + 1):
        shapes = find_named_shapes(presentation.Slides.Item(number), TARGET_OBJECT)
        if shapes:
            return number, shapes
    return 0, []


def update_presentation(
    input_ppt: Path,
    output_ppt: Path,
    regular_url: str,
    direct_url: str,
    log: Callable[[str], None],
    progress: Callable[[int], None],
) -> tuple[int, int, int]:
    powerpoint = presentation = None
    regular_count = direct_count = skipped_count = 0
    try:
        log("Starting Microsoft PowerPoint...")
        powerpoint = win32.DispatchEx("PowerPoint.Application")
        powerpoint.Visible = True
        try:
            powerpoint.WindowState = PP_WINDOW_MINIMIZED
        except Exception:
            pass
        presentation = powerpoint.Presentations.Open(
            str(input_ppt.resolve()), ReadOnly=False, Untitled=False, WithWindow=True
        )
        slide_count = int(presentation.Slides.Count)
        log(f"Slides found: {slide_count}")

        for slide_number in range(1, slide_count + 1):
            progress(round(slide_number / max(slide_count, 1) * 90))
            slide = presentation.Slides.Item(slide_number)
            performance_shapes = find_named_shapes(slide, PERFORMANCE_TABLE_OBJECT)
            if not performance_shapes:
                continue

            fund_name = ""
            for candidate in range(slide_number, max(0, slide_number - 3), -1):
                fund_name = get_fund_name(presentation.Slides.Item(candidate))
                if fund_name:
                    break
            fund_label = fund_name or "Unknown fund"

            for shape_index, performance_shape in enumerate(performance_shapes, 1):
                try:
                    plan_type = detect_plan_type(performance_shape)
                    target_slide_number, shapes = find_target_slide_and_shapes(presentation, slide_number)
                    if not shapes:
                        raise RuntimeError(f"'{TARGET_OBJECT}' was not found after slide {slide_number}.")
                    target_slide = presentation.Slides.Item(target_slide_number)
                    url = regular_url if plan_type == "regular" else direct_url
                    replacements = 0
                    for target_index, target_shape in enumerate(shapes, 1):
                        for range_index, (container_shape, legacy) in enumerate(target_text_ranges(target_shape), 1):
                            overlay_name = (
                                f"{LINK_OVERLAY_PREFIX}{target_slide_number}_"
                                f"{shape_index}_{target_index}_{range_index}"
                            )
                            old_url, new_url = replace_url_and_add_overlay(
                                target_slide, container_shape, legacy, url, overlay_name
                            )
                            replacements += 1
                            log(
                                f"{fund_label} | Performance slide {slide_number} | "
                                f"Link slide {target_slide_number} | {plan_type.title()} | "
                                f"{old_url} -> {new_url} | Lato, bold, no underline, clickable overlay"
                            )
                    if replacements == 0:
                        raise RuntimeError(
                            f"'{TARGET_OBJECT}' was found on slide {target_slide_number}, "
                            "but the link sentence was not found."
                        )
                    if plan_type == "regular":
                        regular_count += replacements
                    else:
                        direct_count += replacements
                except Exception as exc:
                    skipped_count += 1
                    log(f"WARNING: {fund_label} on slide {slide_number} was skipped: {exc}")

        if regular_count + direct_count == 0:
            raise RuntimeError("No Annexure URLs were updated.")

        output_ppt.parent.mkdir(parents=True, exist_ok=True)
        if output_ppt.exists():
            try:
                output_ppt.unlink()
            except PermissionError as exc:
                raise PermissionError(f"The output PowerPoint is open or locked:\n{output_ppt}") from exc
        file_format = PP_SAVE_PPTM if output_ppt.suffix.lower() == ".pptm" else PP_SAVE_PPTX
        progress(95)
        presentation.SaveAs(str(output_ppt.resolve()), file_format)
        progress(100)
        return regular_count, direct_count, skipped_count
    finally:
        if presentation is not None:
            try:
                presentation.Close()
            except Exception:
                pass
        if powerpoint is not None:
            try:
                powerpoint.Quit()
            except Exception:
                pass


def extract_plain_url(value: str, label: str) -> str:
    """Accept a plain URL or pasted HTML anchor and return only the URL."""
    value = html.unescape(value.strip())
    href_match = re.search(r"href\s*=\s*[\"\'](https?://[^\"\']+)[\"\']", value, re.I)
    if href_match:
        value = href_match.group(1).strip()
    else:
        url_match = re.search(r"https?://[^\s<>\"]+", value, re.I)
        if url_match:
            value = url_match.group(0).rstrip(".,;:)]}")
    if not re.fullmatch(r"https?://\S+", value, re.I):
        raise ValueError(f"Enter a valid plain URL or HTML link for {label}.")
    return value


def build_output_path(input_ppt: Path, folder: Path) -> Path:
    return folder / f"{input_ppt.stem}_Annexure_Links_Updated{input_ppt.suffix.lower()}"


class LinkUpdateWorker(QObject):
    log = pyqtSignal(str)
    progress = pyqtSignal(int)
    completed = pyqtSignal(int, int, int, str, str)
    failed = pyqtSignal(str, str)

    def __init__(self, input_ppt: Path, output_folder: Path, regular_url: str, direct_url: str) -> None:
        super().__init__()
        self.input_ppt = input_ppt
        self.output_folder = output_folder
        self.regular_url = regular_url
        self.direct_url = direct_url

    def run(self) -> None:
        pythoncom.CoInitialize()
        lines: list[str] = []
        stamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        output_ppt = build_output_path(self.input_ppt, self.output_folder)
        log_file = self.output_folder / f"Annexure_Link_Update_{stamp}.txt"

        def emit(message: str) -> None:
            lines.append(str(message))
            self.log.emit(str(message))

        try:
            self.output_folder.mkdir(parents=True, exist_ok=True)
            emit("=" * 76)
            emit("PERFORMANCE ANNEXURE LINK UPDATER - NO UNDERLINE OVERLAY MODE")
            emit("=" * 76)
            emit(f"Input: {self.input_ppt}")
            emit(f"Regular URL: {self.regular_url}")
            emit(f"Direct URL: {self.direct_url}")
            emit("Visible URL: Lato, bold, no underline")
            emit("Click behavior: 99% transparent hyperlink overlay with ppActionHyperlink")
            regular, direct, skipped = update_presentation(
                self.input_ppt, output_ppt, self.regular_url, self.direct_url,
                emit, self.progress.emit,
            )
            emit("STATUS: SUCCESS")
            emit(f"Regular links updated: {regular}")
            emit(f"Direct links updated: {direct}")
            emit(f"Skipped blocks: {skipped}")
            log_file.write_text("\n".join(lines), encoding="utf-8")
            self.completed.emit(regular, direct, skipped, str(output_ppt), str(log_file))
        except Exception as exc:
            details = traceback.format_exc()
            emit(f"STATUS: FAILED\nERROR: {exc}")
            emit(details)
            try:
                log_file.write_text("\n".join(lines), encoding="utf-8")
            except Exception:
                pass
            self.failed.emit(str(exc), details)
        finally:
            pythoncom.CoUninitialize()


class MainWindow(QMainWindow):
    def __init__(self) -> None:
        super().__init__()
        self.thread: Optional[QThread] = None
        self.worker: Optional[LinkUpdateWorker] = None
        self.setWindowTitle("PowerPoint Annexure Link Updater")
        self.resize(980, 700)
        self.build_ui()

    def build_ui(self) -> None:
        root = QWidget()
        self.setCentralWidget(root)
        layout = QVBoxLayout(root)
        layout.setContentsMargins(24, 20, 24, 20)
        layout.setSpacing(12)
        title = QLabel("PowerPoint Performance Annexure Link Updater")
        title.setStyleSheet("font-size:20px;font-weight:700;color:#97144C;")
        description = QLabel(
            "The visible URL is plain Lato bold text without underline. A transparent "
            "clickable overlay is positioned over the URL so the link remains clickable."
        )
        description.setWordWrap(True)
        layout.addWidget(title)
        layout.addWidget(description)

        form = QFormLayout()
        self.input_edit = QLineEdit()
        self.output_edit = QLineEdit()
        self.regular_edit = QLineEdit(REGULAR_LINK)
        self.direct_edit = QLineEdit(DIRECT_LINK)
        form.addRow("Input PowerPoint:", self.path_row(self.input_edit, self.pick_input))
        form.addRow("Output folder:", self.path_row(self.output_edit, self.pick_output))
        form.addRow("Regular/WDP link:", self.regular_edit)
        form.addRow("Direct/ALL link:", self.direct_edit)
        layout.addLayout(form)

        self.run_button = QPushButton("Update Annexure Links")
        self.run_button.clicked.connect(self.start_processing)
        self.progress_bar = QProgressBar()
        self.progress_bar.setRange(0, 100)
        self.status_label = QLabel("Ready")
        self.log_box = QPlainTextEdit()
        self.log_box.setReadOnly(True)
        layout.addWidget(self.run_button)
        layout.addWidget(self.progress_bar)
        layout.addWidget(self.status_label)
        layout.addWidget(self.log_box, 1)

    def path_row(self, edit: QLineEdit, handler: Callable[[], None]) -> QWidget:
        widget = QWidget()
        row = QHBoxLayout(widget)
        row.setContentsMargins(0, 0, 0, 0)
        button = QPushButton("Browse...")
        button.clicked.connect(handler)
        row.addWidget(edit, 1)
        row.addWidget(button)
        return widget

    def pick_input(self) -> None:
        selected, _ = QFileDialog.getOpenFileName(
            self, "Select PowerPoint", "", "PowerPoint (*.pptx *.pptm)"
        )
        if selected:
            path = Path(selected)
            self.input_edit.setText(str(path))
            if not self.output_edit.text().strip():
                self.output_edit.setText(str(path.parent))

    def pick_output(self) -> None:
        selected = QFileDialog.getExistingDirectory(
            self, "Select Output Folder", self.output_edit.text().strip()
        )
        if selected:
            self.output_edit.setText(selected)

    def validate_inputs(self) -> tuple[Path, Path, str, str]:
        input_text = self.input_edit.text().strip()
        output_text = self.output_edit.text().strip()
        if not input_text:
            raise ValueError("Select an input PowerPoint.")
        input_ppt = Path(input_text)
        if not input_ppt.is_file() or input_ppt.suffix.lower() not in {".pptx", ".pptm"}:
            raise ValueError("Select a valid .pptx or .pptm file.")
        if not output_text:
            raise ValueError("Select an output folder.")
        folder = Path(output_text)
        folder.mkdir(parents=True, exist_ok=True)
        return (
            input_ppt, folder,
            extract_plain_url(self.regular_edit.text(), "Regular/WDP"),
            extract_plain_url(self.direct_edit.text(), "Direct/ALL"),
        )

    def set_running(self, running: bool) -> None:
        for widget in (self.run_button, self.input_edit, self.output_edit, self.regular_edit, self.direct_edit):
            widget.setDisabled(running)
        self.status_label.setText("Processing..." if running else "Ready")

    def start_processing(self) -> None:
        try:
            values = self.validate_inputs()
        except Exception as exc:
            QMessageBox.warning(self, "Invalid Input", str(exc))
            return
        self.log_box.clear()
        self.progress_bar.setValue(0)
        self.set_running(True)
        self.thread = QThread(self)
        self.worker = LinkUpdateWorker(*values)
        self.worker.moveToThread(self.thread)
        self.thread.started.connect(self.worker.run)
        self.worker.log.connect(self.log_box.appendPlainText)
        self.worker.progress.connect(self.progress_bar.setValue)
        self.worker.completed.connect(self.processing_completed)
        self.worker.failed.connect(self.processing_failed)
        self.worker.completed.connect(self.thread.quit)
        self.worker.failed.connect(self.thread.quit)
        self.thread.finished.connect(self.cleanup_thread)
        self.thread.start()

    def processing_completed(self, regular: int, direct: int, skipped: int, output: str, log_file: str) -> None:
        self.set_running(False)
        self.progress_bar.setValue(100)
        self.status_label.setText(f"Completed: {regular} Regular, {direct} Direct")
        QMessageBox.information(
            self, "Completed",
            f"Regular links: {regular}\nDirect links: {direct}\nSkipped: {skipped}"
            f"\n\nOutput:\n{output}\n\nLog:\n{log_file}",
        )

    def processing_failed(self, error: str, details: str) -> None:
        self.set_running(False)
        self.status_label.setText("Processing failed")
        self.log_box.appendPlainText("\nERROR DETAILS:\n" + details)
        QMessageBox.critical(self, "Processing Failed", error)

    def cleanup_thread(self) -> None:
        if self.worker is not None:
            self.worker.deleteLater()
        if self.thread is not None:
            self.thread.deleteLater()
        self.worker = None
        self.thread = None

    def closeEvent(self, event: QCloseEvent) -> None:
        if self.thread is not None and self.thread.isRunning():
            QMessageBox.information(self, "Processing", "Please wait until processing completes.")
            event.ignore()
        else:
            event.accept()


def main() -> int:
    app = QApplication(sys.argv)
    app.setStyle("Fusion")
    window = MainWindow()
    window.show()
    return app.exec()


if __name__ == "__main__":
    sys.exit(main())
