"""Update PowerPoint performance tables from individual Axis factsheet workbooks.

Each Excel file is expected to contain one factsheet, normally on a sheet named
"Factsheet". The performance sections are identified by the labels
"Performance - Regular Plan" and "Performance - Direct Plan". Excel stores each
period as Amount followed by Returns; PowerPoint stores CAGR followed by Current
Value, so the updater reverses each pair while writing.

Windows setup:
    py -m pip install pywin32 openpyxl

Picker mode (select one PPT and the folder containing all fund Excel files):
    py update_performance_tables_excel_folder.py

Command line:
    py update_performance_tables_excel_folder.py --ppt input.pptx \
       --excel-folder "C:/Axis Factsheets" --output updated.pptx

PowerPoint must be installed. Formula cells must have cached results.
"""
from __future__ import annotations

import argparse
import logging
import math
import re
import sys
import tkinter as tk
import unicodedata
from dataclasses import dataclass
from pathlib import Path
from tkinter import filedialog, messagebox
from typing import Dict, Iterable, List, Optional, Sequence, Tuple

import pythoncom
import win32com.client as win32
from openpyxl import load_workbook

LOG = logging.getLogger("performance_table_updater")
MSO_GROUP = 6
MSO_TRUE = -1
MSO_TABLE = 19
TARGET_NAMES = {"performanetable", "performancetable"}
FUND_SHAPE_NAME = "fundname"
PPT_ROWS = 5
PPT_COLS = 9
PERIODS = ("1 YEAR", "3 YEAR", "5 YEAR", "SINCE INCEPTION")

FUND_ALIASES = {
    "FLEXI": "AXIS FLEXI CAP FUND", "FLEXI CAP": "AXIS FLEXI CAP FUND",
    "FOCUS": "AXIS FOCUSED FUND", "FOCUSED": "AXIS FOCUSED FUND",
    "LARGE MID": "AXIS LARGE AND MID CAP FUND", "LARGE AND MID": "AXIS LARGE AND MID CAP FUND",
    "LARGE MID CAP": "AXIS LARGE AND MID CAP FUND", "LARGE": "AXIS LARGE CAP FUND",
    "LARGE CAP": "AXIS LARGE CAP FUND", "MID": "AXIS MIDCAP FUND",
    "MID CAP": "AXIS MIDCAP FUND", "MIDCAP": "AXIS MIDCAP FUND",
    "MOMENTUM": "AXIS MOMENTUM FUND", "INNOVATION": "AXIS INNOVATION FUND",
    "MULTICAP": "AXIS MULTICAP FUND", "MULTI CAP": "AXIS MULTICAP FUND",
    "MANUFACTURING": "AXIS INDIA MANUFACTURING FUND",
    "INDIA MANUFACTURING": "AXIS INDIA MANUFACTURING FUND",
    "SMALLCAP": "AXIS SMALL CAP FUND", "SMALL CAP": "AXIS SMALL CAP FUND",
    "QUANT": "AXIS QUANT FUND", "SERVICES": "AXIS SERVICES OPPORTUNITIES FUND",
    "SERVICES OPPORTUNITIES": "AXIS SERVICES OPPORTUNITIES FUND",
    "ELSS": "AXIS ELSS TAX SAVER FUND", "ELSS TAX SAVER": "AXIS ELSS TAX SAVER FUND",
}


@dataclass
class PerformanceBlock:
    workbook: str
    sheet: str
    fund_key: str
    fund_display: str
    plan: str
    values: List[List[str]]
    source_cells: List[List[str]]


def clean(value: object) -> str:
    return re.sub(r"\s+", " ", str(value or "").replace("\r", " ").replace("\n", " ")).strip()


def plan_text(value: object) -> str:
    text = unicodedata.normalize("NFKD", clean(value)).upper()
    return re.sub(r"[^A-Z0-9]+", " ", text)


def detect_plan(value: object) -> Optional[str]:
    text = plan_text(value)
    if re.search(r"\bDIRECT\b|\bDIR\b", text):
        return "direct"
    if re.search(r"\bREGULAR\b|\bREG\b", text):
        return "regular"
    return None


def normalise_fund(value: object) -> str:
    text = unicodedata.normalize("NFKD", clean(value)).replace("’", "'")
    text = text.replace("&", " AND ").upper().replace("'", "")
    text = re.sub(
        r"\bDIRECT\b|\bDIR\b|\bREGULAR\b|\bREG\b|\bPLAN\b|\bGROWTH\b|\bOPTION\b|"
        r"\bIDCW\b|\bFUND OF FUND\b|\bFUND OF FUNDS\b", " ", text)
    text = re.sub(r"[^A-Z0-9]+", " ", text)
    text = " ".join(text.split())
    return FUND_ALIASES.get(text, text)


def period_name(value: object) -> Optional[str]:
    text = plan_text(value)
    if "SINCE INCEPTION" in text:
        return "SINCE INCEPTION"
    for years in (1, 3, 5, 10):
        if re.search(rf"\b{years}\s*YEARS?\b", text):
            return f"{years} YEAR"
    return None


def metric_kind(value: object) -> Optional[str]:
    text = plan_text(value)
    if "RETURN" in text or "CAGR" in text:
        return "return"
    if "AMOUNT" in text or "CURRENT VALUE" in text or "INVESTMENT" in text:
        return "amount"
    return None


def display_value(value: object, number_format: str = "General", metric: Optional[str] = None) -> str:
    if value is None:
        return ""
    if isinstance(value, str):
        text = clean(value)
        return "NA" if text.upper() in {"NA", "N/A", "-", "–", "—"} else text
    if isinstance(value, bool):
        return str(value)
    if isinstance(value, (int, float)):
        number = float(value)
        if math.isnan(number) or math.isinf(number):
            return ""
        # Axis return columns commonly contain 8.738 to mean 8.738%, even when
        # the Excel number format is General. Explicit metric classification wins.
        if metric == "return":
            if "%" in str(number_format or ""):
                number *= 100
            return f"{number:.2f}%"
        if "%" in str(number_format or ""):
            match = re.search(r"\.([0#]+)%", str(number_format))
            decimals = len(match.group(1)) if match else 2
            return f"{number * 100:.{decimals}f}%"
        if metric == "amount" or abs(number - round(number)) < 1e-9:
            return f"{int(round(number)):,}"
        return f"{number:,.2f}"
    return clean(value)


def find_section_headers(ws) -> List[Tuple[int, str]]:
    sections: List[Tuple[int, str]] = []
    for row in range(1, ws.max_row + 1):
        for col in range(1, min(ws.max_column, 4) + 1):
            text = plan_text(ws.cell(row, col).value)
            if "PERFORMANCE" not in text:
                continue
            plan = detect_plan(text)
            if plan:
                sections.append((row, plan))
                break
    return sections


def map_explicit_columns(ws, header_row: int) -> Tuple[int, Dict[str, Tuple[int, int]]]:
    """Return label column and period -> (return column, amount column).

    The individual Axis workbook has explicit headers such as:
      1 Year_Amount in Rs. | 1 Year_Returns (%)
    PowerPoint expects the opposite order:
      CAGR (%) | Current Value of Investment
    """
    period_parts: Dict[str, Dict[str, int]] = {}
    label_col: Optional[int] = None
    for col in range(1, ws.max_column + 1):
        value = ws.cell(header_row, col).value
        text = plan_text(value)
        if "FUND" in text and "BENCHMARK" in text:
            label_col = col
        period = period_name(value)
        kind = metric_kind(value)
        if period and kind:
            period_parts.setdefault(period, {})[kind] = col

    missing = [p for p in PERIODS if not {"return", "amount"}.issubset(period_parts.get(p, {}))]
    if label_col is None or missing:
        raise ValueError(f"Row {header_row}: missing label/metric headers: {', '.join(missing) or 'Fund / Benchmark'}")
    return label_col, {p: (period_parts[p]["return"], period_parts[p]["amount"]) for p in PERIODS}


def extract_sheet_blocks(ws, workbook_name: str) -> List[PerformanceBlock]:
    blocks: List[PerformanceBlock] = []
    for header_row, plan in find_section_headers(ws):
        label_col, metric_map = map_explicit_columns(ws, header_row)
        values: List[List[str]] = []
        addresses: List[List[str]] = []
        for source_row in range(header_row + 1, header_row + 4):
            label_cell = ws.cell(source_row, label_col)
            label = clean(label_cell.value)
            if not label:
                break
            row_values = [display_value(label_cell.value, label_cell.number_format)]
            row_cells = [label_cell.coordinate]
            for period in PERIODS:
                return_col, amount_col = metric_map[period]
                for col, kind in ((return_col, "return"), (amount_col, "amount")):
                    cell = ws.cell(source_row, col)
                    row_values.append(display_value(cell.value, cell.number_format, kind) or "NA")
                    row_cells.append(cell.coordinate)
            values.append(row_values)
            addresses.append(row_cells)

        if len(values) != 3 or not all(len(row) == PPT_COLS for row in values):
            raise ValueError(f"{workbook_name} / {ws.title}: {plan} block is not 3 x 9")
        fund_display = values[0][0]
        fund_key = normalise_fund(fund_display)
        if not fund_key:
            raise ValueError(f"{workbook_name} / {ws.title}: fund name is blank")
        blocks.append(PerformanceBlock(workbook_name, ws.title, fund_key, fund_display,
                                       plan, values, addresses))
    return blocks


def workbook_blocks(workbook_path: Path) -> List[PerformanceBlock]:
    formulas = load_workbook(workbook_path, read_only=False, data_only=False)
    cached = load_workbook(workbook_path, read_only=False, data_only=True)
    try:
        all_blocks: List[PerformanceBlock] = []
        errors: List[str] = []
        preferred = ["Factsheet"] if "Factsheet" in cached.sheetnames else cached.sheetnames
        for name in preferred:
            try:
                blocks = extract_sheet_blocks(cached[name], workbook_path.name)
            except ValueError as exc:
                errors.append(str(exc))
                continue
            for block in blocks:
                for row_cells in block.source_cells:
                    for address in row_cells[1:]:
                        formula_cell = formulas[name][address]
                        cached_cell = cached[name][address]
                        if formula_cell.data_type == "f" and cached_cell.value is None:
                            errors.append(f"{workbook_path.name} / {name}!{address} has no cached formula result")
            all_blocks.extend(blocks)
        if errors and not all_blocks:
            raise ValueError("\n".join(errors[:25]))
        if not all_blocks:
            raise ValueError(f"{workbook_path.name}: no Regular/Direct performance sections found")
        return all_blocks
    finally:
        formulas.close()
        cached.close()


def load_sources(workbook_paths: Sequence[Path]) -> Dict[Tuple[str, str], PerformanceBlock]:
    sources: Dict[Tuple[str, str], PerformanceBlock] = {}
    errors: List[str] = []
    for path in workbook_paths:
        try:
            blocks = workbook_blocks(path)
        except Exception as exc:
            errors.append(str(exc))
            continue
        for block in blocks:
            key = (block.fund_key, block.plan)
            if key in sources:
                old = sources[key]
                errors.append(
                    f"Duplicate {block.plan} source for {block.fund_key}: "
                    f"{old.workbook}/{old.sheet}, {block.workbook}/{block.sheet}")
            else:
                sources[key] = block
    if errors:
        raise ValueError("\n".join(errors[:25]))
    if not sources:
        raise ValueError("No performance blocks were loaded from the selected Excel files")
    LOG.info("Loaded %d fund/plan blocks from %d workbook(s)", len(sources), len(workbook_paths))
    return sources


def iter_shapes(shapes) -> Iterable[object]:
    for index in range(1, shapes.Count + 1):
        shape = shapes.Item(index)
        yield shape
        if shape.Type == MSO_GROUP:
            yield from iter_shapes(shape.GroupItems)


def named_shapes(slide, names: Sequence[str]) -> List[object]:
    wanted = {name.casefold() for name in names}
    return [shape for shape in iter_shapes(slide.Shapes) if str(shape.Name).casefold() in wanted]


def shape_text(shape) -> str:
    try:
        if shape.HasTextFrame == MSO_TRUE and shape.TextFrame.HasText == MSO_TRUE:
            return clean(shape.TextFrame.TextRange.Text)
    except Exception:
        pass
    return ""


def find_slide_fund(slides, slide_no: int) -> Optional[str]:
    for index in range(slide_no, 0, -1):
        for shape in named_shapes(slides.Item(index), [FUND_SHAPE_NAME]):
            text = shape_text(shape)
            if text:
                return text
    return None


def table_matrix(table) -> List[List[str]]:
    result = []
    for row in range(1, table.Rows.Count + 1):
        current = []
        for col in range(1, table.Columns.Count + 1):
            try:
                current.append(clean(table.Cell(row, col).Shape.TextFrame.TextRange.Text))
            except Exception:
                current.append("")
        result.append(current)
    return result


def detect_ppt_plan(table) -> Optional[str]:
    matrix = table_matrix(table)
    for row in matrix[2:]:
        found = detect_plan(" ".join(row))
        if found:
            return found
    return detect_plan(" ".join(value for row in matrix for value in row))


def token_score(left: str, right: str) -> float:
    a, b = set(left.split()), set(right.split())
    return 2.0 * len(a & b) / (len(a) + len(b)) if a and b else 0.0


def resolve_source(fund_text: str, plan: str,
                   sources: Dict[Tuple[str, str], PerformanceBlock]) -> Tuple[Optional[PerformanceBlock], str]:
    wanted = normalise_fund(fund_text)
    candidates = [(key, block) for (key, p), block in sources.items() if p == plan]
    for key, block in candidates:
        if key == wanted:
            return block, "exact"
    contained = [(key, block) for key, block in candidates if wanted and (wanted in key or key in wanted)]
    if len(contained) == 1:
        return contained[0][1], "containment"
    ranked = sorted(((token_score(wanted, key), key, block) for key, block in candidates), reverse=True)
    if ranked:
        best = ranked[0]
        second = ranked[1][0] if len(ranked) > 1 else 0.0
        if best[0] >= 0.72 and best[0] - second >= 0.08:
            return best[2], f"token score {best[0]:.2f}"
    return None, "no unambiguous match"


def update_table(shape, values: Sequence[Sequence[str]]) -> int:
    if shape.Type != MSO_TABLE and getattr(shape, "HasTable", 0) != MSO_TRUE:
        raise TypeError(f"Shape {shape.Name!r} is not a PowerPoint table")
    table = shape.Table
    if table.Rows.Count < PPT_ROWS or table.Columns.Count < PPT_COLS:
        raise ValueError(f"Table is {table.Rows.Count}x{table.Columns.Count}; at least 5x9 is required")
    changed = 0
    # Preserve PPT column 1 labels. Write CAGR then Current Value for each period.
    for source_row in range(3):
        for source_col in range(1, PPT_COLS):
            table.Cell(source_row + 3, source_col + 1).Shape.TextFrame.TextRange.Text = values[source_row][source_col]
            changed += 1
    return changed


def update_presentation(ppt_path: Path, excel_paths: Sequence[Path], output_path: Path) -> Tuple[int, int]:
    sources = load_sources(excel_paths)
    pythoncom.CoInitialize()
    app = presentation = None
    updated = skipped = 0
    try:
        app = win32.DispatchEx("PowerPoint.Application")
        app.Visible = True
        presentation = app.Presentations.Open(str(ppt_path.resolve()), ReadOnly=False,
                                              Untitled=False, WithWindow=False)
        slides = presentation.Slides
        for slide_no in range(1, slides.Count + 1):
            for shape in named_shapes(slides.Item(slide_no), list(TARGET_NAMES)):
                try:
                    if shape.Type != MSO_TABLE and getattr(shape, "HasTable", 0) != MSO_TRUE:
                        raise TypeError("Named shape is not a table")
                    plan = detect_ppt_plan(shape.Table)
                    if not plan:
                        raise ValueError("Regular or Direct was not found in the PowerPoint table")
                    fund_text = find_slide_fund(slides, slide_no)
                    if not fund_text:
                        raise ValueError("No preceding FundName shape contains a fund name")
                    source, method = resolve_source(fund_text, plan, sources)
                    if source is None:
                        raise ValueError(f"No {plan.title()} source matched {fund_text!r}")
                    changed = update_table(shape, source.values)
                    updated += 1
                    LOG.info("Slide %d: %s %s updated from %s/%s (%s, %d cells)",
                             slide_no, fund_text, plan, source.workbook, source.sheet, method, changed)
                except Exception as exc:
                    skipped += 1
                    LOG.error("Slide %d table %s skipped: %s", slide_no, shape.Name, exc)
        output_path.parent.mkdir(parents=True, exist_ok=True)
        presentation.SaveAs(str(output_path.resolve()))
        return updated, skipped
    finally:
        if presentation is not None:
            presentation.Close()
        if app is not None:
            app.Quit()
        pythoncom.CoUninitialize()


def excel_files_in_folder(folder: Path, recursive: bool = False) -> List[Path]:
    """Return usable Excel factsheets from a folder in stable name order."""
    iterator = folder.rglob("*") if recursive else folder.glob("*")
    files = [
        path for path in iterator
        if path.is_file()
        and path.suffix.lower() in {".xlsx", ".xlsm"}
        and not path.name.startswith("~$")
    ]
    return sorted(files, key=lambda path: path.name.casefold())


def choose_inputs() -> Optional[Tuple[Path, Path, Path]]:
    root = tk.Tk(); root.withdraw(); root.attributes("-topmost", True)
    try:
        ppt = filedialog.askopenfilename(parent=root, title="Select PowerPoint template",
                                         filetypes=[("PowerPoint", "*.pptx")])
        if not ppt:
            return None
        excel_folder = filedialog.askdirectory(
            parent=root,
            title="Select folder containing individual Axis fund Excel files",
            initialdir=str(Path(ppt).parent))
        if not excel_folder:
            return None
        output = filedialog.asksaveasfilename(parent=root, title="Save updated PowerPoint as",
                                               initialdir=str(Path(ppt).parent),
                                               initialfile=f"{Path(ppt).stem} - Updated Performance.pptx",
                                               defaultextension=".pptx",
                                               filetypes=[("PowerPoint", "*.pptx")])
        if not output:
            return None
        return Path(ppt), Path(excel_folder), Path(output)
    finally:
        root.destroy()


def show_message(kind: str, title: str, text: str) -> None:
    root = tk.Tk(); root.withdraw(); root.attributes("-topmost", True)
    try:
        getattr(messagebox, kind)(title, text, parent=root)
    finally:
        root.destroy()


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Update PPT performance tables from a folder of Axis factsheet files")
    parser.add_argument("--ppt", type=Path)
    parser.add_argument("--excel-folder", type=Path)
    parser.add_argument("--output", type=Path)
    parser.add_argument("--recursive", action="store_true",
                        help="Also scan subfolders under --excel-folder")
    parser.add_argument("--log-level", choices=["DEBUG", "INFO", "WARNING", "ERROR"], default="INFO")
    args = parser.parse_args()
    supplied = [args.ppt, args.excel_folder, args.output]
    if any(item is not None for item in supplied) and not all(item is not None for item in supplied):
        parser.error("Supply --ppt, --excel-folder and --output together, or none for picker mode")
    return args


def main() -> int:
    args = parse_args()
    logging.basicConfig(level=getattr(logging, args.log_level), format="%(levelname)s: %(message)s")
    graphical = not all([args.ppt, args.excel_folder, args.output])
    try:
        selected = choose_inputs() if graphical else (args.ppt, args.excel_folder, args.output)
        if selected is None:
            return 0
        ppt, excel_folder, output = selected
        if not ppt.is_file():
            raise FileNotFoundError(f"PowerPoint not found: {ppt}")
        if not excel_folder.is_dir():
            raise NotADirectoryError(f"Excel folder not found: {excel_folder}")
        excels = excel_files_in_folder(excel_folder, recursive=(args.recursive if not graphical else False))
        if not excels:
            scope = "folder and subfolders" if (args.recursive if not graphical else False) else "folder"
            raise FileNotFoundError(f"No .xlsx or .xlsm files found in the selected {scope}: {excel_folder}")
        if output.resolve() == ppt.resolve():
            raise ValueError("Output must be different from the source PowerPoint")
        updated, skipped = update_presentation(ppt, excels, output)
        text = (f"Completed.\n\nUpdated: {updated}\nSkipped: {skipped}"
                f"\nExcel folder: {excel_folder}\nExcel files scanned: {len(excels)}"
                f"\n\nOutput:\n{output}")
        LOG.info(text.replace("\n", " "))
        if graphical:
            show_message("showinfo", "Performance update complete", text)
        return 0 if updated else 2
    except Exception as exc:
        LOG.exception("Update failed")
        if graphical:
            show_message("showerror", "Performance update failed", str(exc))
        return 1



# ---------------- GUI and tolerant folder-processing overrides ----------------
import queue
import threading
from datetime import datetime
from tkinter import ttk


def period_name(value: object) -> Optional[str]:
    """Recognise headers such as 1Year_Amount, 3 Years Returns and Since_Inception."""
    text = plan_text(value).replace("YEARS", "YEAR")
    compact = text.replace(" ", "")
    if "SINCEINCEPTION" in compact:
        return "SINCE INCEPTION"
    for years in (1, 3, 5, 10):
        if f"{years}YEAR" in compact:
            return f"{years} YEAR"
    return None


def map_explicit_columns(ws, header_row: int) -> Tuple[int, Dict[str, Tuple[int, int]]]:
    """Map period columns even when year/metric text is split or inconsistently spaced."""
    period_parts: Dict[str, Dict[str, int]] = {}
    label_col = None
    for col in range(1, ws.max_column + 1):
        raw = ws.cell(header_row, col).value
        text = plan_text(raw)
        if label_col is None and "FUND" in text and "BENCHMARK" in text:
            label_col = col
        period = period_name(raw)
        kind = metric_kind(raw)
        if period and kind:
            period_parts.setdefault(period, {})[kind] = col

    # Fallback for Axis layouts: locate each period heading and use its two columns.
    # Amount is first and Return is second in Excel; PowerPoint receives Return then Amount.
    for col in range(1, ws.max_column + 1):
        period = period_name(ws.cell(header_row, col).value)
        if not period or {"return", "amount"}.issubset(period_parts.get(period, {})):
            continue
        first, second = col, col + 1
        first_kind = metric_kind(ws.cell(header_row, first).value)
        second_kind = metric_kind(ws.cell(header_row, second).value) if second <= ws.max_column else None
        parts = period_parts.setdefault(period, {})
        if first_kind:
            parts[first_kind] = first
        if second_kind:
            parts[second_kind] = second
        if "amount" not in parts:
            parts["amount"] = first
        if "return" not in parts and second <= ws.max_column:
            parts["return"] = second

    if label_col is None:
        # In the supplied Axis files the label column is immediately before 1-year amount.
        one_year = period_parts.get("1 YEAR", {})
        anchor = one_year.get("amount") or one_year.get("return")
        if anchor:
            label_col = anchor - 1
    missing = [p for p in PERIODS if not {"return", "amount"}.issubset(period_parts.get(p, {}))]
    if label_col is None or missing:
        raise ValueError(f"Row {header_row}: missing label/metric headers: {', '.join(missing) or 'Fund / Benchmark'}")
    return label_col, {p: (period_parts[p]["return"], period_parts[p]["amount"]) for p in PERIODS}


def collect_ppt_requirements(slides) -> Tuple[List[Tuple[int, object, str, str]], set]:
    targets = []
    fund_keys = set()
    for slide_no in range(1, slides.Count + 1):
        for shape in named_shapes(slides.Item(slide_no), list(TARGET_NAMES)):
            try:
                plan = detect_ppt_plan(shape.Table)
                fund_text = find_slide_fund(slides, slide_no)
                if plan and fund_text:
                    key = normalise_fund(fund_text)
                    targets.append((slide_no, shape, plan, fund_text))
                    fund_keys.add(key)
            except Exception:
                continue
    return targets, fund_keys


def filename_might_match(path: Path, wanted_keys: set) -> bool:
    key = normalise_fund(path.stem)
    if not key:
        return True
    if any(key == wanted or key in wanted or wanted in key or token_score(key, wanted) >= 0.72
           for wanted in wanted_keys):
        return True
    # Generic names are parsed because the actual fund may only appear inside the workbook.
    generic = {"FACTSHEET", "FUND", "AXIS", "DATA", "PERFORMANCE"}
    return len(set(key.split()) - generic) <= 1


def update_presentation_with_progress(ppt_path: Path, excel_paths: Sequence[Path], output_path: Path,
                                      progress=None, log=None) -> Tuple[int, int, int]:
    progress = progress or (lambda current, total, message: None)
    log = log or (lambda message, level="INFO": None)
    pythoncom.CoInitialize()
    app = presentation = None
    updated = skipped_tables = ignored_files = 0
    try:
        progress(0, max(len(excel_paths) + 2, 1), "Opening PowerPoint")
        app = win32.DispatchEx("PowerPoint.Application")
        app.Visible = True
        presentation = app.Presentations.Open(str(ppt_path.resolve()), ReadOnly=False,
                                              Untitled=False, WithWindow=False)
        targets, wanted_keys = collect_ppt_requirements(presentation.Slides)
        if not targets:
            raise ValueError("No usable PerformanceTable/PerformaneTable with FundName was found in the PowerPoint")
        log(f"PowerPoint contains {len(targets)} performance table(s) for {len(wanted_keys)} fund(s).")

        sources: Dict[Tuple[str, str], PerformanceBlock] = {}
        total = len(excel_paths) + 2
        for index, path in enumerate(excel_paths, 1):
            progress(index, total, f"Reading {path.name}")
            if not filename_might_match(path, wanted_keys):
                ignored_files += 1
                log(f"IGNORED: {path.name} (fund filename not present in PowerPoint)", "SKIP")
                continue
            try:
                blocks = workbook_blocks(path)
            except Exception as exc:
                # A malformed or unrelated file must not stop the whole folder run.
                ignored_files += 1
                log(f"SKIPPED: {path.name} ({exc})", "WARNING")
                continue
            matched = 0
            for block in blocks:
                if not any(block.fund_key == wanted or block.fund_key in wanted or wanted in block.fund_key
                           or token_score(block.fund_key, wanted) >= 0.72 for wanted in wanted_keys):
                    continue
                key = (block.fund_key, block.plan)
                if key in sources:
                    log(f"DUPLICATE IGNORED: {path.name}, {block.plan}, {block.fund_display}", "WARNING")
                    continue
                sources[key] = block
                matched += 1
            if matched:
                log(f"LOADED: {path.name} ({matched} matching plan block(s))")
            else:
                ignored_files += 1
                log(f"IGNORED: {path.name} (workbook fund not present in PowerPoint)", "SKIP")

        progress(len(excel_paths) + 1, total, "Updating PowerPoint tables")
        for slide_no, shape, plan, fund_text in targets:
            source, method = resolve_source(fund_text, plan, sources)
            if source is None:
                skipped_tables += 1
                log(f"TABLE SKIPPED: slide {slide_no}, {fund_text}, {plan} (no matching Excel data)", "WARNING")
                continue
            try:
                changed = update_table(shape, source.values)
                updated += 1
                log(f"UPDATED: slide {slide_no}, {fund_text}, {plan} from {source.workbook} ({changed} cells)")
            except Exception as exc:
                skipped_tables += 1
                log(f"TABLE SKIPPED: slide {slide_no}, {fund_text}, {plan} ({exc})", "ERROR")

        progress(total, total, "Saving updated PowerPoint")
        output_path.parent.mkdir(parents=True, exist_ok=True)
        presentation.SaveAs(str(output_path.resolve()))
        log(f"SAVED: {output_path}")
        return updated, skipped_tables, ignored_files
    finally:
        if presentation is not None:
            presentation.Close()
        if app is not None:
            app.Quit()
        pythoncom.CoUninitialize()


class GuiLogHandler(logging.Handler):
    def __init__(self, sink):
        super().__init__()
        self.sink = sink
    def emit(self, record):
        self.sink(self.format(record), record.levelname)


class PerformanceUpdaterGUI:
    def __init__(self):
        self.root = tk.Tk()
        self.root.title("Axis Performance Table Updater")
        self.root.geometry("900x650")
        self.root.minsize(720, 520)
        self.events = queue.Queue()
        self.ppt_var = tk.StringVar()
        self.folder_var = tk.StringVar()
        self.output_var = tk.StringVar()
        self.recursive_var = tk.BooleanVar(value=False)
        self.status_var = tk.StringVar(value="Select the PowerPoint and Excel folder.")
        self._build()
        self.root.after(100, self._poll)

    def _build(self):
        outer = ttk.Frame(self.root, padding=14)
        outer.pack(fill="both", expand=True)
        ttk.Label(outer, text="Axis Performance Table Updater", font=("Segoe UI", 16, "bold")).pack(anchor="w")
        ttk.Label(outer, text="Updates only funds found in the selected PowerPoint. Unrelated or invalid Excel files are logged and ignored.").pack(anchor="w", pady=(2, 14))

        form = ttk.Frame(outer)
        form.pack(fill="x")
        self._row(form, 0, "PowerPoint", self.ppt_var, self._browse_ppt)
        self._row(form, 1, "Excel folder", self.folder_var, self._browse_folder)
        self._row(form, 2, "Output PowerPoint", self.output_var, self._browse_output)
        form.columnconfigure(1, weight=1)
        ttk.Checkbutton(outer, text="Include Excel files in subfolders", variable=self.recursive_var).pack(anchor="w", pady=(10, 8))

        buttons = ttk.Frame(outer)
        buttons.pack(fill="x")
        self.start_btn = ttk.Button(buttons, text="Start update", command=self._start)
        self.start_btn.pack(side="left")
        ttk.Button(buttons, text="Clear log", command=lambda: self.log_text.delete("1.0", "end")).pack(side="left", padx=8)
        ttk.Button(buttons, text="Open output folder", command=self._open_output_folder).pack(side="left")

        self.progress = ttk.Progressbar(outer, mode="determinate")
        self.progress.pack(fill="x", pady=(14, 4))
        ttk.Label(outer, textvariable=self.status_var).pack(anchor="w")

        log_frame = ttk.LabelFrame(outer, text="Run log", padding=6)
        log_frame.pack(fill="both", expand=True, pady=(12, 0))
        self.log_text = tk.Text(log_frame, wrap="word", state="normal", font=("Consolas", 9))
        scroll = ttk.Scrollbar(log_frame, orient="vertical", command=self.log_text.yview)
        self.log_text.configure(yscrollcommand=scroll.set)
        self.log_text.pack(side="left", fill="both", expand=True)
        scroll.pack(side="right", fill="y")

    def _row(self, parent, row, label, variable, command):
        ttk.Label(parent, text=label, width=18).grid(row=row, column=0, sticky="w", pady=4)
        ttk.Entry(parent, textvariable=variable).grid(row=row, column=1, sticky="ew", padx=6, pady=4)
        ttk.Button(parent, text="Browse...", command=command).grid(row=row, column=2, pady=4)

    def _browse_ppt(self):
        value = filedialog.askopenfilename(title="Select PowerPoint", filetypes=[("PowerPoint", "*.pptx")])
        if value:
            self.ppt_var.set(value)
            if not self.output_var.get():
                p = Path(value)
                self.output_var.set(str(p.with_name(p.stem + " - Updated Performance.pptx")))

    def _browse_folder(self):
        value = filedialog.askdirectory(title="Select folder containing fund Excel files")
        if value:
            self.folder_var.set(value)

    def _browse_output(self):
        value = filedialog.asksaveasfilename(title="Save updated PowerPoint", defaultextension=".pptx",
                                             filetypes=[("PowerPoint", "*.pptx")])
        if value:
            self.output_var.set(value)

    def _open_output_folder(self):
        import os
        folder = Path(self.output_var.get()).parent
        if folder.is_dir():
            os.startfile(str(folder))

    def _emit(self, message, level="INFO"):
        self.events.put(("log", datetime.now().strftime("%H:%M:%S"), level, str(message)))

    def _progress(self, current, total, message):
        self.events.put(("progress", current, total, message))

    def _start(self):
        if not self.ppt_var.get().strip() or not self.folder_var.get().strip() or not self.output_var.get().strip():
            messagebox.showerror("Invalid input", "Select a valid PowerPoint, Excel folder and output file.")
            return
        ppt, folder, output = map(Path, (self.ppt_var.get(), self.folder_var.get(), self.output_var.get()))
        if not ppt.is_file() or not folder.is_dir():
            messagebox.showerror("Invalid input", "Select a valid PowerPoint, Excel folder and output file.")
            return
        if output.resolve() == ppt.resolve():
            messagebox.showerror("Invalid output", "Output must be different from the source PowerPoint.")
            return
        excels = excel_files_in_folder(folder, self.recursive_var.get())
        if not excels:
            messagebox.showerror("No Excel files", "No .xlsx or .xlsm files were found in the selected folder.")
            return
        self.start_btn.configure(state="disabled")
        self.progress["value"] = 0
        self._emit(f"Starting. Found {len(excels)} Excel file(s) in {folder}.")
        log_path = output.with_suffix(".log")

        def worker():
            lines = []
            def both(message, level="INFO"):
                line = f"{datetime.now():%Y-%m-%d %H:%M:%S} [{level}] {message}"
                lines.append(line)
                self._emit(message, level)
            try:
                result = update_presentation_with_progress(ppt, excels, output, self._progress, both)
                log_path.write_text("\n".join(lines), encoding="utf-8")
                self.events.put(("done", result, str(output), str(log_path)))
            except Exception as exc:
                both(f"FAILED: {exc}", "ERROR")
                log_path.write_text("\n".join(lines), encoding="utf-8")
                self.events.put(("failed", str(exc), str(log_path)))
        threading.Thread(target=worker, daemon=True).start()

    def _poll(self):
        try:
            while True:
                event = self.events.get_nowait()
                if event[0] == "log":
                    _, stamp, level, message = event
                    self.log_text.insert("end", f"{stamp} [{level}] {message}\n")
                    self.log_text.see("end")
                elif event[0] == "progress":
                    _, current, total, message = event
                    self.progress["maximum"] = max(total, 1)
                    self.progress["value"] = current
                    self.status_var.set(f"{message} ({current}/{total})")
                elif event[0] == "done":
                    _, result, output, log_path = event
                    updated, skipped, ignored = result
                    self.start_btn.configure(state="normal")
                    self.status_var.set("Completed")
                    messagebox.showinfo("Performance update complete",
                                        f"Updated tables: {updated}\nSkipped tables: {skipped}\nIgnored Excel files: {ignored}\n\nOutput: {output}\nLog: {log_path}")
                elif event[0] == "failed":
                    _, error, log_path = event
                    self.start_btn.configure(state="normal")
                    self.status_var.set("Failed")
                    messagebox.showerror("Performance update failed", f"{error}\n\nLog: {log_path}")
        except queue.Empty:
            pass
        self.root.after(100, self._poll)

    def run(self):
        self.root.mainloop()


def gui_main() -> int:
    PerformanceUpdaterGUI().run()
    return 0


if __name__ == "__main__":
    # No arguments opens the full GUI; command-line arguments keep automation support.
    if len(sys.argv) == 1:
        sys.exit(gui_main())
    sys.exit(main())
