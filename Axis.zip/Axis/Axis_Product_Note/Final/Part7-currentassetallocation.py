# -*- coding: utf-8 -*-
"""
CURRENT ASSET ALLOCATION UPDATE - COMPLETE LOGIC
================================================

EXCEL LOGIC
-----------
1. Open the hardcoded .xls workbook through Microsoft Excel Win32 COM in read-only mode.
2. Treat the first worksheet as INDEX.
3. Find the INDEX headers "Scheme Name" and "Short Name" dynamically.
4. Build a mapping: normalized Scheme Name -> Short Name.
5. For a matched PowerPoint FundName, find the Excel fund sheet whose name starts with
   the mapped Short Name.
6. In that fund sheet, find "COMPOSITION BY ASSET".
7. Read consecutive label/value pairs below that heading, skipping leading blank rows.
8. Convert decimal values such as 0.7118 to 71.18%. A real zero remains 0.00%.

POWERPOINT LOGIC
----------------
1. Open the hardcoded PowerPoint through Microsoft PowerPoint Win32 COM.
2. Process slides and shapes in their existing order, including shapes inside groups.
3. FIRST scan the entire slide for FundName before processing any table. This fixes slide 1,
   where the table appears earlier than FundName in PowerPoint z-order.
4. Match FundName against Excel INDEX and keep the match active for the slide and later slides.
5. Accept BOTH target table spellings found in the template:
      - CurrentAssetAllocation   (slides 9, 13, 17, 21)
      - CurrectAssetAllocation   (slides 1 and 5; template spelling)
6. Use TextFrame2.TextRange for table-cell reading/writing. This avoids the unreliable
   TextFrame.TextRange behaviour that caused column-two values to overwrite column one.
7. Detect zero-height or merged blank spacer rows and DO NOT write into those rows.
8. Existing non-spacer rows, including dummy text such as Monil and old zero values,
   are cleared and reused.
9. If Excel contains more records than safe existing rows, add normal rows at the bottom.
10. Write fresh Excel labels into column 1 and fresh values into column 2.
11. Preserve formatting, but explicitly force inserted font colour to white and vertical
    alignment to middle. Percentage/value cells are also horizontally center aligned.
    Preserve font name, font size, bold, italic, margins, fill, borders,
    row height, table position, and table dimensions as far as PowerPoint COM permits.
12. Read every written cell back through TextFrame2 and stop on any mismatch.
13. Save to a new hardcoded PPTX path and create a detailed text log.

REQUIREMENTS
------------
- Windows
- Desktop Microsoft Excel and Microsoft PowerPoint
- pywin32: pip install pywin32
"""

# Import Path for Windows file paths.
from pathlib import Path
# Import regular expressions for normalization.
import re
# Import traceback for detailed error logs.
import traceback
# Import Unicode normalization.
import unicodedata
# Import Microsoft Office Win32 COM support.
import win32com.client as win32

# ----------------------------- HARDCODED PATHS -----------------------------
# Define the source PowerPoint path.
INPUT_PPT_PATH = Path(r"C:\monil\Axis_preet\New Template - Axis Hybrid Funds WDP_DP - Leaflet - Final.pptx")
# Define the source Excel portfolio path.
INPUT_EXCEL_PATH = Path(r"C:\monil\Axis_preet\Portfolios - August 2026.xls")
# Define the output PowerPoint path.
OUTPUT_PPT_PATH = Path(r"C:\monil\Axis_preet\save.pptx")
# Define the processing log path.
LOG_FILE_PATH = Path(r"C:\monil\Axis_preet\current_asset_allocation_update_log.txt")

# ----------------------------- OBJECT SETTINGS -----------------------------
# Define the PowerPoint object containing the fund name.
FUND_OBJECT_NAME = "fundname"
# Define both target-table spellings present in the template.
ASSET_TABLE_OBJECT_NAMES = {"currentassetallocation", "currectassetallocation"}
# Define the Excel INDEX scheme-name header.
INDEX_SCHEME_NAME_HEADER = "Scheme Name"
# Define the Excel INDEX short-name header.
INDEX_SHORT_NAME_HEADER = "Short Name"
# Define the fund-sheet section heading.
ASSET_SECTION_SEARCH_TEXT = "COMPOSITION BY ASSET"
# Define the maximum top rows searched for INDEX headers.
INDEX_HEADER_SEARCH_LIMIT = 20
# Define the maximum blank rows allowed below an asset heading before data starts.
MAX_LEADING_BLANK_ROWS = 10
# Define the Office group shape type.
MSO_GROUP_SHAPE_TYPE = 6
# Define the Office table shape type.
MSO_TABLE_SHAPE_TYPE = 19
# Define Office True.
MSO_TRUE = -1
# Define PPTX SaveAs format.
PP_SAVE_AS_OPEN_XML_PRESENTATION = 24
# Define white Office RGB font colour.
WHITE_RGB = 16777215
# Define TextFrame2 vertical middle alignment.
MSO_ANCHOR_MIDDLE = 3
# Define TextFrame2 horizontal center paragraph alignment.
MSO_ALIGN_CENTER = 2


def clean_text(value):
    # Return blank for a missing value.
    if value is None:
        return ""
    # Convert the value to text.
    text = str(value)
    # Collapse whitespace and line breaks.
    text = re.sub(r"\s+", " ", text)
    # Remove surrounding spaces.
    return text.strip()


def normalize_name(value):
    # Clean the original value.
    text = clean_text(value)
    # Normalize Unicode characters.
    text = unicodedata.normalize("NFKD", text)
    # Normalize apostrophes.
    text = text.replace("’", "'").replace("‘", "'").replace("`", "'")
    # Treat ampersand as the word and.
    text = text.replace("&", " and ")
    # Replace punctuation with spaces.
    text = re.sub(r"[^A-Za-z0-9]+", " ", text)
    # Make matching case-insensitive.
    text = text.lower()
    # Collapse spaces introduced by punctuation removal.
    text = re.sub(r"\s+", " ", text)
    # Return the normalized value.
    return text.strip()


def format_asset_value(value):
    # Attempt numeric percentage formatting.
    try:
        # Convert to a floating-point number.
        number = float(value)
        # Convert decimal fractions to percentage points.
        percentage = number * 100.0 if abs(number) <= 1.0 else number
        # Return exactly two decimals.
        return f"{percentage:.2f}%"
    # Handle non-numeric source values.
    except (TypeError, ValueError):
        # Clean the source text.
        text = clean_text(value)
        # Avoid adding a duplicate percent sign.
        return text if text.endswith("%") else f"{text}%"


def used_range_to_matrix(worksheet):
    # Read the worksheet UsedRange in one operation.
    raw_values = worksheet.UsedRange.Value
    # Return an empty matrix for an empty sheet.
    if raw_values is None:
        return []
    # Convert a one-cell result into a matrix.
    if not isinstance(raw_values, tuple):
        return [[raw_values]]
    # Convert a one-row result into a matrix.
    if raw_values and not isinstance(raw_values[0], tuple):
        return [list(raw_values)]
    # Convert tuple rows to mutable lists.
    return [list(row) for row in raw_values]


def find_index_columns(index_matrix):
    # Normalize the required scheme header.
    scheme_target = normalize_name(INDEX_SCHEME_NAME_HEADER)
    # Normalize the required short-name header.
    short_target = normalize_name(INDEX_SHORT_NAME_HEADER)
    # Search the configured header area.
    for row_index in range(min(INDEX_HEADER_SEARCH_LIMIT, len(index_matrix))):
        # Read the current potential header row.
        row = index_matrix[row_index]
        # Initialize the scheme column.
        scheme_column = None
        # Initialize the short-name column.
        short_column = None
        # Search every cell in this row.
        for column_index, cell_value in enumerate(row):
            # Normalize the current header.
            normalized_cell = normalize_name(cell_value)
            # Store the Scheme Name column.
            if normalized_cell == scheme_target:
                scheme_column = column_index
            # Store the Short Name column.
            if normalized_cell == short_target:
                short_column = column_index
        # Return when both required headers are found.
        if scheme_column is not None and short_column is not None:
            return row_index, scheme_column, short_column
    # Raise a clear layout error.
    raise ValueError('Could not find both "Scheme Name" and "Short Name" in INDEX.')


def build_index_mapping(index_matrix, log_lines):
    # Find INDEX header positions.
    header_row, scheme_column, short_column = find_index_columns(index_matrix)
    # Create the scheme mapping.
    mapping = {}
    # Process INDEX data rows.
    for row_number in range(header_row + 1, len(index_matrix)):
        # Read the current row.
        row = index_matrix[row_number]
        # Skip short rows.
        if max(scheme_column, short_column) >= len(row):
            continue
        # Read the complete scheme name.
        scheme_name = clean_text(row[scheme_column])
        # Read the short name.
        short_name = clean_text(row[short_column])
        # Skip incomplete mappings.
        if not scheme_name or not short_name:
            continue
        # Normalize the scheme key.
        key = normalize_name(scheme_name)
        # Prevent ambiguous duplicates.
        if key in mapping:
            raise ValueError(f"Duplicate normalized Scheme Name in INDEX: {scheme_name}")
        # Store the mapping record.
        mapping[key] = {"scheme_name": scheme_name, "short_name": short_name}
    # Stop if INDEX contains no usable mappings.
    if not mapping:
        raise ValueError("No usable Scheme Name mappings were found in INDEX.")
    # Log the total mapping count.
    log_lines.append(f"INDEX FUND COUNT: {len(mapping)}")
    # Return the mapping.
    return mapping


def find_fund_worksheet(workbook, short_name):
    # Normalize the expected sheet prefix.
    expected_prefix = clean_text(short_name).upper()
    # Search every workbook worksheet.
    for sheet_index in range(1, workbook.Worksheets.Count + 1):
        # Obtain the worksheet.
        worksheet = workbook.Worksheets.Item(sheet_index)
        # Compare the worksheet prefix.
        if clean_text(worksheet.Name).upper().startswith(expected_prefix):
            return worksheet
    # Raise a clear mapping error.
    raise ValueError(f'No worksheet starts with Short Name "{short_name}".')


def is_next_section_heading(label):
    # Normalize the potential section label.
    normalized = normalize_name(label)
    # Stop at another composition section.
    if normalized.startswith("composition by"):
        return True
    # Stop at common total rows.
    return normalized in {"grand total", "net assets", "total"}


def extract_asset_allocation(worksheet, log_lines):
    # Read the matched fund sheet.
    matrix = used_range_to_matrix(worksheet)
    # Stop for an empty sheet.
    if not matrix:
        raise ValueError(f'Worksheet "{worksheet.Name}" is empty.')
    # Initialize section row.
    section_row = None
    # Initialize section column.
    section_column = None
    # Normalize the target section heading.
    target = normalize_name(ASSET_SECTION_SEARCH_TEXT)
    # Search every used cell.
    for row_index, row in enumerate(matrix):
        # Search the current row.
        for column_index, cell_value in enumerate(row):
            # Match the composition heading.
            if target in normalize_name(cell_value):
                section_row = row_index
                section_column = column_index
                break
        # Stop after the first section match.
        if section_row is not None:
            break
    # Stop when the section is absent.
    if section_row is None or section_column is None:
        raise ValueError(f'"{ASSET_SECTION_SEARCH_TEXT}" was not found in "{worksheet.Name}".')
    # The percentage is in the adjacent column.
    value_column = section_column + 1
    # Create the extracted output rows.
    allocation_rows = []
    # Track whether data has started.
    data_started = False
    # Count leading spacer rows.
    leading_blanks = 0
    # Read rows below the section heading.
    for row_index in range(section_row + 1, len(matrix)):
        # Read the current row.
        row = matrix[row_index]
        # Read the label.
        label = clean_text(row[section_column]) if section_column < len(row) else ""
        # Read the value.
        value = row[value_column] if value_column < len(row) else None
        # Treat numeric zero as a valid present value.
        value_present = value is not None and clean_text(value) != ""
        # Skip blank rows before data starts.
        if not label and not value_present and not data_started:
            leading_blanks += 1
            if leading_blanks > MAX_LEADING_BLANK_ROWS:
                break
            continue
        # Stop at the first blank after data starts.
        if not label and not value_present and data_started:
            break
        # Stop at another summary heading or total.
        if label and is_next_section_heading(label):
            break
        # Skip malformed leading rows.
        if not data_started and (not label or not value_present):
            continue
        # Stop at malformed rows after data begins.
        if data_started and (not label or not value_present):
            break
        # Mark the start of valid data.
        data_started = True
        # Store the formatted record.
        allocation_rows.append((label, format_asset_value(value)))
    # Stop when no data rows are found.
    if not allocation_rows:
        raise ValueError(f'No asset-allocation rows were found in "{worksheet.Name}".')
    # Log the source sheet.
    log_lines.append(f"ASSET SOURCE SHEET: {worksheet.Name}")
    # Log every extracted record.
    log_lines.extend(f"  ASSET ROW: {label} | {value}" for label, value in allocation_rows)
    # Return the records.
    return allocation_rows


def get_allocation_for_fund(workbook, fund_key, mapping, cache, log_lines):
    # Return cached data for repeated fund sections.
    if fund_key in cache:
        return cache[fund_key]
    # Read the INDEX mapping record.
    record = mapping[fund_key]
    # Find the corresponding fund worksheet.
    worksheet = find_fund_worksheet(workbook, record["short_name"])
    # Extract the asset allocation.
    rows = extract_asset_allocation(worksheet, log_lines)
    # Cache the extracted data.
    cache[fund_key] = rows
    # Return the allocation.
    return rows


def get_shape_text(shape):
    # Return blank when the shape has no text frame.
    if shape.HasTextFrame != MSO_TRUE:
        return ""
    # Prefer TextFrame2 for stable Unicode and table-related handling.
    try:
        return clean_text(shape.TextFrame2.TextRange.Text)
    # Fall back for older placeholder implementations.
    except Exception:
        return clean_text(shape.TextFrame.TextRange.Text)


def get_cell_text_range(cell):
    # Return TextFrame2.TextRange, which is reliable for independent table cells.
    return cell.Shape.TextFrame2.TextRange


def read_cell_text(cell):
    # Read and clean the TextFrame2 table-cell text.
    return clean_text(get_cell_text_range(cell).Text)


def capture_text_format(text_range):
    # Create a reusable text-style dictionary.
    style = {}
    # Capture common TextFrame2 Font properties.
    for name in ["Name", "Size", "Bold", "Italic", "UnderlineStyle"]:
        try:
            style[name] = getattr(text_range.Font, name)
        except Exception:
            pass
    # Capture font colour.
    try:
        style["FillForeColorRGB"] = text_range.Font.Fill.ForeColor.RGB
        style["FillTransparency"] = text_range.Font.Fill.Transparency
    except Exception:
        pass
    # Capture paragraph alignment.
    try:
        style["Alignment"] = text_range.ParagraphFormat.Alignment
    except Exception:
        pass
    # Return the style.
    return style


def apply_text_format(text_range, style):
    # Apply common font properties.
    for name in ["Name", "Size", "Bold", "Italic", "UnderlineStyle"]:
        if name in style:
            try:
                setattr(text_range.Font, name, style[name])
            except Exception:
                pass
    # Apply font colour.
    if "FillForeColorRGB" in style:
        try:
            text_range.Font.Fill.ForeColor.RGB = style["FillForeColorRGB"]
            text_range.Font.Fill.Transparency = style.get("FillTransparency", 0)
        except Exception:
            pass
    # Apply paragraph alignment.
    if "Alignment" in style:
        try:
            text_range.ParagraphFormat.Alignment = style["Alignment"]
        except Exception:
            pass


def capture_cell_style(cell):
    # Obtain the cell shape.
    shape = cell.Shape
    # Create the style dictionary.
    style = {"text": capture_text_format(get_cell_text_range(cell)), "borders": {}}
    # Capture TextFrame2 margins and layout.
    for name in ["MarginLeft", "MarginRight", "MarginTop", "MarginBottom", "VerticalAnchor", "WordWrap", "AutoSize"]:
        try:
            style[name] = getattr(shape.TextFrame2, name)
        except Exception:
            pass
    # Capture fill properties.
    try:
        style["CellFillRGB"] = shape.Fill.ForeColor.RGB
        style["CellFillTransparency"] = shape.Fill.Transparency
        style["CellFillVisible"] = shape.Fill.Visible
    except Exception:
        pass
    # Capture borders.
    for border_index in range(1, 5):
        try:
            border = cell.Borders.Item(border_index)
            style["borders"][border_index] = {
                "Visible": border.Visible,
                "Weight": border.Weight,
                "RGB": border.ForeColor.RGB,
                "Transparency": border.Transparency,
            }
        except Exception:
            pass
    # Return the style.
    return style


def apply_cell_style(cell, style):
    # Obtain the cell shape.
    shape = cell.Shape
    # Apply TextFrame2 layout properties.
    for name in ["MarginLeft", "MarginRight", "MarginTop", "MarginBottom", "VerticalAnchor", "WordWrap", "AutoSize"]:
        if name in style:
            try:
                setattr(shape.TextFrame2, name, style[name])
            except Exception:
                pass
    # Apply fill properties.
    if "CellFillRGB" in style:
        try:
            shape.Fill.ForeColor.RGB = style["CellFillRGB"]
            shape.Fill.Transparency = style.get("CellFillTransparency", 0)
            shape.Fill.Visible = style.get("CellFillVisible", MSO_TRUE)
        except Exception:
            pass
    # Apply border properties.
    for border_index, border_style in style.get("borders", {}).items():
        try:
            border = cell.Borders.Item(border_index)
            border.Visible = border_style["Visible"]
            border.Weight = border_style["Weight"]
            border.ForeColor.RGB = border_style["RGB"]
            border.Transparency = border_style["Transparency"]
        except Exception:
            pass
    # Apply text formatting to the current range.
    apply_text_format(get_cell_text_range(cell), style.get("text", {}))


def set_cell_text(cell, value, fallback_style):
    # Capture the cell's current style before replacing text.
    current_style = capture_cell_style(cell)
    # Use fallback text formatting when the current cell has incomplete formatting.
    current_text_style = current_style.get("text", {})
    # Read the current font size.
    current_size = current_text_style.get("Size", 0)
    # Fall back to the captured template style when needed.
    if current_size in (None, 0, -2):
        current_text_style = fallback_style.get("text", current_text_style)
    # Replace only the TextFrame2 cell text.
    get_cell_text_range(cell).Text = str(value)
    # Reapply the preserved text formatting.
    apply_text_format(get_cell_text_range(cell), current_text_style)
    # Force all freshly written table text to white as requested.
    try:
        get_cell_text_range(cell).Font.Fill.Solid()
        get_cell_text_range(cell).Font.Fill.ForeColor.RGB = WHITE_RGB
        get_cell_text_range(cell).Font.Fill.Transparency = 0
    except Exception:
        pass
    # Force vertical alignment to the middle of the cell.
    try:
        cell.Shape.TextFrame2.VerticalAnchor = MSO_ANCHOR_MIDDLE
    except Exception:
        pass


def center_value_cell(cell):
    # Force the value cell text to horizontal center alignment.
    try:
        # Apply center alignment to the complete TextFrame2 paragraph range.
        get_cell_text_range(cell).ParagraphFormat.Alignment = MSO_ALIGN_CENTER
    # Ignore an Office-version-specific alignment failure without stopping the workflow.
    except Exception:
        pass
    # Keep the value vertically aligned to the middle of the cell.
    try:
        # Apply middle vertical anchoring to the value cell.
        cell.Shape.TextFrame2.VerticalAnchor = MSO_ANCHOR_MIDDLE
    # Ignore an Office-version-specific vertical-anchor failure.
    except Exception:
        pass


def is_spacer_or_merged_row(table, row_index):
    # A zero-height row is a template spacer and must not receive data.
    try:
        if float(table.Rows.Item(row_index).Height) <= 0.5:
            return True
    except Exception:
        pass
    # Read both current logical cell texts.
    label = read_cell_text(table.Cell(row_index, 1))
    value = read_cell_text(table.Cell(row_index, 2))
    # A fully blank original row is treated as a spacer to avoid merged-cell corruption.
    return not label and not value


def update_asset_table(shape, allocation_rows, log_lines):
    # Confirm the shape is a table.
    if shape.Type != MSO_TABLE_SHAPE_TYPE:
        raise ValueError(f'Object "{shape.Name}" is not a PowerPoint table.')
    # Obtain the table.
    table = shape.Table
    # Require two columns.
    if table.Columns.Count < 2:
        raise ValueError(f'Table "{shape.Name}" must contain at least two columns.')
    # Capture the original row count.
    original_row_count = table.Rows.Count
    # Capture each original row height.
    row_heights = [table.Rows.Item(index).Height for index in range(1, original_row_count + 1)]
    # Capture every original cell style before any writing.
    styles = []
    # Process original rows.
    for row_index in range(1, original_row_count + 1):
        # Capture both column styles.
        styles.append([capture_cell_style(table.Cell(row_index, column_index)) for column_index in range(1, table.Columns.Count + 1)])
    # Create a list of safe physical rows.
    writable_rows = []
    # Inspect every existing row.
    for row_index in range(1, original_row_count + 1):
        # Skip zero-height or blank spacer rows.
        if is_spacer_or_merged_row(table, row_index):
            log_lines.append(f"SKIPPED SPACER/MERGED ROW | Object {shape.Name} | Row {row_index}")
            continue
        # Reuse nonblank rows, including dummy Monil/0 rows.
        writable_rows.append(row_index)
    # Add regular rows until enough safe rows exist.
    while len(writable_rows) < len(allocation_rows):
        # Add a normal row at the bottom.
        table.Rows.Add()
        # Read the new row index.
        new_row = table.Rows.Count
        # Use the last original row as the style template.
        source_index = original_row_count - 1
        # Copy the template row height.
        table.Rows.Item(new_row).Height = row_heights[source_index]
        # Apply styles to all new cells.
        for column_index in range(1, table.Columns.Count + 1):
            apply_cell_style(table.Cell(new_row, column_index), styles[source_index][column_index - 1])
        # Register the new writable row.
        writable_rows.append(new_row)
        # Log the addition.
        log_lines.append(f"ADDED WRITABLE ROW | Object {shape.Name} | Row {new_row}")
    # Clear every safe writable row before fresh data is entered.
    for physical_row in writable_rows:
        # Select the nearest original style row.
        source_index = min(physical_row, len(styles)) - 1
        # Clear label text.
        set_cell_text(table.Cell(physical_row, 1), "", styles[source_index][0])
        # Clear value text.
        set_cell_text(table.Cell(physical_row, 2), "", styles[source_index][1])
    # Write fresh Excel records into safe rows.
    for data_index, (label, value) in enumerate(allocation_rows):
        # Map the Excel record to a physical PowerPoint row.
        physical_row = writable_rows[data_index]
        # Select the nearest original formatting row.
        source_index = min(physical_row, len(styles)) - 1
        # Write the label through TextFrame2.
        set_cell_text(table.Cell(physical_row, 1), label, styles[source_index][0])
        # Write the value through TextFrame2.
        set_cell_text(table.Cell(physical_row, 2), value, styles[source_index][1])
        # Force only the percentage/value column to horizontal center alignment.
        center_value_cell(table.Cell(physical_row, 2))
    # Verify all fresh records.
    for data_index, (expected_label, expected_value) in enumerate(allocation_rows):
        # Read the mapped physical row.
        physical_row = writable_rows[data_index]
        # Read back the label through TextFrame2.
        actual_label = read_cell_text(table.Cell(physical_row, 1))
        # Read back the value through TextFrame2.
        actual_value = read_cell_text(table.Cell(physical_row, 2))
        # Stop if either cell differs.
        if actual_label != clean_text(expected_label) or actual_value != clean_text(expected_value):
            raise RuntimeError(
                f"PowerPoint table write verification failed on slide table {shape.Name}, physical row {physical_row}: "
                f"expected [{expected_label} | {expected_value}], got [{actual_label} | {actual_value}]"
            )
    # Verify that unused safe rows are blank.
    for physical_row in writable_rows[len(allocation_rows):]:
        # Read the unused label.
        extra_label = read_cell_text(table.Cell(physical_row, 1))
        # Read the unused value.
        extra_value = read_cell_text(table.Cell(physical_row, 2))
        # Stop if old content remains.
        if extra_label or extra_value:
            raise RuntimeError(f"Old table content remains at physical row {physical_row}: [{extra_label} | {extra_value}]")


def find_fund_names_in_collection(shapes):
    # Create a list of all FundName texts found in this shape collection.
    fund_names = []
    # Process every shape in the collection.
    for shape_index in range(1, shapes.Count + 1):
        # Obtain the current shape.
        shape = shapes.Item(shape_index)
        # Read the Selection Pane object name.
        object_name = clean_text(shape.Name).casefold()
        # Capture visible text from every FundName object.
        if object_name == FUND_OBJECT_NAME:
            fund_names.append(get_shape_text(shape))
        # Search inside grouped shapes as well.
        if shape.Type == MSO_GROUP_SHAPE_TYPE:
            fund_names.extend(find_fund_names_in_collection(shape.GroupItems))
    # Return all FundName texts found on the slide.
    return fund_names


def process_asset_tables_in_collection(shapes, slide_number, state, workbook, mapping, cache, log_lines):
    # Process every shape in the collection after the slide FundName has already been resolved.
    for shape_index in range(1, shapes.Count + 1):
        # Obtain the current shape.
        shape = shapes.Item(shape_index)
        # Normalize the Selection Pane object name.
        object_name = clean_text(shape.Name).casefold()
        # Handle either accepted asset-allocation table spelling.
        if object_name in ASSET_TABLE_OBJECT_NAMES:
            # Read the active fund resolved before table processing.
            fund_key = state["current_fund_key"]
            # Skip only when the slide and prior state contain no matched FundName.
            if fund_key is None:
                state["skipped_tables"].append(f"Slide {slide_number}: {shape.Name}")
                log_lines.append(f"SKIPPED TABLE | Slide {slide_number} | Object {shape.Name} | No matched FundName")
            else:
                # Read or retrieve Excel allocation rows.
                allocation_rows = get_allocation_for_fund(workbook, fund_key, mapping, cache, log_lines)
                # Freshly update the table.
                update_asset_table(shape, allocation_rows, log_lines)
                # Increase the update count.
                state["updated_table_count"] += 1
                # Log the completed table update.
                log_lines.append(
                    f"UPDATED TABLE | Slide {slide_number} | Object {shape.Name} | "
                    f"Fund {mapping[fund_key]['scheme_name']} | Rows {len(allocation_rows)} | Font White | Vertical Middle"
                )
        # Recursively process tables inside grouped shapes.
        if shape.Type == MSO_GROUP_SHAPE_TYPE:
            process_asset_tables_in_collection(shape.GroupItems, slide_number, state, workbook, mapping, cache, log_lines)

def update_powerpoint(ppt_path, output_path, workbook, mapping, cache, log_lines):
    # Initialize PowerPoint application reference.
    powerpoint_app = None
    # Initialize presentation reference.
    presentation = None
    # Start protected processing.
    try:
        # Start a separate PowerPoint instance.
        powerpoint_app = win32.DispatchEx("PowerPoint.Application")
        # Keep PowerPoint visible for stable desktop COM automation.
        powerpoint_app.Visible = MSO_TRUE
        # Open the input presentation.
        presentation = powerpoint_app.Presentations.Open(str(ppt_path), WithWindow=MSO_TRUE)
        # Create shared slide-processing state.
        state = {
            "current_fund_key": None,
            "updated_table_count": 0,
            "unmatched_funds": [],
            "skipped_tables": [],
        }
        # Process every slide in order.
        for slide_number in range(1, presentation.Slides.Count + 1):
            # Obtain the current slide.
            slide = presentation.Slides.Item(slide_number)
            # FIRST scan the complete slide for FundName, regardless of shape/z-order.
            slide_fund_names = find_fund_names_in_collection(slide.Shapes)
            # Use the last FundName found on the slide when more than one exists.
            if slide_fund_names:
                # Read the displayed slide fund name.
                fund_text = slide_fund_names[-1]
                # Normalize the fund name for INDEX matching.
                fund_key = normalize_name(fund_text)
                # Store a successful slide-level match before any table is processed.
                if fund_key in mapping:
                    state["current_fund_key"] = fund_key
                    record = mapping[fund_key]
                    log_lines.append(
                        f"MATCHED FUNDNAME BEFORE TABLES | Slide {slide_number} | "
                        f"{fund_text} -> {record['scheme_name']} | {record['short_name']}"
                    )
                # Clear the active fund when the slide FundName is unmatched.
                else:
                    state["current_fund_key"] = None
                    state["unmatched_funds"].append(f"Slide {slide_number}: {fund_text}")
                    log_lines.append(f"UNMATCHED FUNDNAME | Slide {slide_number} | {fund_text}")
            # SECOND update all target tables using the already-resolved slide fund.
            process_asset_tables_in_collection(slide.Shapes, slide_number, state, workbook, mapping, cache, log_lines)
        # Stop if no target table was updated.
        if state["updated_table_count"] == 0:
            raise RuntimeError("No CurrentAssetAllocation/CurrectAssetAllocation table was updated.")
        # Create the output folder.
        output_path.parent.mkdir(parents=True, exist_ok=True)
        # Remove an older output file.
        if output_path.exists():
            output_path.unlink()
        # Save the updated presentation as PPTX.
        presentation.SaveAs(str(output_path), PP_SAVE_AS_OPEN_XML_PRESENTATION)
        # Force final save.
        presentation.Save()
        # Log the actual save path.
        log_lines.append(f"POWERPOINT SAVED FILE: {presentation.FullName}")
        # Log the total updated count.
        log_lines.append(f"TOTAL TABLES UPDATED: {state['updated_table_count']}")
        # Log unmatched funds.
        if state["unmatched_funds"]:
            log_lines.append("UNMATCHED FUNDNAME OBJECTS:")
            log_lines.extend(f"  - {item}" for item in state["unmatched_funds"])
        # Log skipped tables.
        if state["skipped_tables"]:
            log_lines.append("SKIPPED TABLES:")
            log_lines.extend(f"  - {item}" for item in state["skipped_tables"])
        # Return the update count.
        return state["updated_table_count"]
    # Always close PowerPoint resources.
    finally:
        # Close the presentation.
        if presentation is not None:
            presentation.Close()
        # Quit PowerPoint.
        if powerpoint_app is not None:
            powerpoint_app.Quit()


def validate_paths():
    # Confirm the input PPT exists.
    if not INPUT_PPT_PATH.is_file():
        raise FileNotFoundError(f"Input PowerPoint not found: {INPUT_PPT_PATH}")
    # Confirm the input Excel exists.
    if not INPUT_EXCEL_PATH.is_file():
        raise FileNotFoundError(f"Input Excel not found: {INPUT_EXCEL_PATH}")
    # Confirm the output extension.
    if OUTPUT_PPT_PATH.suffix.lower() != ".pptx":
        raise ValueError("OUTPUT_PPT_PATH must end with .pptx")
    # Prevent overwriting the source file.
    if INPUT_PPT_PATH.resolve() == OUTPUT_PPT_PATH.resolve():
        raise ValueError("Input and output PowerPoint paths must be different.")


def write_log(log_lines):
    # Create the log folder.
    LOG_FILE_PATH.parent.mkdir(parents=True, exist_ok=True)
    # Write all entries with Windows line endings.
    LOG_FILE_PATH.write_text("\r\n".join(log_lines), encoding="utf-8")


def main():
    # Create the processing log.
    log_lines = []
    # Initialize Excel application reference.
    excel_app = None
    # Initialize workbook reference.
    workbook = None
    # Start top-level protected processing.
    try:
        # Validate hardcoded paths.
        validate_paths()
        # Log input and output paths.
        log_lines.append(f"INPUT PPT: {INPUT_PPT_PATH}")
        log_lines.append(f"INPUT EXCEL: {INPUT_EXCEL_PATH}")
        log_lines.append(f"OUTPUT PPT: {OUTPUT_PPT_PATH}")
        # Start a separate Excel application.
        excel_app = win32.DispatchEx("Excel.Application")
        # Keep Excel hidden.
        excel_app.Visible = False
        # Disable Excel prompts.
        excel_app.DisplayAlerts = False
        # Disable screen updates.
        excel_app.ScreenUpdating = False
        # Open the workbook read-only.
        workbook = excel_app.Workbooks.Open(str(INPUT_EXCEL_PATH), UpdateLinks=0, ReadOnly=True)
        # Read the first worksheet as INDEX.
        index_sheet = workbook.Worksheets.Item(1)
        # Convert INDEX to a matrix.
        index_matrix = used_range_to_matrix(index_sheet)
        # Build Scheme Name to Short Name mapping.
        mapping = build_index_mapping(index_matrix, log_lines)
        # Log the INDEX sheet name.
        log_lines.append(f"INDEX SHEET: {index_sheet.Name}")
        # Create a fund allocation cache.
        cache = {}
        # Update the presentation.
        updated_count = update_powerpoint(INPUT_PPT_PATH, OUTPUT_PPT_PATH, workbook, mapping, cache, log_lines)
        # Record success.
        log_lines.append("STATUS: SUCCESS")
        # Print summary.
        print(f"Completed successfully. Updated {updated_count} asset-allocation table(s).")
        print(f"Output presentation: {OUTPUT_PPT_PATH}")
        print(f"Log file: {LOG_FILE_PATH}")
    # Capture all failures.
    except Exception as error:
        # Record failure status.
        log_lines.append("STATUS: FAILED")
        # Record the readable error.
        log_lines.append(f"ERROR: {error}")
        # Record the complete traceback.
        log_lines.append(traceback.format_exc())
        # Print the error.
        print(f"Process failed: {error}")
        # Re-raise for a nonzero process exit code.
        raise
    # Always close Excel and write the log.
    finally:
        # Close the workbook without saving.
        if workbook is not None:
            workbook.Close(SaveChanges=False)
        # Quit Excel.
        if excel_app is not None:
            excel_app.Quit()
        # Write the processing log.
        write_log(log_lines)


import sys
import pythoncom
from typing import Optional
from PyQt6.QtCore import QObject, QThread, pyqtSignal
from PyQt6.QtWidgets import (
    QApplication, QFileDialog, QFormLayout, QHBoxLayout, QLabel, QLineEdit,
    QMainWindow, QMessageBox, QPlainTextEdit, QProgressBar, QPushButton,
    QVBoxLayout, QWidget,
)


class UpdateWorker(QObject):
    """Run the embedded Current Asset Allocation logic for GUI and Main flow."""
    log = pyqtSignal(str)
    completed = pyqtSignal(int, str, str)
    failed = pyqtSignal(str, str)

    def __init__(self, ppt: Path, excel: Path, output: Path, log_file: Path) -> None:
        super().__init__()
        self.ppt = Path(ppt)
        self.excel = Path(excel)
        self.output = Path(output)
        self.log_file = Path(log_file)

    def run(self) -> None:
        pythoncom.CoInitialize()
        excel_app = None
        workbook = None
        log_lines = [
            f"INPUT PPT: {self.ppt}",
            f"INPUT EXCEL: {self.excel}",
            f"OUTPUT PPT: {self.output}",
        ]
        try:
            if not self.ppt.is_file():
                raise FileNotFoundError(f"Input PowerPoint not found: {self.ppt}")
            if not self.excel.is_file():
                raise FileNotFoundError(f"Input Excel not found: {self.excel}")
            if self.output.suffix.lower() != ".pptx":
                raise ValueError("Output PowerPoint must end with .pptx")
            if self.ppt.resolve() == self.output.resolve():
                raise ValueError("Input and output PowerPoint paths must be different.")

            for line in log_lines:
                self.log.emit(line)
            self.log.emit("Starting Microsoft Excel...")
            excel_app = win32.DispatchEx("Excel.Application")
            excel_app.Visible = False
            excel_app.DisplayAlerts = False
            excel_app.ScreenUpdating = False
            workbook = excel_app.Workbooks.Open(
                str(self.excel.resolve()), UpdateLinks=0, ReadOnly=True
            )
            index_sheet = workbook.Worksheets.Item(1)
            index_matrix = used_range_to_matrix(index_sheet)
            mapping = build_index_mapping(index_matrix, log_lines)
            log_lines.append(f"INDEX SHEET: {index_sheet.Name}")
            updated_count = update_powerpoint(
                self.ppt, self.output, workbook, mapping, {}, log_lines
            )
            log_lines.append("STATUS: SUCCESS")
            self.log_file.parent.mkdir(parents=True, exist_ok=True)
            self.log_file.write_text("\r\n".join(log_lines), encoding="utf-8")
            self.completed.emit(updated_count, str(self.output), str(self.log_file))
        except Exception as error:
            log_lines.extend(["STATUS: FAILED", f"ERROR: {error}", traceback.format_exc()])
            try:
                self.log_file.parent.mkdir(parents=True, exist_ok=True)
                self.log_file.write_text("\r\n".join(log_lines), encoding="utf-8")
            except Exception:
                pass
            self.failed.emit(str(error), traceback.format_exc())
        finally:
            if workbook is not None:
                workbook.Close(SaveChanges=False)
            if excel_app is not None:
                excel_app.Quit()
            pythoncom.CoUninitialize()


class MainWindow(QMainWindow):
    def __init__(self) -> None:
        super().__init__()
        self.setWindowTitle("Current Asset Allocation")
        self.thread: Optional[QThread] = None
        self.worker: Optional[UpdateWorker] = None
        self._build_ui()

    def _build_ui(self) -> None:
        root = QWidget()
        self.setCentralWidget(root)
        layout = QVBoxLayout(root)
        layout.setContentsMargins(12, 12, 12, 12)
        layout.setSpacing(8)
        layout.addWidget(QLabel("Update Current Asset Allocation tables in PowerPoint"))
        form = QFormLayout()
        form.setFieldGrowthPolicy(QFormLayout.FieldGrowthPolicy.ExpandingFieldsGrow)
        self.ppt_edit = self._path_row(form, "PowerPoint", "PowerPoint (*.pptx *.pptm)", False)
        self.excel_edit = self._path_row(form, "Portfolio workbook", "Excel (*.xls *.xlsx *.xlsm *.xlsb)", False)
        self.output_edit = self._path_row(form, "Output PowerPoint", "PowerPoint (*.pptx)", True)
        self.log_edit = self._path_row(form, "Log file", "Text (*.txt)", True)
        layout.addLayout(form)
        self.run_button = QPushButton("Update Current Asset Allocation")
        self.run_button.clicked.connect(self.start)
        layout.addWidget(self.run_button)
        self.progress = QProgressBar()
        self.progress.setRange(0, 1)
        layout.addWidget(self.progress)
        self.status = QPlainTextEdit()
        self.status.setReadOnly(True)
        self.status.setPlaceholderText("Processing messages will appear here.")
        layout.addWidget(self.status)

    def _path_row(self, form, label, file_filter, save):
        edit = QLineEdit()
        button = QPushButton("Browse...")
        def browse():
            if save:
                path, _ = QFileDialog.getSaveFileName(self, f"Select {label}", edit.text(), file_filter)
            else:
                path, _ = QFileDialog.getOpenFileName(self, f"Select {label}", edit.text(), file_filter)
            if path:
                edit.setText(path)
                if edit is self.ppt_edit if hasattr(self, 'ppt_edit') else False:
                    pass
        button.clicked.connect(browse)
        row = QHBoxLayout()
        row.addWidget(edit, 1)
        row.addWidget(button)
        form.addRow(label, row)
        return edit

    def start(self) -> None:
        ppt = Path(self.ppt_edit.text().strip())
        excel = Path(self.excel_edit.text().strip())
        output = Path(self.output_edit.text().strip())
        log_file = Path(self.log_edit.text().strip())
        if not ppt.is_file() or not excel.is_file() or not output.name or not log_file.name:
            QMessageBox.warning(self, "Check inputs", "Select valid input files and output paths.")
            return
        self.status.clear()
        self.run_button.setEnabled(False)
        self.progress.setRange(0, 0)
        self.thread = QThread(self)
        self.worker = UpdateWorker(ppt, excel, output, log_file)
        self.worker.moveToThread(self.thread)
        self.thread.started.connect(self.worker.run)
        self.worker.log.connect(self.status.appendPlainText)
        self.worker.completed.connect(self._completed)
        self.worker.failed.connect(self._failed)
        self.worker.completed.connect(self.thread.quit)
        self.worker.failed.connect(self.thread.quit)
        self.thread.finished.connect(self.worker.deleteLater)
        self.thread.finished.connect(self.thread.deleteLater)
        self.thread.start()

    def _finish(self) -> None:
        self.progress.setRange(0, 1)
        self.run_button.setEnabled(True)

    def _completed(self, count, output, log_file) -> None:
        self._finish()
        self.progress.setValue(1)
        QMessageBox.information(self, "Complete", f"Updated {count} table(s).\n\nOutput: {output}\nLog: {log_file}")

    def _failed(self, message, details) -> None:
        self._finish()
        self.status.appendPlainText(details)
        QMessageBox.critical(self, "Update failed", message)


def gui_main() -> int:
    app = QApplication.instance() or QApplication(sys.argv)
    window = MainWindow()
    window.show()
    return app.exec()


if __name__ == "__main__":
    raise SystemExit(gui_main())
