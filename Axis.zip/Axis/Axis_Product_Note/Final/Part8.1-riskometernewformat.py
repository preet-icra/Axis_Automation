# -*- coding: utf-8 -*-
"""Risk Parameters PowerPoint Updater - one Excel file per fund.

The application first reads FundName objects from the PowerPoint, then scans the
selected Excel folder. Excel files for funds not present in the PowerPoint are
ignored. Matching workbooks are searched for Standard Deviation, Beta and
Sharpe Ratio and the matching RiskParameters tables are updated.

Install:
    py -m pip install PyQt6 pywin32
Run:
    py riskparameters_excel_folder_updater.py
"""
from __future__ import annotations

import os
import re
import sys
import traceback
import unicodedata
from dataclasses import dataclass
from datetime import datetime
from pathlib import Path
from typing import Any, Callable, Iterator, Optional

import pythoncom
import win32com.client as win32
from PyQt6.QtCore import QObject, QThread, pyqtSignal
from PyQt6.QtGui import QCloseEvent
from PyQt6.QtWidgets import (
    QApplication, QCheckBox, QFileDialog, QFormLayout, QHBoxLayout, QLabel,
    QLineEdit, QMainWindow, QMessageBox, QPlainTextEdit, QProgressBar,
    QPushButton, QVBoxLayout, QWidget,
)

FUND_NAME_OBJECT = "FundName"
RISK_PARAMETERS_OBJECT = "RiskParameters"
EXCEL_EXTENSIONS = {".xls", ".xlsx", ".xlsm", ".xlsb"}
PARAMETER_ALIASES = {
    "standard_deviation": (
        "standard deviation", "standard deviation %", "std deviation",
        "std. deviation", "std dev", "std. dev.", "stdev",
    ),
    "beta": ("beta", "portfolio beta"),
    "sharpe_ratio": ("sharpe ratio", "sharpe ratio**", "sharpe"),
}
FUND_LABEL_ALIASES = ("fund name", "fundname", "scheme name", "scheme")
MSO_GROUP = 6
MSO_TRUE = -1
MSO_FALSE = 0
PP_SAVE_AS_OPEN_XML_PRESENTATION = 24
PP_WINDOW_MINIMIZED = 2
FONT_NAME = "Lato"
FONT_SIZE = 7


@dataclass
class FundRiskData:
    fund_name: str
    standard_deviation: Any = None
    beta: Any = None
    sharpe_ratio: Any = None
    source_file: Optional[Path] = None
    source_sheet: str = ""

    def completeness(self) -> int:
        return sum(
            not is_empty(value) and clean_text(value).casefold() != "na"
            for value in (self.standard_deviation, self.beta, self.sharpe_ratio)
        )


@dataclass
class PptTarget:
    slide_no: int
    fund_name: str


def clean_text(value: Any) -> str:
    if value is None:
        return ""
    return re.sub(
        r"\s+", " ",
        str(value).replace("\r", " ").replace("\n", " ").replace("\t", " "),
    ).strip()


def normalize_text(value: Any) -> str:
    text = unicodedata.normalize("NFKD", clean_text(value))
    text = text.replace("&", " and ").replace("’", "'").replace("‘", "'")
    text = text.replace("–", "-").replace("—", "-").casefold()
    text = re.sub(r"[^a-z0-9]+", " ", text)
    return re.sub(r"\s+", " ", text).strip()


def normalize_fund_name(value: Any) -> str:
    text = normalize_text(value)
    removals = (
        "risk parameters", "risk parameter", "fund factsheet", "fund fact sheet",
        "factsheet", "fact sheet", "monthly report", "regular plan", "direct plan",
        "growth option", "idcw option", "portfolio", "report", "data", "dir",
    )
    for phrase in removals:
        text = re.sub(rf"\b{re.escape(phrase)}\b", " ", text)
    return re.sub(r"\s+", " ", text).strip()


def token_score(first: str, second: str) -> float:
    left = set(normalize_fund_name(first).split())
    right = set(normalize_fund_name(second).split())
    return 2.0 * len(left & right) / (len(left) + len(right)) if left and right else 0.0


def is_empty(value: Any) -> bool:
    return value is None or (isinstance(value, str) and not value.strip())


def label_matches(value: Any, aliases: tuple[str, ...]) -> bool:
    normalized = normalize_text(value)
    compact = normalized.replace(" ", "")
    if not normalized:
        return False
    for alias in aliases:
        candidate = normalize_text(alias)
        if normalized == candidate or compact == candidate.replace(" ", ""):
            return True
        if len(normalized) <= len(candidate) + 8 and normalized.startswith(candidate):
            return True
    return False


def fund_names_match(first: str, second: str) -> bool:
    left, right = normalize_fund_name(first), normalize_fund_name(second)
    if not left or not right:
        return False
    if left == right or left.replace(" ", "") == right.replace(" ", ""):
        return True
    left_compact, right_compact = left.replace(" ", ""), right.replace(" ", "")
    if min(len(left_compact), len(right_compact)) >= 12 and (
        left_compact in right_compact or right_compact in left_compact
    ):
        return True
    return token_score(left, right) >= 0.82


def filename_matches_any_fund(path: Path, ppt_funds: list[str]) -> bool:
    stem = normalize_fund_name(path.stem)
    if not stem:
        return True
    return any(fund_names_match(stem, fund) for fund in ppt_funds)


def matrix_from_used_range(worksheet: Any) -> tuple[list[list[Any]], int, int]:
    used = worksheet.UsedRange
    start_row, start_col = int(used.Row), int(used.Column)
    rows, cols = int(used.Rows.Count), int(used.Columns.Count)
    values = used.Value2
    if rows == 1 and cols == 1:
        matrix = [[values]]
    elif rows == 1:
        matrix = [list(values)]
    elif cols == 1:
        matrix = [[row[0] if isinstance(row, tuple) else row] for row in values]
    else:
        matrix = [list(row) for row in values]
    return matrix, start_row, start_col


def matrix_value(matrix: list[list[Any]], row: int, col: int) -> Any:
    if row < 0 or col < 0 or row >= len(matrix) or col >= len(matrix[row]):
        return None
    return matrix[row][col]


def is_parameter_label(value: Any) -> bool:
    return any(label_matches(value, aliases) for aliases in PARAMETER_ALIASES.values())


def usable_parameter_value(value: Any) -> bool:
    if is_empty(value):
        return False
    if isinstance(value, (int, float)) and not isinstance(value, bool):
        return True
    text = clean_text(value)
    if normalize_text(text) in {"na", "n a", "nil", "none", "-"}:
        return True
    try:
        float(text.replace(",", "").replace("%", ""))
        return True
    except ValueError:
        return False


def find_paired_value(matrix: list[list[Any]], row: int, col: int) -> Any:
    max_cols = max((len(item) for item in matrix), default=0)
    # The supplied individual files normally have the value in the next column.
    for candidate_col in range(col + 1, min(col + 8, max_cols)):
        value = matrix_value(matrix, row, candidate_col)
        if is_parameter_label(value):
            break
        if usable_parameter_value(value):
            return value
    for candidate_row in range(row + 1, min(row + 4, len(matrix))):
        value = matrix_value(matrix, candidate_row, col)
        if is_parameter_label(value):
            break
        if usable_parameter_value(value):
            return value
    return None


def find_parameter(matrix: list[list[Any]], aliases: tuple[str, ...]) -> tuple[Any, Optional[tuple[int, int]]]:
    for row_no, row in enumerate(matrix):
        for col_no, value in enumerate(row):
            if label_matches(value, aliases):
                return find_paired_value(matrix, row_no, col_no), (row_no, col_no)
    return None, None


def looks_like_fund_name(value: Any) -> bool:
    text = clean_text(value)
    normalized = normalize_text(text)
    if not text or len(text) > 120:
        return False
    if not normalized.startswith("axis ") or " fund" not in f" {normalized}":
        return False
    reject = ("benchmark", "direct plan", "regular plan", "growth option")
    return not any(item in text.casefold() for item in reject)


def find_sheet_fund_name(matrix: list[list[Any]]) -> Optional[str]:
    for row_no, row in enumerate(matrix[:40]):
        for col_no, value in enumerate(row):
            if label_matches(value, FUND_LABEL_ALIASES):
                for next_col in range(col_no + 1, min(col_no + 6, len(row))):
                    candidate = clean_text(matrix_value(matrix, row_no, next_col))
                    if looks_like_fund_name(candidate):
                        return candidate
    for row in matrix[:35]:
        for value in row[:12]:
            if looks_like_fund_name(value):
                return clean_text(value)
    return None


def record_priority(record: FundRiskData) -> tuple[int, int, int]:
    sheet = record.source_sheet.casefold()
    return record.completeness(), int("factsheet" in sheet), -len(sheet)


def read_sheet_record(
    worksheet: Any,
    excel_path: Path,
    fallback_fund_name: str,
    log: Callable[[str, str], None],
) -> Optional[FundRiskData]:
    matrix, _, _ = matrix_from_used_range(worksheet)
    found: dict[str, Any] = {}
    for key, aliases in PARAMETER_ALIASES.items():
        value, _ = find_parameter(matrix, aliases)
        found[key] = value
    if all(is_empty(value) for value in found.values()):
        return None

    fund_name = find_sheet_fund_name(matrix) or fallback_fund_name
    if not fund_name:
        log(f"Sheet '{worksheet.Name}': risk values found but fund name is unavailable.", "WARNING")
        return None
    record = FundRiskData(
        fund_name=fund_name,
        standard_deviation=found["standard_deviation"] if not is_empty(found["standard_deviation"]) else "NA",
        beta=found["beta"] if not is_empty(found["beta"]) else "NA",
        sharpe_ratio=found["sharpe_ratio"] if not is_empty(found["sharpe_ratio"]) else "NA",
        source_file=excel_path,
        source_sheet=str(worksheet.Name),
    )
    log(
        f"FOUND: {record.fund_name} / {record.source_sheet} | "
        f"SD={record.standard_deviation} | Beta={record.beta} | Sharpe={record.sharpe_ratio}",
        "INFO",
    )
    return record


def read_one_workbook(
    excel: Any,
    excel_path: Path,
    ppt_funds: list[str],
    log: Callable[[str, str], None],
) -> Optional[FundRiskData]:
    workbook = None
    records: list[FundRiskData] = []
    try:
        workbook = excel.Workbooks.Open(
            str(excel_path.resolve()), UpdateLinks=0, ReadOnly=True,
            IgnoreReadOnlyRecommended=True,
        )
        fallback = excel_path.stem
        for sheet_no in range(1, int(workbook.Worksheets.Count) + 1):
            worksheet = workbook.Worksheets.Item(sheet_no)
            try:
                record = read_sheet_record(worksheet, excel_path, fallback, log)
                if record is not None:
                    records.append(record)
            except Exception as exc:
                log(f"Sheet skipped: {excel_path.name} / {worksheet.Name} ({exc})", "WARNING")
    finally:
        if workbook is not None:
            workbook.Close(SaveChanges=False)

    matching = [record for record in records if any(
        fund_names_match(record.fund_name, fund) for fund in ppt_funds
    )]
    if not matching:
        return None
    return max(matching, key=record_priority)


def list_excel_files(folder: Path, recursive: bool) -> list[Path]:
    iterator = folder.rglob("*") if recursive else folder.glob("*")
    return sorted(
        (
            path for path in iterator
            if path.is_file()
            and path.suffix.lower() in EXCEL_EXTENSIONS
            and not path.name.startswith("~$")
        ),
        key=lambda path: path.name.casefold(),
    )


def parse_number(value: Any) -> tuple[Optional[float], bool]:
    if value is None or isinstance(value, bool):
        return None, False
    if isinstance(value, (int, float)):
        return float(value), False
    text = clean_text(value)
    if normalize_text(text) in {"na", "n a", "nil", "none", "-"}:
        return None, False
    had_percent = "%" in text
    try:
        return float(text.replace("%", "").replace(",", "").strip()), had_percent
    except ValueError:
        return None, had_percent


def format_percentage(value: Any) -> str:
    if normalize_text(value) in {"na", "n a", "nil", "none", "-"}:
        return "NA"
    number, had_percent = parse_number(value)
    if number is None:
        return clean_text(value) or "NA"
    # Excel may store 0.1126 or 11.26 for 11.26 percent.
    if not had_percent and abs(number) <= 1:
        number *= 100
    return f"{number:.2f}%"


def format_decimal(value: Any) -> str:
    if normalize_text(value) in {"na", "n a", "nil", "none", "-"}:
        return "NA"
    number, _ = parse_number(value)
    if number is None:
        return clean_text(value) or "NA"
    return f"{number:.2f}"


def formatted_record(record: FundRiskData) -> dict[str, str]:
    return {
        "standard_deviation": format_percentage(record.standard_deviation),
        "beta": format_decimal(record.beta),
        "sharpe_ratio": format_decimal(record.sharpe_ratio),
    }


def iter_shapes(collection: Any) -> Iterator[Any]:
    for index in range(1, collection.Count + 1):
        shape = collection.Item(index)
        yield shape
        try:
            if int(shape.Type) == MSO_GROUP:
                yield from iter_shapes(shape.GroupItems)
        except Exception:
            pass


def shape_name(shape: Any) -> str:
    try:
        return clean_text(shape.Name)
    except Exception:
        return ""


def find_named_shapes(slide: Any, required_name: str) -> list[Any]:
    target = normalize_text(required_name)
    return [shape for shape in iter_shapes(slide.Shapes) if normalize_text(shape_name(shape)) == target]


def shape_text(shape: Any) -> str:
    try:
        return clean_text(shape.TextFrame.TextRange.Text)
    except Exception:
        return ""


def get_slide_fund_name(slide: Any) -> Optional[str]:
    for shape in find_named_shapes(slide, FUND_NAME_OBJECT):
        text = shape_text(shape)
        if text:
            return text
    return None


def table_cell_text(table: Any, row: int, col: int) -> str:
    try:
        return clean_text(table.Cell(row, col).Shape.TextFrame.TextRange.Text)
    except Exception:
        return ""


def find_table_label(table: Any, aliases: tuple[str, ...]) -> Optional[tuple[int, int]]:
    for row in range(1, table.Rows.Count + 1):
        for col in range(1, table.Columns.Count + 1):
            if label_matches(table_cell_text(table, row, col), aliases):
                return row, col
    return None


def find_table_value_position(table: Any, label_row: int, label_col: int) -> Optional[tuple[int, int]]:
    rows, cols = int(table.Rows.Count), int(table.Columns.Count)
    right = (label_row, label_col + 1) if label_col < cols else None
    below = (label_row + 1, label_col) if label_row < rows else None
    right_text = table_cell_text(table, *right) if right else ""
    below_text = table_cell_text(table, *below) if below else ""
    if right and is_parameter_label(right_text) and below:
        return below
    if below and is_parameter_label(below_text) and right:
        return right
    if right and usable_parameter_value(right_text):
        return right
    if below and usable_parameter_value(below_text):
        return below
    if rows == 2 and cols >= 3 and below:
        return below
    if rows >= 3 and cols >= 2 and right:
        return right
    return right or below


def find_risk_tables(slide: Any) -> list[Any]:
    named = find_named_shapes(slide, RISK_PARAMETERS_OBJECT)
    if named:
        return named
    fallback: list[Any] = []
    for shape in iter_shapes(slide.Shapes):
        try:
            if shape.HasTable != MSO_TRUE:
                continue
            table = shape.Table
            score = sum(find_table_label(table, aliases) is not None for aliases in PARAMETER_ALIASES.values())
            if score >= 2:
                fallback.append(shape)
        except Exception:
            pass
    return fallback


def collect_ppt_funds(presentation: Any, log: Callable[[str, str], None]) -> tuple[list[str], list[PptTarget]]:
    funds: list[str] = []
    targets: list[PptTarget] = []
    current_fund: Optional[str] = None
    current_fund_slide = 0
    for slide_no in range(1, int(presentation.Slides.Count) + 1):
        slide = presentation.Slides.Item(slide_no)
        found = get_slide_fund_name(slide)
        if found:
            current_fund = found
            current_fund_slide = slide_no
            if not any(fund_names_match(found, existing) for existing in funds):
                funds.append(found)
        if find_risk_tables(slide):
            if current_fund and slide_no - current_fund_slide <= 4:
                targets.append(PptTarget(slide_no, current_fund))
            else:
                log(f"Slide {slide_no}: RiskParameters has no FundName in its four-slide block.", "WARNING")
    return funds, targets


def find_fund_record(ppt_name: str, records: list[FundRiskData]) -> Optional[FundRiskData]:
    exact = [record for record in records if normalize_fund_name(record.fund_name) == normalize_fund_name(ppt_name)]
    if exact:
        return max(exact, key=record_priority)
    candidates = [record for record in records if fund_names_match(ppt_name, record.fund_name)]
    return max(candidates, key=record_priority) if candidates else None


def write_table_value(cell: Any, text: str) -> None:
    text_range = cell.Shape.TextFrame.TextRange
    text_range.Text = text
    text_range.Font.Name = FONT_NAME
    text_range.Font.Size = FONT_SIZE
    text_range.Font.Bold = MSO_FALSE
    text_range.Font.Italic = MSO_FALSE


def update_risk_table(shape: Any, record: FundRiskData, log: Callable[[str, str], None]) -> int:
    if shape.HasTable != MSO_TRUE:
        raise RuntimeError(f"'{RISK_PARAMETERS_OBJECT}' exists but is not a table.")
    table = shape.Table
    values = formatted_record(record)
    updated = 0
    for key, display in (
        ("standard_deviation", "Standard Deviation"),
        ("beta", "Beta"),
        ("sharpe_ratio", "Sharpe Ratio"),
    ):
        position = find_table_label(table, PARAMETER_ALIASES[key])
        if position is None:
            log(f"Label not found: {display}", "WARNING")
            continue
        value_position = find_table_value_position(table, *position)
        if value_position is None:
            log(f"Value cell not found: {display}", "WARNING")
            continue
        value = values[key] or "NA"
        write_table_value(table.Cell(*value_position), value)
        written = table_cell_text(table, *value_position)
        if clean_text(written) != clean_text(value):
            raise RuntimeError(f"Verification failed for {display}: expected '{value}', got '{written}'")
        log(f"Updated {display}: {value}", "INFO")
        updated += 1
    return updated


def process_folder_and_powerpoint(
    input_ppt: Path,
    excel_folder: Path,
    output_ppt: Path,
    recursive: bool,
    log: Callable[[str, str], None],
    progress: Callable[[int], None],
) -> tuple[int, int, int, int]:
    powerpoint = presentation = excel = None
    updated_slides = updated_values = ignored_files = skipped_files = 0
    try:
        progress(2)
        log("Opening PowerPoint and collecting required fund names...", "INFO")
        powerpoint = win32.DispatchEx("PowerPoint.Application")
        powerpoint.Visible = True
        try:
            powerpoint.WindowState = PP_WINDOW_MINIMIZED
        except Exception:
            pass
        presentation = powerpoint.Presentations.Open(
            str(input_ppt.resolve()), ReadOnly=False, Untitled=False, WithWindow=True
        )
        ppt_funds, targets = collect_ppt_funds(presentation, log)
        if not ppt_funds or not targets:
            raise RuntimeError("No usable FundName and RiskParameters targets were found in the PowerPoint.")
        log(f"PowerPoint contains {len(ppt_funds)} fund(s) and {len(targets)} RiskParameters target slide(s).", "INFO")

        files = list_excel_files(excel_folder, recursive)
        if not files:
            raise RuntimeError("No supported Excel files were found in the selected folder.")
        log(f"Excel files found: {len(files)}", "INFO")
        progress(8)

        excel = win32.DispatchEx("Excel.Application")
        excel.Visible = False
        excel.DisplayAlerts = False
        excel.ScreenUpdating = False
        excel.EnableEvents = False
        records: list[FundRiskData] = []
        for index, path in enumerate(files, 1):
            progress(8 + int(index / max(len(files), 1) * 58))
            if not filename_matches_any_fund(path, ppt_funds):
                ignored_files += 1
                log(f"IGNORED: {path.name} (fund filename not present in PowerPoint)", "SKIP")
                continue
            try:
                record = read_one_workbook(excel, path, ppt_funds, log)
                if record is None:
                    ignored_files += 1
                    log(f"IGNORED: {path.name} (workbook fund not present in PowerPoint or no risk values)", "SKIP")
                    continue
                existing = find_fund_record(record.fund_name, records)
                if existing is not None:
                    if record_priority(record) > record_priority(existing):
                        records.remove(existing)
                        records.append(record)
                        log(f"REPLACED DUPLICATE: {path.name} has the more complete record.", "WARNING")
                    else:
                        log(f"DUPLICATE IGNORED: {path.name}", "WARNING")
                    continue
                records.append(record)
                log(f"LOADED: {path.name} for {record.fund_name}", "INFO")
            except Exception as exc:
                skipped_files += 1
                log(f"SKIPPED: {path.name} ({exc})", "WARNING")

        for index, target in enumerate(targets, 1):
            progress(68 + int(index / max(len(targets), 1) * 25))
            record = find_fund_record(target.fund_name, records)
            if record is None:
                log(f"TABLE SKIPPED: slide {target.slide_no}, no Excel match for '{target.fund_name}'.", "WARNING")
                continue
            slide = presentation.Slides.Item(target.slide_no)
            tables = find_risk_tables(slide)
            source = record.source_file.name if record.source_file else "Unknown"
            log(f"Slide {target.slide_no}: matched {target.fund_name} to {source} / {record.source_sheet}", "INFO")
            count = sum(update_risk_table(table, record, log) for table in tables)
            if count:
                updated_slides += 1
                updated_values += count

        output_ppt.parent.mkdir(parents=True, exist_ok=True)
        if output_ppt.exists():
            output_ppt.unlink()
        progress(96)
        presentation.SaveAs(str(output_ppt.resolve()), PP_SAVE_AS_OPEN_XML_PRESENTATION)
        progress(100)
        log(f"SAVED: {output_ppt}", "INFO")
        return updated_slides, updated_values, ignored_files, skipped_files
    finally:
        if excel is not None:
            try:
                excel.Quit()
            except Exception:
                pass
        if presentation is not None:
            try:
                presentation.Close()
            except Exception:
                pass
        if powerpoint is not None:
            try:
                powerpoint.Quit()
            except Exception:
                pass


def write_log(path: Path, lines: list[str]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text("\n".join(lines), encoding="utf-8")


class RiskParameterWorker(QObject):
    log = pyqtSignal(str)
    progress = pyqtSignal(int)
    completed = pyqtSignal(int, int, int, int, str, str)
    failed = pyqtSignal(str, str, str)

    def __init__(self, input_ppt: Path, excel_folder: Path, output_folder: Path, recursive: bool) -> None:
        super().__init__()
        self.input_ppt = input_ppt
        self.excel_folder = excel_folder
        self.output_folder = output_folder
        self.recursive = recursive

    def run(self) -> None:
        pythoncom.CoInitialize()
        lines: list[str] = []
        stamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        output_ppt = self.output_folder / f"{self.input_ppt.stem}_RiskParameters_Updated.pptx"
        log_file = self.output_folder / f"RiskParameters_Log_{stamp}.txt"

        def emit(message: str, level: str = "INFO") -> None:
            line = f"{datetime.now():%H:%M:%S} [{level}] {message}"
            lines.append(line)
            self.log.emit(line)

        try:
            self.output_folder.mkdir(parents=True, exist_ok=True)
            emit("RISK PARAMETERS UPDATER - EXCEL FOLDER / INDIVIDUAL FUND FILES")
            emit(f"Input PowerPoint: {self.input_ppt}")
            emit(f"Excel folder: {self.excel_folder}")
            result = process_folder_and_powerpoint(
                self.input_ppt, self.excel_folder, output_ppt, self.recursive,
                emit, self.progress.emit,
            )
            slides, values, ignored, skipped = result
            emit(
                f"SUCCESS | Slides updated: {slides} | Values updated: {values} | "
                f"Files ignored: {ignored} | Files skipped with errors: {skipped}"
            )
            write_log(log_file, lines)
            self.completed.emit(slides, values, ignored, skipped, str(output_ppt), str(log_file))
        except Exception as exc:
            details = traceback.format_exc()
            emit(f"FAILED: {exc}", "ERROR")
            emit(details, "ERROR")
            try:
                write_log(log_file, lines)
            except Exception:
                pass
            self.failed.emit(str(exc), details, str(log_file))
        finally:
            pythoncom.CoUninitialize()


class MainWindow(QMainWindow):
    def __init__(self) -> None:
        super().__init__()
        self.thread: Optional[QThread] = None
        self.worker: Optional[RiskParameterWorker] = None
        self.setWindowTitle("Risk Parameters PowerPoint Updater - Excel Folder")
        self.resize(1000, 740)
        self.build_ui()

    def build_ui(self) -> None:
        root = QWidget()
        self.setCentralWidget(root)
        layout = QVBoxLayout(root)
        layout.setContentsMargins(24, 20, 24, 20)
        layout.setSpacing(14)

        title = QLabel("Risk Parameters PowerPoint Updater")
        title.setStyleSheet("font-size: 20px; font-weight: 700; color: #1F4E79;")
        description = QLabel(
            "Select a PowerPoint and a folder containing separate fund Excel files. "
            "Only funds used by the PowerPoint are loaded. Other Excel files are ignored and logged. "
            "The updater writes Standard Deviation, Beta and Sharpe Ratio into RiskParameters tables."
        )
        description.setWordWrap(True)
        layout.addWidget(title)
        layout.addWidget(description)

        form = QFormLayout()
        form.setHorizontalSpacing(12)
        form.setVerticalSpacing(12)
        self.ppt_edit = QLineEdit()
        self.excel_folder_edit = QLineEdit()
        self.output_folder_edit = QLineEdit()
        form.addRow("Input PowerPoint:", self.path_row(self.ppt_edit, self.pick_ppt))
        form.addRow("Fund Excel folder:", self.path_row(self.excel_folder_edit, self.pick_excel_folder))
        form.addRow("Output folder:", self.path_row(self.output_folder_edit, self.pick_output_folder))
        layout.addLayout(form)

        self.recursive_check = QCheckBox("Include Excel files in subfolders")
        layout.addWidget(self.recursive_check)

        buttons = QHBoxLayout()
        self.run_button = QPushButton("Update Risk Parameters")
        self.run_button.clicked.connect(self.start_processing)
        clear_button = QPushButton("Clear Log")
        clear_button.clicked.connect(self.log_box_clear)
        open_button = QPushButton("Open Output Folder")
        open_button.clicked.connect(self.open_output_folder)
        buttons.addWidget(self.run_button)
        buttons.addWidget(clear_button)
        buttons.addWidget(open_button)
        buttons.addStretch()
        layout.addLayout(buttons)

        self.progress_bar = QProgressBar()
        self.progress_bar.setRange(0, 100)
        self.progress_bar.setFormat("Ready")
        self.status_label = QLabel("Ready")
        self.log_box = QPlainTextEdit()
        self.log_box.setReadOnly(True)
        self.log_box.setStyleSheet("font-family: Consolas; font-size: 9pt;")
        layout.addWidget(self.progress_bar)
        layout.addWidget(self.status_label)
        layout.addWidget(self.log_box, 1)

    def path_row(self, edit: QLineEdit, handler: Callable[[], None]) -> QWidget:
        widget = QWidget()
        row = QHBoxLayout(widget)
        row.setContentsMargins(0, 0, 0, 0)
        button = QPushButton("Browse...")
        button.clicked.connect(handler)
        row.addWidget(edit, 1)
        row.addWidget(button)
        return widget

    def pick_ppt(self) -> None:
        filename, _ = QFileDialog.getOpenFileName(self, "Select PowerPoint", "", "PowerPoint (*.pptx)")
        if filename:
            path = Path(filename)
            self.ppt_edit.setText(str(path))
            if not self.output_folder_edit.text().strip():
                self.output_folder_edit.setText(str(path.parent))

    def pick_excel_folder(self) -> None:
        start = str(Path(self.ppt_edit.text()).parent) if self.ppt_edit.text().strip() else ""
        folder = QFileDialog.getExistingDirectory(self, "Select folder containing fund Excel files", start)
        if folder:
            self.excel_folder_edit.setText(folder)

    def pick_output_folder(self) -> None:
        folder = QFileDialog.getExistingDirectory(self, "Select output folder", "")
        if folder:
            self.output_folder_edit.setText(folder)

    def open_output_folder(self) -> None:
        folder = Path(self.output_folder_edit.text().strip())
        if folder.is_dir():
            os.startfile(str(folder))

    def validate_inputs(self) -> Optional[tuple[Path, Path, Path, bool]]:
        ppt_text = self.ppt_edit.text().strip()
        excel_text = self.excel_folder_edit.text().strip()
        output_text = self.output_folder_edit.text().strip()
        ppt = Path(ppt_text) if ppt_text else None
        excel_folder = Path(excel_text) if excel_text else None
        output_folder = Path(output_text) if output_text else None
        if ppt is None or not ppt.is_file() or ppt.suffix.lower() != ".pptx":
            QMessageBox.warning(self, "Invalid PowerPoint", "Select a valid .pptx file.")
            return None
        if excel_folder is None or not excel_folder.is_dir():
            QMessageBox.warning(self, "Invalid Excel folder", "Select a valid folder containing fund Excel files.")
            return None
        if output_folder is None:
            QMessageBox.warning(self, "Missing output folder", "Select an output folder.")
            return None
        output_folder.mkdir(parents=True, exist_ok=True)
        return ppt, excel_folder, output_folder, self.recursive_check.isChecked()

    def start_processing(self) -> None:
        selected = self.validate_inputs()
        if selected is None:
            return
        self.log_box.clear()
        self.run_button.setEnabled(False)
        self.progress_bar.setValue(0)
        self.progress_bar.setFormat("%p%")
        self.status_label.setText("Reading PowerPoint, filtering Excel files and updating risk tables...")
        self.thread = QThread(self)
        self.worker = RiskParameterWorker(*selected)
        self.worker.moveToThread(self.thread)
        self.thread.started.connect(self.worker.run)
        self.worker.log.connect(self.log_box.appendPlainText)
        self.worker.progress.connect(self.progress_bar.setValue)
        self.worker.completed.connect(self.processing_completed)
        self.worker.failed.connect(self.processing_failed)
        self.worker.completed.connect(self.thread.quit)
        self.worker.failed.connect(self.thread.quit)
        self.thread.finished.connect(self.cleanup_thread)
        self.thread.start()

    def log_box_clear(self) -> None:
        self.log_box.clear()

    def processing_completed(
        self, slides: int, values: int, ignored: int, skipped: int,
        output_file: str, log_file: str,
    ) -> None:
        self.run_button.setEnabled(True)
        self.progress_bar.setValue(100)
        self.progress_bar.setFormat("Completed")
        self.status_label.setText(f"Completed: {slides} slide(s), {values} value(s)")
        QMessageBox.information(
            self, "Completed",
            f"Slides updated: {slides}\nValues updated: {values}\n"
            f"Excel files ignored: {ignored}\nExcel files skipped with errors: {skipped}\n\n"
            f"Output:\n{output_file}\n\nLog:\n{log_file}",
        )

    def processing_failed(self, error: str, details: str, log_file: str) -> None:
        self.run_button.setEnabled(True)
        self.progress_bar.setFormat("Failed")
        self.status_label.setText("Processing failed")
        self.log_box.appendPlainText("\nERROR DETAILS:\n" + details)
        QMessageBox.critical(self, "Processing failed", f"{error}\n\nLog:\n{log_file}")

    def cleanup_thread(self) -> None:
        if self.worker:
            self.worker.deleteLater()
        if self.thread:
            self.thread.deleteLater()
        self.worker = None
        self.thread = None

    def closeEvent(self, event: QCloseEvent) -> None:
        if self.thread is not None and self.thread.isRunning():
            QMessageBox.information(self, "Processing", "Wait for processing to finish.")
            event.ignore()
        else:
            event.accept()


def main() -> int:
    app = QApplication(sys.argv)
    app.setApplicationName("Risk Parameters PowerPoint Updater")
    app.setStyle("Fusion")
    window = MainWindow()
    window.show()
    return app.exec()


if __name__ == "__main__":
    sys.exit(main())
