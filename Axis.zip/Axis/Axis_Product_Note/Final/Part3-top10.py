from __future__ import annotations

import os
import re
import sys
import tempfile
import traceback
import shutil
from pathlib import Path
from xml.sax.saxutils import escape as xml_escape

from PIL import Image, ImageDraw, ImageFont
from PyQt6.QtCore import QObject, QThread, pyqtSignal
from PyQt6.QtGui import QIntValidator
from PyQt6.QtWidgets import (
    QApplication, QFileDialog, QGridLayout, QHBoxLayout, QLabel, QLineEdit,
    QMainWindow, QMessageBox, QPlainTextEdit, QProgressBar, QPushButton,
    QVBoxLayout, QWidget,
)

import pythoncom
import pywintypes
import win32com.client as win32
import winreg


MSO_SEND_BACKWARD = 3

GRAPH_PURPLE_HEX = "#702F8F"
GRAPH_GRAY_HEX = "#BFBFBF"
GRAPH_TEXT_HEX = "#262626"
DIVIDER_OPACITY = 0.18

DEFAULT_GRAPH_WIDTH_PERCENT = 110
DEFAULT_GRAPH_HEIGHT_PERCENT = 100
MIN_GRAPH_SCALE_PERCENT = 25
MAX_GRAPH_SCALE_PERCENT = 300
DEFAULT_BAR_WIDTH_PERCENT = 85
MIN_BAR_WIDTH_PERCENT = 25
MAX_BAR_WIDTH_PERCENT = 100

STOCK_OBJECT = "Top10StocksGraph"
SECTOR_OBJECT = "Top10SectorsGraph"

# Source layout produced by the Top 10 Stocks / Top 10 Sectors workbook.
# Each fund is one worksheet.
FUND_TITLE_CELL = "A1"
STOCK_FIRST_ROW = 4
STOCK_LAST_ROW = 13
STOCK_NAME_COL = 2       # B
STOCK_WEIGHT_COL = 3     # C
SECTOR_FIRST_ROW = 4
SECTOR_LAST_ROW = 13
SECTOR_NAME_COL = 6      # F
SECTOR_WEIGHT_COL = 7    # G


def compact(value) -> str:
    return re.sub(r"\s+", " ", str(value or "")).strip()


def norm(value) -> str:
    text = compact(value).casefold().replace("–", "-").replace("—", "-")
    return compact(re.sub(r"[^a-z0-9]+", " ", text))


# Canonical aliases. Add future exceptions here using normalized names.
FUND_NAME_ALIASES = {
    "axis childrens fund": "axis childrens fund",
    "axis children s fund": "axis childrens fund",
}


def fund_match_key(value) -> str:
    """Create a plan-independent, punctuation-independent fund matching key."""
    key = norm(value)

    # Standardize apostrophe variants. norm("Children's") becomes
    # "children s", while Excel often contains "childrens".
    key = re.sub(r"\bchildren\s+s\b", "childrens", key)

    # Remove plan/option text when it occurs after the base fund name.
    # Examples supported:
    #   Axis Balanced Advantage Fund Regular Plan
    #   Axis Balanced Advantage Fund Direct Plan Growth
    #   Axis Balanced Advantage Fund - Reg Growth
    #   Axis Children's Fund Direct IDCW Payout
    suffix_pattern = (
        r"\s+(?:direct|dir|regular|reg)"
        r"(?:\s+plan)?"
        r"(?:\s+(?:growth|idcw|dividend|payout|reinvestment|option))*\s*$"
    )
    key = compact(re.sub(suffix_pattern, "", key, flags=re.I))

    return FUND_NAME_ALIASES.get(key, key)


def detect_plan(value) -> str:
    key = norm(value)
    if re.search(r"\b(?:direct|dir)\b", key):
        return "direct"
    if re.search(r"\b(?:regular|reg)\b", key):
        return "regular"
    return "unspecified"


def com_message(exc: Exception) -> str:
    if isinstance(exc, pywintypes.com_error):
        parts = [f"HRESULT={exc.hresult}", compact(exc.strerror)]
        if exc.excepinfo:
            source = compact(exc.excepinfo[1])
            description = compact(exc.excepinfo[2])
            if source:
                parts.append(f"source={source}")
            if description:
                parts.append(f"description={description}")
        return "; ".join(parts)
    return str(exc)


def open_workbook_robust(excel, source_path: Path, temp_dir: Path):
    source_path = source_path.resolve()
    attempts = []
    try:
        workbook = excel.Workbooks.Open(
            Filename=str(source_path), UpdateLinks=0, ReadOnly=True,
            IgnoreReadOnlyRecommended=True, Notify=False,
            AddToMru=False, Local=True,
        )
        return workbook, None
    except Exception as exc:
        attempts.append("original path: " + com_message(exc))

    local_copy = temp_dir / ("source" + source_path.suffix.lower())
    shutil.copy2(source_path, local_copy)
    try:
        workbook = excel.Workbooks.Open(
            Filename=str(local_copy), UpdateLinks=0, ReadOnly=True,
            IgnoreReadOnlyRecommended=True, AddToMru=False,
        )
        return workbook, local_copy
    except Exception as exc:
        attempts.append("local copy: " + com_message(exc))

    raise RuntimeError("Excel could not open the workbook. " + " | ".join(attempts))


def iter_shape_tree(container):
    """Yield top-level and nested group shapes from a slide or group."""
    try:
        count = int(container.Shapes.Count)
        getter = container.Shapes.Item
    except Exception:
        try:
            count = int(container.GroupItems.Count)
            getter = container.GroupItems.Item
        except Exception:
            return

    for index in range(1, count + 1):
        try:
            shape = getter(index)
        except Exception:
            continue
        yield shape
        try:
            if int(shape.Type) == 6:
                yield from iter_shape_tree(shape)
        except Exception:
            pass


def iter_shapes(slide):
    yield from iter_shape_tree(slide)


def get_shape(slide, name: str):
    """Find a Selection Pane object even when it is nested in a group."""
    wanted = compact(name).casefold()

    # Fast path for a top-level shape.
    try:
        return slide.Shapes.Item(name)
    except Exception:
        pass

    # Recursive path for grouped objects.
    for shape in iter_shapes(slide):
        try:
            if compact(shape.Name).casefold() == wanted:
                return shape
        except Exception:
            pass
    return None


def shape_text(shape) -> str:
    """Read text from text boxes, tables, and grouped PowerPoint objects."""
    values = []

    try:
        if int(shape.HasTextFrame) != 0 and int(shape.TextFrame.HasText) != 0:
            value = compact(shape.TextFrame.TextRange.Text)
            if value:
                values.append(value)
    except Exception:
        pass

    # TextFrame2 covers some modern Office text objects.
    try:
        value = compact(shape.TextFrame2.TextRange.Text)
        if value and value not in values:
            values.append(value)
    except Exception:
        pass

    # Native PowerPoint table.
    try:
        if int(shape.HasTable) != 0:
            table = shape.Table
            for row in range(1, int(table.Rows.Count) + 1):
                for col in range(1, int(table.Columns.Count) + 1):
                    try:
                        value = compact(
                            table.Cell(row, col).Shape.TextFrame.TextRange.Text
                        )
                        if value:
                            values.append(value)
                    except Exception:
                        pass
    except Exception:
        pass

    # Grouped content.
    try:
        if int(shape.Type) == 6:
            for index in range(1, int(shape.GroupItems.Count) + 1):
                value = shape_text(shape.GroupItems.Item(index))
                if value:
                    values.append(value)
    except Exception:
        pass

    return compact(" ".join(values))


def slide_text(slide) -> str:
    return compact(" ".join(shape_text(shape) for shape in iter_shapes(slide)))



def has_targets(slide) -> bool:
    return (
        get_shape(slide, STOCK_OBJECT) is not None
        and get_shape(slide, SECTOR_OBJECT) is not None
    )


def worksheet_fund_name(worksheet) -> str:
    """Read the fund name from A1; fall back to the worksheet name."""
    value = compact(worksheet.Range(FUND_TITLE_CELL).Value2)
    return value or compact(worksheet.Name)


def to_percent_number(value):
    if value is None or isinstance(value, bool):
        return None
    try:
        number = float(value)
    except (TypeError, ValueError):
        text = compact(value).replace(",", "")
        if not text:
            return None
        try:
            if text.endswith("%"):
                return float(text[:-1])
            number = float(text)
        except ValueError:
            return None
    return number * 100.0 if abs(number) <= 1.0 else number


def read_rows_from_sheet(worksheet, object_name: str) -> list[tuple[str, float]]:
    """
    Read directly from the generated Top 10 workbook tables.

    Stocks:  B4:B13 names, C4:C13 weights.
    Sectors: F4:F13 names, G4:G13 weights.
    """
    if object_name == STOCK_OBJECT:
        first_row, last_row = STOCK_FIRST_ROW, STOCK_LAST_ROW
        name_col, weight_col = STOCK_NAME_COL, STOCK_WEIGHT_COL
    elif object_name == SECTOR_OBJECT:
        first_row, last_row = SECTOR_FIRST_ROW, SECTOR_LAST_ROW
        name_col, weight_col = SECTOR_NAME_COL, SECTOR_WEIGHT_COL
    else:
        raise ValueError(f"Unknown graph object: {object_name}")

    rows = []
    for row in range(first_row, last_row + 1):
        label = compact(worksheet.Cells(row, name_col).Value2)
        value = to_percent_number(worksheet.Cells(row, weight_col).Value2)
        if label and value is not None:
            rows.append((label, value))

    if not rows:
        source = (
            f"B{first_row}:C{last_row}"
            if object_name == STOCK_OBJECT
            else f"F{first_row}:G{last_row}"
        )
        raise RuntimeError(
            f"No readable data found for {object_name} in {worksheet.Name}!{source}."
        )

    rows.sort(key=lambda item: (-item[1], item[0].casefold()))
    return rows[:10]


def find_target_slides_by_fundname(presentation, excel_fund: str):
    """Find every FundName occurrence and its own following graph slide."""
    excel_key = fund_match_key(excel_fund)
    slide_count = int(presentation.Slides.Count)
    occurrences = []

    # First collect every exact Selection Pane object named FundName.
    for slide_index in range(1, slide_count + 1):
        slide = presentation.Slides.Item(slide_index)
        fund_shape = get_shape(slide, "FundName")
        if fund_shape is None:
            continue

        ppt_fund = compact(shape_text(fund_shape))
        ppt_key = fund_match_key(ppt_fund)
        if ppt_key == excel_key:
            occurrences.append({
                "fund_slide": slide_index,
                "ppt_fund": ppt_fund,
                "ppt_key": ppt_key,
            })

    matches = []
    for occurrence_index, occurrence in enumerate(occurrences, start=1):
        fund_slide_index = occurrence["fund_slide"]

        # Stop before the next matching occurrence, so occurrence 1 cannot
        # accidentally use occurrence 2's graph slide.
        if occurrence_index < len(occurrences):
            search_end = occurrences[occurrence_index]["fund_slide"] - 1
        else:
            search_end = min(slide_count, fund_slide_index + 4)

        graph_slide = None
        # In the supplied template the portfolio graph slide immediately
        # follows each cover slide. Same-slide support is retained.
        for graph_index in [fund_slide_index] + list(
            range(fund_slide_index + 1, search_end + 1)
        ):
            candidate = presentation.Slides.Item(graph_index)
            if has_targets(candidate):
                graph_slide = candidate
                break

        if graph_slide is None:
            raise RuntimeError(
                f"FundName '{occurrence['ppt_fund']}' was found on slide "
                f"{fund_slide_index}, but no following slide before the next "
                f"occurrence contains both '{STOCK_OBJECT}' and "
                f"'{SECTOR_OBJECT}'."
            )

        matches.append({
            "fund_slide": fund_slide_index,
            "graph_slide": graph_slide,
            "graph_slide_index": int(graph_slide.SlideIndex),
            "ppt_fund": occurrence["ppt_fund"],
            "plan": detect_plan(occurrence["ppt_fund"]),
            "excel_key": excel_key,
            "ppt_key": occurrence["ppt_key"],
            "occurrence": occurrence_index,
        })

    return matches



def detected_fundname_values(presentation) -> list[str]:
    values = []
    for slide_index in range(1, int(presentation.Slides.Count) + 1):
        shape = get_shape(presentation.Slides.Item(slide_index), "FundName")
        if shape is not None:
            value = compact(shape_text(shape))
            values.append(f"slide {slide_index}: {value or '[empty]'}")
    return values



def target_shape_geometry(slide, object_name: str) -> dict:
    shape = get_shape(slide, object_name)
    if shape is None:
        raise RuntimeError(
            f"PowerPoint object '{object_name}' is missing from slide {slide.SlideIndex}."
        )
    return {
        "left": float(shape.Left),
        "top": float(shape.Top),
        "width": float(shape.Width),
        "height": float(shape.Height),
        "rotation": float(shape.Rotation),
        "z": int(shape.ZOrderPosition),
    }


def scaled_target_shape_geometry(
    slide, object_name: str, width_percent: int, height_percent: int
) -> dict:
    geometry = target_shape_geometry(slide, object_name)
    width_scale = max(
        MIN_GRAPH_SCALE_PERCENT,
        min(MAX_GRAPH_SCALE_PERCENT, int(width_percent)),
    ) / 100.0
    height_scale = max(
        MIN_GRAPH_SCALE_PERCENT,
        min(MAX_GRAPH_SCALE_PERCENT, int(height_percent)),
    ) / 100.0

    new_width = geometry["width"] * width_scale
    new_height = geometry["height"] * height_scale
    centre_x = geometry["left"] + geometry["width"] / 2.0
    centre_y = geometry["top"] + geometry["height"] / 2.0
    geometry["left"] = centre_x - new_width / 2.0
    geometry["top"] = centre_y - new_height / 2.0
    geometry["width"] = new_width
    geometry["height"] = new_height
    return geometry


def locate_lato_font() -> str:
    windows = Path(os.environ.get("WINDIR", r"C:\Windows"))
    fonts_dir = windows / "Fonts"
    for name in ("Lato-Regular.ttf", "Lato-Regular_0.ttf", "Lato-Medium.ttf"):
        candidate = fonts_dir / name
        if candidate.exists():
            return str(candidate)

    registry_paths = (
        (winreg.HKEY_LOCAL_MACHINE,
         r"SOFTWARE\Microsoft\Windows NT\CurrentVersion\Fonts"),
        (winreg.HKEY_CURRENT_USER,
         r"SOFTWARE\Microsoft\Windows NT\CurrentVersion\Fonts"),
    )
    for hive, key_path in registry_paths:
        try:
            with winreg.OpenKey(hive, key_path) as key:
                index = 0
                while True:
                    try:
                        display_name, file_value, _ = winreg.EnumValue(key, index)
                        index += 1
                    except OSError:
                        break
                    if "lato regular" not in display_name.casefold():
                        continue
                    path = Path(str(file_value))
                    if not path.is_absolute():
                        path = fonts_dir / path
                    if path.exists():
                        return str(path)
        except OSError:
            pass

    raise RuntimeError(
        "Lato Regular is not installed. Install the Lato font family in Windows."
    )


def render_exact_portfolio_graph(
    rows: list[tuple[str, float]],
    output_svg: Path,
    target_width: float,
    target_height: float,
    font_size: int,
    bar_width_percent: int,
):
    """Render the same flat labels/divider/purple-gray bars as an SVG."""
    scale = 5.0
    width = max(1.0, float(target_width) * scale)
    height = max(1.0, float(target_height) * scale)
    rows = sorted(rows, key=lambda item: (-item[1], item[0].casefold()))[:10]
    if not rows:
        raise RuntimeError("No rows were supplied to the SVG renderer.")

    font_size = max(8, min(200, int(font_size)))
    top_margin = height * 0.025
    bottom_margin = height * 0.025
    row_pitch = (height - top_margin - bottom_margin) / len(rows)
    bar_height = max(8.0, row_pitch * 0.48)

    right_margin = max(8.0, width * 0.008)
    value_column_width = max(width * 0.105, 100.0)
    value_x = width - right_margin - value_column_width
    gap = max(14.0, width * 0.012)
    track_right = value_x - gap
    maximum_track_width = max(70.0, width * 0.255)
    bar_width_percent = max(
        MIN_BAR_WIDTH_PERCENT,
        min(MAX_BAR_WIDTH_PERCENT, int(bar_width_percent)),
    )
    track_width = max(35.0, maximum_track_width * bar_width_percent / 100.0)
    track_left = track_right - track_width
    separator_x = track_left
    label_right = separator_x - gap

    # Touch the font here so missing Lato fails before PowerPoint replacement.
    font_path = locate_lato_font()
    canvas = Image.new("RGB", (10, 10), "white")
    ImageDraw.Draw(canvas).textbbox(
        (0, 0), rows[0][0], font=ImageFont.truetype(font_path, font_size)
    )

    divider_width = max(2.0, scale * 0.65)
    max_value = max(value for _, value in rows) or 1.0
    baseline_offset = font_size * 0.35

    svg = [
        '<?xml version="1.0" encoding="UTF-8" standalone="no"?>',
        f'<svg xmlns="http://www.w3.org/2000/svg" width="{width:.2f}" '
        f'height="{height:.2f}" viewBox="0 0 {width:.2f} {height:.2f}" '
        'preserveAspectRatio="xMidYMid meet">',
        '<style>.lbl,.val{font-family:Lato,sans-serif;font-weight:400;fill:#262626;}</style>',
        '<defs>',
        f'<clipPath id="labelClip"><rect x="0" y="0" width="{label_right:.2f}" '
        f'height="{height:.2f}"/></clipPath>',
        f'<clipPath id="valueClip"><rect x="{value_x:.2f}" y="0" '
        f'width="{max(1.0, width-right_margin-value_x):.2f}" height="{height:.2f}"/></clipPath>',
        '</defs>',
        f'<line x1="{separator_x:.2f}" y1="{top_margin:.2f}" '
        f'x2="{separator_x:.2f}" y2="{height-bottom_margin:.2f}" '
        f'stroke="#000000" stroke-opacity="{DIVIDER_OPACITY:.2f}" '
        f'stroke-width="{divider_width:.2f}"/>',
    ]

    for index, (label, value) in enumerate(rows):
        centre_y = top_margin + row_pitch * (index + 0.5)
        baseline_y = centre_y + baseline_offset
        bar_top = centre_y - bar_height / 2.0
        purple_width = max(
            scale * 2,
            min(track_width, track_width * max(0.0, value) / max_value),
        )
        svg.extend([
            f'<text class="lbl" x="{label_right:.2f}" y="{baseline_y:.2f}" '
            f'font-size="{font_size}" text-anchor="end" '
            f'clip-path="url(#labelClip)">{xml_escape(label)}</text>',
            f'<rect x="{track_left:.2f}" y="{bar_top:.2f}" '
            f'width="{track_width:.2f}" height="{bar_height:.2f}" '
            f'fill="{GRAPH_GRAY_HEX}"/>',
            f'<rect x="{track_left:.2f}" y="{bar_top:.2f}" '
            f'width="{purple_width:.2f}" height="{bar_height:.2f}" '
            f'fill="{GRAPH_PURPLE_HEX}"/>',
            f'<text class="val" x="{value_x:.2f}" y="{baseline_y:.2f}" '
            f'font-size="{font_size}" text-anchor="start" '
            f'clip-path="url(#valueClip)">{value:.1f}%</text>',
        ])

    svg.append('</svg>')
    output_svg.parent.mkdir(parents=True, exist_ok=True)
    output_svg.write_text("\n".join(svg), encoding="utf-8")


def replace_placeholder_with_vector_graphic(
    slide, object_name: str, svg_path: Path, geometry: dict
):
    old = get_shape(slide, object_name)
    if old is None:
        raise RuntimeError(
            f"PowerPoint object '{object_name}' is missing from slide {slide.SlideIndex}."
        )

    new_shape = slide.Shapes.AddPicture(
        str(svg_path.resolve()), False, True,
        geometry["left"], geometry["top"],
        geometry["width"], geometry["height"],
    )
    if new_shape is None:
        raise RuntimeError(f"PowerPoint could not insert '{svg_path.name}'.")

    old.Delete()
    new_shape.LockAspectRatio = 0
    new_shape.Left = geometry["left"]
    new_shape.Top = geometry["top"]
    new_shape.Width = geometry["width"]
    new_shape.Height = geometry["height"]
    new_shape.Rotation = geometry["rotation"]
    new_shape.Name = object_name

    try:
        while int(new_shape.ZOrderPosition) > geometry["z"]:
            new_shape.ZOrder(MSO_SEND_BACKWARD)
    except Exception:
        pass


class Worker(QObject):
    log = pyqtSignal(str)
    progress = pyqtSignal(int)
    finished = pyqtSignal(str)
    failed = pyqtSignal(str)

    def __init__(
        self, excel_path, ppt_path, output_folder,
        font_size=38,
        graph_width_percent=DEFAULT_GRAPH_WIDTH_PERCENT,
        graph_height_percent=DEFAULT_GRAPH_HEIGHT_PERCENT,
        bar_width_percent=DEFAULT_BAR_WIDTH_PERCENT,
    ):
        super().__init__()
        self.excel_path = Path(excel_path)
        self.ppt_path = Path(ppt_path)
        self.output_folder = Path(output_folder)
        self.font_size = max(8, min(200, int(font_size)))
        self.graph_width_percent = max(
            MIN_GRAPH_SCALE_PERCENT,
            min(MAX_GRAPH_SCALE_PERCENT, int(graph_width_percent)),
        )
        self.graph_height_percent = max(
            MIN_GRAPH_SCALE_PERCENT,
            min(MAX_GRAPH_SCALE_PERCENT, int(graph_height_percent)),
        )
        self.bar_width_percent = max(
            MIN_BAR_WIDTH_PERCENT,
            min(MAX_BAR_WIDTH_PERCENT, int(bar_width_percent)),
        )

    def run(self):
        pythoncom.CoInitialize()
        excel = powerpoint = workbook = presentation = None
        current_stage = "initialization"
        temp_root = None

        try:
            self.output_folder.mkdir(parents=True, exist_ok=True)
            output = self.output_folder / f"{self.ppt_path.stem}_graphs_updated.pptx"
            temp_root = Path(tempfile.mkdtemp(prefix="fund_graphs_"))

            current_stage = "starting Excel"
            excel = win32.DispatchEx("Excel.Application")
            excel.Visible = False
            excel.DisplayAlerts = False
            excel.EnableEvents = False
            excel.AskToUpdateLinks = False

            current_stage = "opening generated Top 10 workbook"
            workbook, _ = open_workbook_robust(excel, self.excel_path, temp_root)

            current_stage = "starting PowerPoint"
            powerpoint = win32.DispatchEx("PowerPoint.Application")
            powerpoint.Visible = True
            presentation = powerpoint.Presentations.Open(
                str(self.ppt_path.resolve()), False, False, True
            )

            detected_names = detected_fundname_values(presentation)
            self.log.emit(
                f"PowerPoint FundName objects detected: {len(detected_names)}"
            )
            for detected_name in detected_names:
                self.log.emit("  " + detected_name)

            worksheets = [
                workbook.Worksheets.Item(index)
                for index in range(1, int(workbook.Worksheets.Count) + 1)
            ]
            # Build one job for every repeated FundName occurrence. If the same
            # fund appears twice in PowerPoint, both nearby graph slides are updated.
            jobs = []
            failures = []

            for worksheet in worksheets:
                try:
                    fund = worksheet_fund_name(worksheet)
                    matches = find_target_slides_by_fundname(presentation, fund)

                    if not matches:
                        self.log.emit(
                            f"IGNORED: {worksheet.Name}\n"
                            f"  Fund: {fund}\n"
                            f"  Match key: {fund_match_key(fund)}\n"
                            "  Reason: no Selection Pane object named FundName matched this fund"
                        )
                        continue

                    for match in matches:
                        # Do not collapse repeated FundName occurrences. Each match
                        # receives its own stock and sector graph update.
                        jobs.append((worksheet, fund, match))

                except Exception as exc:
                    failures.append(
                        f"{worksheet.Name}: matching repeated FundName objects: "
                        f"{com_message(exc)}"
                    )
                    self.log.emit("ERROR: " + failures[-1])

            total = max(1, len(jobs) * 2)
            done = 0

            for worksheet, fund, target_match in jobs:
                try:
                    slide = target_match["graph_slide"]
                    self.log.emit(
                        f"{worksheet.Name}\n"
                        f"  Excel fund: {fund}\n"
                        f"  PowerPoint FundName: {target_match['ppt_fund']}\n"
                        f"  Matching occurrence: {target_match['occurrence']}\n"
                                                f"  Match key: {target_match['ppt_key']}\n"
                        f"  Fund slide: {target_match['fund_slide']}\n"
                        f"  Graph slide: {slide.SlideIndex}"
                    )

                    for object_name in (STOCK_OBJECT, SECTOR_OBJECT):
                        current_stage = (
                            f"reading {object_name} from {worksheet.Name} "
                            f"for graph slide {slide.SlideIndex}"
                        )
                        rows = read_rows_from_sheet(worksheet, object_name)
                        target = scaled_target_shape_geometry(
                            slide, object_name,
                            self.graph_width_percent,
                            self.graph_height_percent,
                        )
                        svg_path = temp_root / (
                            f"{abs(hash((worksheet.Name, slide.SlideIndex)))}_"
                            f"{object_name}.svg"
                        )

                        current_stage = (
                            f"rendering {object_name} for {worksheet.Name} "
                            f"on graph slide {slide.SlideIndex}"
                        )
                        render_exact_portfolio_graph(
                            rows, svg_path,
                            target["width"], target["height"],
                            self.font_size, self.bar_width_percent,
                        )

                        current_stage = (
                            f"inserting {object_name} into PowerPoint "
                            f"slide {slide.SlideIndex}"
                        )
                        replace_placeholder_with_vector_graphic(
                            slide, object_name, svg_path, target
                        )
                        done += 1
                        self.progress.emit(round(done * 100 / total))
                        source = (
                            f"B{STOCK_FIRST_ROW}:C{STOCK_LAST_ROW}"
                            if object_name == STOCK_OBJECT
                            else f"F{SECTOR_FIRST_ROW}:G{SECTOR_LAST_ROW}"
                        )
                        self.log.emit(
                            f"  Updated {object_name} from "
                            f"{worksheet.Name}!{source} ({len(rows)} rows)"
                        )

                except Exception as exc:
                    failures.append(
                        f"{worksheet.Name} / graph slide "
                        f"{target_match['graph_slide_index']}: "
                        f"{current_stage}: {com_message(exc)}"
                    )
                    self.log.emit("ERROR: " + failures[-1])
                    done += 2
                    self.progress.emit(min(100, round(done * 100 / total)))

            current_stage = "saving PowerPoint"
            presentation.SaveAs(str(output.resolve()))
            presentation.Close()
            presentation = None
            self.progress.emit(100)

            suffix = ""
            if failures:
                suffix = (
                    f"\n\nCompleted with {len(failures)} worksheet error(s). "
                    "Review the log."
                )
            self.finished.emit(str(output) + suffix)

        except Exception as exc:
            self.failed.emit(
                f"Stage: {current_stage}\n{com_message(exc)}\n\n"
                f"{traceback.format_exc()}"
            )
        finally:
            try:
                if presentation is not None:
                    presentation.Close()
            except Exception:
                pass
            try:
                if workbook is not None:
                    workbook.Close(False)
            except Exception:
                pass
            try:
                if powerpoint is not None:
                    powerpoint.Quit()
            except Exception:
                pass
            try:
                if excel is not None:
                    excel.Quit()
            except Exception:
                pass
            if temp_root and temp_root.exists():
                shutil.rmtree(temp_root, ignore_errors=True)
            pythoncom.CoUninitialize()


class MainWindow(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("Fund Graphs: Generated Excel to PowerPoint")
        self.resize(850, 680)
        self.thread = None
        self.worker = None

        root = QWidget()
        self.setCentralWidget(root)
        layout = QVBoxLayout(root)
        grid = QGridLayout()
        layout.addLayout(grid)

        self.excel_edit = QLineEdit()
        self.ppt_edit = QLineEdit()
        self.output_edit = QLineEdit()

        items = [
            ("Generated Top 10 Excel file", self.excel_edit, self.pick_excel),
            ("PowerPoint input", self.ppt_edit, self.pick_ppt),
            ("Output folder", self.output_edit, self.pick_output),
        ]
        for row, (label, edit, handler) in enumerate(items):
            grid.addWidget(QLabel(label), row, 0)
            grid.addWidget(edit, row, 1)
            button = QPushButton("Browse...")
            button.clicked.connect(handler)
            grid.addWidget(button, row, 2)

        self.font_size_edit = QLineEdit("38")
        self.graph_width_edit = QLineEdit(str(DEFAULT_GRAPH_WIDTH_PERCENT))
        self.graph_height_edit = QLineEdit(str(DEFAULT_GRAPH_HEIGHT_PERCENT))
        self.bar_width_edit = QLineEdit(str(DEFAULT_BAR_WIDTH_PERCENT))

        self.font_size_edit.setValidator(QIntValidator(8, 200, self))
        self.graph_width_edit.setValidator(
            QIntValidator(MIN_GRAPH_SCALE_PERCENT, MAX_GRAPH_SCALE_PERCENT, self)
        )
        self.graph_height_edit.setValidator(
            QIntValidator(MIN_GRAPH_SCALE_PERCENT, MAX_GRAPH_SCALE_PERCENT, self)
        )
        self.bar_width_edit.setValidator(
            QIntValidator(MIN_BAR_WIDTH_PERCENT, MAX_BAR_WIDTH_PERCENT, self)
        )

        grid.addWidget(QLabel("Labels and values font size"), 3, 0)
        grid.addWidget(self.font_size_edit, 3, 1)
        grid.addWidget(QLabel("Graph width (%)"), 4, 0)
        grid.addWidget(self.graph_width_edit, 4, 1)
        grid.addWidget(QLabel("Graph height (%)"), 5, 0)
        grid.addWidget(self.graph_height_edit, 5, 1)
        grid.addWidget(QLabel("Bar width (%)"), 6, 0)
        grid.addWidget(self.bar_width_edit, 6, 1)

        self.run_button = QPushButton("Update PowerPoint Graphs")
        self.run_button.clicked.connect(self.start)
        layout.addWidget(self.run_button)

        self.progress = QProgressBar()
        layout.addWidget(self.progress)

        self.log = QPlainTextEdit()
        self.log.setReadOnly(True)
        layout.addWidget(self.log, 1)

        footer = QHBoxLayout()
        footer.addStretch()
        self.open_button = QPushButton("Open Output Folder")
        self.open_button.setEnabled(False)
        self.open_button.clicked.connect(self.open_output)
        footer.addWidget(self.open_button)
        layout.addLayout(footer)

    def pick_excel(self):
        path, _ = QFileDialog.getOpenFileName(
            self,
            "Select generated Top 10 Excel workbook",
            "",
            "Excel workbooks (*.xlsx *.xlsm *.xls)",
        )
        if path:
            self.excel_edit.setText(path)

    def pick_ppt(self):
        path, _ = QFileDialog.getOpenFileName(
            self, "Select PowerPoint", "", "PowerPoint (*.pptx *.pptm)"
        )
        if path:
            self.ppt_edit.setText(path)

    def pick_output(self):
        path = QFileDialog.getExistingDirectory(self, "Select output folder")
        if path:
            self.output_edit.setText(path)

    def start(self):
        excel_path = self.excel_edit.text().strip()
        ppt_path = self.ppt_edit.text().strip()
        output_folder = self.output_edit.text().strip()

        if not excel_path or not ppt_path or not output_folder:
            QMessageBox.warning(
                self, "Missing selection", "Select the Excel file, PowerPoint, and output folder."
            )
            return
        if not Path(excel_path).is_file() or not Path(ppt_path).is_file():
            QMessageBox.warning(
                self, "Invalid selection", "The Excel or PowerPoint path is invalid."
            )
            return

        try:
            font_size = int(self.font_size_edit.text())
            graph_width = int(self.graph_width_edit.text())
            graph_height = int(self.graph_height_edit.text())
            bar_width = int(self.bar_width_edit.text())
        except ValueError:
            QMessageBox.warning(
                self, "Invalid value", "All size fields must contain whole numbers."
            )
            return

        self.run_button.setEnabled(False)
        self.open_button.setEnabled(False)
        self.progress.setValue(0)
        self.log.clear()
        self.log.appendPlainText(
            "Source logic:\n"
            "  One generated workbook\n"
            "  One fund per worksheet\n"
            "  Fund name: A1 or worksheet name\n"
            "  If the same FundName appears twice, both occurrences are updated\n"
            "  Alias: Axis Children's Fund = Axis Childrens Fund\n"
            "  Stocks: B4:C13\n"
            "  Sectors: F4:G13\n\n"
        )

        self.thread = QThread(self)
        self.worker = Worker(
            excel_path, ppt_path, output_folder,
            font_size, graph_width, graph_height, bar_width,
        )
        self.worker.moveToThread(self.thread)
        self.thread.started.connect(self.worker.run)
        self.worker.log.connect(self.log.appendPlainText)
        self.worker.progress.connect(self.progress.setValue)
        self.worker.finished.connect(self.done)
        self.worker.failed.connect(self.failed)
        self.worker.finished.connect(self.thread.quit)
        self.worker.failed.connect(self.thread.quit)
        self.thread.finished.connect(self.worker.deleteLater)
        self.thread.finished.connect(self.thread.deleteLater)
        self.thread.start()

    def done(self, message):
        self.run_button.setEnabled(True)
        self.open_button.setEnabled(True)
        self.log.appendPlainText("\nSaved: " + message)
        QMessageBox.information(self, "Completed", message)

    def failed(self, message):
        self.run_button.setEnabled(True)
        self.log.appendPlainText(message)
        QMessageBox.critical(
            self, "Failed", "Processing failed. The exact stage is shown in the log."
        )

    def open_output(self):
        path = self.output_edit.text().strip()
        if path:
            os.startfile(path)


def main():
    if sys.platform != "win32":
        raise SystemExit("Windows with desktop Excel and PowerPoint is required.")
    app = QApplication(sys.argv)
    window = MainWindow()
    window.show()
    sys.exit(app.exec())


if __name__ == "__main__":
    main()
