# -*- coding: utf-8 -*-
"""Risk Parameters PowerPoint Updater - scan every sheet in one selected workbook.

Install:
    py -m pip install PyQt6 pywin32
Run:
    py riskparameters_all_sheets_updater.py
"""
from __future__ import annotations

import re
import sys
import traceback
import unicodedata
from dataclasses import dataclass
from datetime import datetime
from pathlib import Path
from typing import Any, Callable, Iterator, Optional

import pythoncom
import win32com.client as win32
from PyQt6.QtCore import QObject, QThread, pyqtSignal
from PyQt6.QtGui import QCloseEvent
from PyQt6.QtWidgets import (
    QApplication, QFileDialog, QFormLayout, QHBoxLayout, QLabel, QLineEdit,
    QMainWindow, QMessageBox, QPlainTextEdit, QProgressBar, QPushButton,
    QVBoxLayout, QWidget,
)

FUND_NAME_OBJECT = "FundName"
RISK_PARAMETERS_OBJECT = "RiskParameters"
EXCEL_EXTENSIONS = {".xls", ".xlsx", ".xlsm", ".xlsb"}
PARAMETER_ALIASES = {
    "standard_deviation": (
        "standard deviation", "standard deviation %", "std deviation",
        "std. deviation", "std dev", "std. dev.", "stdev",
    ),
    "beta": ("beta", "portfolio beta"),
    "sharpe_ratio": ("sharpe ratio", "sharpe ratio**", "sharpe"),
}
FUND_LABEL_ALIASES = ("fund name", "fundname", "scheme name", "scheme")
MSO_GROUP = 6
MSO_TRUE = -1
MSO_FALSE = 0
PP_SAVE_AS_OPEN_XML_PRESENTATION = 24
PP_WINDOW_MINIMIZED = 2
FONT_NAME = "Lato"
FONT_SIZE = 7


@dataclass
class FundRiskData:
    fund_name: str
    standard_deviation: Any = None
    beta: Any = None
    sharpe_ratio: Any = None
    source_file: Optional[Path] = None
    source_sheet: str = ""

    def completeness(self) -> int:
        return sum(
            not is_empty(x) and clean_text(x).casefold() != "na"
            for x in (self.standard_deviation, self.beta, self.sharpe_ratio)
        )


def clean_text(value: Any) -> str:
    if value is None:
        return ""
    return re.sub(
        r"\s+", " ",
        str(value).replace("\r", " ").replace("\n", " ").replace("\t", " "),
    ).strip()


def normalize_text(value: Any) -> str:
    text = unicodedata.normalize("NFKD", clean_text(value))
    text = text.replace("&", " and ").replace("’", "'").replace("‘", "'")
    text = text.replace("–", "-").replace("—", "-").casefold()
    text = re.sub(r"[^a-z0-9]+", " ", text)
    return re.sub(r"\s+", " ", text).strip()


def normalize_fund_name(value: Any) -> str:
    text = normalize_text(value)
    removals = (
        "risk parameters", "risk parameter", "fund factsheet", "fund fact sheet",
        "factsheet", "fact sheet", "monthly report", "regular plan", "direct plan",
        "growth option", "idcw option", "portfolio", "report", "data", "dir",
    )
    for phrase in removals:
        text = re.sub(rf"\b{re.escape(phrase)}\b", " ", text)
    return re.sub(r"\s+", " ", text).strip()


def is_empty(value: Any) -> bool:
    return value is None or (isinstance(value, str) and not value.strip())


def label_matches(value: Any, aliases: tuple[str, ...]) -> bool:
    normalized = normalize_text(value)
    compact = normalized.replace(" ", "")
    if not normalized:
        return False
    for alias in aliases:
        a = normalize_text(alias)
        if normalized == a or compact == a.replace(" ", ""):
            return True
        if len(normalized) <= len(a) + 8 and normalized.startswith(a):
            return True
    return False


def fund_names_match(first: str, second: str) -> bool:
    left, right = normalize_fund_name(first), normalize_fund_name(second)
    if not left or not right:
        return False
    if left == right or left.replace(" ", "") == right.replace(" ", ""):
        return True
    lc, rc = left.replace(" ", ""), right.replace(" ", "")
    return min(len(lc), len(rc)) >= 14 and (lc in rc or rc in lc)


def matrix_from_used_range(worksheet: Any) -> tuple[list[list[Any]], int, int]:
    used = worksheet.UsedRange
    start_row, start_col = int(used.Row), int(used.Column)
    rows, cols = int(used.Rows.Count), int(used.Columns.Count)
    values = used.Value2
    if rows == 1 and cols == 1:
        matrix = [[values]]
    elif rows == 1:
        matrix = [list(values)]
    elif cols == 1:
        matrix = [[row[0] if isinstance(row, tuple) else row] for row in values]
    else:
        matrix = [list(row) for row in values]
    return matrix, start_row, start_col


def matrix_value(matrix: list[list[Any]], row: int, col: int) -> Any:
    if row < 0 or col < 0 or row >= len(matrix) or col >= len(matrix[row]):
        return None
    return matrix[row][col]


def is_parameter_label(value: Any) -> bool:
    return any(label_matches(value, aliases) for aliases in PARAMETER_ALIASES.values())


def usable_parameter_value(value: Any) -> bool:
    if is_empty(value):
        return False
    if isinstance(value, (int, float)) and not isinstance(value, bool):
        return True
    text = clean_text(value)
    if normalize_text(text) in {"na", "n a", "nil", "none", "-"}:
        return True
    try:
        float(text.replace(",", "").replace("%", ""))
        return True
    except ValueError:
        return False


def find_paired_value(matrix: list[list[Any]], row: int, col: int) -> Any:
    max_cols = max((len(r) for r in matrix), default=0)
    for candidate_col in range(col + 1, min(col + 8, max_cols)):
        value = matrix_value(matrix, row, candidate_col)
        if is_parameter_label(value):
            break
        if usable_parameter_value(value):
            return value
    for candidate_row in range(row + 1, min(row + 4, len(matrix))):
        value = matrix_value(matrix, candidate_row, col)
        if is_parameter_label(value):
            break
        if usable_parameter_value(value):
            return value
    return None


def find_parameter(matrix: list[list[Any]], aliases: tuple[str, ...]) -> tuple[Any, Optional[tuple[int, int]]]:
    for r, row in enumerate(matrix):
        for c, value in enumerate(row):
            if label_matches(value, aliases):
                return find_paired_value(matrix, r, c), (r, c)
    return None, None


def looks_like_fund_name(value: Any) -> bool:
    text = clean_text(value)
    norm = normalize_text(text)
    if not text or len(text) > 120:
        return False
    if not norm.startswith("axis ") or " fund" not in f" {norm}":
        return False
    reject = ("benchmark", "direct plan", "regular plan", "growth option", "money market fund - direct")
    return not any(item in text.casefold() for item in reject)


def find_sheet_fund_name(matrix: list[list[Any]], sheet_name: str) -> Optional[str]:
    del sheet_name
    for r, row in enumerate(matrix[:40]):
        for c, value in enumerate(row):
            if label_matches(value, FUND_LABEL_ALIASES):
                for cc in range(c + 1, min(c + 6, len(row))):
                    candidate = clean_text(matrix_value(matrix, r, cc))
                    if looks_like_fund_name(candidate):
                        return candidate
    for row in matrix[:35]:
        for value in row[:12]:
            if looks_like_fund_name(value):
                return clean_text(value)
    return None


def read_sheet_record(worksheet: Any, excel_path: Path, log: Callable[[str], None]) -> Optional[FundRiskData]:
    matrix, _, _ = matrix_from_used_range(worksheet)
    found: dict[str, Any] = {}
    for key, aliases in PARAMETER_ALIASES.items():
        value, _ = find_parameter(matrix, aliases)
        found[key] = value
    if all(is_empty(v) for v in found.values()):
        return None

    fund_name = find_sheet_fund_name(matrix, str(worksheet.Name))
    if not fund_name:
        log(f"  Sheet '{worksheet.Name}': risk labels found, but fund title was not found; skipped.")
        return None

    record = FundRiskData(
        fund_name=fund_name,
        standard_deviation=found["standard_deviation"] if not is_empty(found["standard_deviation"]) else "NA",
        beta=found["beta"] if not is_empty(found["beta"]) else "NA",
        sharpe_ratio=found["sharpe_ratio"] if not is_empty(found["sharpe_ratio"]) else "NA",
        source_file=excel_path,
        source_sheet=str(worksheet.Name),
    )
    log(
        f"  FOUND '{record.fund_name}' on sheet '{record.source_sheet}' | "
        f"SD={record.standard_deviation} | Beta={record.beta} | Sharpe={record.sharpe_ratio}"
    )
    return record


def record_priority(record: FundRiskData) -> tuple[int, int, int]:
    name = record.source_sheet.casefold()
    return (record.completeness(), int("dir" in name and "data" not in name), -len(name))


def read_excel_source(excel_path: Path, log: Callable[[str], None]) -> list[FundRiskData]:
    if not excel_path.is_file():
        raise FileNotFoundError(f"Excel file not found:\n{excel_path}")
    if excel_path.suffix.lower() not in EXCEL_EXTENSIONS:
        raise ValueError("Select a valid Excel workbook: .xls, .xlsx, .xlsm, or .xlsb")
    if excel_path.name.startswith("~$"):
        raise ValueError("Select the actual workbook, not Excel's temporary lock file.")

    excel = None
    workbook = None
    all_records: list[FundRiskData] = []
    try:
        log(f"Excel workbook: {excel_path.name}")
        excel = win32.DispatchEx("Excel.Application")
        excel.Visible = False
        excel.DisplayAlerts = False
        excel.ScreenUpdating = False
        excel.EnableEvents = False
        workbook = excel.Workbooks.Open(
            str(excel_path.resolve()), UpdateLinks=0, ReadOnly=True,
            IgnoreReadOnlyRecommended=True,
        )
        sheet_count = int(workbook.Worksheets.Count)
        log(f"Worksheets found: {sheet_count}")
        for sheet_no in range(1, sheet_count + 1):
            worksheet = workbook.Worksheets.Item(sheet_no)
            log(f"Scanning sheet {sheet_no}/{sheet_count}: {worksheet.Name}")
            try:
                record = read_sheet_record(worksheet, excel_path, log)
                if record is not None:
                    all_records.append(record)
            except Exception as exc:
                log(f"  WARNING sheet '{worksheet.Name}': {exc}")
    finally:
        if workbook is not None:
            try:
                workbook.Close(SaveChanges=False)
            except Exception:
                pass
        if excel is not None:
            try:
                excel.Quit()
            except Exception:
                pass

    best: dict[str, FundRiskData] = {}
    for record in all_records:
        key = normalize_fund_name(record.fund_name)
        if not key:
            continue
        existing = best.get(key)
        if existing is None or record_priority(record) > record_priority(existing):
            best[key] = record
    records = sorted(best.values(), key=lambda item: normalize_fund_name(item.fund_name))
    if not records:
        raise RuntimeError("No usable fund risk parameters were found in any worksheet.")
    log(f"Unique fund records after de-duplication: {len(records)}")
    return records


def parse_number(value: Any) -> tuple[Optional[float], bool]:
    if value is None or isinstance(value, bool):
        return None, False
    if isinstance(value, (int, float)):
        return float(value), False
    text = clean_text(value)
    if normalize_text(text) in {"na", "n a", "nil", "none", "-"}:
        return None, False
    had_percent = "%" in text
    try:
        return float(text.replace("%", "").replace(",", "").strip()), had_percent
    except ValueError:
        return None, had_percent


def format_percentage(value: Any) -> str:
    if normalize_text(value) in {"na", "n a", "nil", "none", "-"}:
        return "NA"
    number, had_percent = parse_number(value)
    if number is None:
        return clean_text(value) or "NA"
    if not had_percent and abs(number) <= 1:
        number *= 100
    return f"{number:.2f}%"


def format_decimal(value: Any) -> str:
    if normalize_text(value) in {"na", "n a", "nil", "none", "-"}:
        return "NA"
    number, _ = parse_number(value)
    if number is None:
        return clean_text(value) or "NA"
    return f"{number:.2f}"


def formatted_record(record: FundRiskData) -> dict[str, str]:
    return {
        "standard_deviation": format_percentage(record.standard_deviation),
        "beta": format_decimal(record.beta),
        "sharpe_ratio": format_decimal(record.sharpe_ratio),
    }


def iter_shapes(collection: Any) -> Iterator[Any]:
    for index in range(1, collection.Count + 1):
        shape = collection.Item(index)
        yield shape
        try:
            if int(shape.Type) == MSO_GROUP:
                yield from iter_shapes(shape.GroupItems)
        except Exception:
            pass


def shape_name(shape: Any) -> str:
    try:
        return clean_text(shape.Name)
    except Exception:
        return ""


def find_named_shapes(slide: Any, required_name: str) -> list[Any]:
    target = normalize_text(required_name)
    return [s for s in iter_shapes(slide.Shapes) if normalize_text(shape_name(s)) == target]


def shape_text(shape: Any) -> str:
    try:
        return clean_text(shape.TextFrame.TextRange.Text)
    except Exception:
        return ""


def get_slide_fund_name(slide: Any) -> Optional[str]:
    for shape in find_named_shapes(slide, FUND_NAME_OBJECT):
        text = shape_text(shape)
        if text:
            return text
    return None


def table_cell_text(table: Any, row: int, col: int) -> str:
    try:
        return clean_text(table.Cell(row, col).Shape.TextFrame.TextRange.Text)
    except Exception:
        return ""


def find_table_label(table: Any, aliases: tuple[str, ...]) -> Optional[tuple[int, int]]:
    for row in range(1, table.Rows.Count + 1):
        for col in range(1, table.Columns.Count + 1):
            if label_matches(table_cell_text(table, row, col), aliases):
                return row, col
    return None


def find_table_value_position(table: Any, label_row: int, label_col: int) -> Optional[tuple[int, int]]:
    """Return value cell for vertical or horizontal Risk Parameters tables."""
    rows = int(table.Rows.Count)
    cols = int(table.Columns.Count)
    right = (label_row, label_col + 1) if label_col < cols else None
    below = (label_row + 1, label_col) if label_row < rows else None
    right_text = table_cell_text(table, *right) if right else ""
    below_text = table_cell_text(table, *below) if below else ""

    # Horizontal layout: the right-hand cell is another label; value is below.
    if right and is_parameter_label(right_text) and below:
        return below
    # Vertical layout: the cell below is another label; value is on the right.
    if below and is_parameter_label(below_text) and right:
        return right
    if right and usable_parameter_value(right_text):
        return right
    if below and usable_parameter_value(below_text):
        return below
    # Empty-cell structural fallbacks.
    if rows == 2 and cols >= 3 and below:
        return below
    if rows >= 3 and cols >= 2 and right:
        return right
    return right or below


def find_risk_tables(slide: Any) -> list[Any]:
    named = find_named_shapes(slide, RISK_PARAMETERS_OBJECT)
    if named:
        return named
    fallback: list[Any] = []
    for shape in iter_shapes(slide.Shapes):
        try:
            if shape.HasTable != MSO_TRUE:
                continue
            table = shape.Table
            score = sum(find_table_label(table, aliases) is not None for aliases in PARAMETER_ALIASES.values())
            if score >= 2:
                fallback.append(shape)
        except Exception:
            pass
    return fallback


def find_fund_record(ppt_name: str, records: list[FundRiskData]) -> Optional[FundRiskData]:
    target = normalize_fund_name(ppt_name)
    exact = [r for r in records if normalize_fund_name(r.fund_name) == target]
    if exact:
        return max(exact, key=record_priority)
    candidates = [r for r in records if fund_names_match(ppt_name, r.fund_name)]
    if not candidates:
        return None
    return max(candidates, key=lambda r: (record_priority(r), len(normalize_fund_name(r.fund_name))))


def write_table_value(cell: Any, text: str) -> None:
    text_range = cell.Shape.TextFrame.TextRange
    text_range.Text = text
    text_range.Font.Name = FONT_NAME
    text_range.Font.Size = FONT_SIZE
    text_range.Font.Bold = MSO_FALSE
    text_range.Font.Italic = MSO_FALSE


def update_risk_table(shape: Any, record: FundRiskData, log: Callable[[str], None]) -> int:
    if shape.HasTable != MSO_TRUE:
        raise RuntimeError(f"'{RISK_PARAMETERS_OBJECT}' exists but is not a table.")
    table = shape.Table
    values = formatted_record(record)
    updated = 0
    for key, display in (
        ("standard_deviation", "Standard Deviation"),
        ("beta", "Beta"),
        ("sharpe_ratio", "Sharpe Ratio"),
    ):
        position = find_table_label(table, PARAMETER_ALIASES[key])
        if position is None:
            log(f"    WARNING: label not found for {display}")
            continue
        value_position = find_table_value_position(table, *position)
        if value_position is None:
            log(f"    WARNING: value cell not found for {display}")
            continue
        value = values[key] or "NA"
        write_table_value(table.Cell(*value_position), value)
        written = table_cell_text(table, *value_position)
        if clean_text(written) != clean_text(value):
            raise RuntimeError(f"Verification failed for {display}: expected '{value}', got '{written}'")
        relation = "right of label" if value_position[0] == position[0] else "below label"
        log(f"    Updated {display}: {value} ({relation})")
        updated += 1
    return updated


def update_powerpoint(
    input_ppt: Path,
    output_ppt: Path,
    records: list[FundRiskData],
    log: Callable[[str], None],
    progress: Callable[[int], None],
) -> tuple[int, int]:
    powerpoint = None
    presentation = None
    updated_slides = 0
    updated_values = 0
    try:
        log("Starting Microsoft PowerPoint...")
        powerpoint = win32.DispatchEx("PowerPoint.Application")
        powerpoint.Visible = True
        try:
            powerpoint.WindowState = PP_WINDOW_MINIMIZED
        except Exception:
            pass
        presentation = powerpoint.Presentations.Open(
            str(input_ppt.resolve()), ReadOnly=False, Untitled=False, WithWindow=True
        )
        slide_count = int(presentation.Slides.Count)
        log(f"Slides found: {slide_count}")
        current_fund: Optional[str] = None
        current_fund_slide = 0
        for slide_no in range(1, slide_count + 1):
            progress(15 + int(slide_no / max(slide_count, 1) * 75))
            slide = presentation.Slides.Item(slide_no)
            found_name = get_slide_fund_name(slide)
            if found_name:
                current_fund, current_fund_slide = found_name, slide_no
                log(f"Slide {slide_no}: FundName = {found_name}")
            tables = find_risk_tables(slide)
            if not tables:
                continue
            if not current_fund or slide_no - current_fund_slide > 4:
                log(f"Slide {slide_no}: RiskParameters found without a FundName in the same four-slide block; skipped.")
                continue
            record = find_fund_record(current_fund, records)
            if record is None:
                log(f"Slide {slide_no}: no Excel match for '{current_fund}'.")
                continue
            source_name = record.source_file.name if record.source_file else "Unknown"
            log(f"  Matched '{record.fund_name}' from {source_name} / {record.source_sheet}")
            count = sum(update_risk_table(table, record, log) for table in tables)
            if count:
                updated_slides += 1
                updated_values += count
        output_ppt.parent.mkdir(parents=True, exist_ok=True)
        if output_ppt.exists():
            output_ppt.unlink()
        progress(95)
        presentation.SaveAs(str(output_ppt.resolve()), PP_SAVE_AS_OPEN_XML_PRESENTATION)
        progress(100)
        return updated_slides, updated_values
    finally:
        if presentation is not None:
            try:
                presentation.Close()
            except Exception:
                pass
        if powerpoint is not None:
            try:
                powerpoint.Quit()
            except Exception:
                pass


def write_log(path: Path, lines: list[str]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text("\n".join(lines), encoding="utf-8")


class RiskParameterWorker(QObject):
    log = pyqtSignal(str)
    progress = pyqtSignal(int)
    completed = pyqtSignal(int, int, str, str)
    failed = pyqtSignal(str, str)

    def __init__(self, input_ppt: Path, excel_file: Path, output_folder: Path) -> None:
        super().__init__()
        self.input_ppt = input_ppt
        self.excel_file = excel_file
        self.output_folder = output_folder

    def run(self) -> None:
        pythoncom.CoInitialize()
        lines: list[str] = []
        stamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        output_ppt = self.output_folder / f"{self.input_ppt.stem}_RiskParameters_Updated.pptx"
        log_file = self.output_folder / f"RiskParameters_Log_{stamp}.txt"

        def emit(message: str) -> None:
            lines.append(str(message))
            self.log.emit(str(message))

        try:
            self.output_folder.mkdir(parents=True, exist_ok=True)
            emit("=" * 72)
            emit("RISK PARAMETERS UPDATER - SINGLE WORKBOOK / ALL SHEETS")
            emit("=" * 72)
            emit(f"Input PowerPoint: {self.input_ppt}")
            emit(f"Excel workbook: {self.excel_file}")
            self.progress.emit(2)
            records = read_excel_source(self.excel_file, emit)
            self.progress.emit(12)
            slides, values = update_powerpoint(self.input_ppt, output_ppt, records, emit, self.progress.emit)
            emit(f"SUCCESS | Slides updated: {slides} | Values updated: {values}")
            write_log(log_file, lines)
            self.completed.emit(slides, values, str(output_ppt), str(log_file))
        except Exception as exc:
            details = traceback.format_exc()
            emit(f"FAILED: {exc}")
            emit(details)
            try:
                write_log(log_file, lines)
            except Exception:
                pass
            self.failed.emit(str(exc), details)
        finally:
            pythoncom.CoUninitialize()


class MainWindow(QMainWindow):
    def __init__(self) -> None:
        super().__init__()
        self.thread: Optional[QThread] = None
        self.worker: Optional[RiskParameterWorker] = None
        self.setWindowTitle("Risk Parameters PowerPoint Updater - Single Excel File")
        self.resize(980, 720)
        self.build_ui()

    def build_ui(self) -> None:
        root = QWidget()
        self.setCentralWidget(root)
        layout = QVBoxLayout(root)
        layout.setContentsMargins(24, 20, 24, 20)
        layout.setSpacing(14)
        title = QLabel("Risk Parameters PowerPoint Updater")
        title.setStyleSheet("font-size: 20px; font-weight: 700; color: #1F4E79;")
        description = QLabel(
            "Scans every worksheet in the selected Excel workbook, extracts each fund's "
            "Standard Deviation, Beta and Sharpe Ratio, then updates horizontal or vertical "
            "RiskParameters tables in the matching four-slide PowerPoint fund block."
        )
        description.setWordWrap(True)
        layout.addWidget(title)
        layout.addWidget(description)
        form = QFormLayout()
        form.setHorizontalSpacing(12)
        form.setVerticalSpacing(12)
        self.ppt_edit = QLineEdit()
        self.excel_file_edit = QLineEdit()
        self.output_folder_edit = QLineEdit()
        form.addRow("Input PowerPoint:", self.path_row(self.ppt_edit, self.pick_ppt))
        form.addRow("Factsheet Excel file:", self.path_row(self.excel_file_edit, self.pick_excel_file))
        form.addRow("Output folder:", self.path_row(self.output_folder_edit, self.pick_output_folder))
        layout.addLayout(form)
        buttons = QHBoxLayout()
        self.run_button = QPushButton("Update Risk Parameters")
        self.run_button.clicked.connect(self.start_processing)
        clear = QPushButton("Clear Log")
        clear.clicked.connect(self.log_box_clear)
        buttons.addWidget(self.run_button)
        buttons.addWidget(clear)
        buttons.addStretch()
        layout.addLayout(buttons)
        self.progress_bar = QProgressBar()
        self.progress_bar.setRange(0, 100)
        self.progress_bar.setFormat("Ready")
        self.status_label = QLabel("Ready")
        self.log_box = QPlainTextEdit()
        self.log_box.setReadOnly(True)
        layout.addWidget(self.progress_bar)
        layout.addWidget(self.status_label)
        layout.addWidget(self.log_box, 1)

    def path_row(self, edit: QLineEdit, handler: Callable[[], None]) -> QWidget:
        widget = QWidget()
        row = QHBoxLayout(widget)
        row.setContentsMargins(0, 0, 0, 0)
        button = QPushButton("Browse...")
        button.clicked.connect(handler)
        row.addWidget(edit, 1)
        row.addWidget(button)
        return widget

    def pick_ppt(self) -> None:
        filename, _ = QFileDialog.getOpenFileName(self, "Select PowerPoint", "", "PowerPoint (*.pptx)")
        if filename:
            path = Path(filename)
            self.ppt_edit.setText(str(path))
            if not self.output_folder_edit.text().strip():
                self.output_folder_edit.setText(str(path.parent))

    def pick_excel_file(self) -> None:
        start = str(Path(self.ppt_edit.text()).parent) if self.ppt_edit.text().strip() else ""
        filename, _ = QFileDialog.getOpenFileName(
            self, "Select factsheet Excel workbook", start,
            "Excel Workbooks (*.xlsx *.xlsm *.xlsb *.xls);;All Files (*.*)",
        )
        if filename:
            self.excel_file_edit.setText(filename)

    def pick_output_folder(self) -> None:
        folder = QFileDialog.getExistingDirectory(self, "Select output folder", "")
        if folder:
            self.output_folder_edit.setText(folder)

    def validate_inputs(self) -> Optional[tuple[Path, Path, Path]]:
        ppt_text = self.ppt_edit.text().strip()
        excel_text = self.excel_file_edit.text().strip()
        output_text = self.output_folder_edit.text().strip()
        ppt = Path(ppt_text) if ppt_text else None
        excel_file = Path(excel_text) if excel_text else None
        output_folder = Path(output_text) if output_text else None
        if ppt is None or not ppt.is_file() or ppt.suffix.lower() != ".pptx":
            QMessageBox.warning(self, "Invalid PowerPoint", "Select a valid .pptx file.")
            return None
        if excel_file is None or not excel_file.is_file() or excel_file.suffix.lower() not in EXCEL_EXTENSIONS:
            QMessageBox.warning(self, "Invalid Excel file", "Select a valid factsheet Excel workbook.")
            return None
        if output_folder is None:
            QMessageBox.warning(self, "Missing output folder", "Select an output folder.")
            return None
        output_folder.mkdir(parents=True, exist_ok=True)
        return ppt, excel_file, output_folder

    def start_processing(self) -> None:
        selected = self.validate_inputs()
        if selected is None:
            return
        self.log_box.clear()
        self.run_button.setEnabled(False)
        self.progress_bar.setValue(0)
        self.progress_bar.setFormat("%p%")
        self.status_label.setText("Scanning every worksheet and updating PowerPoint...")
        self.thread = QThread(self)
        self.worker = RiskParameterWorker(*selected)
        self.worker.moveToThread(self.thread)
        self.thread.started.connect(self.worker.run)
        self.worker.log.connect(self.log_box.appendPlainText)
        self.worker.progress.connect(self.progress_bar.setValue)
        self.worker.completed.connect(self.processing_completed)
        self.worker.failed.connect(self.processing_failed)
        self.worker.completed.connect(self.thread.quit)
        self.worker.failed.connect(self.thread.quit)
        self.thread.finished.connect(self.cleanup_thread)
        self.thread.start()

    def log_box_clear(self) -> None:
        self.log_box.clear()

    def processing_completed(self, slides: int, values: int, output_file: str, log_file: str) -> None:
        self.run_button.setEnabled(True)
        self.progress_bar.setValue(100)
        self.progress_bar.setFormat("Completed")
        self.status_label.setText(f"Completed: {slides} slide(s), {values} value(s)")
        QMessageBox.information(
            self, "Completed",
            f"Slides updated: {slides}\nValues updated: {values}\n\nOutput:\n{output_file}\n\nLog:\n{log_file}",
        )

    def processing_failed(self, error: str, details: str) -> None:
        self.run_button.setEnabled(True)
        self.progress_bar.setFormat("Failed")
        self.status_label.setText("Processing failed")
        self.log_box.appendPlainText("\nERROR DETAILS:\n" + details)
        QMessageBox.critical(self, "Processing failed", error)

    def cleanup_thread(self) -> None:
        if self.worker:
            self.worker.deleteLater()
        if self.thread:
            self.thread.deleteLater()
        self.worker = None
        self.thread = None

    def closeEvent(self, event: QCloseEvent) -> None:
        if self.thread is not None and self.thread.isRunning():
            QMessageBox.information(self, "Processing", "Wait for processing to finish.")
            event.ignore()
        else:
            event.accept()


def main() -> int:
    app = QApplication(sys.argv)
    app.setApplicationName("Risk Parameters PowerPoint Updater")
    app.setStyle("Fusion")
    window = MainWindow()
    window.show()
    return app.exec()


if __name__ == "__main__":
    sys.exit(main())
