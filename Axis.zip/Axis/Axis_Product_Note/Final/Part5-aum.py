import os
import re
import sys
import traceback
import unicodedata
from decimal import Decimal, InvalidOperation, ROUND_HALF_UP

import pythoncom
import win32com.client as win32
from PyQt6.QtCore import QThread, pyqtSignal
from PyQt6.QtGui import QFont
from PyQt6.QtWidgets import (
    QApplication, QCheckBox, QFileDialog, QGridLayout, QGroupBox,
    QHBoxLayout, QLabel, QLineEdit, QMainWindow, QMessageBox,
    QPlainTextEdit, QPushButton, QProgressBar, QSpinBox,
    QVBoxLayout, QWidget,
)

# Excel / PowerPoint settings
DEFAULT_SHEET = "Scheme List"
SCHEME_HEADER = "Name of Scheme"
AUM_HEADER = "AUM"
FUND_OBJECT = "FundName"
AUM_OBJECT = "AUMData"

MSO_GROUP = 6
MSO_TRUE = -1
XL_UP = -4162
PP_SAVE_AS_PPTX = 24


def normalize_text(value):
    """Normalize names so case, *, &, punctuation, spacing and line breaks do not block matching."""
    if value is None:
        return ""
    text = unicodedata.normalize("NFKC", str(value))
    replacements = {
        "\u00a0": " ", "\u2018": "'", "\u2019": "'",
        "\u201c": '"', "\u201d": '"', "\u2013": "-",
        "\u2014": "-", "\u2212": "-", "&": " and ",
    }
    for old, new in replacements.items():
        text = text.replace(old, new)
    text = text.casefold()
    text = re.sub(r"[^a-z0-9]+", " ", text)
    return re.sub(r"\s+", " ", text).strip()


def clean_text(value):
    if value is None:
        return ""
    return re.sub(r"\s+", " ", str(value).replace("\v", " ")).strip()


def to_decimal(value):
    if value is None or isinstance(value, bool):
        return None
    if isinstance(value, Decimal):
        return value
    if isinstance(value, (int, float)):
        try:
            return Decimal(str(value))
        except InvalidOperation:
            return None
    text = str(value).replace(",", "").replace("₹", "").strip()
    text = re.sub(r"\b(?:INR|Rs\.?|Crores?|Cr\.?)\b", "", text, flags=re.I)
    match = re.search(r"[-+]?\d+(?:\.\d+)?", text)
    if not match:
        return None
    try:
        return Decimal(match.group(0))
    except InvalidOperation:
        return None


def indian_format(text):
    negative = text.startswith("-")
    if negative:
        text = text[1:]
    whole, dot, fraction = text.partition(".")
    if len(whole) > 3:
        last_three = whole[-3:]
        remaining = whole[:-3]
        groups = []
        while len(remaining) > 2:
            groups.insert(0, remaining[-2:])
            remaining = remaining[:-2]
        if remaining:
            groups.insert(0, remaining)
        whole = ",".join(groups + [last_three])
    result = whole + (dot + fraction if dot else "")
    return "-" + result if negative else result


def format_aum(value, decimals, use_indian_commas):
    number = to_decimal(value)
    if number is None:
        return ""
    number = number.quantize(Decimal("1").scaleb(-decimals), rounding=ROUND_HALF_UP)
    text = f"{number:.{decimals}f}"
    if use_indian_commas:
        text = indian_format(text)
    return f"₹ {text} Cr"


def find_headers(sheet, search_rows=25):
    used = sheet.UsedRange
    first_row, first_col = used.Row, used.Column
    last_row = first_row + used.Rows.Count - 1
    last_col = first_col + used.Columns.Count - 1
    wanted_scheme = normalize_text(SCHEME_HEADER)
    wanted_aum = normalize_text(AUM_HEADER)

    for row in range(first_row, min(last_row, first_row + search_rows - 1) + 1):
        scheme_col = aum_col = None
        for col in range(first_col, last_col + 1):
            header = normalize_text(sheet.Cells(row, col).Value)
            if header == wanted_scheme:
                scheme_col = col
            elif header == wanted_aum:
                aum_col = col
        if scheme_col and aum_col:
            return row, scheme_col, aum_col
    raise ValueError(
        f"Could not find '{SCHEME_HEADER}' and '{AUM_HEADER}' in worksheet '{sheet.Name}'."
    )


def select_sheet(workbook, requested_name):
    if requested_name:
        for i in range(1, workbook.Worksheets.Count + 1):
            sheet = workbook.Worksheets.Item(i)
            if str(sheet.Name).strip().casefold() == requested_name.strip().casefold():
                return sheet
    for i in range(1, workbook.Worksheets.Count + 1):
        sheet = workbook.Worksheets.Item(i)
        try:
            find_headers(sheet)
            return sheet
        except ValueError:
            pass
    raise ValueError("No worksheet containing Name of Scheme and AUM was found.")


def read_excel(excel_path, sheet_name, log):
    excel = workbook = None
    try:
        log("Opening Excel...")
        excel = win32.DispatchEx("Excel.Application")
        excel.Visible = False
        excel.DisplayAlerts = False
        workbook = excel.Workbooks.Open(os.path.abspath(excel_path), UpdateLinks=0, ReadOnly=True)
        sheet = select_sheet(workbook, sheet_name)
        header_row, scheme_col, aum_col = find_headers(sheet)
        log(f"Using worksheet '{sheet.Name}', header row {header_row}.")

        last_row = max(
            sheet.Cells(sheet.Rows.Count, scheme_col).End(XL_UP).Row,
            sheet.Cells(sheet.Rows.Count, aum_col).End(XL_UP).Row,
        )
        lookup = {}
        for row in range(header_row + 1, last_row + 1):
            scheme = clean_text(sheet.Cells(row, scheme_col).Value2)
            aum = to_decimal(sheet.Cells(row, aum_col).Value2)
            if not scheme or aum is None:
                continue
            key = normalize_text(scheme)
            if key not in lookup:
                lookup[key] = {"scheme": scheme, "aum": aum, "row": row}
            else:
                log(f"Duplicate Excel name ignored at row {row}: {scheme}")

        if not lookup:
            raise ValueError("No valid scheme/AUM records were found in Excel.")
        log(f"Loaded {len(lookup)} scheme/AUM records.")
        return lookup
    finally:
        if workbook is not None:
            try:
                workbook.Close(False)
            except Exception:
                pass
        if excel is not None:
            try:
                excel.Quit()
            except Exception:
                pass


def get_shape_name(shape):
    try:
        return str(shape.Name).strip()
    except Exception:
        return ""


def find_in_shape(shape, target_name):
    found = []
    if get_shape_name(shape).casefold() == target_name.casefold():
        found.append(shape)
    try:
        if int(shape.Type) == MSO_GROUP:
            for i in range(1, shape.GroupItems.Count + 1):
                found.extend(find_in_shape(shape.GroupItems.Item(i), target_name))
    except Exception:
        pass
    return found


def find_on_slide(slide, target_name):
    found = []
    for i in range(1, slide.Shapes.Count + 1):
        found.extend(find_in_shape(slide.Shapes.Item(i), target_name))
    return found


def get_shape_text(shape):
    try:
        if shape.HasTextFrame == MSO_TRUE:
            return clean_text(shape.TextFrame.TextRange.Text)
    except Exception:
        pass
    try:
        return clean_text(shape.TextFrame2.TextRange.Text)
    except Exception:
        return ""


def set_shape_text(shape, text):
    try:
        if shape.HasTextFrame == MSO_TRUE:
            shape.TextFrame.TextRange.Text = text
            return
    except Exception:
        pass
    try:
        shape.TextFrame2.TextRange.Text = text
    except Exception as exc:
        raise ValueError(f"PowerPoint object '{get_shape_name(shape)}' cannot accept text.") from exc


def unique_output(path):
    if not os.path.exists(path):
        return path
    folder, filename = os.path.split(path)
    stem, extension = os.path.splitext(filename)
    number = 1
    while True:
        candidate = os.path.join(folder, f"{stem}_{number}{extension}")
        if not os.path.exists(candidate):
            return candidate
        number += 1


def collect_presentation_objects(presentation, log, progress):
    """Collect FundName and AUMData objects globally in slide order."""
    funds = []
    aums = []
    slide_count = presentation.Slides.Count

    for slide_no in range(1, slide_count + 1):
        slide = presentation.Slides.Item(slide_no)
        fund_shapes = find_on_slide(slide, FUND_OBJECT)
        aum_shapes = find_on_slide(slide, AUM_OBJECT)

        for order, shape in enumerate(fund_shapes, start=1):
            funds.append({
                "slide": slide_no,
                "order": order,
                "shape": shape,
                "name": get_shape_text(shape),
            })
        for order, shape in enumerate(aum_shapes, start=1):
            aums.append({
                "slide": slide_no,
                "order": order,
                "shape": shape,
            })

        if fund_shapes or aum_shapes:
            log(
                f"Slide {slide_no}: {len(fund_shapes)} FundName and "
                f"{len(aum_shapes)} AUMData object(s)."
            )
        progress(int((slide_no / slide_count) * 35))

    return funds, aums


def pair_funds_with_aums(funds, aums):
    """
    Pair each FundName with the first unused AUMData occurring after it
    and before the next FundName. If none exists in that interval, use
    the next unused AUMData anywhere later in the presentation.
    """
    pairs = []
    used_aum_indexes = set()

    for fund_index, fund in enumerate(funds):
        next_fund_slide = funds[fund_index + 1]["slide"] if fund_index + 1 < len(funds) else float("inf")
        selected = None

        # Preferred: AUM after the fund and before the next fund.
        for aum_index, aum in enumerate(aums):
            if aum_index in used_aum_indexes:
                continue
            if fund["slide"] <= aum["slide"] < next_fund_slide:
                selected = aum_index
                break

        # Fallback: next unused AUM on any later slide.
        if selected is None:
            for aum_index, aum in enumerate(aums):
                if aum_index in used_aum_indexes:
                    continue
                if aum["slide"] >= fund["slide"]:
                    selected = aum_index
                    break

        if selected is None:
            pairs.append((fund, None))
        else:
            used_aum_indexes.add(selected)
            pairs.append((fund, aums[selected]))

    return pairs


def update_powerpoint(ppt_path, output_path, lookup, decimals, indian_commas,
                      overwrite, keep_open, log, progress):
    powerpoint = presentation = None
    matched = updated = 0
    unmatched = []
    missing_aum = []

    try:
        log("Opening PowerPoint...")
        powerpoint = win32.DispatchEx("PowerPoint.Application")
        powerpoint.Visible = True
        presentation = powerpoint.Presentations.Open(
            os.path.abspath(ppt_path), ReadOnly=False, Untitled=False, WithWindow=True
        )
        if presentation.Slides.Count == 0:
            raise ValueError("The presentation contains no slides.")

        funds, aums = collect_presentation_objects(presentation, log, progress)
        log(f"Found {len(funds)} FundName object(s) and {len(aums)} AUMData object(s) in total.")
        log("Pairing objects across slides in presentation order...")

        pairs = pair_funds_with_aums(funds, aums)
        total = max(len(pairs), 1)

        for index, (fund, aum) in enumerate(pairs, start=1):
            fund_name = fund["name"]
            record = lookup.get(normalize_text(fund_name))

            if record is None:
                unmatched.append((fund["slide"], fund_name or "(blank FundName)"))
                log(f"No Excel match on slide {fund['slide']}: {fund_name or '(blank FundName)'}")
                progress(35 + int((index / total) * 55))
                continue

            matched += 1
            if aum is None:
                missing_aum.append((fund["slide"], fund_name))
                log(f"No later AUMData object for FundName on slide {fund['slide']}: {fund_name}")
                progress(35 + int((index / total) * 55))
                continue

            previous_text = get_shape_text(aum["shape"])
            if previous_text and not overwrite:
                log(
                    f"Skipped {fund_name}: AUMData on slide {aum['slide']} "
                    f"already contains '{previous_text}'."
                )
                progress(35 + int((index / total) * 55))
                continue

            value = format_aum(record["aum"], decimals, indian_commas)
            set_shape_text(aum["shape"], value)
            updated += 1
            log(
                f"Updated '{fund_name}' from FundName slide {fund['slide']} "
                f"into AUMData slide {aum['slide']} -> {value}"
            )
            progress(35 + int((index / total) * 55))

        output_path = os.path.splitext(os.path.abspath(output_path))[0] + ".pptx"
        output_path = unique_output(output_path)
        log(f"Saving: {output_path}")
        presentation.SaveAs(output_path, PP_SAVE_AS_PPTX)
        progress(100)

        if keep_open:
            presentation.Saved = True
        else:
            presentation.Close()
            presentation = None

        return {
            "output": output_path,
            "fund_objects": len(funds),
            "aum_objects": len(aums),
            "matched": matched,
            "updated": updated,
            "unmatched": unmatched,
            "missing_aum": missing_aum,
        }
    finally:
        if presentation is not None and not keep_open:
            try:
                presentation.Close()
            except Exception:
                pass
        if powerpoint is not None and not keep_open:
            try:
                powerpoint.Quit()
            except Exception:
                pass


class Worker(QThread):
    log_signal = pyqtSignal(str)
    progress_signal = pyqtSignal(int)
    done_signal = pyqtSignal(dict)
    error_signal = pyqtSignal(str)

    def __init__(self, settings):
        super().__init__()
        self.settings = settings

    def run(self):
        pythoncom.CoInitialize()
        try:
            lookup = read_excel(
                self.settings["excel"], self.settings["sheet"], self.log_signal.emit
            )
            result = update_powerpoint(
                self.settings["ppt"], self.settings["output"], lookup,
                self.settings["decimals"], self.settings["indian_commas"],
                self.settings["overwrite"], self.settings["keep_open"],
                self.log_signal.emit, self.progress_signal.emit,
            )
            self.done_signal.emit(result)
        except Exception:
            error = traceback.format_exc()
            self.log_signal.emit(error)
            self.error_signal.emit(error)
        finally:
            pythoncom.CoUninitialize()


class MainWindow(QMainWindow):
    def __init__(self):
        super().__init__()
        self.worker = None
        self.setWindowTitle("Excel AUM to PowerPoint Updater - Cross-Slide")
        self.resize(920, 700)
        self.build_ui()

    def build_ui(self):
        central = QWidget()
        self.setCentralWidget(central)
        layout = QVBoxLayout(central)

        title = QLabel("Excel AUM to PowerPoint Updater")
        font = QFont()
        font.setPointSize(16)
        font.setBold(True)
        title.setFont(font)
        description = QLabel(
            "This version supports FundName and AUMData objects on different slides. "
            "Each FundName is paired with the next AUMData before the following FundName."
        )
        description.setWordWrap(True)
        layout.addWidget(title)
        layout.addWidget(description)

        files_box = QGroupBox("Files")
        files = QGridLayout(files_box)
        self.excel_edit = QLineEdit()
        self.ppt_edit = QLineEdit()
        self.output_edit = QLineEdit()
        excel_button = QPushButton("Browse...")
        ppt_button = QPushButton("Browse...")
        output_button = QPushButton("Browse...")
        excel_button.clicked.connect(self.select_excel)
        ppt_button.clicked.connect(self.select_ppt)
        output_button.clicked.connect(self.select_output)
        files.addWidget(QLabel("Excel file:"), 0, 0)
        files.addWidget(self.excel_edit, 0, 1)
        files.addWidget(excel_button, 0, 2)
        files.addWidget(QLabel("PowerPoint file:"), 1, 0)
        files.addWidget(self.ppt_edit, 1, 1)
        files.addWidget(ppt_button, 1, 2)
        files.addWidget(QLabel("Output PowerPoint:"), 2, 0)
        files.addWidget(self.output_edit, 2, 1)
        files.addWidget(output_button, 2, 2)
        layout.addWidget(files_box)

        settings_box = QGroupBox("Settings")
        settings = QGridLayout(settings_box)
        self.sheet_edit = QLineEdit(DEFAULT_SHEET)
        self.decimal_spin = QSpinBox()
        self.decimal_spin.setRange(0, 6)
        self.decimal_spin.setValue(2)
        self.indian_checkbox = QCheckBox("Use Indian comma formatting")
        self.overwrite_checkbox = QCheckBox("Overwrite existing AUMData text")
        self.overwrite_checkbox.setChecked(True)
        self.keep_open_checkbox = QCheckBox("Keep PowerPoint open after completion")
        settings.addWidget(QLabel("Worksheet:"), 0, 0)
        settings.addWidget(self.sheet_edit, 0, 1)
        settings.addWidget(QLabel("Decimal places:"), 1, 0)
        settings.addWidget(self.decimal_spin, 1, 1)
        settings.addWidget(self.indian_checkbox, 2, 0, 1, 2)
        settings.addWidget(self.overwrite_checkbox, 3, 0, 1, 2)
        settings.addWidget(self.keep_open_checkbox, 4, 0, 1, 2)
        settings.addWidget(QLabel("Output example: ₹ 31448.32 Cr"), 5, 0, 1, 2)
        layout.addWidget(settings_box)

        controls = QHBoxLayout()
        self.run_button = QPushButton("Update PowerPoint AUM")
        self.run_button.setMinimumHeight(38)
        self.run_button.clicked.connect(self.start)
        self.progress = QProgressBar()
        controls.addWidget(self.run_button)
        controls.addWidget(self.progress)
        layout.addLayout(controls)

        self.log_box = QPlainTextEdit()
        self.log_box.setReadOnly(True)
        layout.addWidget(self.log_box)

    def select_excel(self):
        path, _ = QFileDialog.getOpenFileName(
            self, "Select Excel file", "", "Excel files (*.xlsx *.xlsm *.xls)"
        )
        if path:
            self.excel_edit.setText(path)

    def select_ppt(self):
        path, _ = QFileDialog.getOpenFileName(
            self, "Select PowerPoint file", "", "PowerPoint files (*.pptx *.pptm *.ppt)"
        )
        if path:
            self.ppt_edit.setText(path)
            folder = os.path.dirname(path)
            stem = os.path.splitext(os.path.basename(path))[0]
            self.output_edit.setText(os.path.join(folder, stem + "_AUM_Updated.pptx"))

    def select_output(self):
        path, _ = QFileDialog.getSaveFileName(
            self, "Save updated PowerPoint", self.output_edit.text(),
            "PowerPoint presentation (*.pptx)"
        )
        if path:
            if not path.lower().endswith(".pptx"):
                path += ".pptx"
            self.output_edit.setText(path)

    def start(self):
        excel = self.excel_edit.text().strip()
        ppt = self.ppt_edit.text().strip()
        output = self.output_edit.text().strip()
        if not os.path.isfile(excel):
            QMessageBox.warning(self, "Excel file", "Select a valid Excel file.")
            return
        if not os.path.isfile(ppt):
            QMessageBox.warning(self, "PowerPoint file", "Select a valid PowerPoint file.")
            return
        if not output:
            QMessageBox.warning(self, "Output file", "Select an output file.")
            return
        if os.path.abspath(ppt) == os.path.abspath(output):
            QMessageBox.warning(self, "Output file", "Output must differ from the input PowerPoint.")
            return

        self.log_box.clear()
        self.progress.setValue(0)
        self.run_button.setEnabled(False)
        self.worker = Worker({
            "excel": excel,
            "ppt": ppt,
            "output": output,
            "sheet": self.sheet_edit.text().strip(),
            "decimals": self.decimal_spin.value(),
            "indian_commas": self.indian_checkbox.isChecked(),
            "overwrite": self.overwrite_checkbox.isChecked(),
            "keep_open": self.keep_open_checkbox.isChecked(),
        })
        self.worker.log_signal.connect(self.log_box.appendPlainText)
        self.worker.progress_signal.connect(self.progress.setValue)
        self.worker.done_signal.connect(self.completed)
        self.worker.error_signal.connect(self.failed)
        self.worker.start()

    def completed(self, result):
        self.run_button.setEnabled(True)
        if result["unmatched"]:
            self.log_box.appendPlainText("\nUNMATCHED EXCEL FUND NAMES:")
            for slide, name in result["unmatched"]:
                self.log_box.appendPlainText(f"Slide {slide}: {name}")
        if result["missing_aum"]:
            self.log_box.appendPlainText("\nFUND NAMES WITHOUT A LATER AUMData OBJECT:")
            for slide, name in result["missing_aum"]:
                self.log_box.appendPlainText(f"Slide {slide}: {name}")

        QMessageBox.information(
            self, "Completed",
            f"FundName objects: {result['fund_objects']}\n"
            f"AUMData objects: {result['aum_objects']}\n"
            f"Excel matches: {result['matched']}\n"
            f"AUMData updated: {result['updated']}\n"
            f"Unmatched names: {len(result['unmatched'])}\n"
            f"Missing later AUMData: {len(result['missing_aum'])}\n\n"
            f"Saved to:\n{result['output']}"
        )

    def failed(self, _error):
        self.run_button.setEnabled(True)
        QMessageBox.critical(
            self, "Failed", "Processing failed. Review the processing log for details."
        )


def main():
    app = QApplication(sys.argv)
    app.setStyle("Fusion")
    window = MainWindow()
    window.show()
    sys.exit(app.exec())


if __name__ == "__main__":
    main()
