from __future__ import annotations

import sys
from pathlib import Path
from typing import Any, Callable

import pythoncom
import win32com.client as win32
from PyQt6.QtCore import QThread, pyqtSignal
from PyQt6.QtGui import QCloseEvent
from PyQt6.QtWidgets import (
    QApplication, QCheckBox, QFileDialog, QFrame, QGridLayout, QHBoxLayout,
    QLabel, QLineEdit, QMainWindow, QMessageBox, QPlainTextEdit,
    QProgressBar, QPushButton, QVBoxLayout, QWidget,
)

# =============================================================================
# Configuration
# =============================================================================
INPUT_FILE = r""
OUTPUT_FOLDER = r""

# IMPORTANT: This exact worksheet is used. "Market Cap Mix_" is not used.
SOURCE_SHEET_NAME = "Market Cap Mix"
OUTPUT_FILE_NAME = "Market_Cap_Charts_From_Market_Cap_Mix.xlsx"
OUTPUT_SHEET_NAME = "Market Cap Charts"

EXCEL_VISIBLE = False
OPEN_OUTPUT_AFTER_PROCESSING = False
SKIP_EMPTY_FUNDS = True
ZERO_TOLERANCE = 0.0000001
BLACK_LABEL_THRESHOLD = 0.05

MARKET_CAP_LABELS = ("Large Cap", "Mid Cap", "Small Cap")
CHART_COLORS = {
    "Large Cap": (244, 81, 30),
    "Mid Cap": (0, 98, 79),
    "Small Cap": (112, 48, 160),
}

DARK_BLUE_RGB = (31, 78, 121)
LIGHT_BLUE_RGB = (221, 235, 247)
LIGHT_GRAY_RGB = (242, 242, 242)
WHITE_RGB = (255, 255, 255)
BLACK_RGB = (0, 0, 0)
GREEN_TEXT_RGB = (0, 128, 0)
BORDER_RGB = (191, 191, 191)

SECTION_START_ROW = 2
SECTION_HEIGHT_ROWS = 23
TABLE_START_COLUMN = 2
TABLE_END_COLUMN = 4
CHART_LEFT_COLUMN = 6
CHART_TOP_ROW_OFFSET = 2
CHART_WIDTH = 470
CHART_HEIGHT = 285
USE_3D_PIE_CHART = True
SHOW_LEGEND = True
SHOW_VALUE_LABELS = True
PIE_3D_ELEVATION = 30
PIE_3D_PERSPECTIVE = 20

# Excel / Office constants
XL_TO_LEFT = -4159
XL_CENTER = -4108
XL_LEFT = -4131
XL_RIGHT = -4152
XL_PIE = 5
XL_3D_PIE = -4102
XL_LABEL_POSITION_BEST_FIT = 5
XL_EDGE_LEFT = 7
XL_EDGE_TOP = 8
XL_EDGE_BOTTOM = 9
XL_EDGE_RIGHT = 10
XL_INSIDE_HORIZONTAL = 12
XL_INSIDE_VERTICAL = 11
XL_CONTINUOUS = 1
XL_THIN = 2
XL_MEDIUM = -4138
XL_OPEN_XML_WORKBOOK = 51
MSO_TRUE = -1
MSO_FALSE = 0


def rgb_to_excel(red: int, green: int, blue: int) -> int:
    if any(x < 0 or x > 255 for x in (red, green, blue)):
        raise ValueError("RGB components must be between 0 and 255.")
    return red + green * 256 + blue * 65536


def clean_text(value: Any) -> str:
    return "" if value is None else str(value).strip()


def safe_float(value: Any) -> float:
    if value is None:
        return 0.0
    if isinstance(value, bool):
        return float(value)
    if isinstance(value, (int, float)):
        return float(value)
    text = clean_text(value)
    if not text or text.startswith("#"):
        return 0.0
    is_percent = "%" in text
    try:
        number = float(text.replace(",", "").replace("%", "").strip())
    except (TypeError, ValueError):
        return 0.0
    return number / 100.0 if is_percent else number


def validate_input_file(input_file: str) -> Path:
    if not input_file.strip():
        raise ValueError("Please select an Excel input file.")
    path = Path(input_file).expanduser().resolve()
    if not path.is_file():
        raise FileNotFoundError(f"The selected Excel file does not exist:\n{path}")
    if path.suffix.lower() not in {".xlsx", ".xlsm", ".xlsb", ".xls"}:
        raise ValueError("Select an Excel workbook: .xlsx, .xlsm, .xlsb, or .xls")
    return path


def build_output_path(input_file: str, output_folder: str = "") -> Path:
    input_path = Path(input_file).expanduser().resolve()
    folder = Path(output_folder).expanduser().resolve() if output_folder.strip() else input_path.parent
    folder.mkdir(parents=True, exist_ok=True)
    return folder / OUTPUT_FILE_NAME


def find_source_sheet(workbook: Any, required_name: str) -> Any:
    """Select the exact sheet 'Market Cap Mix', never 'Market Cap Mix_'."""
    # Exact case-sensitive match first.
    for index in range(1, workbook.Worksheets.Count + 1):
        worksheet = workbook.Worksheets(index)
        if clean_text(worksheet.Name) == required_name:
            return worksheet

    # Case-insensitive exact match second. Underscores are intentionally retained.
    target = required_name.casefold()
    for index in range(1, workbook.Worksheets.Count + 1):
        worksheet = workbook.Worksheets(index)
        if clean_text(worksheet.Name).casefold() == target:
            return worksheet

    available = [
        clean_text(workbook.Worksheets(index).Name)
        for index in range(1, workbook.Worksheets.Count + 1)
    ]
    raise ValueError(
        f"Exact worksheet '{required_name}' was not found.\n\n"
        f"Available worksheets:\n" + "\n".join(available)
    )


def find_market_cap_rows(worksheet: Any) -> dict[str, int]:
    """Find Large/Mid/Small labels in column A of the exact source sheet."""
    used = worksheet.UsedRange
    first_row = int(used.Row)
    last_row = int(used.Row + used.Rows.Count - 1)
    rows: dict[str, int] = {}

    for row in range(first_row, last_row + 1):
        label = clean_text(worksheet.Cells(row, 1).Value).casefold()
        for required in MARKET_CAP_LABELS:
            if label == required.casefold() and required not in rows:
                rows[required] = row

    missing = [label for label in MARKET_CAP_LABELS if label not in rows]
    if missing:
        raise ValueError(
            f"The exact worksheet '{SOURCE_SHEET_NAME}' does not contain these "
            f"labels in column A: {', '.join(missing)}"
        )
    return rows


def identify_fund_header_row(worksheet: Any, category_rows: dict[str, int]) -> int:
    """The screenshot structure uses fund names one row above Large Cap."""
    ordered = [category_rows[label] for label in MARKET_CAP_LABELS]
    if ordered != sorted(ordered):
        raise ValueError("Large Cap, Mid Cap, and Small Cap are not in the expected order.")
    header_row = min(ordered) - 1
    if header_row < 1 or not clean_text(worksheet.Cells(header_row, 2).Value):
        raise ValueError("The fund-name header row could not be identified.")
    return header_row


def get_last_fund_column(worksheet: Any, header_row: int) -> int:
    column = int(worksheet.Cells(header_row, worksheet.Columns.Count).End(XL_TO_LEFT).Column)
    if column < 2:
        raise ValueError("No fund names were found in the source worksheet.")
    return column


def extract_fund_data(worksheet: Any, status_callback: Callable[[str], None] | None = None) -> list[dict[str, Any]]:
    report = status_callback or print
    category_rows = find_market_cap_rows(worksheet)
    header_row = identify_fund_header_row(worksheet, category_rows)
    last_column = get_last_fund_column(worksheet, header_row)

    report(f"Confirmed exact source worksheet: {worksheet.Name}")
    report(f"Fund-name row: {header_row}")
    report(
        "Category rows: "
        + ", ".join(f"{name}=row {category_rows[name]}" for name in MARKET_CAP_LABELS)
    )
    report(f"Last fund column: {last_column}")

    funds: list[dict[str, Any]] = []
    for column in range(2, last_column + 1):
        fund_name = clean_text(worksheet.Cells(header_row, column).Value)
        if not fund_name:
            continue

        values = {
            category: safe_float(worksheet.Cells(category_rows[category], column).Value)
            for category in MARKET_CAP_LABELS
        }
        total = sum(values.values())
        if SKIP_EMPTY_FUNDS and abs(total) <= ZERO_TOLERANCE:
            report(f"Skipped empty fund: {fund_name}")
            continue

        funds.append({
            "fund_name": fund_name,
            "values": values,
            "source_column": column,
        })
        report(
            f"Read {fund_name}: Large={values['Large Cap']:.2%}, "
            f"Mid={values['Mid Cap']:.2%}, Small={values['Small Cap']:.2%}, "
            f"Total={total:.2%}"
        )

    if not funds:
        raise ValueError("No funds with usable market-cap data were found.")
    return funds


def apply_border(cell_range: Any, border_index: int, weight: int = XL_THIN,
                 color: tuple[int, int, int] = BORDER_RGB) -> None:
    border = cell_range.Borders(border_index)
    border.LineStyle = XL_CONTINUOUS
    border.Weight = weight
    border.Color = rgb_to_excel(*color)


def apply_box_border(cell_range: Any) -> None:
    for index in (XL_EDGE_LEFT, XL_EDGE_TOP, XL_EDGE_RIGHT, XL_EDGE_BOTTOM):
        apply_border(cell_range, index)


def format_output_worksheet(worksheet: Any) -> None:
    worksheet.Activate()
    try:
        worksheet.Application.ActiveWindow.DisplayGridlines = False
    except Exception:
        pass
    worksheet.Cells.Font.Name = "Aptos"
    worksheet.Cells.Font.Size = 10
    worksheet.Columns("A:A").ColumnWidth = 3
    worksheet.Columns("B:B").ColumnWidth = 24
    worksheet.Columns("C:C").ColumnWidth = 16
    worksheet.Columns("D:D").ColumnWidth = 14
    worksheet.Columns("E:E").ColumnWidth = 3
    worksheet.Columns("F:L").ColumnWidth = 12
    worksheet.PageSetup.Orientation = 2
    worksheet.PageSetup.Zoom = False
    worksheet.PageSetup.FitToPagesWide = 1
    worksheet.PageSetup.FitToPagesTall = False


def create_fund_table(worksheet: Any, start_row: int, fund_name: str,
                      values: dict[str, float]) -> dict[str, Any]:
    heading = worksheet.Range(
        worksheet.Cells(start_row, TABLE_START_COLUMN),
        worksheet.Cells(start_row, 12),
    )
    heading.Merge()
    heading.Value = fund_name
    heading.Interior.Color = rgb_to_excel(*DARK_BLUE_RGB)
    heading.Font.Color = rgb_to_excel(*WHITE_RGB)
    heading.Font.Bold = True
    heading.Font.Size = 14
    heading.HorizontalAlignment = XL_LEFT
    heading.VerticalAlignment = XL_CENTER
    heading.RowHeight = 27

    header_row = start_row + 2
    first_data_row = header_row + 1
    last_data_row = first_data_row + 2
    total_row = last_data_row + 1

    headers = ("Market Cap Category", "Allocation", "Chart Color")
    for column, value in enumerate(headers, TABLE_START_COLUMN):
        worksheet.Cells(header_row, column).Value = value

    header_range = worksheet.Range(
        worksheet.Cells(header_row, TABLE_START_COLUMN),
        worksheet.Cells(header_row, TABLE_END_COLUMN),
    )
    header_range.Interior.Color = rgb_to_excel(*LIGHT_BLUE_RGB)
    header_range.Font.Bold = True
    header_range.HorizontalAlignment = XL_CENTER
    header_range.VerticalAlignment = XL_CENTER
    header_range.RowHeight = 22

    categories: list[str] = []
    chart_values: list[float] = []
    for offset, category in enumerate(MARKET_CAP_LABELS):
        row = first_data_row + offset
        value = float(values.get(category, 0.0))
        worksheet.Cells(row, 2).Value = category
        worksheet.Cells(row, 3).Value = value
        worksheet.Cells(row, 3).NumberFormat = "0.00%"
        worksheet.Cells(row, 4).Value = ""
        worksheet.Cells(row, 2).Font.Color = rgb_to_excel(*GREEN_TEXT_RGB)
        worksheet.Cells(row, 3).Font.Color = rgb_to_excel(*GREEN_TEXT_RGB)
        worksheet.Cells(row, 2).HorizontalAlignment = XL_LEFT
        worksheet.Cells(row, 3).HorizontalAlignment = XL_RIGHT
        worksheet.Cells(row, 4).Interior.Color = rgb_to_excel(*CHART_COLORS[category])
        worksheet.Rows(row).RowHeight = 20
        if value > ZERO_TOLERANCE:
            categories.append(category)
            chart_values.append(value)

    worksheet.Cells(total_row, 2).Value = "Total"
    worksheet.Cells(total_row, 3).Formula = f"=SUM(C{first_data_row}:C{last_data_row})"
    worksheet.Cells(total_row, 3).NumberFormat = "0.00%"

    total_range = worksheet.Range(worksheet.Cells(total_row, 2), worksheet.Cells(total_row, 4))
    total_range.Font.Bold = True
    total_range.Interior.Color = rgb_to_excel(*LIGHT_GRAY_RGB)
    apply_border(total_range, XL_EDGE_TOP, XL_MEDIUM, DARK_BLUE_RGB)

    table_range = worksheet.Range(worksheet.Cells(header_row, 2), worksheet.Cells(total_row, 4))
    apply_box_border(table_range)
    for index in (XL_INSIDE_HORIZONTAL, XL_INSIDE_VERTICAL):
        apply_border(table_range, index)

    return {"categories": categories, "values": chart_values}


def add_ppt_style_legend(worksheet: Any, chart_left: float, chart_top: float,
                         categories: list[str], chart_name: str) -> None:
    if not SHOW_LEGEND or not categories:
        return
    item_width, marker_size, label_width = 100.0, 10.0, 96.0
    start_left = chart_left + (CHART_WIDTH - item_width * len(categories)) / 2.0
    marker_top = chart_top + 202.0
    label_top = marker_top + 14.0

    for index, category in enumerate(categories):
        center_x = start_left + index * item_width + item_width / 2.0
        marker = worksheet.Shapes.AddShape(
            9, center_x - marker_size / 2.0, marker_top, marker_size, marker_size
        )
        marker.Name = f"{chart_name}_LegendMarker_{index + 1}"
        marker.Fill.Visible = MSO_TRUE
        marker.Fill.Solid()
        marker.Fill.ForeColor.RGB = rgb_to_excel(*CHART_COLORS[category])
        marker.Line.Visible = MSO_FALSE

        label = worksheet.Shapes.AddTextbox(
            1, center_x - label_width / 2.0, label_top, label_width, 20.0
        )
        label.Name = f"{chart_name}_LegendLabel_{index + 1}"
        label.Line.Visible = MSO_FALSE
        label.Fill.Visible = MSO_FALSE
        label_text = category.upper().replace(" ", "")
        try:
            text_range = label.TextFrame2.TextRange
            text_range.Text = label_text
            text_range.Font.Name = "Aptos"
            text_range.Font.Size = 11
            text_range.Font.Fill.ForeColor.RGB = rgb_to_excel(*BLACK_RGB)
            text_range.ParagraphFormat.Alignment = 2
            label.TextFrame2.MarginLeft = 0
            label.TextFrame2.MarginRight = 0
            label.TextFrame2.MarginTop = 0
            label.TextFrame2.MarginBottom = 0
        except Exception:
            label.TextFrame.Characters().Text = label_text
            label.TextFrame.Characters().Font.Name = "Aptos"
            label.TextFrame.Characters().Font.Size = 11
            label.TextFrame.HorizontalAlignment = XL_CENTER


def apply_ppt_style_chart_layout(chart: Any) -> None:
    try:
        chart.HasTitle = False
        chart.HasLegend = False
        chart.ChartArea.Format.Line.Visible = MSO_FALSE
        chart.ChartArea.Format.Fill.Visible = MSO_FALSE
        chart.PlotArea.Format.Line.Visible = MSO_FALSE
        chart.PlotArea.Format.Fill.Visible = MSO_FALSE
        chart.PlotArea.Left = 54
        chart.PlotArea.Top = 20
        chart.PlotArea.Width = 362
        chart.PlotArea.Height = 160
    except Exception:
        pass
    try:
        chart.Elevation = PIE_3D_ELEVATION
        chart.Rotation = 0
        chart.Perspective = PIE_3D_PERSPECTIVE
        chart.RightAngleAxes = False
        chart.ChartGroups(1).FirstSliceAngle = 270
    except Exception:
        pass


def apply_raw_value_labels(series: Any, values: list[float]) -> None:
    """Display original source allocations rather than normalized pie shares."""
    if not SHOW_VALUE_LABELS:
        return
    series.HasDataLabels = True
    labels = series.DataLabels()
    labels.ShowValue = True
    labels.ShowPercentage = False
    labels.ShowCategoryName = False
    labels.ShowSeriesName = False
    labels.ShowLegendKey = False
    labels.Position = XL_LABEL_POSITION_BEST_FIT
    labels.NumberFormat = "0.00%"
    labels.Font.Bold = False
    labels.Font.Size = 8

    for index, raw_value in enumerate(values, start=1):
        label = series.Points(index).DataLabel
        label.Text = f"{raw_value:.2%}"
        label.Font.Color = rgb_to_excel(
            *(BLACK_RGB if raw_value < BLACK_LABEL_THRESHOLD else WHITE_RGB)
        )
        label.Font.Bold = False
        label.Font.Size = 8


def create_market_cap_chart(worksheet: Any, start_row: int,
                            chart_data: dict[str, Any]) -> Any:
    categories = chart_data["categories"]
    values = chart_data["values"]
    if not categories:
        return None

    top_row = start_row + CHART_TOP_ROW_OFFSET
    chart_left = float(worksheet.Cells(top_row, CHART_LEFT_COLUMN).Left)
    chart_top = float(worksheet.Cells(top_row, CHART_LEFT_COLUMN).Top)
    chart_object = worksheet.ChartObjects().Add(
        chart_left, chart_top, CHART_WIDTH, CHART_HEIGHT
    )
    chart_name = f"MarketCapChart_{start_row}"
    chart_object.Name = chart_name

    try:
        chart_object.ShapeRange.Line.Visible = MSO_FALSE
        chart_object.ShapeRange.Fill.Visible = MSO_FALSE
    except Exception:
        pass

    chart = chart_object.Chart
    chart.ChartType = XL_3D_PIE if USE_3D_PIE_CHART else XL_PIE
    while chart.SeriesCollection().Count > 0:
        chart.SeriesCollection(1).Delete()

    series = chart.SeriesCollection().NewSeries()
    series.Name = ""
    series.XValues = tuple(categories)
    series.Values = tuple(values)
    chart.HasTitle = False
    chart.HasLegend = False

    for index, category in enumerate(categories, start=1):
        point = series.Points(index)
        point.Format.Fill.Visible = MSO_TRUE
        point.Format.Fill.Solid()
        point.Format.Fill.ForeColor.RGB = rgb_to_excel(*CHART_COLORS[category])
        point.Format.Line.Visible = MSO_FALSE

    apply_ppt_style_chart_layout(chart)
    apply_raw_value_labels(series, values)
    try:
        chart.Refresh()
        apply_raw_value_labels(series, values)
    except Exception:
        pass

    add_ppt_style_legend(worksheet, chart_left, chart_top, categories, chart_name)
    return chart_object


def create_output_workbook(excel: Any, funds: list[dict[str, Any]], output_path: Path,
                           status_callback=None, progress_callback=None) -> Any:
    report = status_callback or print
    workbook = excel.Workbooks.Add()
    while workbook.Worksheets.Count > 1:
        workbook.Worksheets(workbook.Worksheets.Count).Delete()

    worksheet = workbook.Worksheets(1)
    worksheet.Name = OUTPUT_SHEET_NAME
    format_output_worksheet(worksheet)

    total = len(funds)
    for index, fund in enumerate(funds):
        start_row = SECTION_START_ROW + index * SECTION_HEIGHT_ROWS
        report(f"Creating {index + 1}/{total}: {fund['fund_name']}")
        chart_data = create_fund_table(
            worksheet, start_row, fund["fund_name"], fund["values"]
        )
        create_market_cap_chart(worksheet, start_row, chart_data)
        if progress_callback:
            progress_callback(round((index + 1) / total * 100))

    worksheet.Activate()
    if output_path.exists():
        try:
            output_path.unlink()
        except PermissionError as exc:
            raise PermissionError(f"Close the open output workbook:\n{output_path}") from exc

    report(f"Saving output workbook: {output_path}")
    workbook.SaveAs(str(output_path), FileFormat=XL_OPEN_XML_WORKBOOK)
    return workbook


def process_file(input_file: str, output_folder: str = "", status_callback=None,
                 progress_callback=None,
                 open_output: bool = OPEN_OUTPUT_AFTER_PROCESSING) -> str:
    input_path = validate_input_file(input_file)
    output_path = build_output_path(str(input_path), output_folder)
    if input_path.resolve() == output_path.resolve():
        raise ValueError("The generated workbook cannot overwrite the source workbook.")

    report = status_callback or print
    excel = source_workbook = output_workbook = None
    pythoncom.CoInitialize()
    try:
        report("Starting Microsoft Excel...")
        excel = win32.DispatchEx("Excel.Application")
        excel.Visible = EXCEL_VISIBLE
        excel.DisplayAlerts = False
        excel.ScreenUpdating = False
        excel.EnableEvents = False

        report(f"Opening source workbook: {input_path}")
        source_workbook = excel.Workbooks.Open(
            str(input_path), UpdateLinks=0, ReadOnly=True,
            IgnoreReadOnlyRecommended=True,
        )

        source_worksheet = find_source_sheet(source_workbook, SOURCE_SHEET_NAME)
        report(f"Reading exact worksheet: {source_worksheet.Name}")
        funds = extract_fund_data(source_worksheet, report)
        report(f"Found {len(funds)} funds with market-cap data.")

        output_workbook = create_output_workbook(
            excel, funds, output_path, report, progress_callback
        )
        output_workbook.Close(SaveChanges=True)
        output_workbook = None
        source_workbook.Close(SaveChanges=False)
        source_workbook = None
        excel.ScreenUpdating = True

        if open_output:
            report("Opening the generated workbook...")
            excel.Visible = True
            opened = excel.Workbooks.Open(str(output_path))
            opened.Worksheets(OUTPUT_SHEET_NAME).Activate()
            excel = None
        else:
            excel.Quit()
            excel = None

        report("Processing completed successfully.")
        report(f"Output file: {output_path}")
        return str(output_path)

    except Exception as exc:
        raise RuntimeError(f"Excel processing failed: {exc}") from exc
    finally:
        if output_workbook is not None:
            try: output_workbook.Close(SaveChanges=False)
            except Exception: pass
        if source_workbook is not None:
            try: source_workbook.Close(SaveChanges=False)
            except Exception: pass
        if excel is not None:
            try:
                excel.DisplayAlerts = False
                excel.Quit()
            except Exception:
                pass
        pythoncom.CoUninitialize()


class ExcelProcessingWorker(QThread):
    status_changed = pyqtSignal(str)
    progress_changed = pyqtSignal(int)
    processing_finished = pyqtSignal(str)
    processing_failed = pyqtSignal(str)

    def __init__(self, input_file: str, output_folder: str, open_output: bool) -> None:
        super().__init__()
        self.input_file = input_file
        self.output_folder = output_folder
        self.open_output = open_output

    def run(self) -> None:
        try:
            output = process_file(
                self.input_file, self.output_folder,
                self.status_changed.emit, self.progress_changed.emit,
                self.open_output,
            )
            self.processing_finished.emit(output)
        except Exception as exc:
            self.processing_failed.emit(str(exc))


class MarketCapChartWindow(QMainWindow):
    def __init__(self) -> None:
        super().__init__()
        self.worker: ExcelProcessingWorker | None = None
        self.setWindowTitle("Market Cap Chart Generator - Exact Sheet")
        self.setMinimumSize(860, 650)
        self.resize(980, 720)
        self.create_widgets()
        self.create_layout()
        self.connect_signals()
        self.apply_style()

    def create_widgets(self) -> None:
        self.title_label = QLabel("Market Cap Chart Workbook Generator")
        self.title_label.setObjectName("TitleLabel")
        self.description_label = QLabel(
            "Creates charts only from the exact worksheet named 'Market Cap Mix'. "
            "The similarly named worksheet 'Market Cap Mix_' is ignored."
        )
        self.description_label.setWordWrap(True)
        self.description_label.setObjectName("DescriptionLabel")

        self.input_file_edit = QLineEdit(INPUT_FILE)
        self.input_file_edit.setReadOnly(True)
        self.input_file_edit.setPlaceholderText("Select the source Excel workbook")
        self.input_file_button = QPushButton("Browse Excel File")

        self.output_folder_edit = QLineEdit(OUTPUT_FOLDER)
        self.output_folder_edit.setReadOnly(True)
        self.output_folder_edit.setPlaceholderText("Leave empty to save beside source workbook")
        self.output_folder_button = QPushButton("Browse Output Folder")
        self.clear_output_button = QPushButton("Use Source Folder")

        self.open_output_checkbox = QCheckBox("Open generated workbook after processing")
        self.open_output_checkbox.setChecked(OPEN_OUTPUT_AFTER_PROCESSING)
        self.process_button = QPushButton("Generate Market Cap Workbook")
        self.process_button.setObjectName("ProcessButton")
        self.process_button.setMinimumHeight(46)
        self.progress_bar = QProgressBar()
        self.progress_bar.setRange(0, 100)
        self.progress_bar.setFormat("%p% completed")
        self.status_output = QPlainTextEdit()
        self.status_output.setReadOnly(True)

    def create_layout(self) -> None:
        central = QWidget()
        main = QVBoxLayout(central)
        main.setContentsMargins(28, 24, 28, 24)
        main.setSpacing(16)
        main.addWidget(self.title_label)
        main.addWidget(self.description_label)

        card = QFrame(); card.setObjectName("Card")
        grid = QGridLayout(card); grid.setContentsMargins(20, 20, 20, 20)
        grid.addWidget(QLabel("<b>Input Excel file</b>"), 0, 0)
        grid.addWidget(self.input_file_edit, 1, 0)
        grid.addWidget(self.input_file_button, 1, 1)
        grid.addWidget(QLabel("<b>Output folder</b>"), 2, 0)
        grid.addWidget(self.output_folder_edit, 3, 0)
        buttons = QHBoxLayout()
        buttons.addWidget(self.output_folder_button)
        buttons.addWidget(self.clear_output_button)
        grid.addLayout(buttons, 3, 1)
        main.addWidget(card)

        info = QFrame(); info.setObjectName("Card")
        info_grid = QGridLayout(info); info_grid.setContentsMargins(20, 16, 20, 16)
        details = [
            ("Exact source worksheet:", SOURCE_SHEET_NAME),
            ("Ignored worksheet:", "Market Cap Mix_"),
            ("Output filename:", OUTPUT_FILE_NAME),
            ("Source structure:", "Fund names in row above Large/Mid/Small rows"),
            ("Chart labels:", "Original allocations, not normalized pie percentages"),
        ]
        for row, (label, value) in enumerate(details):
            info_grid.addWidget(QLabel(f"<b>{label}</b>"), row, 0)
            info_grid.addWidget(QLabel(value), row, 1)
        main.addWidget(info)

        main.addWidget(self.open_output_checkbox)
        main.addWidget(self.process_button)
        main.addWidget(self.progress_bar)
        main.addWidget(QLabel("<b>Processing status</b>"))
        main.addWidget(self.status_output, 1)
        self.setCentralWidget(central)

    def connect_signals(self) -> None:
        self.input_file_button.clicked.connect(self.select_input_file)
        self.output_folder_button.clicked.connect(self.select_output_folder)
        self.clear_output_button.clicked.connect(self.output_folder_edit.clear)
        self.process_button.clicked.connect(self.start_processing)

    def apply_style(self) -> None:
        self.setStyleSheet("""
        QMainWindow { background:#F4F7FB; }
        QLabel { color:#1F2937; font-size:11pt; }
        QLabel#TitleLabel { color:#1F4E79; font-size:21pt; font-weight:700; }
        QLabel#DescriptionLabel { color:#4B5563; font-size:10.5pt; }
        QFrame#Card { background:white; border:1px solid #D6DEE8; border-radius:10px; }
        QLineEdit { min-height:36px; padding:4px 9px; border:1px solid #BFC9D4; border-radius:6px; background:white; }
        QPushButton { min-height:36px; padding:4px 14px; border:1px solid #1F4E79; border-radius:6px; background:white; color:#1F4E79; font-weight:600; }
        QPushButton:hover { background:#EAF2F8; }
        QPushButton#ProcessButton { background:#1F4E79; color:white; border:none; font-size:11pt; }
        QProgressBar { min-height:25px; border:1px solid #BFC9D4; border-radius:6px; background:white; text-align:center; }
        QProgressBar::chunk { background:#00624F; border-radius:5px; }
        QPlainTextEdit { background:white; border:1px solid #D6DEE8; border-radius:7px; padding:7px; font-family:Consolas; font-size:9.5pt; }
        """)

    def select_input_file(self) -> None:
        current = self.input_file_edit.text().strip()
        initial = str(Path(current).parent) if current else str(Path.home())
        selected, _ = QFileDialog.getOpenFileName(
            self, "Select Excel Workbook", initial,
            "Excel Workbooks (*.xlsx *.xlsm *.xlsb *.xls);;All Files (*.*)",
        )
        if selected:
            self.input_file_edit.setText(selected)

    def select_output_folder(self) -> None:
        existing = self.output_folder_edit.text().strip()
        source = self.input_file_edit.text().strip()
        initial = existing or (str(Path(source).parent) if source else str(Path.home()))
        selected = QFileDialog.getExistingDirectory(self, "Select Output Folder", initial)
        if selected:
            self.output_folder_edit.setText(selected)

    def append_status(self, message: str) -> None:
        self.status_output.appendPlainText(message)

    def set_processing_state(self, processing: bool) -> None:
        for widget in (
            self.input_file_button, self.output_folder_button,
            self.clear_output_button, self.open_output_checkbox,
            self.process_button,
        ):
            widget.setDisabled(processing)
        self.process_button.setText(
            "Generating Workbook..." if processing else "Generate Market Cap Workbook"
        )

    def start_processing(self) -> None:
        input_file = self.input_file_edit.text().strip()
        output_folder = self.output_folder_edit.text().strip()
        try:
            input_path = validate_input_file(input_file)
            output_path = build_output_path(str(input_path), output_folder)
            if input_path.resolve() == output_path.resolve():
                raise ValueError("The output workbook cannot replace the source workbook.")
        except Exception as exc:
            QMessageBox.warning(self, "Invalid Selection", str(exc))
            return

        self.status_output.clear()
        self.progress_bar.setValue(0)
        self.set_processing_state(True)
        self.append_status("Preparing to read the exact Market Cap Mix worksheet...")
        self.worker = ExcelProcessingWorker(
            input_file, output_folder, self.open_output_checkbox.isChecked()
        )
        self.worker.status_changed.connect(self.append_status)
        self.worker.progress_changed.connect(self.progress_bar.setValue)
        self.worker.processing_finished.connect(self.processing_completed)
        self.worker.processing_failed.connect(self.processing_failed)
        self.worker.start()

    def processing_completed(self, output_path: str) -> None:
        self.set_processing_state(False)
        self.progress_bar.setValue(100)
        self.append_status(f"Workbook created successfully:\n{output_path}")
        QMessageBox.information(
            self, "Workbook Generated",
            f"Market-cap workbook created:\n\n{output_path}",
        )
        self.worker = None

    def processing_failed(self, error_message: str) -> None:
        self.set_processing_state(False)
        self.append_status(f"ERROR: {error_message}")
        QMessageBox.critical(self, "Processing Failed", error_message)
        self.worker = None

    def closeEvent(self, event: QCloseEvent) -> None:
        if self.worker is not None and self.worker.isRunning():
            QMessageBox.warning(
                self, "Processing in Progress",
                "Wait until workbook generation finishes.",
            )
            event.ignore()
        else:
            event.accept()


def main() -> None:
    application = QApplication(sys.argv)
    application.setApplicationName("Market Cap Chart Generator - Exact Sheet")
    application.setStyle("Fusion")
    window = MarketCapChartWindow()
    window.show()
    sys.exit(application.exec())


if __name__ == "__main__":
    main()
