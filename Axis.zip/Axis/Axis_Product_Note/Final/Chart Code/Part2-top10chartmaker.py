from __future__ import annotations

import re
import sys
import traceback
from pathlib import Path

import xlsxwriter
from openpyxl import load_workbook
from PyQt6.QtCore import QObject, QThread, pyqtSignal
from PyQt6.QtGui import QFont
from PyQt6.QtWidgets import (
    QApplication, QFileDialog, QFormLayout, QFrame, QHBoxLayout, QLabel,
    QLineEdit, QMainWindow, QMessageBox, QProgressBar, QPushButton,
    QVBoxLayout, QWidget,
)

SOURCE_SHEET = "Equity"
HEADER_ROW = 3
SCHEME_COL = 2
VALUE_COL = 6
STOCK_COL = 8
SECTOR_COL = 10
TOP_N = 10
FONT_NAME = "Lato"
PURPLE = "#7030A0"
DARK_PURPLE = "#5B0B70"
GRAY = "#CFCFCF"
TEXT_COLOR = "#262626"
WHITE = "#FFFFFF"


def clean_text(value):
    if value is None:
        return ""
    return re.sub(r"\s+", " ", str(value)).strip()


def canonical_scheme_name(value):
    """Keep the full source name and repair known truncated source names."""
    name = clean_text(value)
    aliases = {
        "axis multi asset allocation fun": "Axis Multi Asset Allocation Fund",
    }
    return aliases.get(name.casefold(), name)


def to_number(value):
    if value is None or isinstance(value, bool):
        return None
    if isinstance(value, (int, float)):
        return float(value)
    text = str(value).strip().replace(",", "")
    if not text or text.startswith("#"):
        return None
    try:
        return float(text[:-1]) / 100 if text.endswith("%") else float(text)
    except ValueError:
        return None


def safe_sheet_name(name, used):
    """Excel tab names are limited to 31 chars; this affects only the tab."""
    base = re.sub(r"[\\/*?:\[\]]", " ", clean_text(name))
    base = re.sub(r"\s+", " ", base).strip(" '") or "Scheme"
    base = base[:31]
    candidate = base
    number = 2
    while candidate.casefold() in used:
        suffix = f"_{number}"
        candidate = base[:31 - len(suffix)] + suffix
        number += 1
    used.add(candidate.casefold())
    return candidate


def get_equity_sheet(workbook):
    if SOURCE_SHEET in workbook.sheetnames:
        return workbook[SOURCE_SHEET]
    for worksheet in workbook.worksheets:
        header = clean_text(worksheet.cell(HEADER_ROW, SCHEME_COL).value)
        if header.casefold() == "scheme name":
            return worksheet
    raise ValueError("Equity sheet or Scheme Name header on row 3 was not found.")


def read_source(path):
    workbook = load_workbook(path, read_only=True, data_only=True)
    try:
        worksheet = get_equity_sheet(workbook)
        schemes = {}
        rows = worksheet.iter_rows(
            min_row=HEADER_ROW + 1, min_col=1, max_col=SECTOR_COL,
            values_only=True,
        )
        for row in rows:
            scheme = canonical_scheme_name(row[SCHEME_COL - 1])
            stock = clean_text(row[STOCK_COL - 1])
            sector = clean_text(row[SECTOR_COL - 1])
            weight = to_number(row[VALUE_COL - 1])
            if not scheme or weight is None:
                continue
            info = schemes.setdefault(scheme, {"stocks": {}, "sectors": {}})
            if stock and not stock.startswith("#"):
                info["stocks"][stock] = info["stocks"].get(stock, 0.0) + weight
            if sector and not sector.startswith("#"):
                info["sectors"][sector] = info["sectors"].get(sector, 0.0) + weight
        return schemes
    finally:
        workbook.close()


def setup_formats(book):
    return {
        "sheet_title": book.add_format({"font_name": FONT_NAME, "font_size": 15, "bold": True, "font_color": WHITE, "bg_color": DARK_PURPLE, "align": "left", "valign": "vcenter"}),
        "section_stock": book.add_format({"font_name": FONT_NAME, "font_size": 11, "bold": True, "font_color": DARK_PURPLE, "bg_color": "#EADCF0", "align": "left", "valign": "vcenter"}),
        "section_sector": book.add_format({"font_name": FONT_NAME, "font_size": 11, "bold": True, "font_color": DARK_PURPLE, "bg_color": "#E2F0D9", "align": "left", "valign": "vcenter"}),
        "header": book.add_format({"font_name": FONT_NAME, "font_size": 10, "bold": True, "font_color": WHITE, "bg_color": DARK_PURPLE, "align": "center", "valign": "vcenter"}),
        "rank": book.add_format({"font_name": FONT_NAME, "font_size": 10, "font_color": TEXT_COLOR, "align": "center", "valign": "vcenter", "bottom": 1, "bottom_color": "#D9D9D9"}),
        "text": book.add_format({"font_name": FONT_NAME, "font_size": 10, "font_color": TEXT_COLOR, "valign": "vcenter", "bottom": 1, "bottom_color": "#D9D9D9"}),
        "percent": book.add_format({"font_name": FONT_NAME, "font_size": 10, "font_color": TEXT_COLOR, "align": "center", "valign": "vcenter", "num_format": "0.0%", "bottom": 1, "bottom_color": "#D9D9D9"}),
        "source_label": book.add_format({"font_name": FONT_NAME, "font_size": 9, "bold": True, "font_color": "#666666"}),
        "source": book.add_format({"font_name": FONT_NAME, "font_size": 9, "italic": True, "font_color": "#666666"}),
        "chart_heading": book.add_format({"font_name": FONT_NAME, "font_size": 15, "bold": True, "font_color": WHITE, "bg_color": DARK_PURPLE, "align": "left", "valign": "vcenter"}),
        "hidden_header": book.add_format({"font_name": FONT_NAME, "bold": True}),
        "hidden_percent": book.add_format({"font_name": FONT_NAME, "num_format": "0.0%"}),
    }


def write_table(ws, formats, full_scheme_name, stocks, sectors):
    # IMPORTANT: A1 stores the full scheme name, not the truncated worksheet tab.
    ws.merge_range("A1:H1", full_scheme_name, formats["sheet_title"])
    ws.set_row(0, 25)
    ws.merge_range("A2:C2", "Top 10 Stocks", formats["section_stock"])
    ws.merge_range("E2:G2", "Top 10 Sectors", formats["section_sector"])
    for column, text in enumerate(("Rank", "Stock Name", "Weight")):
        ws.write(2, column, text, formats["header"])
    for column, text in zip((4, 5, 6), ("Rank", "Sector Name", "Weight")):
        ws.write(2, column, text, formats["header"])
    for rank, (name, weight) in enumerate(stocks, 1):
        row = rank + 2
        ws.write_number(row, 0, rank, formats["rank"])
        ws.write(row, 1, name, formats["text"])
        ws.write_number(row, 2, weight, formats["percent"])
    for rank, (name, weight) in enumerate(sectors, 1):
        row = rank + 2
        ws.write_number(row, 4, rank, formats["rank"])
        ws.write(row, 5, name, formats["text"])
        ws.write_number(row, 6, weight, formats["percent"])
    ws.write("A15", "Source logic", formats["source_label"])
    ws.merge_range("B15:H15", "Stocks: H grouped and summed by F | Sectors: J grouped and summed by F", formats["source"])
    ws.merge_range("A17:D17", "Stocks: Lowest to Highest", formats["section_stock"])
    ws.merge_range("E17:H17", "Sectors: Lowest to Highest", formats["section_sector"])
    for col, text in enumerate(("Rank", "Stock Name", "Weight", "Highest - Weight")):
        ws.write(17, col, text, formats["header"])
    for col, text in zip((4, 5, 6, 7), ("Rank", "Sector Name", "Weight", "Highest - Weight")):
        ws.write(17, col, text, formats["header"])
    asc_stocks = sorted(stocks, key=lambda x: (x[1], x[0].casefold()))
    asc_sectors = sorted(sectors, key=lambda x: (x[1], x[0].casefold()))
    max_stock = stocks[0][1] if stocks else 0.0
    max_sector = sectors[0][1] if sectors else 0.0
    for rank, (name, weight) in enumerate(asc_stocks, 1):
        row = rank + 17
        ws.write_number(row, 0, rank, formats["rank"]); ws.write(row, 1, name, formats["text"])
        ws.write_number(row, 2, weight, formats["percent"]); ws.write_number(row, 3, max_stock-weight, formats["percent"])
    for rank, (name, weight) in enumerate(asc_sectors, 1):
        row = rank + 17
        ws.write_number(row, 4, rank, formats["rank"]); ws.write(row, 5, name, formats["text"])
        ws.write_number(row, 6, weight, formats["percent"]); ws.write_number(row, 7, max_sector-weight, formats["percent"])


def write_chart_source_data(ws, formats, stocks, sectors):
    for col, text in zip((23,24,25), ("Stock Name","Weight","Highest - Weight")): ws.write(30,col,text,formats["hidden_header"])
    for col, text in zip((27,28,29), ("Sector Name","Weight","Highest - Weight")): ws.write(30,col,text,formats["hidden_header"])
    max_stock = stocks[0][1] if stocks else 0.0; max_sector = sectors[0][1] if sectors else 0.0
    for row,(name,weight) in enumerate(stocks,31):
        ws.write(row,23,name); ws.write_number(row,24,weight,formats["hidden_percent"]); ws.write_number(row,25,max_stock-weight,formats["hidden_percent"])
    for row,(name,weight) in enumerate(sectors,31):
        ws.write(row,27,name); ws.write_number(row,28,weight,formats["hidden_percent"]); ws.write_number(row,29,max_sector-weight,formats["hidden_percent"])
    ws.set_column(23,25,None,None,{"hidden":True}); ws.set_column(27,29,None,None,{"hidden":True})


def insert_chart(book, ws, category_col, weight_col, gap_col, count, anchor):
    if count <= 0: return
    sn = ws.name.replace("'", "''"); first, last = 32, 31 + count
    categories=f"='{sn}'!${category_col}${first}:${category_col}${last}"; weights=f"='{sn}'!${weight_col}${first}:${weight_col}${last}"; gaps=f"='{sn}'!${gap_col}${first}:${gap_col}${last}"
    chart=book.add_chart({"type":"bar","subtype":"stacked"}); chart.show_hidden_data()
    chart.add_series({"name":"Weight","categories":categories,"values":weights,"fill":{"color":PURPLE},"border":{"none":True},"gap":55})
    custom=[{"value":f"='{sn}'!${weight_col}${r}","font":{"name":FONT_NAME,"size":10,"color":TEXT_COLOR}} for r in range(first,last+1)]
    chart.add_series({"name":"Highest - Weight","categories":categories,"values":gaps,"fill":{"color":GRAY},"border":{"none":True},"data_labels":{"position":"outside_end","num_format":"0.0%","font":{"name":FONT_NAME,"size":10,"color":TEXT_COLOR},"custom":custom}})
    chart.set_title({"none":True}); chart.set_legend({"none":True})
    chart.set_x_axis({"visible":False,"min":0,"major_gridlines":{"visible":False},"line":{"color":"#BFBFBF","width":1},"label_position":"none"})
    chart.set_y_axis({"reverse":True,"label_position":"low","line":{"color":"#BFBFBF","width":1},"major_tick_mark":"none","minor_tick_mark":"none","num_font":{"name":FONT_NAME,"size":10,"color":TEXT_COLOR}})
    chart.set_chartarea({"border":{"color":"#808080","width":1},"fill":{"color":WHITE}}); chart.set_plotarea({"border":{"none":True},"fill":{"color":WHITE},"layout":{"x":0.33,"y":0.10,"width":0.53,"height":0.80}}); chart.set_size({"width":720,"height":330})
    ws.insert_chart(anchor,chart,{"x_offset":0,"y_offset":0,"object_position":1})


def insert_chart_sections(book, ws, formats, stocks, sectors):
    write_chart_source_data(ws,formats,stocks,sectors); ws.set_row(30,27); ws.merge_range("A31:C31","Top 10 Stocks",formats["chart_heading"]); insert_chart(book,ws,"X","Y","Z",len(stocks),"A32")
    ws.set_row(50,27); ws.merge_range("A51:C51","Top 10 Sectors",formats["chart_heading"]); insert_chart(book,ws,"AB","AC","AD",len(sectors),"A52")


def create_output(input_file, output_file, progress_callback=None):
    schemes=read_source(input_file)
    if not schemes: raise ValueError("No valid scheme data found.")
    book=xlsxwriter.Workbook(output_file,{"constant_memory":False})
    try:
        formats=setup_formats(book); used=set(); names=sorted(schemes,key=str.casefold)
        for index,scheme in enumerate(names,1):
            info=schemes[scheme]; stocks=sorted(info["stocks"].items(),key=lambda x:(-x[1],x[0].casefold()))[:TOP_N]; sectors=sorted(info["sectors"].items(),key=lambda x:(-x[1],x[0].casefold()))[:TOP_N]
            ws=book.add_worksheet(safe_sheet_name(scheme,used)); ws.hide_gridlines(2); ws.freeze_panes(3,0); ws.set_zoom(90); ws.set_default_row(18)
            for col,width in zip("ABCDEFGH",(9,42,14,17,9,36,14,17)): ws.set_column(f"{col}:{col}",width)
            write_table(ws,formats,scheme,stocks,sectors); insert_chart_sections(book,ws,formats,stocks,sectors)
            ws.set_landscape(); ws.fit_to_pages(1,0); ws.set_margins(left=.25,right=.25,top=.4,bottom=.4)
            if progress_callback: progress_callback(int(index*100/len(names)),scheme)
    finally: book.close()
    return len(schemes)


class ExportWorker(QObject):
    progress=pyqtSignal(int,str); finished=pyqtSignal(int,str); failed=pyqtSignal(str)
    def __init__(self,input_file,output_file): super().__init__(); self.input_file=input_file; self.output_file=output_file
    def run(self):
        try: self.finished.emit(create_output(self.input_file,self.output_file,lambda p,s:self.progress.emit(p,s)),str(Path(self.output_file).resolve()))
        except Exception: self.failed.emit(traceback.format_exc())


class MainWindow(QMainWindow):
    def __init__(self):
        super().__init__(); self.thread=None; self.worker=None; self.setWindowTitle("Top 10 Stocks and Sectors Exporter"); self.setMinimumSize(760,430); self.build_ui()
    def build_ui(self):
        root=QWidget(); self.setCentralWidget(root); layout=QVBoxLayout(root); layout.setContentsMargins(28,24,28,24); layout.setSpacing(18)
        title=QLabel("Top 10 Stocks and Sectors"); title.setObjectName("title"); subtitle=QLabel("Select the source workbook and generate a styled Excel file with grouped stock and sector charts."); subtitle.setWordWrap(True); layout.addWidget(title); layout.addWidget(subtitle)
        card=QFrame(); form=QFormLayout(card); self.input_edit=QLineEdit(); self.output_edit=QLineEdit()
        ib=QPushButton("Browse"); ib.clicked.connect(self.browse_input); ir=QHBoxLayout(); ir.addWidget(self.input_edit,1); ir.addWidget(ib); form.addRow("Input file",ir)
        ob=QPushButton("Browse"); ob.clicked.connect(self.browse_output); orow=QHBoxLayout(); orow.addWidget(self.output_edit,1); orow.addWidget(ob); form.addRow("Output file",orow); layout.addWidget(card)
        self.progress=QProgressBar(); self.status=QLabel("Ready"); layout.addWidget(self.progress); layout.addWidget(self.status); actions=QHBoxLayout(); actions.addStretch(); self.generate_button=QPushButton("Generate Excel"); self.generate_button.clicked.connect(self.start_export); actions.addWidget(self.generate_button); layout.addLayout(actions)
    def browse_input(self):
        f,_=QFileDialog.getOpenFileName(self,"Select Market Cap Liquidity Excel","","Excel files (*.xlsx *.xlsm)")
        if f: self.input_edit.setText(f); p=Path(f); self.output_edit.setText(str(p.with_name(f"{p.stem}_Top10_Styled_Charts.xlsx")))
    def browse_output(self):
        f,_=QFileDialog.getSaveFileName(self,"Save Output Excel",self.output_edit.text() or "Top10_Styled_Charts.xlsx","Excel workbook (*.xlsx)")
        if f: self.output_edit.setText(f if f.lower().endswith(".xlsx") else f+".xlsx")
    def start_export(self):
        inp=self.input_edit.text().strip(); out=self.output_edit.text().strip()
        if not inp or not Path(inp).is_file(): QMessageBox.warning(self,"Input required","Please select a valid input Excel file."); return
        if not out: QMessageBox.warning(self,"Output required","Please select an output Excel file."); return
        self.generate_button.setEnabled(False); self.progress.setValue(0); self.thread=QThread(self); self.worker=ExportWorker(inp,out); self.worker.moveToThread(self.thread); self.thread.started.connect(self.worker.run); self.worker.progress.connect(lambda p,s:(self.progress.setValue(p),self.status.setText(f"Processing: {s}"))); self.worker.finished.connect(self.on_finished); self.worker.failed.connect(self.on_failed); self.worker.finished.connect(self.thread.quit); self.worker.failed.connect(self.thread.quit); self.thread.start()
    def on_finished(self,count,path): self.generate_button.setEnabled(True); self.progress.setValue(100); self.status.setText(f"Completed. {count} scheme(s) processed."); QMessageBox.information(self,"Export complete",f"Schemes processed: {count}\n\nOutput:\n{path}")
    def on_failed(self,details): self.generate_button.setEnabled(True); self.status.setText("Export failed."); QMessageBox.critical(self,"Export failed",details.strip().splitlines()[-1])


def main():
    app=QApplication(sys.argv); app.setFont(QFont(FONT_NAME,10)); window=MainWindow(); window.show(); return app.exec()

if __name__ == "__main__": raise SystemExit(main())
