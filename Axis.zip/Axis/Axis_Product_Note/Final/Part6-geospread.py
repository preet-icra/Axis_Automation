# -*- coding: utf-8 -*-
"""Axis geographical AUM to PowerPoint updater with a PyQt6 GUI.

Requirements:
    pip install pywin32 PyQt6

Windows desktop Microsoft Excel and PowerPoint must be installed.
"""

from pathlib import Path
import os
import re
import sys
import traceback
import unicodedata

import pythoncom
import win32com.client as win32
from PyQt6.QtCore import QObject, QThread, pyqtSignal
from PyQt6.QtWidgets import (
    QApplication,
    QFileDialog,
    QFormLayout,
    QHBoxLayout,
    QLabel,
    QLineEdit,
    QMainWindow,
    QMessageBox,
    QPlainTextEdit,
    QPushButton,
    QVBoxLayout,
    QWidget,
)


# Default paths shown when the application starts. They can be changed in the GUI.
INPUT_PPT_PATH = Path(
    r"C:\monil\Axis_preet\New Template - Axis Hybrid Funds WDP_DP - Leaflet - Final.pptx"
)
INPUT_EXCEL_PATH = Path(
    r"C:\monil\Axis_preet\Geographical AUM report required August-2026.xlsb"
)
OUTPUT_PPT_PATH = Path(r"C:\monil\Axis_preet\save.pptx")
LOG_FILE_PATH = Path(
    r"C:\Bandhan_Support\Output\geospreads_update_log.txt"
)

FUND_OBJECT_NAME = "FundName"
GEO_OBJECT_NAME = "geospreads"
SCHEME_NAME_HEADER = "scheme Name"
OUTPUT_FONT_NAME = "Lato"
OUTPUT_FONT_SIZE = 7
HEADER_SEARCH_ROW_LIMIT = 20
GEOGRAPHICAL_COLUMN_COUNT = 5
MSO_GROUP_SHAPE_TYPE = 6
MSO_TRUE = -1


def clean_text(value):
    if value is None:
        return ""
    return re.sub(r"\s+", " ", str(value)).strip()


def normalize_name(value):
    text = clean_text(value)
    text = unicodedata.normalize("NFKD", text)
    text = text.replace("’", "'").replace("‘", "'").replace("`", "'")
    text = text.replace("&", " and ")
    text = re.sub(r"[^A-Za-z0-9]+", " ", text)
    return re.sub(r"\s+", " ", text.lower()).strip()


def normalize_header(value, is_first_header=False):
    text = clean_text(value)
    text = re.sub(r"(?<=[A-Za-z])(?=\d)", " ", text)
    text = re.sub(r"(?<=\d)(?=[A-Za-z])", " ", text)
    text = re.sub(r"\s+", " ", text).strip()
    if text:
        first = text[0].upper() if is_first_header else text[0].lower()
        text = first + text[1:]
    return text


def format_percentage(value):
    try:
        number = float(value)
        # Excel cells formatted as percentages commonly expose 0.3623 for 36.23%.
        # Values greater than 1 are treated as already expressed in percentage points.
        if abs(number) <= 1:
            number *= 100
        return f"{number:.2f}%"
    except (TypeError, ValueError):
        text = clean_text(value)
        if not text:
            return ""
        return text if text.endswith("%") else f"{text}%"


def excel_used_range_to_matrix(used_range):
    raw_values = used_range.Value
    if raw_values is None:
        return []
    if not isinstance(raw_values, tuple):
        return [[raw_values]]
    if raw_values and not isinstance(raw_values[0], tuple):
        return [list(raw_values)]
    return [list(row) for row in raw_values]


def read_geographical_excel(excel_path, log_lines):
    excel_app = None
    workbook = None
    try:
        excel_app = win32.DispatchEx("Excel.Application")
        excel_app.Visible = False
        excel_app.DisplayAlerts = False
        excel_app.ScreenUpdating = False

        workbook = excel_app.Workbooks.Open(
            str(excel_path), UpdateLinks=0, ReadOnly=True
        )
        worksheet = workbook.Worksheets(1)
        matrix = excel_used_range_to_matrix(worksheet.UsedRange)
        if not matrix:
            raise ValueError("The first Excel worksheet is empty.")

        target_header = normalize_name(SCHEME_NAME_HEADER)
        scheme_header_row = None
        scheme_name_column = None

        for row_index in range(min(HEADER_SEARCH_ROW_LIMIT, len(matrix))):
            for column_index, cell_value in enumerate(matrix[row_index]):
                if normalize_name(cell_value) == target_header:
                    scheme_header_row = row_index
                    scheme_name_column = column_index
                    break
            if scheme_header_row is not None:
                break

        if scheme_header_row is None or scheme_name_column is None:
            raise ValueError(
                f'Excel header "{SCHEME_NAME_HEADER}" was not found in the '
                f"first {HEADER_SEARCH_ROW_LIMIT} rows."
            )

        subheader_row = scheme_header_row + 1
        geo_start_column = scheme_name_column + 1
        geo_end_column = geo_start_column + GEOGRAPHICAL_COLUMN_COUNT

        if subheader_row >= len(matrix):
            raise ValueError("The Excel geographical subheader row is missing.")
        if len(matrix[scheme_header_row]) <= geo_start_column:
            raise ValueError("The main geographical heading cell is missing.")
        if len(matrix[subheader_row]) < geo_end_column:
            raise ValueError(
                "Expected five geographical columns after scheme Name were not found."
            )

        main_heading = clean_text(
            matrix[scheme_header_row][geo_start_column]
        )
        geographical_headers = matrix[subheader_row][
            geo_start_column:geo_end_column
        ]

        if not main_heading:
            raise ValueError("The main geographical heading is blank.")
        if any(not clean_text(header) for header in geographical_headers):
            raise ValueError("One or more geographical subheaders are blank.")

        scheme_records = {}
        for row_number in range(subheader_row + 1, len(matrix)):
            row = matrix[row_number]
            if scheme_name_column >= len(row):
                continue

            scheme_name = clean_text(row[scheme_name_column])
            if not scheme_name:
                continue

            values = list(row[geo_start_column:geo_end_column])
            values.extend(
                [None] * (GEOGRAPHICAL_COLUMN_COUNT - len(values))
            )
            if any(value is None or clean_text(value) == "" for value in values):
                log_lines.append(
                    f"SKIPPED INCOMPLETE EXCEL ROW {row_number + 1}: "
                    f"{scheme_name}"
                )
                continue

            normalized_key = normalize_name(scheme_name)
            if normalized_key in scheme_records:
                raise ValueError(
                    "Duplicate normalized scheme name found in Excel: "
                    f"{scheme_name}"
                )

            scheme_records[normalized_key] = {
                "name": scheme_name,
                "values": values,
            }

        if not scheme_records:
            raise ValueError(
                "No complete scheme records were found in the Excel workbook."
            )

        log_lines.append(f"EXCEL SHEET: {worksheet.Name}")
        log_lines.append(f"MAIN HEADING: {main_heading}")
        log_lines.append(
            "SUBHEADERS: "
            + " | ".join(clean_text(item) for item in geographical_headers)
        )
        log_lines.append(f"USABLE SCHEME COUNT: {len(scheme_records)}")
        return main_heading, geographical_headers, scheme_records

    finally:
        if workbook is not None:
            workbook.Close(SaveChanges=False)
        if excel_app is not None:
            excel_app.Quit()


def build_geographical_text(main_heading, geographical_headers, values):
    sections = []
    for index, (header, value) in enumerate(
        zip(geographical_headers, values)
    ):
        display_header = normalize_header(
            header, is_first_header=(index == 0)
        )
        display_value = format_percentage(value)
        sections.append(f"{display_header}- {display_value}")
    return f"{main_heading} " + ", ".join(sections)


def get_shape_text(shape):
    if shape.HasTextFrame != MSO_TRUE:
        return ""
    if shape.TextFrame.HasText != MSO_TRUE:
        return ""
    return clean_text(shape.TextFrame.TextRange.Text)


def update_geospreads_shape(shape, new_text):
    if shape.HasTextFrame != MSO_TRUE:
        raise ValueError(
            f'The object "{shape.Name}" does not contain a text frame.'
        )

    shape.TextFrame.TextRange.Text = new_text
    text_range = shape.TextFrame.TextRange
    text_range.Font.Name = OUTPUT_FONT_NAME
    text_range.Font.Size = OUTPUT_FONT_SIZE
    try:
        text_range.Font.NameComplexScript = OUTPUT_FONT_NAME
    except Exception:
        pass


def process_shape_collection(
    shapes,
    slide_number,
    state,
    scheme_records,
    main_heading,
    geographical_headers,
    log_lines,
):
    for shape_index in range(1, shapes.Count + 1):
        shape = shapes.Item(shape_index)
        object_name = clean_text(shape.Name)

        if object_name.casefold() == FUND_OBJECT_NAME.casefold():
            fund_text = get_shape_text(shape)
            normalized_fund = normalize_name(fund_text)

            if normalized_fund in scheme_records:
                state["current_fund_key"] = normalized_fund
                log_lines.append(
                    f"MATCHED FUNDNAME | Slide {slide_number} | "
                    f"{fund_text} -> "
                    f"{scheme_records[normalized_fund]['name']}"
                )
            else:
                state["current_fund_key"] = None
                display_name = fund_text or "<blank FundName>"
                state["unmatched_funds"].append(
                    f"Slide {slide_number}: {display_name}"
                )
                log_lines.append(
                    f"UNMATCHED FUNDNAME | Slide {slide_number} | "
                    f"{display_name}"
                )

        elif object_name.casefold() == GEO_OBJECT_NAME.casefold():
            current_key = state["current_fund_key"]
            if current_key is None:
                state["skipped_geo_slides"].append(slide_number)
                log_lines.append(
                    f"SKIPPED GEOSPREADS | Slide {slide_number} | "
                    "No matched preceding FundName"
                )
            else:
                values = scheme_records[current_key]["values"]
                new_text = build_geographical_text(
                    main_heading, geographical_headers, values
                )
                update_geospreads_shape(shape, new_text)
                state["updated_count"] += 1
                log_lines.append(
                    f"UPDATED GEOSPREADS | Slide {slide_number} | "
                    f"{scheme_records[current_key]['name']} | {new_text}"
                )

        if shape.Type == MSO_GROUP_SHAPE_TYPE:
            process_shape_collection(
                shape.GroupItems,
                slide_number,
                state,
                scheme_records,
                main_heading,
                geographical_headers,
                log_lines,
            )


def update_powerpoint(
    ppt_path,
    output_path,
    main_heading,
    geographical_headers,
    scheme_records,
    log_lines,
):
    powerpoint_app = None
    presentation = None
    try:
        powerpoint_app = win32.DispatchEx("PowerPoint.Application")
        powerpoint_app.Visible = MSO_TRUE
        presentation = powerpoint_app.Presentations.Open(
            str(ppt_path), WithWindow=MSO_TRUE
        )

        state = {
            "current_fund_key": None,
            "updated_count": 0,
            "unmatched_funds": [],
            "skipped_geo_slides": [],
        }

        for slide_number in range(1, presentation.Slides.Count + 1):
            slide = presentation.Slides.Item(slide_number)
            process_shape_collection(
                slide.Shapes,
                slide_number,
                state,
                scheme_records,
                main_heading,
                geographical_headers,
                log_lines,
            )

        if state["updated_count"] == 0:
            raise RuntimeError(
                "No geospreads object was updated. Review FundName matches "
                "and object names."
            )

        output_path.parent.mkdir(parents=True, exist_ok=True)
        if output_path.exists():
            output_path.unlink()

        # 24 = ppSaveAsOpenXMLPresentation.
        presentation.SaveAs(str(output_path), 24)
        log_lines.append(
            f"TOTAL GEOSPREADS UPDATED: {state['updated_count']}"
        )

        if state["unmatched_funds"]:
            log_lines.append("UNMATCHED FUNDNAME OBJECTS:")
            log_lines.extend(
                f"  - {item}" for item in state["unmatched_funds"]
            )

        if state["skipped_geo_slides"]:
            unique_slides = list(
                dict.fromkeys(state["skipped_geo_slides"])
            )
            log_lines.append(
                "SKIPPED GEOSPREADS SLIDES: "
                + ", ".join(map(str, unique_slides))
            )

        return state["updated_count"]

    finally:
        if presentation is not None:
            presentation.Close()
        if powerpoint_app is not None:
            powerpoint_app.Quit()


def write_processing_log(log_path, log_lines):
    log_path.parent.mkdir(parents=True, exist_ok=True)
    log_path.write_text("\r\n".join(log_lines), encoding="utf-8")


class UpdateWorker(QObject):
    finished = pyqtSignal(int, list)
    failed = pyqtSignal(str, list)
    progress = pyqtSignal(str)

    def __init__(self, ppt_path, excel_path, output_path, log_path):
        super().__init__()
        self.ppt_path = Path(ppt_path)
        self.excel_path = Path(excel_path)
        self.output_path = Path(output_path)
        self.log_path = Path(log_path)

    def run(self):
        messages = [
            f"INPUT PPT: {self.ppt_path}",
            f"INPUT EXCEL: {self.excel_path}",
            f"OUTPUT PPT: {self.output_path}",
            f"LOG FILE: {self.log_path}",
        ]

        pythoncom.CoInitialize()
        try:
            self.progress.emit("Reading geographical AUM workbook...")
            heading, headers, records = read_geographical_excel(
                self.excel_path, messages
            )
            self.progress.emit(
                f"Loaded {len(records)} usable scheme record(s)."
            )
            self.progress.emit("Updating PowerPoint presentation...")

            count = update_powerpoint(
                self.ppt_path,
                self.output_path,
                heading,
                headers,
                records,
                messages,
            )

            messages.append(f"STATUS: SUCCESS ({count} updated)")
            write_processing_log(self.log_path, messages)
            self.progress.emit(
                f"Completed successfully. Updated {count} object(s)."
            )
            self.finished.emit(count, messages)

        except Exception as error:
            messages.extend(
                [
                    "STATUS: FAILED",
                    f"ERROR: {error}",
                    traceback.format_exc(),
                ]
            )
            try:
                write_processing_log(self.log_path, messages)
            except Exception as log_error:
                messages.append(f"LOG WRITE ERROR: {log_error}")
            self.failed.emit(str(error), messages)

        finally:
            pythoncom.CoUninitialize()


class MainWindow(QMainWindow):
    def __init__(self):
        super().__init__()
        self.worker_thread = None
        self.worker = None

        self.setWindowTitle("Axis Geospread Update")
        self.resize(850, 520)

        body = QWidget()
        self.setCentralWidget(body)
        layout = QVBoxLayout(body)
        layout.setContentsMargins(16, 16, 16, 16)
        layout.setSpacing(10)

        title = QLabel("Update geographical allocation text in PowerPoint")
        layout.addWidget(title)

        description = QLabel(
            'Reads scheme data from Excel and updates PowerPoint objects '
            'named "FundName" and "geospreads".'
        )
        description.setWordWrap(True)
        layout.addWidget(description)

        form = QFormLayout()
        form.setFieldGrowthPolicy(
            QFormLayout.FieldGrowthPolicy.ExpandingFieldsGrow
        )
        self.ppt_edit = self._add_path_row(
            form,
            "PowerPoint template:",
            str(INPUT_PPT_PATH),
            self._browse_ppt,
        )
        self.excel_edit = self._add_path_row(
            form,
            "Geographical AUM workbook:",
            str(INPUT_EXCEL_PATH),
            self._browse_excel,
        )
        self.output_edit = self._add_path_row(
            form,
            "Output PowerPoint:",
            str(OUTPUT_PPT_PATH),
            self._browse_output,
        )
        self.log_edit = self._add_path_row(
            form,
            "Processing log:",
            str(LOG_FILE_PATH),
            self._browse_log,
        )
        layout.addLayout(form)

        button_row = QHBoxLayout()
        self.run_button = QPushButton("Update Geospreads")
        self.run_button.clicked.connect(self.run_update)
        self.run_button.setDefault(True)
        button_row.addWidget(self.run_button)

        self.clear_button = QPushButton("Clear Messages")
        self.clear_button.clicked.connect(self._clear_messages)
        button_row.addWidget(self.clear_button)

        self.open_output_button = QPushButton("Open Output Folder")
        self.open_output_button.clicked.connect(self._open_output_folder)
        button_row.addWidget(self.open_output_button)
        button_row.addStretch(1)
        layout.addLayout(button_row)

        self.status = QPlainTextEdit()
        self.status.setReadOnly(True)
        self.status.setPlaceholderText(
            "Processing messages will appear here."
        )
        layout.addWidget(self.status, 1)
        self.statusBar().showMessage("Ready")

    def _add_path_row(self, form, label, value, callback):
        edit = QLineEdit(value)
        row = QHBoxLayout()
        row.addWidget(edit, 1)
        browse_button = QPushButton("Browse...")
        browse_button.clicked.connect(callback)
        row.addWidget(browse_button)
        form.addRow(label, row)
        return edit

    def _browse_ppt(self):
        path, _ = QFileDialog.getOpenFileName(
            self,
            "Select PowerPoint template",
            self.ppt_edit.text(),
            "PowerPoint Presentations (*.pptx *.pptm);;All Files (*.*)",
        )
        if path:
            self.ppt_edit.setText(path)

    def _browse_excel(self):
        path, _ = QFileDialog.getOpenFileName(
            self,
            "Select geographical AUM workbook",
            self.excel_edit.text(),
            "Excel Workbooks (*.xlsx *.xlsm *.xlsb *.xls);;All Files (*.*)",
        )
        if path:
            self.excel_edit.setText(path)

    def _browse_output(self):
        path, _ = QFileDialog.getSaveFileName(
            self,
            "Save updated PowerPoint",
            self.output_edit.text(),
            "PowerPoint Presentation (*.pptx)",
        )
        if path:
            if not path.lower().endswith(".pptx"):
                path += ".pptx"
            self.output_edit.setText(path)

    def _browse_log(self):
        path, _ = QFileDialog.getSaveFileName(
            self,
            "Save processing log",
            self.log_edit.text(),
            "Text Files (*.txt)",
        )
        if path:
            if not path.lower().endswith(".txt"):
                path += ".txt"
            self.log_edit.setText(path)

    def _validate_gui_paths(self):
        ppt_path = Path(self.ppt_edit.text().strip())
        excel_path = Path(self.excel_edit.text().strip())
        output_path = Path(self.output_edit.text().strip())
        log_path = Path(self.log_edit.text().strip())

        if not ppt_path.is_file():
            raise FileNotFoundError(
                f"PowerPoint template not found:\n{ppt_path}"
            )
        if ppt_path.suffix.lower() not in {".pptx", ".pptm"}:
            raise ValueError(
                "The PowerPoint template must be a PPTX or PPTM file."
            )
        if not excel_path.is_file():
            raise FileNotFoundError(
                f"Excel workbook not found:\n{excel_path}"
            )
        if excel_path.suffix.lower() not in {
            ".xlsx",
            ".xlsm",
            ".xlsb",
            ".xls",
        }:
            raise ValueError(
                "The Excel input must be XLSX, XLSM, XLSB, or XLS."
            )
        if not output_path.name:
            raise ValueError("Select an output PowerPoint path.")
        if output_path.suffix.lower() != ".pptx":
            raise ValueError(
                "The output PowerPoint path must end with .pptx."
            )
        if not log_path.name:
            raise ValueError("Select a log file path.")
        if log_path.suffix.lower() != ".txt":
            raise ValueError("The log file path must end with .txt.")
        if ppt_path.resolve() == output_path.resolve():
            raise ValueError(
                "The output PowerPoint must be different from the input."
            )
        return ppt_path, excel_path, output_path, log_path

    def run_update(self):
        try:
            ppt_path, excel_path, output_path, log_path = (
                self._validate_gui_paths()
            )
        except Exception as error:
            QMessageBox.warning(self, "Check paths", str(error))
            return

        self.status.clear()
        self._append_status(f"Input PowerPoint: {ppt_path}")
        self._append_status(f"Input Excel: {excel_path}")
        self._append_status(f"Output PowerPoint: {output_path}")
        self._append_status(f"Log file: {log_path}")
        self._append_status("")
        self._append_status("Starting processing...")

        self.run_button.setEnabled(False)
        self.clear_button.setEnabled(False)
        self.statusBar().showMessage("Processing...")

        self.worker_thread = QThread(self)
        self.worker = UpdateWorker(
            ppt_path, excel_path, output_path, log_path
        )
        self.worker.moveToThread(self.worker_thread)

        self.worker_thread.started.connect(self.worker.run)
        self.worker.progress.connect(self._append_status)
        self.worker.finished.connect(self._processing_finished)
        self.worker.failed.connect(self._processing_failed)
        self.worker.finished.connect(self.worker_thread.quit)
        self.worker.failed.connect(self.worker_thread.quit)
        self.worker_thread.finished.connect(self.worker.deleteLater)
        self.worker_thread.finished.connect(self._thread_finished)
        self.worker_thread.finished.connect(
            self.worker_thread.deleteLater
        )
        self.worker_thread.start()

    def _append_status(self, message):
        self.status.appendPlainText(message)
        scrollbar = self.status.verticalScrollBar()
        scrollbar.setValue(scrollbar.maximum())

    def _processing_finished(self, count, messages):
        self.status.setPlainText("\n".join(messages))
        self.statusBar().showMessage(
            f"Complete: {count} object(s) updated"
        )
        QMessageBox.information(
            self,
            "Geospread update complete",
            f"Updated {count} geospreads object(s).\n\n"
            f"Output:\n{self.output_edit.text()}\n\n"
            f"Log:\n{self.log_edit.text()}",
        )

    def _processing_failed(self, error_message, messages):
        self.status.setPlainText("\n".join(messages))
        self.statusBar().showMessage("Processing failed")
        QMessageBox.critical(
            self,
            "Geospread update failed",
            f"{error_message}\n\nReview the processing log for details.",
        )

    def _thread_finished(self):
        self.run_button.setEnabled(True)
        self.clear_button.setEnabled(True)
        self.worker = None
        self.worker_thread = None

    def _clear_messages(self):
        self.status.clear()
        self.statusBar().showMessage("Ready")

    def _open_output_folder(self):
        output_text = self.output_edit.text().strip()
        if not output_text:
            QMessageBox.warning(
                self,
                "Output folder",
                "Select an output PowerPoint path first.",
            )
            return

        output_folder = Path(output_text).parent
        if not output_folder.exists():
            QMessageBox.warning(
                self,
                "Output folder",
                f"The folder does not exist:\n{output_folder}",
            )
            return
        os.startfile(str(output_folder))

    def closeEvent(self, event):
        if self.worker_thread and self.worker_thread.isRunning():
            QMessageBox.warning(
                self,
                "Processing in progress",
                "Wait for Excel and PowerPoint processing to complete "
                "before closing the application.",
            )
            event.ignore()
            return
        event.accept()


def main():
    app = QApplication(sys.argv)
    app.setApplicationName("Axis Geospread Update")
    window = MainWindow()
    window.show()
    sys.exit(app.exec())


if __name__ == "__main__":
    main()
