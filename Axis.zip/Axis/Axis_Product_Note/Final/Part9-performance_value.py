"""Update PowerPoint tables named PerformaneTable/PerformanceTable from one factsheet workbook.

The uploaded Axis workbook stores many fund factsheets as separate worksheets.
Each normal factsheet sheet contains the Regular block followed by the Direct block;
*_Dir sheets repeat only the Regular block and are therefore ignored when the matching
normal sheet exists.

Windows setup:
    py -m pip install pywin32 openpyxl

Picker mode:
    py update_performance_tables_workbook.py

Command line:
    py update_performance_tables_workbook.py --ppt input.pptx --excel Axis_Equity_Factsheet_30_09_2026.xlsx --output updated.pptx

PowerPoint must be installed. Formula cells in the workbook must have cached results.
"""
from __future__ import annotations

import argparse
import logging
import math
import re
import sys
import tkinter as tk
import unicodedata
from dataclasses import dataclass
from pathlib import Path
from tkinter import filedialog, messagebox
from typing import Dict, Iterable, List, Optional, Sequence, Tuple

import pythoncom
import win32com.client as win32
from openpyxl import load_workbook

LOG = logging.getLogger("performance_table_updater")
MSO_GROUP = 6
MSO_TRUE = -1
MSO_TABLE = 19
TARGET_NAMES = {"performanetable", "performancetable"}
FUND_SHAPE_NAME = "fundname"
PPT_ROWS = 5
PPT_COLS = 9
PERIODS = ("1 YEAR", "3 YEAR", "5 YEAR", "SINCE INCEPTION")

FUND_ALIASES = {
    "FLEXI": "AXIS FLEXI CAP FUND", "FLEXI CAP": "AXIS FLEXI CAP FUND",
    "FOCUS": "AXIS FOCUSED FUND", "FOCUSED": "AXIS FOCUSED FUND",
    "LARGE MID": "AXIS LARGE AND MID CAP FUND", "LARGE AND MID": "AXIS LARGE AND MID CAP FUND",
    "LARGE MID CAP": "AXIS LARGE AND MID CAP FUND", "LARGE": "AXIS LARGE CAP FUND",
    "LARGE CAP": "AXIS LARGE CAP FUND", "MID": "AXIS MIDCAP FUND",
    "MID CAP": "AXIS MIDCAP FUND", "MIDCAP": "AXIS MIDCAP FUND",
    "MOMENTUM": "AXIS MOMENTUM FUND", "INNOVATION": "AXIS INNOVATION FUND",
    "MULTICAP": "AXIS MULTICAP FUND", "MULTI CAP": "AXIS MULTICAP FUND",
    "MANUFACTURING": "AXIS INDIA MANUFACTURING FUND",
    "INDIA MANUFACTURING": "AXIS INDIA MANUFACTURING FUND",
    "SMALLCAP": "AXIS SMALL CAP FUND", "SMALL CAP": "AXIS SMALL CAP FUND",
    "QUANT": "AXIS QUANT FUND", "SERVICES": "AXIS SERVICES OPPORTUNITIES FUND",
    "SERVICES OPPORTUNITIES": "AXIS SERVICES OPPORTUNITIES FUND",
    "ELSS": "AXIS ELSS TAX SAVER FUND", "ELSS TAX SAVER": "AXIS ELSS TAX SAVER FUND",
}


@dataclass
class PerformanceBlock:
    sheet: str
    fund_key: str
    fund_display: str
    plan: str
    values: List[List[str]]       # 3 rows x 9 columns: label + 8 values
    source_cells: List[List[str]]


def clean(value: object) -> str:
    return re.sub(r"\s+", " ", str(value or "").replace("\r", " ").replace("\n", " ")).strip()


def plan_text(value: object) -> str:
    text = unicodedata.normalize("NFKD", clean(value)).upper()
    return re.sub(r"[^A-Z0-9]+", " ", text)


def detect_plan(value: object) -> Optional[str]:
    text = plan_text(value)
    if re.search(r"\bDIRECT\b|\bDIR\b", text):
        return "direct"
    if re.search(r"\bREGULAR\b|\bREG\b", text):
        return "regular"
    return None


def normalise_fund(value: object) -> str:
    text = unicodedata.normalize("NFKD", clean(value)).replace("’", "'")
    text = text.replace("&", " AND ").upper().replace("'", "")
    text = re.sub(
        r"\bDIRECT\b|\bDIR\b|\bREGULAR\b|\bREG\b|\bPLAN\b|\bGROWTH\b|\bOPTION\b|"
        r"\bIDCW\b|\bFUND OF FUND\b|\bFUND OF FUNDS\b", " ", text)
    text = re.sub(r"[^A-Z0-9]+", " ", text)
    text = " ".join(text.split())
    return FUND_ALIASES.get(text, text)


def period_name(value: object) -> Optional[str]:
    text = plan_text(value)
    if "SINCE INCEPTION" in text:
        return "SINCE INCEPTION"
    for years in (1, 3, 5, 10):
        if re.search(rf"\b{years}\s+YEARS?\b", text):
            return f"{years} YEAR"
    return None


def display_value(value: object, number_format: str = "General") -> str:
    if value is None:
        return ""
    if isinstance(value, str):
        text = clean(value)
        return "NA" if text.upper() in {"NA", "N/A", "-", "–", "—"} else text
    if isinstance(value, bool):
        return str(value)
    if isinstance(value, (int, float)):
        number = float(value)
        if math.isnan(number) or math.isinf(number):
            return ""
        if "%" in str(number_format or ""):
            match = re.search(r"\.([0#]+)%", str(number_format))
            decimals = len(match.group(1)) if match else 2
            return f"{number * 100:.{decimals}f}%"
        if abs(number - round(number)) < 1e-9:
            return f"{int(round(number)):,}"
        return f"{number:,.2f}"
    return clean(value)


def mapped_metric_columns(ws, header_row: int) -> Dict[str, Tuple[int, int]]:
    """Map each period to its CAGR and current-value columns."""
    hits: Dict[str, int] = {}
    for col in range(1, ws.max_column + 1):
        name = period_name(ws.cell(header_row, col).value)
        if name and name not in hits:
            hits[name] = col
    result: Dict[str, Tuple[int, int]] = {}
    for name, first_col in hits.items():
        # In this workbook each period heading is over two adjacent columns.
        result[name] = (first_col, first_col + 1)
    return result


def find_performance_headers(ws) -> Tuple[int, int, Dict[str, Tuple[int, int]]]:
    for row in range(1, ws.max_row + 1):
        if not any(clean(ws.cell(row, col).value).upper() == "PERFORMANCE"
                   for col in range(1, ws.max_column + 1)):
            continue
        for header_row in range(row + 1, min(row + 5, ws.max_row) + 1):
            metrics = mapped_metric_columns(ws, header_row)
            if "1 YEAR" in metrics and "SINCE INCEPTION" in metrics:
                label_col = min(metrics["1 YEAR"]) - 1
                return header_row, label_col, metrics
    raise ValueError("Performance heading and period columns were not found")


def extract_sheet_blocks(ws) -> List[PerformanceBlock]:
    header_row, label_col, metric_map = find_performance_headers(ws)
    blocks: List[PerformanceBlock] = []
    for row in range(header_row + 1, min(ws.max_row, header_row + 25) + 1):
        label = clean(ws.cell(row, label_col).value)
        plan = detect_plan(label)
        if not plan or "BENCHMARK" in label.upper():
            continue
        if row + 2 > ws.max_row:
            continue

        values: List[List[str]] = []
        addresses: List[List[str]] = []
        for source_row in range(row, row + 3):
            row_values = [display_value(ws.cell(source_row, label_col).value,
                                        ws.cell(source_row, label_col).number_format)]
            row_cells = [ws.cell(source_row, label_col).coordinate]
            for period in PERIODS:
                cols = metric_map.get(period)
                if not cols:
                    row_values.extend(["NA", "NA"])
                    row_cells.extend(["", ""])
                    continue
                for col in cols:
                    cell = ws.cell(source_row, col)
                    row_values.append(display_value(cell.value, cell.number_format) or "NA")
                    row_cells.append(cell.coordinate)
            values.append(row_values)
            addresses.append(row_cells)

        if not all(len(item) == PPT_COLS for item in values):
            raise ValueError(f"{ws.title}: extracted block is not 3 x 9")
        fund_key = normalise_fund(label)
        if not fund_key:
            continue
        blocks.append(PerformanceBlock(ws.title, fund_key, label, plan, values, addresses))
    return blocks


def load_sources(workbook_path: Path) -> Dict[Tuple[str, str], PerformanceBlock]:
    formulas = load_workbook(workbook_path, read_only=False, data_only=False)
    cached = load_workbook(workbook_path, read_only=False, data_only=True)
    try:
        sources: Dict[Tuple[str, str], PerformanceBlock] = {}
        errors: List[str] = []
        sheet_names = set(cached.sheetnames)
        for name in cached.sheetnames:
            upper = name.upper()
            if "_DATA" in upper:
                continue
            # Ignore duplicate Regular-only sheet when a full sheet exists.
            if upper.endswith("_DIR") and name[:-4] in sheet_names:
                continue
            try:
                blocks = extract_sheet_blocks(cached[name])
            except ValueError:
                continue
            for block in blocks:
                # Detect uncached formulas in selected source cells.
                for row_cells in block.source_cells:
                    for address in row_cells[1:]:
                        if not address:
                            continue
                        formula_cell = formulas[name][address]
                        cached_cell = cached[name][address]
                        if formula_cell.data_type == "f" and cached_cell.value is None:
                            errors.append(f"{name}!{address} has no cached formula result")
                key = (block.fund_key, block.plan)
                if key in sources:
                    old = sources[key]
                    errors.append(f"Duplicate {block.plan} source for {block.fund_key}: {old.sheet}, {name}")
                else:
                    sources[key] = block
        if errors:
            raise ValueError("\n".join(errors[:25]))
        if not sources:
            raise ValueError("No Regular/Direct performance blocks were found in the workbook")
        LOG.info("Loaded %d fund/plan performance blocks", len(sources))
        return sources
    finally:
        formulas.close()
        cached.close()


def iter_shapes(shapes) -> Iterable[object]:
    for index in range(1, shapes.Count + 1):
        shape = shapes.Item(index)
        yield shape
        if shape.Type == MSO_GROUP:
            yield from iter_shapes(shape.GroupItems)


def named_shapes(slide, names: Sequence[str]) -> List[object]:
    wanted = {name.casefold() for name in names}
    return [shape for shape in iter_shapes(slide.Shapes)
            if str(shape.Name).casefold() in wanted]


def shape_text(shape) -> str:
    try:
        if shape.HasTextFrame == MSO_TRUE and shape.TextFrame.HasText == MSO_TRUE:
            return clean(shape.TextFrame.TextRange.Text)
    except Exception:
        pass
    return ""


def find_slide_fund(slides, slide_no: int) -> Optional[str]:
    for index in range(slide_no, 0, -1):
        for shape in named_shapes(slides.Item(index), [FUND_SHAPE_NAME]):
            text = shape_text(shape)
            if text:
                return text
    return None


def table_matrix(table) -> List[List[str]]:
    result = []
    for row in range(1, table.Rows.Count + 1):
        current = []
        for col in range(1, table.Columns.Count + 1):
            try:
                current.append(clean(table.Cell(row, col).Shape.TextFrame.TextRange.Text))
            except Exception:
                current.append("")
        result.append(current)
    return result


def detect_ppt_plan(table) -> Optional[str]:
    matrix = table_matrix(table)
    # Prefer data rows, then inspect the entire table.
    for row in matrix[2:]:
        found = detect_plan(" ".join(row))
        if found:
            return found
    return detect_plan(" ".join(value for row in matrix for value in row))


def token_score(left: str, right: str) -> float:
    a, b = set(left.split()), set(right.split())
    return 2.0 * len(a & b) / (len(a) + len(b)) if a and b else 0.0


def resolve_source(fund_text: str, plan: str,
                   sources: Dict[Tuple[str, str], PerformanceBlock]) -> Tuple[Optional[PerformanceBlock], str]:
    wanted = normalise_fund(fund_text)
    candidates = [(key, block) for (key, p), block in sources.items() if p == plan]
    for key, block in candidates:
        if key == wanted:
            return block, "exact"
    contained = [(key, block) for key, block in candidates if wanted and (wanted in key or key in wanted)]
    if len(contained) == 1:
        return contained[0][1], "containment"
    ranked = sorted(((token_score(wanted, key), key, block) for key, block in candidates), reverse=True)
    if ranked:
        best = ranked[0]
        second = ranked[1][0] if len(ranked) > 1 else 0.0
        if best[0] >= 0.72 and best[0] - second >= 0.08:
            return best[2], f"token score {best[0]:.2f}"
    return None, "no unambiguous match"


def update_table(shape, values: Sequence[Sequence[str]]) -> int:
    if shape.Type != MSO_TABLE and getattr(shape, "HasTable", 0) != MSO_TRUE:
        raise TypeError(f"Shape {shape.Name!r} is not a PowerPoint table")
    table = shape.Table
    if table.Rows.Count < PPT_ROWS or table.Columns.Count < PPT_COLS:
        raise ValueError(f"Table is {table.Rows.Count}x{table.Columns.Count}; at least 5x9 is required")
    changed = 0
    # Preserve PPT column 1 labels. Update rows 3-5, columns 2-9.
    for source_row in range(3):
        for source_col in range(1, PPT_COLS):
            table.Cell(source_row + 3, source_col + 1).Shape.TextFrame.TextRange.Text = values[source_row][source_col]
            changed += 1
    return changed


def update_presentation(ppt_path: Path, excel_path: Path, output_path: Path) -> Tuple[int, int]:
    sources = load_sources(excel_path)
    pythoncom.CoInitialize()
    app = presentation = None
    updated = skipped = 0
    try:
        app = win32.DispatchEx("PowerPoint.Application")
        app.Visible = True
        presentation = app.Presentations.Open(str(ppt_path.resolve()), ReadOnly=False,
                                              Untitled=False, WithWindow=False)
        slides = presentation.Slides
        for slide_no in range(1, slides.Count + 1):
            for shape in named_shapes(slides.Item(slide_no), list(TARGET_NAMES)):
                try:
                    if shape.Type != MSO_TABLE and getattr(shape, "HasTable", 0) != MSO_TRUE:
                        raise TypeError("Named shape is not a table")
                    plan = detect_ppt_plan(shape.Table)
                    if not plan:
                        raise ValueError("Regular or Direct was not found in the PowerPoint table")
                    fund_text = find_slide_fund(slides, slide_no)
                    if not fund_text:
                        raise ValueError("No preceding FundName shape contains a fund name")
                    source, method = resolve_source(fund_text, plan, sources)
                    if source is None:
                        raise ValueError(f"No {plan.title()} source matched {fund_text!r}")
                    changed = update_table(shape, source.values)
                    updated += 1
                    LOG.info("Slide %d: %s %s updated from %s (%s, %d cells)",
                             slide_no, fund_text, plan, source.sheet, method, changed)
                except Exception as exc:
                    skipped += 1
                    LOG.error("Slide %d table %s skipped: %s", slide_no, shape.Name, exc)
        output_path.parent.mkdir(parents=True, exist_ok=True)
        presentation.SaveAs(str(output_path.resolve()))
        return updated, skipped
    finally:
        if presentation is not None:
            presentation.Close()
        if app is not None:
            app.Quit()
        pythoncom.CoUninitialize()


def choose_inputs() -> Optional[Tuple[Path, Path, Path]]:
    root = tk.Tk(); root.withdraw(); root.attributes("-topmost", True)
    try:
        ppt = filedialog.askopenfilename(parent=root, title="Select PowerPoint template",
                                         filetypes=[("PowerPoint", "*.pptx")])
        if not ppt:
            return None
        excel = filedialog.askopenfilename(parent=root, title="Select Axis factsheet workbook",
                                           initialdir=str(Path(ppt).parent),
                                           filetypes=[("Excel workbook", "*.xlsx *.xlsm")])
        if not excel:
            return None
        output = filedialog.asksaveasfilename(parent=root, title="Save updated PowerPoint as",
                                               initialdir=str(Path(ppt).parent),
                                               initialfile=f"{Path(ppt).stem} - Updated Performance.pptx",
                                               defaultextension=".pptx",
                                               filetypes=[("PowerPoint", "*.pptx")])
        if not output:
            return None
        return Path(ppt), Path(excel), Path(output)
    finally:
        root.destroy()


def show_message(kind: str, title: str, text: str) -> None:
    root = tk.Tk(); root.withdraw(); root.attributes("-topmost", True)
    try:
        getattr(messagebox, kind)(title, text, parent=root)
    finally:
        root.destroy()


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Update PPT performance tables from a multi-sheet Axis factsheet workbook")
    parser.add_argument("--ppt", type=Path)
    parser.add_argument("--excel", type=Path)
    parser.add_argument("--output", type=Path)
    parser.add_argument("--log-level", choices=["DEBUG", "INFO", "WARNING", "ERROR"], default="INFO")
    args = parser.parse_args()
    supplied = [args.ppt, args.excel, args.output]
    if any(supplied) and not all(supplied):
        parser.error("Supply --ppt, --excel and --output together, or none for picker mode")
    return args


def main() -> int:
    args = parse_args()
    logging.basicConfig(level=getattr(logging, args.log_level), format="%(levelname)s: %(message)s")
    graphical = not all([args.ppt, args.excel, args.output])
    try:
        selected = choose_inputs() if graphical else (args.ppt, args.excel, args.output)
        if selected is None:
            return 0
        ppt, excel, output = selected
        if not ppt.is_file():
            raise FileNotFoundError(f"PowerPoint not found: {ppt}")
        if not excel.is_file():
            raise FileNotFoundError(f"Excel workbook not found: {excel}")
        if output.resolve() == ppt.resolve():
            raise ValueError("Output must be different from the source PowerPoint")
        updated, skipped = update_presentation(ppt, excel, output)
        text = f"Completed.\n\nUpdated: {updated}\nSkipped: {skipped}\n\nOutput:\n{output}"
        LOG.info(text.replace("\n", " "))
        if graphical:
            show_message("showinfo", "Performance update complete", text)
        return 0 if updated else 2
    except Exception as exc:
        LOG.exception("Update failed")
        if graphical:
            show_message("showerror", "Performance update failed", str(exc))
        return 1


if __name__ == "__main__":
    sys.exit(main())
