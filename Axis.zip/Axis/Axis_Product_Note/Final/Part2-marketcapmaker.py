# -*- coding: utf-8 -*-
"""Refresh Excel market-cap charts and paste centered editable charts into PowerPoint.

Install: py -m pip install PyQt6 pywin32
Run:     py market_cap_charts_true_center.py
"""
from __future__ import annotations

import re
import sys
import time
import traceback
from pathlib import Path
from typing import Any, Callable, Optional

import pythoncom
import win32com.client as win32
from PyQt6.QtCore import QThread, pyqtSignal
from PyQt6.QtGui import QCloseEvent
from PyQt6.QtWidgets import (
    QApplication, QCheckBox, QFileDialog, QGridLayout, QHBoxLayout, QLabel,
    QLineEdit, QMainWindow, QMessageBox, QPlainTextEdit, QProgressBar,
    QPushButton, QVBoxLayout, QWidget,
)

EXCEL_SHEET_NAME = "Market Cap Charts"
EXCEL_CHART_PREFIX = "MarketCapChart_"
PPT_FUND_NAME_OBJECT = "FundName"
PPT_GRAPH_OBJECT = "MarketCapGraph"
OUTPUT_SUFFIX = "_with_market_cap_graphs"

FONT_NAME = "Lato"
DATA_LABEL_FONT_SIZE = 6.8
LEGEND_FONT_SIZE = 7.5
NARROW_LEGEND_FONT_SIZE = 7.0
PLACEHOLDER_MARGIN = 1.0

# The pie and legend are centered independently using their widths.
PLOT_TOP_RATIO = 0.075
PLOT_HEIGHT_RATIO = 0.62
NORMAL_PLOT_WIDTH_RATIO = 0.82
NARROW_PLOT_WIDTH_RATIO = 0.76
LEGEND_TOP_RATIO = 0.735
LEGEND_WIDTH_RATIO = 0.90
LEGEND_HEIGHT_RATIO = 0.13
NARROW_PLACEHOLDER_RATIO = 1.20

PP_PASTE_DEFAULT = 0
PP_PASTE_OLE_OBJECT = 10
PP_SAVE_PPTX = 24
PP_SAVE_PPTM = 25
PP_SAVE_PPSX = 28
MSO_TRUE = -1
MSO_FALSE = 0
XL_CALCULATION_AUTOMATIC = -4105
XL_LEGEND_POSITION_BOTTOM = -4107
XL_LABEL_POSITION_BEST_FIT = 5
COPY_ATTEMPTS = 8
COPY_WAIT_SECONDS = 0.75


def clean_text(value: Any) -> str:
    return "" if value is None else re.sub(r"\s+", " ", str(value)).strip()


def normalize_fund_name(value: Any) -> str:
    text = clean_text(value).casefold().replace("’", "'").replace("‘", "'")
    text = re.sub(r"'s\b", "s", text)
    return " ".join("".join(ch if ch.isalnum() else " " for ch in text).split())


def wait_office(seconds: float) -> None:
    end = time.time() + seconds
    while time.time() < end:
        pythoncom.PumpWaitingMessages()
        time.sleep(0.05)


def validate_file(text: str, extensions: set[str], label: str) -> Path:
    if not text.strip():
        raise ValueError(f"Please select the {label}.")
    path = Path(text).expanduser().resolve()
    if not path.is_file():
        raise FileNotFoundError(f"The selected {label} does not exist:\n{path}")
    if path.suffix.lower() not in extensions:
        raise ValueError(f"The {label} must use one of: {', '.join(sorted(extensions))}")
    return path


def output_path(ppt: Path, folder_text: str) -> Path:
    folder = Path(folder_text).expanduser().resolve() if folder_text.strip() else ppt.parent
    folder.mkdir(parents=True, exist_ok=True)
    return folder / f"{ppt.stem}{OUTPUT_SUFFIX}{ppt.suffix}"


def save_format(path: Path) -> int:
    return {".pptm": PP_SAVE_PPTM, ".ppsx": PP_SAVE_PPSX}.get(path.suffix.lower(), PP_SAVE_PPTX)


def shape_text(shape: Any) -> str:
    try:
        if shape.HasTextFrame and shape.TextFrame.HasText:
            return clean_text(shape.TextFrame.TextRange.Text)
    except Exception:
        pass
    try:
        if shape.TextFrame2.HasText:
            return clean_text(shape.TextFrame2.TextRange.Text)
    except Exception:
        pass
    return ""


def find_shape(slide: Any, required_name: str) -> Optional[Any]:
    target = required_name.casefold()
    for index in range(1, int(slide.Shapes.Count) + 1):
        shape = slide.Shapes.Item(index)
        if clean_text(shape.Name).casefold() == target:
            return shape
    return None


def find_targets(presentation: Any) -> list[dict[str, Any]]:
    result: list[dict[str, Any]] = []
    for number in range(1, int(presentation.Slides.Count) + 1):
        slide = presentation.Slides.Item(number)
        fund_shape = find_shape(slide, PPT_FUND_NAME_OBJECT)
        graph_shape = find_shape(slide, PPT_GRAPH_OBJECT)
        if fund_shape is None or graph_shape is None:
            continue
        fund_name = shape_text(fund_shape)
        if not fund_name:
            continue
        result.append({
            "slide": slide, "slide_number": number, "fund_name": fund_name,
            "key": normalize_fund_name(fund_name), "graph_shape": graph_shape,
            "left": float(graph_shape.Left), "top": float(graph_shape.Top),
            "width": float(graph_shape.Width), "height": float(graph_shape.Height),
        })
    return result


def get_excel_sheet(workbook: Any) -> Any:
    for index in range(1, int(workbook.Worksheets.Count) + 1):
        sheet = workbook.Worksheets.Item(index)
        if clean_text(sheet.Name).casefold() == EXCEL_SHEET_NAME.casefold():
            return sheet
    raise ValueError(f"Worksheet '{EXCEL_SHEET_NAME}' was not found.")


def get_chart_fund_name(sheet: Any, chart_object: Any) -> str:
    chart_name = clean_text(chart_object.Name)
    if chart_name.casefold().startswith(EXCEL_CHART_PREFIX.casefold()):
        try:
            row = int(chart_name[len(EXCEL_CHART_PREFIX):])
            value = clean_text(sheet.Cells(row, 2).Value)
            if value:
                return value
        except Exception:
            pass
    try:
        start_row = int(chart_object.TopLeftCell.Row)
    except Exception:
        start_row = 1
    for row in range(start_row, 0, -1):
        value = clean_text(sheet.Cells(row, 2).Value)
        if value:
            return value
    return ""


def build_chart_lookup(sheet: Any) -> dict[str, dict[str, Any]]:
    lookup: dict[str, dict[str, Any]] = {}
    duplicates: list[str] = []
    for index in range(1, int(sheet.ChartObjects().Count) + 1):
        obj = sheet.ChartObjects().Item(index)
        fund = get_chart_fund_name(sheet, obj)
        key = normalize_fund_name(fund)
        if not key:
            continue
        if key in lookup:
            duplicates.append(fund)
        else:
            lookup[key] = {"fund_name": fund, "chart_object": obj}
    if duplicates:
        raise ValueError("Duplicate normalized chart names: " + ", ".join(sorted(set(duplicates))))
    return lookup


def refresh_excel(excel: Any, workbook: Any, sheet: Any) -> None:
    try:
        excel.Calculation = XL_CALCULATION_AUTOMATIC
    except Exception:
        pass
    try:
        workbook.RefreshAll()
    except Exception:
        pass
    try:
        excel.CalculateFullRebuild()
    except Exception:
        try:
            excel.CalculateFull()
        except Exception:
            pass
    wait_office(1.5)
    try:
        sheet.Calculate()
    except Exception:
        pass
    for index in range(1, int(sheet.ChartObjects().Count) + 1):
        try:
            sheet.ChartObjects().Item(index).Chart.Refresh()
        except Exception:
            pass
    wait_office(0.8)


def chart_values(chart: Any) -> str:
    result: list[str] = []
    try:
        for index in range(1, int(chart.SeriesCollection().Count) + 1):
            values = chart.SeriesCollection(index).Values
            if isinstance(values, tuple):
                result.extend(clean_text(v) for v in values)
            else:
                result.append(clean_text(values))
    except Exception:
        return "unavailable"
    return ", ".join(v for v in result if v) or "unavailable"


def format_source_chart(chart_object: Any) -> None:
    chart = chart_object.Chart
    try:
        chart.HasTitle = False
        chart.ChartArea.Format.Fill.Visible = MSO_FALSE
        chart.ChartArea.Format.Line.Visible = MSO_FALSE
    except Exception:
        pass
    try:
        chart.HasLegend = True
        chart.Legend.Position = XL_LEGEND_POSITION_BOTTOM
        chart.Legend.Font.Name = FONT_NAME
        chart.Legend.Font.Size = LEGEND_FONT_SIZE
    except Exception:
        pass
    try:
        for index in range(1, int(chart.SeriesCollection().Count) + 1):
            series = chart.SeriesCollection(index)
            series.HasDataLabels = True
            labels = series.DataLabels()
            labels.Font.Name = FONT_NAME
            labels.Font.Size = DATA_LABEL_FONT_SIZE
            labels.Font.Bold = False
            labels.Position = XL_LABEL_POSITION_BEST_FIT
    except Exception:
        pass
    try:
        chart.Refresh()
    except Exception:
        pass


def copy_chart(excel: Any, sheet: Any, chart_object: Any) -> str:
    excel.Visible = True
    excel.ScreenUpdating = True
    sheet.Activate()
    chart_object.Activate()
    format_source_chart(chart_object)
    wait_office(0.4)
    values = chart_values(chart_object.Chart)
    last_error: Optional[Exception] = None
    for attempt in range(COPY_ATTEMPTS):
        try:
            excel.CutCopyMode = False
        except Exception:
            pass
        try:
            chart_object.Activate()
            chart_object.Copy()
            wait_office(COPY_WAIT_SECONDS + attempt * 0.3)
            return values
        except Exception as exc:
            last_error = exc
            wait_office(0.4)
    raise RuntimeError(f"Excel could not copy chart '{chart_object.Name}': {last_error}")


def is_editable_chart(shape: Any) -> bool:
    try:
        if bool(shape.HasChart):
            return True
    except Exception:
        pass
    try:
        prog_id = clean_text(shape.OLEFormat.ProgID).casefold()
        return "excel.chart" in prog_id or "excel.sheet" in prog_id
    except Exception:
        return False


def paste_editable_chart(slide: Any) -> Any:
    errors: list[str] = []
    for attempt in range(COPY_ATTEMPTS):
        for data_type, label in ((PP_PASTE_DEFAULT, "default"), (PP_PASTE_OLE_OBJECT, "OLE")):
            try:
                result = slide.Shapes.PasteSpecial(DataType=data_type)
                if result.Count:
                    shape = result.Item(1)
                    if is_editable_chart(shape):
                        return shape
                    shape.Delete()
                    errors.append(f"{label}: non-editable")
            except Exception as exc:
                errors.append(f"{label}: {exc}")
        try:
            result = slide.Shapes.Paste()
            if result.Count:
                shape = result.Item(1)
                if is_editable_chart(shape):
                    return shape
                shape.Delete()
                errors.append("Paste: non-editable")
        except Exception as exc:
            errors.append(f"Paste: {exc}")
        wait_office(COPY_WAIT_SECONDS + attempt * 0.3)
    raise RuntimeError("PowerPoint could not paste an editable chart. " + " | ".join(errors[-6:]))


def fit_outer_shape(shape: Any, target: dict[str, Any]) -> None:
    margin = PLACEHOLDER_MARGIN
    shape.LockAspectRatio = MSO_FALSE
    shape.Left = target["left"] + margin
    shape.Top = target["top"] + margin
    shape.Width = max(1.0, target["width"] - 2 * margin)
    shape.Height = max(1.0, target["height"] - 2 * margin)


def center_chart_interior(shape: Any) -> None:
    """Mathematically center both plot and legend inside the embedded chart."""
    try:
        chart = shape.Chart
    except Exception:
        return
    try:
        chart.HasTitle = False
        chart.ChartArea.Format.Fill.Visible = MSO_FALSE
        chart.ChartArea.Format.Line.Visible = MSO_FALSE
        chart.PlotArea.Format.Fill.Visible = MSO_FALSE
        chart.PlotArea.Format.Line.Visible = MSO_FALSE
    except Exception:
        pass
    try:
        width = float(chart.ChartArea.Width)
        height = float(chart.ChartArea.Height)
    except Exception:
        width, height = float(shape.Width), float(shape.Height)

    aspect = width / max(height, 1.0)
    if aspect < NARROW_PLACEHOLDER_RATIO:
        plot_width_ratio = NARROW_PLOT_WIDTH_RATIO
        legend_font_size = NARROW_LEGEND_FONT_SIZE
    else:
        plot_width_ratio = NORMAL_PLOT_WIDTH_RATIO
        legend_font_size = LEGEND_FONT_SIZE

    # These formulas are the key fix: left = (available width - item width) / 2.
    plot_left_ratio = (1.0 - plot_width_ratio) / 2.0
    legend_left_ratio = (1.0 - LEGEND_WIDTH_RATIO) / 2.0

    try:
        plot = chart.PlotArea
        plot.Left = width * plot_left_ratio
        plot.Top = height * PLOT_TOP_RATIO
        plot.Width = width * plot_width_ratio
        plot.Height = height * PLOT_HEIGHT_RATIO
    except Exception:
        pass
    try:
        chart.HasLegend = True
        legend = chart.Legend
        legend.Position = XL_LEGEND_POSITION_BOTTOM
        legend.IncludeInLayout = False
        legend.Left = width * legend_left_ratio
        legend.Top = height * LEGEND_TOP_RATIO
        legend.Width = width * LEGEND_WIDTH_RATIO
        legend.Height = height * LEGEND_HEIGHT_RATIO
        legend.Font.Name = FONT_NAME
        legend.Font.Size = legend_font_size
    except Exception:
        pass
    try:
        for index in range(1, int(chart.SeriesCollection().Count) + 1):
            labels = chart.SeriesCollection(index).DataLabels()
            labels.Font.Name = FONT_NAME
            labels.Font.Size = DATA_LABEL_FONT_SIZE
            labels.Font.Bold = False
            labels.Position = XL_LABEL_POSITION_BEST_FIT
    except Exception:
        pass
    try:
        chart.Refresh()
    except Exception:
        pass


def replace_graph(target: dict[str, Any]) -> Any:
    shape = paste_editable_chart(target["slide"])
    wait_office(0.45)
    fit_outer_shape(shape, target)
    # 3-D pie geometry recalculates after resize. Reapply three times.
    for _ in range(3):
        wait_office(0.30)
        center_chart_interior(shape)
    shape.Name = PPT_GRAPH_OBJECT
    target["graph_shape"].Delete()
    return shape


def process_files(
    ppt_file: str, excel_file: str, output_folder: str,
    status_callback: Optional[Callable[[str], None]] = None,
    progress_callback: Optional[Callable[[int], None]] = None,
    open_output: bool = True,
) -> str:
    report = status_callback or print
    ppt_path = validate_file(ppt_file, {".pptx", ".pptm", ".ppsx"}, "PowerPoint file")
    xls_path = validate_file(excel_file, {".xlsx", ".xlsm", ".xlsb", ".xls"}, "Excel file")
    out_path = output_path(ppt_path, output_folder)
    excel = workbook = powerpoint = presentation = None
    pythoncom.CoInitialize()
    try:
        report("Starting Microsoft Excel...")
        excel = win32.DispatchEx("Excel.Application")
        excel.DisplayAlerts = False
        excel.ScreenUpdating = True
        workbook = excel.Workbooks.Open(str(xls_path), UpdateLinks=0, ReadOnly=True, IgnoreReadOnlyRecommended=True)
        sheet = get_excel_sheet(workbook)
        report("Refreshing formulas and chart caches...")
        refresh_excel(excel, workbook, sheet)
        lookup = build_chart_lookup(sheet)
        report(f"Found {len(lookup)} uniquely named Excel charts.")

        report("Starting Microsoft PowerPoint...")
        powerpoint = win32.DispatchEx("PowerPoint.Application")
        powerpoint.Visible = True
        presentation = powerpoint.Presentations.Open(str(ppt_path), WithWindow=True)
        targets = find_targets(presentation)
        report(f"Found {len(targets)} PowerPoint graph placeholders.")

        matches: list[tuple[dict[str, Any], dict[str, Any]]] = []
        for target in targets:
            record = lookup.get(target["key"])
            if record is None:
                report(f"WARNING: no Excel chart for slide {target['slide_number']}: {target['fund_name']}")
            else:
                matches.append((target, record))
        if not matches:
            raise ValueError("No PowerPoint FundName values matched Excel chart fund names.")

        for index, (target, record) in enumerate(matches, 1):
            report(f"Copying {index}/{len(matches)}: {record['fund_name']} -> slide {target['slide_number']}")
            values = copy_chart(excel, sheet, record["chart_object"])
            report(f"Excel chart values at copy time: {values}")
            try:
                powerpoint.ActiveWindow.View.GotoSlide(target["slide_number"])
            except Exception:
                pass
            wait_office(0.30)
            pasted = replace_graph(target)
            report(f"Pasted centered: L={pasted.Left:.1f}, T={pasted.Top:.1f}, W={pasted.Width:.1f}, H={pasted.Height:.1f}")
            if progress_callback:
                progress_callback(round(index / len(matches) * 100))

        if out_path.exists():
            try:
                out_path.unlink()
            except PermissionError as exc:
                raise PermissionError(f"The output presentation is open:\n{out_path}") from exc
        report(f"Saving output presentation: {out_path}")
        presentation.SaveAs(str(out_path), save_format(out_path))
        presentation.Close(); presentation = None
        workbook.Close(False); workbook = None
        excel.Quit(); excel = None
        if open_output:
            powerpoint.Presentations.Open(str(out_path), WithWindow=True)
            powerpoint = None
        else:
            powerpoint.Quit(); powerpoint = None
        report("Processing completed successfully.")
        return str(out_path)
    except Exception as exc:
        report(traceback.format_exc())
        raise RuntimeError(f"Processing failed: {exc}") from exc
    finally:
        if presentation is not None:
            try: presentation.Close()
            except Exception: pass
        if workbook is not None:
            try: workbook.Close(False)
            except Exception: pass
        if excel is not None:
            try: excel.Quit()
            except Exception: pass
        if powerpoint is not None:
            try: powerpoint.Quit()
            except Exception: pass
        pythoncom.CoUninitialize()


class Worker(QThread):
    status_changed = pyqtSignal(str)
    progress_changed = pyqtSignal(int)
    succeeded = pyqtSignal(str)
    failed = pyqtSignal(str)

    def __init__(self, ppt: str, excel: str, folder: str, open_output: bool) -> None:
        super().__init__()
        self.ppt, self.excel, self.folder, self.open_output = ppt, excel, folder, open_output

    def run(self) -> None:
        try:
            result = process_files(self.ppt, self.excel, self.folder, self.status_changed.emit, self.progress_changed.emit, self.open_output)
            self.succeeded.emit(result)
        except Exception as exc:
            self.failed.emit(str(exc))


class MainWindow(QMainWindow):
    def __init__(self) -> None:
        super().__init__()
        self.worker: Optional[Worker] = None
        self.setWindowTitle("Market Cap Charts to PowerPoint")
        self.resize(960, 720)
        self.build_ui()

    def build_ui(self) -> None:
        root = QWidget(); layout = QVBoxLayout(root)
        layout.setContentsMargins(18, 18, 18, 18); layout.setSpacing(12)
        title = QLabel("Paste Centered Editable Market Cap Charts")
        title.setStyleSheet("font-size:20px;font-weight:700;color:#1F4E79;")
        desc = QLabel("Centers the pie and legend independently inside the exact MarketCapGraph placeholder.")
        layout.addWidget(title); layout.addWidget(desc)
        grid = QGridLayout()
        self.ppt_edit = QLineEdit(); self.ppt_edit.setReadOnly(True)
        self.excel_edit = QLineEdit(); self.excel_edit.setReadOnly(True)
        self.out_edit = QLineEdit(); self.out_edit.setReadOnly(True)
        self.ppt_btn = QPushButton("Browse PowerPoint")
        self.excel_btn = QPushButton("Browse Excel")
        self.out_btn = QPushButton("Browse Output Folder")
        self.same_btn = QPushButton("Use PPT Folder")
        grid.addWidget(QLabel("PowerPoint template"), 0, 0); grid.addWidget(self.ppt_edit, 1, 0); grid.addWidget(self.ppt_btn, 1, 1)
        grid.addWidget(QLabel("Excel workbook"), 2, 0); grid.addWidget(self.excel_edit, 3, 0); grid.addWidget(self.excel_btn, 3, 1)
        grid.addWidget(QLabel("Output folder"), 4, 0); grid.addWidget(self.out_edit, 5, 0)
        row = QHBoxLayout(); row.addWidget(self.out_btn); row.addWidget(self.same_btn); grid.addLayout(row, 5, 1)
        layout.addLayout(grid)
        self.open_check = QCheckBox("Open completed presentation"); self.open_check.setChecked(True)
        self.run_btn = QPushButton("Paste Editable Charts")
        self.progress = QProgressBar(); self.progress.setRange(0, 100)
        self.status = QPlainTextEdit(); self.status.setReadOnly(True)
        layout.addWidget(self.open_check); layout.addWidget(self.run_btn); layout.addWidget(self.progress); layout.addWidget(self.status, 1)
        self.setCentralWidget(root)
        self.ppt_btn.clicked.connect(self.pick_ppt)
        self.excel_btn.clicked.connect(self.pick_excel)
        self.out_btn.clicked.connect(self.pick_out)
        self.same_btn.clicked.connect(self.out_edit.clear)
        self.run_btn.clicked.connect(self.start)

    def pick_ppt(self) -> None:
        name, _ = QFileDialog.getOpenFileName(self, "Select PowerPoint", str(Path.home()), "PowerPoint (*.pptx *.pptm *.ppsx)")
        if name: self.ppt_edit.setText(name)

    def pick_excel(self) -> None:
        name, _ = QFileDialog.getOpenFileName(self, "Select Excel", str(Path.home()), "Excel (*.xlsx *.xlsm *.xlsb *.xls)")
        if name: self.excel_edit.setText(name)

    def pick_out(self) -> None:
        name = QFileDialog.getExistingDirectory(self, "Select Output Folder", str(Path.home()))
        if name: self.out_edit.setText(name)

    def set_busy(self, busy: bool) -> None:
        for widget in (self.ppt_btn, self.excel_btn, self.out_btn, self.same_btn, self.open_check, self.run_btn):
            widget.setDisabled(busy)

    def start(self) -> None:
        self.status.clear(); self.progress.setValue(0); self.set_busy(True)
        self.worker = Worker(self.ppt_edit.text(), self.excel_edit.text(), self.out_edit.text(), self.open_check.isChecked())
        self.worker.status_changed.connect(self.status.appendPlainText)
        self.worker.progress_changed.connect(self.progress.setValue)
        self.worker.succeeded.connect(self.done)
        self.worker.failed.connect(self.error)
        self.worker.start()

    def done(self, path: str) -> None:
        self.set_busy(False); self.progress.setValue(100); self.worker = None
        QMessageBox.information(self, "Completed", f"Presentation created:\n{path}")

    def error(self, message: str) -> None:
        self.set_busy(False); self.status.appendPlainText("ERROR: " + message); self.worker = None
        QMessageBox.critical(self, "Processing Failed", message)

    def closeEvent(self, event: QCloseEvent) -> None:
        if self.worker is not None and self.worker.isRunning():
            QMessageBox.warning(self, "Processing", "Please wait until processing finishes.")
            event.ignore()
        else:
            event.accept()


def main() -> None:
    app = QApplication(sys.argv); app.setStyle("Fusion")
    window = MainWindow(); window.show(); sys.exit(app.exec())


if __name__ == "__main__":
    main()
