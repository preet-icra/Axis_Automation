import os
import re
import sys
from dataclasses import dataclass
from typing import Optional

from openpyxl import load_workbook
from pptx import Presentation
from pptx.enum.shapes import MSO_SHAPE_TYPE

from PyQt6.QtCore import Qt
from PyQt6.QtWidgets import (
    QApplication,
    QCheckBox,
    QComboBox,
    QFileDialog,
    QFormLayout,
    QGroupBox,
    QHBoxLayout,
    QHeaderView,
    QLabel,
    QLineEdit,
    QMainWindow,
    QMessageBox,
    QProgressBar,
    QPushButton,
    QTableWidget,
    QTableWidgetItem,
    QVBoxLayout,
    QWidget,
)

# PowerPoint Selection Pane object names.
FUND_MANAGER_SCHEME_NOTE_OBJECT = "FundManagerSchemeNote"
MANAGER_NOTE_AND_DATE_OBJECT = "ManagerNoteandDate"

# Default Excel sheet shown in the screenshot.
DEFAULT_EXCEL_SHEET = "Disclaimers"


@dataclass
class ExcelManagerRecord:
    manager_name: str
    scheme_count: Optional[int]
    disclaimer: str
    missing_date_count: Optional[int]
    excel_row: int


# -----------------------------------------------------------------------------
# General text helpers
# -----------------------------------------------------------------------------

def normalize(value: object) -> str:
    text = "" if value is None else str(value)
    text = text.replace("\xa0", " ").replace("\r", " ").replace("\n", " ")
    return re.sub(r"\s+", " ", text).strip().casefold()


def clean_ligatures(value: str) -> str:
    return (
        (value or "")
        .replace("\xa0", " ")
        .replace("\ufb00", "ff")
        .replace("\ufb01", "fi")
        .replace("\ufb02", "fl")
        .replace("\ufb03", "ffi")
        .replace("\ufb04", "ffl")
    )


def integer_or_none(value: object) -> Optional[int]:
    if value is None or value == "":
        return None
    try:
        return int(float(value))
    except (TypeError, ValueError):
        return None


# -----------------------------------------------------------------------------
# Excel reading
# -----------------------------------------------------------------------------

HEADER_ALIASES = {
    "manager_name": {
        "fund manager",
        "fundmanager",
        "manager",
        "fund manager name",
        "manager name",
    },
    "scheme_count": {
        "scheme count",
        "schemecount",
        "schemes count",
        "no of schemes",
        "number of schemes",
    },
    "disclaimer": {
        "disclaimer",
        "manager disclaimer",
        "fund manager disclaimer",
        "manager note and date",
    },
    "missing_date_count": {
        "missing date count",
        "missingdatecount",
        "missing dates",
    },
}


def locate_header_row_and_columns(sheet) -> tuple[int, dict[str, int]]:
    """Find the header row within the first 20 worksheet rows."""
    for row_number in range(1, min(sheet.max_row, 20) + 1):
        found: dict[str, int] = {}
        for column_number in range(1, sheet.max_column + 1):
            header = normalize(sheet.cell(row_number, column_number).value)
            if not header:
                continue
            for field_name, aliases in HEADER_ALIASES.items():
                if header in aliases:
                    found[field_name] = column_number
                    break

        if "manager_name" in found and (
            "scheme_count" in found or "disclaimer" in found
        ):
            return row_number, found

    raise ValueError(
        "Could not find the Excel headers. Required header: 'Fund Manager'. "
        "Also include 'Scheme Count' and/or 'Disclaimer'."
    )


def read_excel_records(excel_path: str, sheet_name: str) -> list[ExcelManagerRecord]:
    workbook = load_workbook(excel_path, data_only=True, read_only=True)
    try:
        if sheet_name not in workbook.sheetnames:
            raise ValueError(f"Worksheet '{sheet_name}' was not found.")

        sheet = workbook[sheet_name]
        header_row, columns = locate_header_row_and_columns(sheet)
        records: list[ExcelManagerRecord] = []

        for row_number in range(header_row + 1, sheet.max_row + 1):
            manager_value = sheet.cell(row_number, columns["manager_name"]).value
            manager_name = "" if manager_value is None else str(manager_value).strip()
            if not manager_name:
                continue

            scheme_count = None
            if "scheme_count" in columns:
                scheme_count = integer_or_none(
                    sheet.cell(row_number, columns["scheme_count"]).value
                )

            disclaimer = ""
            if "disclaimer" in columns:
                disclaimer_value = sheet.cell(row_number, columns["disclaimer"]).value
                disclaimer = "" if disclaimer_value is None else str(disclaimer_value).strip()

            missing_date_count = None
            if "missing_date_count" in columns:
                missing_date_count = integer_or_none(
                    sheet.cell(row_number, columns["missing_date_count"]).value
                )

            records.append(
                ExcelManagerRecord(
                    manager_name=manager_name,
                    scheme_count=scheme_count,
                    disclaimer=disclaimer,
                    missing_date_count=missing_date_count,
                    excel_row=row_number,
                )
            )

        if not records:
            raise ValueError("No fund-manager records were found in the worksheet.")

        return records
    finally:
        workbook.close()


def excel_sheet_names(excel_path: str) -> list[str]:
    workbook = load_workbook(excel_path, read_only=True, data_only=True)
    try:
        return list(workbook.sheetnames)
    finally:
        workbook.close()


# -----------------------------------------------------------------------------
# PowerPoint shape helpers
# -----------------------------------------------------------------------------

def find_shape_in_group(group_shape, object_name: str):
    target = object_name.strip().casefold()
    for child in group_shape.shapes:
        if child.name.strip().casefold() == target:
            return child
        if child.shape_type == MSO_SHAPE_TYPE.GROUP:
            result = find_shape_in_group(child, object_name)
            if result is not None:
                return result
    return None


def find_shape(slide, object_name: str):
    """Find the named object, preferring an object that contains editable text."""
    target = object_name.strip().casefold()
    fallback = None

    for shape in slide.shapes:
        if shape.name.strip().casefold() == target:
            if shape_contains_text(shape):
                return shape
            fallback = shape

        if shape.shape_type == MSO_SHAPE_TYPE.GROUP:
            result = find_shape_in_group(shape, object_name)
            if result is not None:
                if shape_contains_text(result):
                    return result
                fallback = result

    return fallback


# -----------------------------------------------------------------------------
# Text-container helpers
# -----------------------------------------------------------------------------

def iter_text_paragraphs(shape):
    """
    Yield paragraphs from text boxes, placeholders, grouped shapes, or tables.

    PowerPoint tables are GraphicFrame objects. GraphicFrame has no text_frame,
    which caused the previous AttributeError. For a table, text is stored in
    each cell's text_frame, so this function safely visits every table cell.
    """
    if shape is None:
        return

    if getattr(shape, "has_text_frame", False):
        for paragraph in shape.text_frame.paragraphs:
            yield paragraph
        return

    if getattr(shape, "has_table", False):
        for row in shape.table.rows:
            for cell in row.cells:
                for paragraph in cell.text_frame.paragraphs:
                    yield paragraph
        return

    if getattr(shape, "shape_type", None) == MSO_SHAPE_TYPE.GROUP:
        for child in shape.shapes:
            yield from iter_text_paragraphs(child)


def shape_contains_text(shape) -> bool:
    if shape is None:
        return False
    if getattr(shape, "has_text_frame", False):
        return True
    if getattr(shape, "has_table", False):
        return True
    if getattr(shape, "shape_type", None) == MSO_SHAPE_TYPE.GROUP:
        return any(shape_contains_text(child) for child in shape.shapes)
    return False


def shape_text(shape) -> str:
    paragraphs = [paragraph.text for paragraph in iter_text_paragraphs(shape)]
    return "\n".join(paragraphs)


# -----------------------------------------------------------------------------
# Formatting-preserving PowerPoint replacement
# -----------------------------------------------------------------------------

def copy_run_format(source_run, target_run) -> None:
    """Copy explicit run formatting when a new run has to be created."""
    source_font = source_run.font
    target_font = target_run.font

    for attribute in ("name", "size", "bold", "italic", "underline"):
        value = getattr(source_font, attribute, None)
        if value is not None:
            setattr(target_font, attribute, value)

    try:
        if source_font.color.rgb is not None:
            target_font.color.rgb = source_font.color.rgb
    except (AttributeError, TypeError, ValueError):
        pass

    # Preserve hyperlink where python-pptx exposes it.
    try:
        address = source_run.hyperlink.address
        if address:
            target_run.hyperlink.address = address
    except (AttributeError, TypeError, ValueError):
        pass


def paragraph_run_ranges(paragraph) -> list[tuple[object, int, int]]:
    ranges = []
    position = 0
    for run in paragraph.runs:
        start = position
        end = start + len(run.text)
        ranges.append((run, start, end))
        position = end
    return ranges


def replace_text_in_paragraph_preserve_format(
    paragraph,
    start: int,
    end: int,
    replacement: str,
) -> bool:
    """
    Replace a paragraph character range without rebuilding the paragraph.

    Unaffected runs remain untouched. Replacement text inherits the formatting
    of the first affected run, so bold text stays bold and regular text stays
    regular.
    """
    ranges = paragraph_run_ranges(paragraph)
    if not ranges:
        run = paragraph.add_run()
        run.text = replacement
        return True

    first_index = None
    last_index = None

    # Insertion at end or at a run boundary inherits the preceding run.
    for index, (_run, run_start, run_end) in enumerate(ranges):
        if run_start <= start < run_end or start == run_end:
            first_index = index
        if end > start and run_start < end <= run_end:
            last_index = index
            break

    if first_index is None:
        first_index = len(ranges) - 1
    if last_index is None:
        last_index = first_index

    first_run, first_start, _first_end = ranges[first_index]
    last_run, last_start, last_end = ranges[last_index]

    before_index = max(0, min(len(first_run.text), start - first_start))
    after_count = max(0, min(len(last_run.text), last_end - end))
    before = first_run.text[:before_index]
    after = last_run.text[len(last_run.text) - after_count:] if after_count else ""

    first_run.text = before + replacement

    if first_index == last_index:
        first_run.text += after
    else:
        for index in range(first_index + 1, last_index):
            ranges[index][0].text = ""
        last_run.text = after

    return True


def replace_first_match_preserve_format(shape, pattern: re.Pattern, replacement) -> bool:
    """Find the first regex match within one paragraph and update only that range."""
    for paragraph in iter_text_paragraphs(shape):
        text = paragraph.text
        match = pattern.search(text)
        if match is None:
            continue

        new_text = replacement(match) if callable(replacement) else replacement
        replace_text_in_paragraph_preserve_format(
            paragraph,
            match.start(),
            match.end(),
            new_text,
        )
        return True
    return False


def replace_entire_paragraph_preserve_format(paragraph, replacement: str) -> None:
    """Replace a whole paragraph while inheriting its original first-run style."""
    ranges = paragraph_run_ranges(paragraph)
    if not ranges:
        paragraph.add_run().text = replacement
        return

    first_run = ranges[0][0]
    first_run.text = replacement
    for run, _start, _end in ranges[1:]:
        run.text = ""


# -----------------------------------------------------------------------------
# Scheme-count and disclaimer update logic
# -----------------------------------------------------------------------------

def update_scheme_count_in_shape(shape, record: ExcelManagerRecord) -> bool:
    if record.scheme_count is None:
        return False

    escaped_name = re.escape(record.manager_name.strip())
    pattern = re.compile(
        rf"({escaped_name}\s+is\s+managing\s+the\s+scheme\s+since\s+"
        rf".*?\s+and\s+(?:he|she|they)\s+(?:manages|manage)\s+)"
        rf"\d+"
        rf"(\s+schemes?\s+of\s+Axis\s+Mutual\s+Fund)",
        re.IGNORECASE,
    )

    scheme_word = "scheme" if record.scheme_count == 1 else "schemes"

    def replacement(match: re.Match) -> str:
        ending = re.sub(
            r"\bschemes?\b",
            scheme_word,
            match.group(2),
            count=1,
            flags=re.IGNORECASE,
        )
        return f"{match.group(1)}{record.scheme_count}{ending}"

    return replace_first_match_preserve_format(shape, pattern, replacement)


def manager_paragraph_pattern(manager_name: str) -> re.Pattern:
    # Manager disclaimers in the screenshot begin with:
    # "Aditya Pagaria is Managing ..."
    return re.compile(
        rf"^\s*{re.escape(manager_name.strip())}\s+is\s+managing\b",
        re.IGNORECASE,
    )


def replace_manager_disclaimer_in_shape(shape, record: ExcelManagerRecord) -> bool:
    """
    Replace the paragraph belonging to a manager in ManagerNoteandDate.

    A disclaimer is replaced only when the paragraph starts with the same
    manager name followed by 'is Managing'. Other disclaimer paragraphs,
    hyperlinks, bold text, dates and legal text remain unchanged.
    """
    if not record.disclaimer.strip():
        return False

    pattern = manager_paragraph_pattern(record.manager_name)
    for paragraph in iter_text_paragraphs(shape):
        if pattern.search(clean_ligatures(paragraph.text)):
            replace_entire_paragraph_preserve_format(paragraph, record.disclaimer.strip())
            return True
    return False


# -----------------------------------------------------------------------------
# PyQt6 user interface
# -----------------------------------------------------------------------------

class FundManagerExcelWindow(QMainWindow):
    def __init__(self):
        super().__init__()
        self.records: list[ExcelManagerRecord] = []
        self.setWindowTitle("Fund Manager Excel to PowerPoint Updater")
        self.resize(1360, 780)
        self.build_ui()

    def build_ui(self) -> None:
        root = QWidget()
        self.setCentralWidget(root)
        main_layout = QVBoxLayout(root)

        files_group = QGroupBox("Input and output files")
        files_form = QFormLayout(files_group)

        ppt_row = QHBoxLayout()
        self.ppt_input_edit = QLineEdit()
        self.ppt_input_edit.setReadOnly(True)
        ppt_button = QPushButton("Browse input PPTX")
        ppt_button.clicked.connect(self.choose_ppt)
        ppt_row.addWidget(self.ppt_input_edit)
        ppt_row.addWidget(ppt_button)

        excel_row = QHBoxLayout()
        self.excel_input_edit = QLineEdit()
        self.excel_input_edit.setReadOnly(True)
        excel_button = QPushButton("Browse Excel")
        excel_button.clicked.connect(self.choose_excel)
        excel_row.addWidget(self.excel_input_edit)
        excel_row.addWidget(excel_button)

        sheet_row = QHBoxLayout()
        self.sheet_combo = QComboBox()
        self.sheet_combo.currentTextChanged.connect(self.load_excel_preview)
        reload_button = QPushButton("Reload Excel data")
        reload_button.clicked.connect(self.load_excel_preview)
        sheet_row.addWidget(self.sheet_combo)
        sheet_row.addWidget(reload_button)

        output_row = QHBoxLayout()
        self.output_edit = QLineEdit()
        output_button = QPushButton("Browse output PPTX")
        output_button.clicked.connect(self.choose_output)
        output_row.addWidget(self.output_edit)
        output_row.addWidget(output_button)

        files_form.addRow("Input PowerPoint:", ppt_row)
        files_form.addRow("Excel file:", excel_row)
        files_form.addRow("Excel worksheet:", sheet_row)
        files_form.addRow("Output PowerPoint:", output_row)
        main_layout.addWidget(files_group)

        actions_group = QGroupBox("Updates to apply")
        actions_layout = QVBoxLayout(actions_group)
        self.count_checkbox = QCheckBox(
            f"Update scheme counts in '{FUND_MANAGER_SCHEME_NOTE_OBJECT}' from Excel"
        )
        self.disclaimer_checkbox = QCheckBox(
            f"Replace manager disclaimers in '{MANAGER_NOTE_AND_DATE_OBJECT}' from Excel"
        )
        self.count_checkbox.setChecked(True)
        self.disclaimer_checkbox.setChecked(True)
        actions_layout.addWidget(self.count_checkbox)
        actions_layout.addWidget(self.disclaimer_checkbox)
        main_layout.addWidget(actions_group)

        help_label = QLabel(
            "Expected Excel headers: Fund Manager, Scheme Count, Disclaimer, and optionally "
            "Missing Date Count. The program detects the columns automatically. Scheme-count "
            "updates do not require FundName. Disclaimer replacement occurs only when the same "
            "manager paragraph already exists in ManagerNoteandDate. Existing PowerPoint bold, "
            "regular, italic, font, colour and hyperlink formatting is preserved."
        )
        help_label.setWordWrap(True)
        main_layout.addWidget(help_label)

        self.preview_table = QTableWidget(0, 5)
        self.preview_table.setHorizontalHeaderLabels(
            ["Excel row", "Fund Manager", "Scheme Count", "Disclaimer", "Missing Date Count"]
        )
        header = self.preview_table.horizontalHeader()
        header.setSectionResizeMode(0, QHeaderView.ResizeMode.ResizeToContents)
        header.setSectionResizeMode(1, QHeaderView.ResizeMode.ResizeToContents)
        header.setSectionResizeMode(2, QHeaderView.ResizeMode.ResizeToContents)
        header.setSectionResizeMode(3, QHeaderView.ResizeMode.Stretch)
        header.setSectionResizeMode(4, QHeaderView.ResizeMode.ResizeToContents)
        self.preview_table.verticalHeader().setVisible(False)
        self.preview_table.setWordWrap(True)
        main_layout.addWidget(self.preview_table)

        self.progress = QProgressBar()
        self.status_label = QLabel("Select the PowerPoint and Excel files.")
        self.status_label.setWordWrap(True)
        main_layout.addWidget(self.progress)
        main_layout.addWidget(self.status_label)

        update_row = QHBoxLayout()
        update_row.addStretch()
        update_button = QPushButton("Update PowerPoint from Excel")
        update_button.setMinimumSize(260, 44)
        update_button.clicked.connect(self.update_powerpoint)
        update_row.addWidget(update_button)
        main_layout.addLayout(update_row)

    def choose_ppt(self) -> None:
        path, _ = QFileDialog.getOpenFileName(
            self,
            "Select input PowerPoint",
            "",
            "PowerPoint Presentation (*.pptx)",
        )
        if not path:
            return
        self.ppt_input_edit.setText(path)
        base, extension = os.path.splitext(path)
        self.output_edit.setText(f"{base}_excel_updated{extension}")

    def choose_excel(self) -> None:
        path, _ = QFileDialog.getOpenFileName(
            self,
            "Select Excel file",
            "",
            "Excel Workbook (*.xlsx *.xlsm)",
        )
        if not path:
            return

        self.excel_input_edit.setText(path)
        try:
            names = excel_sheet_names(path)
        except Exception as error:
            QMessageBox.critical(self, "Excel error", f"Could not read the workbook:\n{error}")
            return

        self.sheet_combo.blockSignals(True)
        self.sheet_combo.clear()
        self.sheet_combo.addItems(names)
        if DEFAULT_EXCEL_SHEET in names:
            self.sheet_combo.setCurrentText(DEFAULT_EXCEL_SHEET)
        self.sheet_combo.blockSignals(False)
        self.load_excel_preview()

    def choose_output(self) -> None:
        path, _ = QFileDialog.getSaveFileName(
            self,
            "Save updated PowerPoint",
            self.output_edit.text().strip(),
            "PowerPoint Presentation (*.pptx)",
        )
        if path:
            if not path.lower().endswith(".pptx"):
                path += ".pptx"
            self.output_edit.setText(path)

    def load_excel_preview(self) -> None:
        excel_path = self.excel_input_edit.text().strip()
        sheet_name = self.sheet_combo.currentText().strip()
        if not excel_path or not sheet_name:
            return

        try:
            self.records = read_excel_records(excel_path, sheet_name)
        except Exception as error:
            self.records = []
            self.preview_table.setRowCount(0)
            self.status_label.setText("Excel data could not be loaded.")
            QMessageBox.warning(self, "Excel data error", str(error))
            return

        self.preview_table.setRowCount(len(self.records))
        for row_index, record in enumerate(self.records):
            values = [
                record.excel_row,
                record.manager_name,
                "" if record.scheme_count is None else record.scheme_count,
                record.disclaimer,
                "" if record.missing_date_count is None else record.missing_date_count,
            ]
            for column_index, value in enumerate(values):
                item = QTableWidgetItem(str(value))
                item.setFlags(item.flags() & ~Qt.ItemFlag.ItemIsEditable)
                self.preview_table.setItem(row_index, column_index, item)

        self.preview_table.resizeRowsToContents()
        self.status_label.setText(
            f"Loaded {len(self.records)} manager record(s) from worksheet '{sheet_name}'."
        )

    def validate_inputs(self) -> Optional[tuple[str, str]]:
        ppt_path = self.ppt_input_edit.text().strip()
        excel_path = self.excel_input_edit.text().strip()
        output_path = self.output_edit.text().strip()

        if not ppt_path or not os.path.isfile(ppt_path):
            QMessageBox.warning(self, "Input required", "Select a valid input PowerPoint file.")
            return None
        if not excel_path or not os.path.isfile(excel_path):
            QMessageBox.warning(self, "Excel required", "Select a valid Excel workbook.")
            return None
        if not output_path:
            QMessageBox.warning(self, "Output required", "Select an output PowerPoint file.")
            return None
        if not output_path.lower().endswith(".pptx"):
            output_path += ".pptx"
            self.output_edit.setText(output_path)
        if os.path.abspath(ppt_path) == os.path.abspath(output_path):
            QMessageBox.warning(
                self,
                "Different output required",
                "Use a different output filename so the original PowerPoint is not overwritten.",
            )
            return None
        if not self.count_checkbox.isChecked() and not self.disclaimer_checkbox.isChecked():
            QMessageBox.warning(self, "No update selected", "Select at least one update option.")
            return None

        if not self.records:
            self.load_excel_preview()
            if not self.records:
                return None

        return ppt_path, output_path

    def update_powerpoint(self) -> None:
        paths = self.validate_inputs()
        if paths is None:
            return
        ppt_path, output_path = paths

        try:
            presentation = Presentation(ppt_path)
        except Exception as error:
            QMessageBox.critical(self, "PowerPoint error", f"Could not open PowerPoint:\n{error}")
            return

        count_updates: list[str] = []
        disclaimer_updates: list[str] = []
        missing_count_managers: list[str] = []
        missing_disclaimer_managers: list[str] = []
        slides_changed: set[int] = set()
        total_slides = len(presentation.slides)

        for slide_number, slide in enumerate(presentation.slides, start=1):
            self.progress.setValue(int(slide_number / max(total_slides, 1) * 90))
            self.status_label.setText(
                f"Processing slide {slide_number} of {total_slides}..."
            )
            QApplication.processEvents()

            scheme_shape = (
                find_shape(slide, FUND_MANAGER_SCHEME_NOTE_OBJECT)
                if self.count_checkbox.isChecked()
                else None
            )
            disclaimer_shape = (
                find_shape(slide, MANAGER_NOTE_AND_DATE_OBJECT)
                if self.disclaimer_checkbox.isChecked()
                else None
            )

            # A named GraphicFrame may be a chart or another non-text object.
            # Only process objects that expose text directly or through table cells.
            if scheme_shape is not None and not shape_contains_text(scheme_shape):
                scheme_shape = None
            if disclaimer_shape is not None and not shape_contains_text(disclaimer_shape):
                disclaimer_shape = None

            slide_changed = False
            for record in self.records:
                if scheme_shape is not None and record.scheme_count is not None:
                    if update_scheme_count_in_shape(scheme_shape, record):
                        count_updates.append(
                            f"Slide {slide_number}: {record.manager_name} -> {record.scheme_count}"
                        )
                        slide_changed = True

                if disclaimer_shape is not None and record.disclaimer.strip():
                    if replace_manager_disclaimer_in_shape(disclaimer_shape, record):
                        disclaimer_updates.append(
                            f"Slide {slide_number}: {record.manager_name}"
                        )
                        slide_changed = True

            if slide_changed:
                slides_changed.add(slide_number)

        # Produce a manager-level not-found summary only if the requested data
        # did not match anywhere in the presentation.
        updated_count_names = {
            normalize(item.split(": ", 1)[1].split(" -> ", 1)[0])
            for item in count_updates
        }
        updated_disclaimer_names = {
            normalize(item.split(": ", 1)[1])
            for item in disclaimer_updates
        }

        if self.count_checkbox.isChecked():
            missing_count_managers = [
                record.manager_name
                for record in self.records
                if record.scheme_count is not None
                and normalize(record.manager_name) not in updated_count_names
            ]

        if self.disclaimer_checkbox.isChecked():
            missing_disclaimer_managers = [
                record.manager_name
                for record in self.records
                if record.disclaimer.strip()
                and normalize(record.manager_name) not in updated_disclaimer_names
            ]

        if not slides_changed:
            self.progress.setValue(0)
            QMessageBox.warning(
                self,
                "Nothing updated",
                "No Excel manager record matched the PowerPoint text.\n\n"
                f"Check the object names '{FUND_MANAGER_SCHEME_NOTE_OBJECT}' and "
                f"'{MANAGER_NOTE_AND_DATE_OBJECT}', and confirm the manager names match.",
            )
            return

        try:
            os.makedirs(os.path.dirname(os.path.abspath(output_path)), exist_ok=True)
            presentation.save(output_path)
        except Exception as error:
            QMessageBox.critical(self, "Save error", f"Could not save PowerPoint:\n{error}")
            return

        self.progress.setValue(100)
        self.status_label.setText(
            f"Completed. Updated {len(slides_changed)} slide(s)."
        )

        result = [
            f"Saved successfully:\n{output_path}",
            "",
            f"Slides changed: {', '.join(map(str, sorted(slides_changed)))}",
            f"Scheme-count replacements: {len(count_updates)}",
            f"Manager-disclaimer replacements: {len(disclaimer_updates)}",
        ]
        if missing_count_managers:
            result.extend([
                "",
                "Scheme-count managers not found anywhere:",
                ", ".join(missing_count_managers),
            ])
        if missing_disclaimer_managers:
            result.extend([
                "",
                "Disclaimer managers not found anywhere:",
                ", ".join(missing_disclaimer_managers),
            ])

        QMessageBox.information(self, "Update completed", "\n".join(result))


def main() -> None:
    app = QApplication(sys.argv)
    app.setApplicationName("Fund Manager Excel to PowerPoint Updater")
    window = FundManagerExcelWindow()
    window.show()
    sys.exit(app.exec())


if __name__ == "__main__":
    main()
