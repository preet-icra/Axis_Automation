import sys
import re
from pathlib import Path
from collections import defaultdict

import pandas as pd
from openpyxl import load_workbook
from openpyxl.styles import Font, PatternFill, Border, Side, Alignment
from openpyxl.utils import get_column_letter
from PyQt6.QtCore import Qt, QThread, pyqtSignal
from PyQt6.QtWidgets import (
    QApplication, QMainWindow, QWidget, QVBoxLayout, QHBoxLayout,
    QLabel, QLineEdit, QPushButton, QFileDialog, QMessageBox,
    QProgressBar, QPlainTextEdit, QGroupBox
)


MANAGER_PATTERN = re.compile(r"fund\s*manager", re.IGNORECASE)
SCHEME_CODE_PATTERN = re.compile(r"scheme\s*code", re.IGNORECASE)
SCHEME_NAME_PATTERN = re.compile(r"(name\s*of\s*scheme|scheme\s*name)", re.IGNORECASE)


def clean_text(value):
    if pd.isna(value):
        return ""
    return " ".join(str(value).strip().split())


def normalized(value):
    return clean_text(value).casefold()


def read_sheet_raw(path, sheet_name):
    return pd.read_excel(path, sheet_name=sheet_name, header=None, dtype=object, engine="openpyxl")


def detect_source(path):
    """Prefer a detailed scheme sheet; fall back to a manager/count summary sheet."""
    excel = pd.ExcelFile(path, engine="openpyxl")
    best = None

    for sheet in excel.sheet_names:
        raw = read_sheet_raw(path, sheet)
        for header_row in range(min(15, len(raw))):
            headers = [clean_text(v) for v in raw.iloc[header_row].tolist()]
            manager_cols = [i for i, h in enumerate(headers) if MANAGER_PATTERN.search(h)]
            scheme_code_cols = [i for i, h in enumerate(headers) if SCHEME_CODE_PATTERN.search(h)]
            scheme_name_cols = [i for i, h in enumerate(headers) if SCHEME_NAME_PATTERN.search(h)]

            # Detailed sheet, such as "Scheme List" in the supplied workbooks.
            if manager_cols and (scheme_code_cols or scheme_name_cols):
                score = 100 + len(manager_cols)
                candidate = (score, "detail", sheet, header_row, headers,
                             manager_cols, scheme_code_cols, scheme_name_cols)
                if best is None or candidate[0] > best[0]:
                    best = candidate

            # Summary sheet, such as Fund Manager / Schemes.
            if len(manager_cols) == 1:
                count_cols = [i for i, h in enumerate(headers)
                              if normalized(h) in {"schemes", "scheme count", "count"}]
                if count_cols:
                    candidate = (10, "summary", sheet, header_row, headers,
                                 manager_cols, count_cols, [])
                    if best is None or candidate[0] > best[0]:
                        best = candidate

    if best is None:
        raise ValueError(
            f"Could not detect a detailed scheme sheet or a Fund Manager/Schemes summary in: {path}"
        )
    return best


def extract_file(path):
    detected = detect_source(path)
    _, kind, sheet, header_row, headers, manager_cols, aux_cols, scheme_name_cols = detected
    raw = read_sheet_raw(path, sheet)
    data = raw.iloc[header_row + 1:].reset_index(drop=True)

    managers = {}  # normalized manager -> display spelling
    manager_schemes = defaultdict(dict)  # manager key -> scheme key -> scheme details

    if kind == "detail":
        scheme_code_col = aux_cols[0] if aux_cols else None
        scheme_name_col = scheme_name_cols[0] if scheme_name_cols else None

        for _, row in data.iterrows():
            code = clean_text(row.iloc[scheme_code_col]) if scheme_code_col is not None else ""
            name = clean_text(row.iloc[scheme_name_col]) if scheme_name_col is not None else ""
            if not code and not name:
                continue
            scheme_key = normalized(code) or normalized(name)
            scheme_display = name or code

            # Using a set prevents duplicate manager names in the same scheme row.
            row_managers = {}
            for col in manager_cols:
                manager = clean_text(row.iloc[col])
                if manager:
                    row_managers[normalized(manager)] = manager

            for mkey, manager in row_managers.items():
                managers.setdefault(mkey, manager)
                manager_schemes[mkey][scheme_key] = {
                    "scheme_code": code,
                    "scheme_name": scheme_display,
                }

        counts = {mkey: len(schemes) for mkey, schemes in manager_schemes.items()}
    else:
        count_col = aux_cols[0]
        counts = {}
        for _, row in data.iterrows():
            manager = clean_text(row.iloc[manager_cols[0]])
            if not manager:
                continue
            mkey = normalized(manager)
            managers.setdefault(mkey, manager)
            value = pd.to_numeric(row.iloc[count_col], errors="coerce")
            counts[mkey] = int(value) if pd.notna(value) else 0

    return {
        "path": str(path), "sheet": sheet, "kind": kind,
        "managers": managers, "counts": counts,
        "manager_schemes": manager_schemes,
    }


def compare_files(old_path, new_path):
    old = extract_file(old_path)
    new = extract_file(new_path)

    all_keys = sorted(set(old["managers"]) | set(new["managers"]),
                      key=lambda k: (new["managers"].get(k) or old["managers"].get(k)).casefold())

    summary_rows = []
    for key in all_keys:
        name = new["managers"].get(key) or old["managers"].get(key)
        old_count = old["counts"].get(key, 0)
        new_count = new["counts"].get(key, 0)
        if key not in old["managers"]:
            status = "Added Fund Manager"
        elif key not in new["managers"]:
            status = "Deleted Fund Manager"
        elif new_count != old_count:
            status = "Scheme Count Changed"
        else:
            status = "No Change"
        summary_rows.append({
            "Fund Manager": name,
            "Status": status,
            "Old Scheme Count": old_count,
            "New Scheme Count": new_count,
            "Count Change": new_count - old_count,
        })

    scheme_rows = []
    if old["kind"] == "detail" and new["kind"] == "detail":
        for key in all_keys:
            name = new["managers"].get(key) or old["managers"].get(key)
            old_schemes = old["manager_schemes"].get(key, {})
            new_schemes = new["manager_schemes"].get(key, {})

            for skey in sorted(set(new_schemes) - set(old_schemes)):
                item = new_schemes[skey]
                scheme_rows.append({
                    "Fund Manager": name, "Change": "Scheme Added",
                    "Scheme Code": item["scheme_code"], "Scheme Name": item["scheme_name"]
                })
            for skey in sorted(set(old_schemes) - set(new_schemes)):
                item = old_schemes[skey]
                scheme_rows.append({
                    "Fund Manager": name, "Change": "Scheme Deleted",
                    "Scheme Code": item["scheme_code"], "Scheme Name": item["scheme_name"]
                })

    summary_df = pd.DataFrame(summary_rows)
    changes_df = summary_df[summary_df["Status"] != "No Change"].copy()
    added_df = summary_df[summary_df["Status"] == "Added Fund Manager"].copy()
    deleted_df = summary_df[summary_df["Status"] == "Deleted Fund Manager"].copy()
    scheme_df = pd.DataFrame(scheme_rows, columns=["Fund Manager", "Change", "Scheme Code", "Scheme Name"])

    return old, new, summary_df, changes_df, added_df, deleted_df, scheme_df


def style_workbook(output_path):
    wb = load_workbook(output_path)
    navy = "1F4E78"
    light_blue = "D9EAF7"
    green = "E2F0D9"
    red = "FCE4D6"
    yellow = "FFF2CC"
    thin = Side(style="thin", color="B7B7B7")

    for ws in wb.worksheets:
        ws.freeze_panes = "A2"
        ws.auto_filter.ref = ws.dimensions
        ws.sheet_view.showGridLines = False
        for cell in ws[1]:
            cell.fill = PatternFill("solid", fgColor=navy)
            cell.font = Font(color="FFFFFF", bold=True)
            cell.alignment = Alignment(horizontal="center", vertical="center")
        for row in ws.iter_rows():
            for cell in row:
                cell.border = Border(bottom=thin)
                cell.alignment = Alignment(vertical="top", wrap_text=True)

        header_map = {cell.value: cell.column for cell in ws[1]}
        status_col = header_map.get("Status")
        change_col = header_map.get("Change")
        for r in range(2, ws.max_row + 1):
            text = ws.cell(r, status_col).value if status_col else ws.cell(r, change_col).value if change_col else ""
            color = None
            if text in ("Added Fund Manager", "Scheme Added"):
                color = green
            elif text in ("Deleted Fund Manager", "Scheme Deleted"):
                color = red
            elif text == "Scheme Count Changed":
                color = yellow
            if color:
                for cell in ws[r]:
                    cell.fill = PatternFill("solid", fgColor=color)

        for col in range(1, ws.max_column + 1):
            max_len = max(len(clean_text(ws.cell(r, col).value)) for r in range(1, ws.max_row + 1))
            ws.column_dimensions[get_column_letter(col)].width = min(max(max_len + 2, 12), 45)
        ws.row_dimensions[1].height = 28

    # Highlight the metadata sheet separately.
    if "Run Info" in wb.sheetnames:
        ws = wb["Run Info"]
        for row in range(2, ws.max_row + 1):
            ws.cell(row, 1).fill = PatternFill("solid", fgColor=light_blue)
            ws.cell(row, 1).font = Font(bold=True)
    wb.save(output_path)


def create_output(old_path, new_path, output_path):
    old, new, summary, changes, added, deleted, scheme_changes = compare_files(old_path, new_path)
    run_info = pd.DataFrame([
        ["Old file", str(old_path)], ["New/client file", str(new_path)],
        ["Old source sheet", old["sheet"]], ["New source sheet", new["sheet"]],
        ["Old source type", old["kind"]], ["New source type", new["kind"]],
        ["Added managers", len(added)], ["Deleted managers", len(deleted)],
        ["Managers with count changes", int((summary["Status"] == "Scheme Count Changed").sum())],
        ["Scheme assignment changes", len(scheme_changes)],
    ], columns=["Item", "Value"])

    with pd.ExcelWriter(output_path, engine="openpyxl") as writer:
        run_info.to_excel(writer, sheet_name="Run Info", index=False)
        changes.to_excel(writer, sheet_name="Manager Changes", index=False)
        added.to_excel(writer, sheet_name="Added Managers", index=False)
        deleted.to_excel(writer, sheet_name="Deleted Managers", index=False)
        scheme_changes.to_excel(writer, sheet_name="Scheme Changes", index=False)
        summary.to_excel(writer, sheet_name="All Managers", index=False)
    style_workbook(output_path)
    return len(added), len(deleted), len(changes), len(scheme_changes)


class CompareWorker(QThread):
    finished_ok = pyqtSignal(str, int, int, int, int)
    failed = pyqtSignal(str)

    def __init__(self, old_path, new_path, output_path):
        super().__init__()
        self.old_path = old_path
        self.new_path = new_path
        self.output_path = output_path

    def run(self):
        try:
            result = create_output(self.old_path, self.new_path, self.output_path)
            self.finished_ok.emit(self.output_path, *result)
        except Exception as exc:
            self.failed.emit(f"{type(exc).__name__}: {exc}")


class MainWindow(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("Fund Manager Scheme Comparison")
        self.resize(820, 520)
        self.worker = None

        root = QWidget()
        self.setCentralWidget(root)
        layout = QVBoxLayout(root)

        title = QLabel("Compare old and new/client fund manager files")
        title.setStyleSheet("font-size: 20px; font-weight: 600;")
        layout.addWidget(title)
        layout.addWidget(QLabel(
            "The program detects the Scheme List columns, compares manager additions/deletions, "
            "scheme counts, and manager-to-scheme assignment changes."
        ))

        group = QGroupBox("Excel files")
        form = QVBoxLayout(group)
        self.old_edit = self.add_file_row(form, "Old file:", self.choose_old)
        self.new_edit = self.add_file_row(form, "New/client file:", self.choose_new)
        self.output_edit = self.add_file_row(form, "Output file:", self.choose_output, save=True)
        layout.addWidget(group)

        self.compare_button = QPushButton("Compare and create Excel report")
        self.compare_button.setMinimumHeight(42)
        self.compare_button.clicked.connect(self.start_comparison)
        layout.addWidget(self.compare_button)

        self.progress = QProgressBar()
        self.progress.setRange(0, 1)
        self.progress.setValue(0)
        layout.addWidget(self.progress)

        self.log = QPlainTextEdit()
        self.log.setReadOnly(True)
        self.log.setPlaceholderText("Status and result details will appear here.")
        layout.addWidget(self.log)

    def add_file_row(self, parent, label_text, callback, save=False):
        row = QHBoxLayout()
        label = QLabel(label_text)
        label.setMinimumWidth(115)
        edit = QLineEdit()
        button = QPushButton("Save as..." if save else "Browse...")
        button.clicked.connect(callback)
        row.addWidget(label)
        row.addWidget(edit, 1)
        row.addWidget(button)
        parent.addLayout(row)
        return edit

    def choose_old(self):
        path, _ = QFileDialog.getOpenFileName(self, "Select old Excel file", "", "Excel files (*.xlsx *.xlsm)")
        if path:
            self.old_edit.setText(path)
            self.suggest_output()

    def choose_new(self):
        path, _ = QFileDialog.getOpenFileName(self, "Select new/client Excel file", "", "Excel files (*.xlsx *.xlsm)")
        if path:
            self.new_edit.setText(path)
            self.suggest_output()

    def choose_output(self):
        start = self.output_edit.text() or "Fund_Manager_Comparison_Output.xlsx"
        path, _ = QFileDialog.getSaveFileName(self, "Save comparison report", start, "Excel workbook (*.xlsx)")
        if path:
            if not path.lower().endswith(".xlsx"):
                path += ".xlsx"
            self.output_edit.setText(path)

    def suggest_output(self):
        new_path = self.new_edit.text().strip()
        if new_path and not self.output_edit.text().strip():
            p = Path(new_path)
            self.output_edit.setText(str(p.with_name("Fund_Manager_Comparison_Output.xlsx")))

    def start_comparison(self):
        old_path = self.old_edit.text().strip()
        new_path = self.new_edit.text().strip()
        output_path = self.output_edit.text().strip()
        if not old_path or not new_path or not output_path:
            QMessageBox.warning(self, "Missing files", "Select the old file, new/client file, and output location.")
            return
        if Path(old_path).resolve() == Path(new_path).resolve():
            QMessageBox.warning(self, "Invalid selection", "Old and new files must be different.")
            return
        if not Path(old_path).is_file() or not Path(new_path).is_file():
            QMessageBox.warning(self, "File not found", "One or both input files do not exist.")
            return
        if not output_path.lower().endswith(".xlsx"):
            output_path += ".xlsx"
            self.output_edit.setText(output_path)

        self.compare_button.setEnabled(False)
        self.progress.setRange(0, 0)
        self.log.setPlainText("Reading workbooks and comparing fund managers and schemes...")
        self.worker = CompareWorker(old_path, new_path, output_path)
        self.worker.finished_ok.connect(self.done)
        self.worker.failed.connect(self.failed)
        self.worker.start()

    def done(self, path, added, deleted, manager_changes, scheme_changes):
        self.progress.setRange(0, 1)
        self.progress.setValue(1)
        self.compare_button.setEnabled(True)
        message = (
            f"Report created: {path}\n\n"
            f"Added fund managers: {added}\nDeleted fund managers: {deleted}\n"
            f"Manager rows changed: {manager_changes}\nScheme assignment changes: {scheme_changes}"
        )
        self.log.setPlainText(message)
        QMessageBox.information(self, "Comparison complete", message)

    def failed(self, error):
        self.progress.setRange(0, 1)
        self.progress.setValue(0)
        self.compare_button.setEnabled(True)
        self.log.setPlainText(error)
        QMessageBox.critical(self, "Comparison failed", error)


def main():
    app = QApplication(sys.argv)
    app.setStyle("Fusion")
    window = MainWindow()
    window.show()
    sys.exit(app.exec())


if __name__ == "__main__":
    main()
