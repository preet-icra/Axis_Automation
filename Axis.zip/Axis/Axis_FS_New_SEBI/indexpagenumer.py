#!/usr/bin/env python3
import re, sys, traceback
from copy import deepcopy
from dataclasses import dataclass
from datetime import datetime
from pathlib import Path
from typing import List
from PyQt6.QtCore import QThread, pyqtSignal
from PyQt6.QtWidgets import QApplication,QFileDialog,QGridLayout,QGroupBox,QLabel,QLineEdit,QMainWindow,QMessageBox,QPushButton,QPlainTextEdit,QVBoxLayout,QWidget
from pptx import Presentation

FUND_SHAPE = "Object 37"
FOOTER_RE = re.compile(r"AutoCategoryPageNumber_\d+", re.I)
CATS = {"Equity":("EquityTable","equity"), "Debt":("DebtTable","debt"), "Hybrid":("HybridTable","hybrid")}

def clean(s):
    """Normalize hidden PowerPoint whitespace and line-break characters."""
    s = (s or "").replace("\v", " ").replace("\xa0", " ")
    s = s.replace("\u200b", "").replace("\u200c", "").replace("\u200d", "")
    return " ".join(s.split()).strip()

def remove_dots(s):
    """Remove a trailing dotted leader, whether separated by spaces or runs."""
    return re.sub(r"[\s.·•…]+$", "", s or "").strip()

def expand_fof(s):
    """Standard visible wording for every Fund-of-Fund spelling."""
    s = re.sub(r"\bfof\b", "Fund Of Fund", s or "", flags=re.I)
    s = re.sub(r"\bfund\s+of\s+funds?\b", "Fund Of Fund", s, flags=re.I)
    return s

def short_name(s):
    """Return only the actual fund name used for display and matching."""
    s = clean(s)
    # Stop before the literal dotted leader even if extra text follows it.
    s = re.split(r"\.{3,}|…{2,}", s, maxsplit=1)[0]
    s = remove_dots(s)
    s = re.sub(r"\s*\([^()]*\)\s*$", "", s).strip()
    return expand_fof(s)

def norm(s):
    """Canonical identity key used everywhere, including final duplicate cleanup."""
    s = short_name(s).casefold().replace("&", "and")
    s = re.sub(r"\bfund\s+of\s+funds?\b", "fof", s)
    # Ignore punctuation, whitespace, invisible characters and capitalization.
    return re.sub(r"[^a-z0-9]+", "", s)

def shape_text(sh):
    parts=[]
    if getattr(sh,"has_text_frame",False): parts.append(sh.text)
    if getattr(sh,"has_table",False):
        for row in sh.table.rows: parts += [c.text for c in row.cells]
    if getattr(sh,"shape_type",None)==6:
        for ch in sh.shapes:
            t=shape_text(ch)
            if t: parts.append(t)
    return clean(" ".join(parts))

def find_name(shapes,name):
    wanted=name.casefold().strip()
    for sh in shapes:
        if (sh.name or "").casefold().strip()==wanted: return sh
        if getattr(sh,"shape_type",None)==6:
            x=find_name(sh.shapes,name)
            if x is not None: return x
    return None

def find_pattern(shapes,pat):
    for sh in shapes:
        if pat.fullmatch((sh.name or "").strip()): return sh
        if getattr(sh,"shape_type",None)==6:
            x=find_pattern(sh.shapes,pat)
            if x is not None: return x
    return None

def find_table(prs,name):
    for no,slide in enumerate(prs.slides,1):
        sh=find_name(slide.shapes,name)
        if sh is not None:
            if not getattr(sh,"has_table",False): raise ValueError(f"'{name}' is not a native table")
            return no,sh.table
    raise ValueError(f"Table '{name}' not found")

def discover(folder,index):
    ppt=[p for p in folder.glob("*.pptx") if not p.name.startswith("~$") and p.resolve()!=index.resolve()]
    result={}
    for cat,(_,word) in CATS.items():
        m=[p for p in ppt if word in p.stem.casefold()]
        if len(m)!=1: raise ValueError(f"Expected one {cat} PPTX; found {len(m)}")
        result[cat]=m[0]
    return result

@dataclass
class Fund:
    name:str; slide:int; page:str; footer:str; slides:List[int]

def read_funds(path,log):
    prs=Presentation(str(path)); order=[]; found={}
    for no,slide in enumerate(prs.slides,1):
        obj=find_name(slide.shapes,FUND_SHAPE)
        if obj is None: continue
        name=short_name(shape_text(obj))
        if not name: continue
        k=norm(name)
        if k in found:
            found[k].slides.append(no)
            continue
        footer=find_pattern(slide.shapes,FOOTER_RE)
        if footer is None: raise ValueError(f"Missing AutoCategoryPageNumber_<n> on slide {no} for '{name}'")
        m=re.search(r"\d+",shape_text(footer).replace(",",""))
        if not m: raise ValueError(f"No number in '{footer.name}' on slide {no}")
        found[k]=Fund(name,no,m.group(),footer.name,[no]); order.append(k)
    funds=[found[k] for k in order]
    if not funds: raise ValueError(f"No funds found in '{path.name}'")
    log(f"  Found {len(funds)} unique funds; grouped {sum(len(f.slides)>1 for f in funds)} repeated slide occurrences.")
    return funds

def header_count(table,cat):
    if len(table.rows)==0:return 0
    vals=[clean(c.text) for c in table.rows[0].cells]; joined=" ".join(vals).casefold()
    if any(x in joined for x in ("fund name","page no","page number","scheme name")):return 1
    non=[v for v in vals if v]
    return 1 if len(non)==1 and cat.casefold() in non[0].casefold() else 0

def get_columns(table,start):
    n=len(table.columns); nums=[]; sizes=[]
    if n<2: raise ValueError("Index table needs at least two columns")
    for c in range(n):
        vals=[clean(table.cell(r,c).text) for r in range(start,len(table.rows))]
        nums.append(sum(bool(re.fullmatch(r"\d+",v)) for v in vals if v)); sizes.append(sum(map(len,vals)))
    pc=max(range(n),key=lambda c:(nums[c],c))
    if nums[pc]==0: pc=n-1
    nc=max((c for c in range(n) if c!=pc),key=lambda c:sizes[c])
    return nc,pc

def set_text_keep_style(cell,value):
    p=cell.text_frame.paragraphs[0]
    if p.runs:
        p.runs[0].text=str(value)
        for run in list(p.runs[1:]): run._r.getparent().remove(run._r)
    else: p.add_run().text=str(value)
    for extra in list(cell.text_frame.paragraphs[1:]): extra._p.getparent().remove(extra._p)

def visible_dot_profile(text):
    text=(text or "").replace("\v","")
    m=re.search(r"(\.{3,})\s*$",text)
    if not m:return None
    prefix=text[:m.start()].rstrip()
    return len(prefix),len(m.group(1))

def template_row(table,at,header,name_col):
    rows=list(range(header,len(table.rows)))
    if not rows: raise ValueError("No data row exists to clone")
    rows.sort(key=lambda r:(abs(r-at),r))
    for r in rows:
        if visible_dot_profile(table.cell(r,name_col).text): return r
    for r in rows:
        xml=table.cell(r,name_col)._tc.xml
        if '<a:tab' in xml or 'leader="dot"' in xml or 'leader="2"' in xml:return r
    return rows[0]

def insert_clone(table,at,template):
    tbl=table._tbl; row=deepcopy(tbl.tr_lst[template])
    if at>=len(tbl.tr_lst):tbl.append(row)
    else:tbl.insert(at,row)

def delete_row(table,row_index):
    """Delete exactly one duplicate table row from the table XML."""
    tbl=table._tbl
    tbl.remove(tbl.tr_lst[row_index])

def set_new_name_with_guaranteed_dots(cell,name,template_text):
    name=short_name(name)
    profile=visible_dot_profile(template_text)
    if profile:
        old_name_len,old_dot_count=profile
        target_total=old_name_len+old_dot_count
    else:
        target_total=110
    dots=max(8,target_total-len(name)-1)
    set_text_keep_style(cell,name+" "+("."*dots))

def table_entries(table,header,name_col):
    result=[]
    for r in range(header,len(table.rows)):
        text=clean(table.cell(r,name_col).text)
        if text: result.append((r,norm(text)))
    return result

def remove_duplicate_rows(table,header,name_col,log,cat):
    """Keep the first row for each canonical name and delete every later copy."""
    first_by_key={}
    duplicate_rows=[]
    for row in range(header,len(table.rows)):
        raw=table.cell(row,name_col).text
        name=short_name(raw)
        if not name:
            continue
        k=norm(name)
        if not k:
            continue
        if k in first_by_key:
            duplicate_rows.append((row,name,first_by_key[k]))
        else:
            first_by_key[k]=row

    # Delete bottom-up so row indexes remain valid.
    for row,name,kept_row in reversed(duplicate_rows):
        delete_row(table,row)
        log(f"  {cat}: removed repeated row {row+1} | {name} | kept row {kept_row+1}")
    return len(duplicate_rows)

def build_row_map(table,header,name_col):
    """Map each canonical fund name to exactly one existing table row."""
    result={}
    for row in range(header,len(table.rows)):
        k=norm(table.cell(row,name_col).text)
        if k and k not in result:
            result[k]=row
    return result

def update_table(prs,cat,funds,log):
    """Rebuild data-row order to exactly match the source category PPT.

    The source order is the order of first fund occurrences in the category PPT.
    Existing matching rows are reused, missing funds are cloned and inserted,
    duplicate/stale index rows are removed, and page values are refreshed.
    """
    table_name=CATS[cat][0]
    slide_no,table=find_table(prs,table_name)
    header=header_count(table,cat)
    nc,pc=get_columns(table,header)
    tbl=table._tbl

    # One source fund per canonical identity, preserving first-occurrence order.
    ordered_funds=[]
    source_seen=set()
    for fund in funds:
        fk=norm(fund.name)
        if not fk:
            continue
        if fk in source_seen:
            log(f"  {cat}: skipped repeated source identity | {fund.name}")
            continue
        source_seen.add(fk)
        ordered_funds.append(fund)

    # Capture all current data rows before changing the XML. Keep only the first
    # row for each canonical fund identity as the reusable formatted row.
    existing_by_key={}
    existing_names={}
    duplicate_count=0
    blank_count=0
    for row_index in range(header,len(table.rows)):
        row_xml=tbl.tr_lst[row_index]
        raw_name=table.cell(row_index,nc).text
        fund_key=norm(raw_name)
        if not fund_key:
            blank_count+=1
            continue
        if fund_key in existing_by_key:
            duplicate_count+=1
            log(f"  {cat}: discarded duplicate existing row | {short_name(raw_name)}")
            continue
        existing_by_key[fund_key]=deepcopy(row_xml)
        existing_names[fund_key]=short_name(raw_name)

    # A clean formatted row is needed for genuinely missing funds. Prefer a row
    # that already has visible dots and is nearest the first data row.
    if len(table.rows)<=header:
        raise ValueError(f"'{table_name}' has no formatted data row to clone.")
    template_index=template_row(table,header,header,nc)
    template_xml=deepcopy(tbl.tr_lst[template_index])
    template_text=table.cell(template_index,nc).text

    # Remove every old data row. Header rows remain untouched. Rows are then
    # appended in exactly the same order as ordered_funds from the source PPT.
    while len(tbl.tr_lst)>header:
        tbl.remove(tbl.tr_lst[-1])

    reused=inserted=0
    for fund in ordered_funds:
        fk=norm(fund.name)
        if fk in existing_by_key:
            tbl.append(deepcopy(existing_by_key[fk]))
            reused+=1
        else:
            tbl.append(deepcopy(template_xml))
            inserted+=1

        row_index=len(tbl.tr_lst)-1
        if fk not in existing_by_key:
            # Clear only this new row, preserving its cloned run formatting.
            for c in range(len(table.columns)):
                if c!=nc:
                    set_text_keep_style(table.cell(row_index,c),"")
            set_new_name_with_guaranteed_dots(
                table.cell(row_index,nc),fund.name,template_text
            )

        # Existing name cell remains unchanged. Only its page value is refreshed.
        set_text_keep_style(table.cell(row_index,pc),fund.page)
        log(
            f"  {cat}: order {row_index-header+1} | {short_name(fund.name)} "
            f"-> page {fund.page}"
        )

    stale_keys=[k for k in existing_by_key if k not in source_seen]
    for k in stale_keys:
        log(f"  {cat}: removed index-only row not present in source PPT | {existing_names[k]}")

    # Final strict verification. The saved table must have the same canonical
    # sequence as the source PPT and must contain each fund exactly once.
    actual=[]
    for row_index in range(header,len(table.rows)):
        k=norm(table.cell(row_index,nc).text)
        if k:
            actual.append(k)
    expected=[norm(f.name) for f in ordered_funds]
    if actual!=expected:
        raise ValueError(
            f"Order verification failed in '{table_name}'. "
            f"Expected {len(expected)} source funds, found {len(actual)} table funds."
        )
    if len(actual)!=len(set(actual)):
        raise ValueError(f"Duplicate verification failed in '{table_name}'.")

    log(
        f"{cat}: {table_name} on slide {slide_no}: source order applied to "
        f"{len(ordered_funds)} funds; reused {reused}, inserted {inserted}, "
        f"removed duplicates {duplicate_count}, removed stale {len(stale_keys)}."
    )


class Worker(QThread):
    progress=pyqtSignal(str);completed=pyqtSignal(str);failed=pyqtSignal(str)
    def __init__(self,index,folder,output):super().__init__();self.index=Path(index);self.folder=Path(folder);self.output=Path(output)
    def run(self):
        try:
            fs=discover(self.folder,self.index);data={}
            for cat,p in fs.items():self.progress.emit(f"Reading {cat}: {p.name}");data[cat]=read_funds(p,self.progress.emit)
            prs=Presentation(str(self.index));self.progress.emit(f"Opening index: {self.index.name}")
            for cat in CATS:update_table(prs,cat,data[cat],self.progress.emit)
            prs.save(str(self.output));self.completed.emit(str(self.output))
        except Exception:self.failed.emit(traceback.format_exc())

class Window(QMainWindow):
    def __init__(self):
        super().__init__();self.worker=None;self.setWindowTitle("Fund PPT Index Updater");self.resize(860,570)
        root=QWidget();self.setCentralWidget(root);layout=QVBoxLayout(root)
        title=QLabel("Fund PPT Index Updater");title.setStyleSheet("font-size:22px;font-weight:700");layout.addWidget(title)
        note=QLabel("Reorders every category table to exactly match the first-occurrence fund order in its source PPT. Existing matching rows are reused, missing rows are inserted, and duplicate or stale rows are removed.");note.setWordWrap(True);layout.addWidget(note)
        box=QGroupBox("Files");grid=QGridLayout(box);self.index=QLineEdit();self.folder=QLineEdit();self.output=QLineEdit()
        self.add(grid,0,"Index PPTX:",self.index,self.pick_index);self.add(grid,1,"Fund PPT folder:",self.folder,self.pick_folder);self.add(grid,2,"Output PPTX:",self.output,self.pick_output);layout.addWidget(box)
        self.runbtn=QPushButton("Update Index PPTX");self.runbtn.setMinimumHeight(42);self.runbtn.clicked.connect(self.run_job);layout.addWidget(self.runbtn)
        self.log=QPlainTextEdit();self.log.setReadOnly(True);layout.addWidget(self.log,1)
    def add(self,g,r,label,edit,fn):
        g.addWidget(QLabel(label),r,0);g.addWidget(edit,r,1);b=QPushButton("Browse...");b.clicked.connect(fn);g.addWidget(b,r,2)
    def pick_index(self):
        p,_=QFileDialog.getOpenFileName(self,"Select index PPTX","","PowerPoint (*.pptx)")
        if p:
            self.index.setText(p);x=Path(p);self.output.setText(str(x.with_name(f"{x.stem}_Updated_{datetime.now():%Y%m%d_%H%M%S}.pptx")))
    def pick_folder(self):
        p=QFileDialog.getExistingDirectory(self,"Select fund PPT folder")
        if p:self.folder.setText(p)
    def pick_output(self):
        p,_=QFileDialog.getSaveFileName(self,"Save output",self.output.text(),"PowerPoint (*.pptx)")
        if p:self.output.setText(p if p.lower().endswith(".pptx") else p+".pptx")
    def run_job(self):
        i,f,o=self.index.text().strip(),self.folder.text().strip(),self.output.text().strip()
        if not Path(i).is_file() or not Path(f).is_dir() or not o:QMessageBox.warning(self,"Missing input","Select valid inputs and output.");return
        if Path(i).resolve()==Path(o).resolve():QMessageBox.warning(self,"Unsafe output","Output must differ from input.");return
        self.log.clear();self.runbtn.setEnabled(False);self.worker=Worker(i,f,o);self.worker.progress.connect(self.log.appendPlainText);self.worker.completed.connect(self.done);self.worker.failed.connect(self.fail);self.worker.start()
    def done(self,p):self.runbtn.setEnabled(True);self.log.appendPlainText(f"\nDone: {p}");QMessageBox.information(self,"Completed",f"Saved to:\n{p}")
    def fail(self,e):self.runbtn.setEnabled(True);self.log.appendPlainText("\nERROR\n"+e);QMessageBox.critical(self,"Failed","See the log.")

def main():
    app=QApplication(sys.argv);app.setStyle("Fusion");w=Window();w.show();sys.exit(app.exec())
if __name__=="__main__":main()
