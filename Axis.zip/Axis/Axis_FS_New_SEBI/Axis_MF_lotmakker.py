from __future__ import annotations

import re
import sys
import traceback
import unicodedata
from dataclasses import dataclass
from pathlib import Path
from typing import Callable

from openpyxl import load_workbook
from PyQt6.QtCore import QObject, QThread, pyqtSignal
from PyQt6.QtGui import QFont
from PyQt6.QtWidgets import (
    QApplication,
    QCheckBox,
    QFileDialog,
    QFormLayout,
    QFrame,
    QHBoxLayout,
    QLabel,
    QLineEdit,
    QMainWindow,
    QMessageBox,
    QProgressBar,
    QPushButton,
    QVBoxLayout,
    QWidget,
)

try:
    import pythoncom
    import win32com.client
except ImportError:
    pythoncom = None
    win32com = None


APP_TITLE = "Category-wise Fund PPT Merger"
CATEGORY_ORDER = ("Equity", "Debt", "Hybrid")
SUPPORTED_EXTENSIONS = {".ppt", ".pptx", ".pptm", ".pps", ".ppsx", ".ppsm"}
OUTPUT_FORMAT_PPTX = 24

# Fixed logical pages that exist outside the individual fund PPT folder.
# Cover 1, Index 2, Tax 2, Equity Outlook 1 => Equity funds begin on page 7.
EQUITY_FUND_START_PAGE = 7
DEBT_OUTLOOK_PAGES = 1
SNAPSHOT_PAGES = 4
HYBRID_OUTLOOK_PAGES = 2

# Generated page-number footer.
FOOTER_COLOR = "#96134D"
FOOTER_SIZE_CM = 0.5
FOOTER_RIGHT_CM = 0.2
FOOTER_BOTTOM_CM = 0.2
FOOTER_FONT_SIZE = 6.5
FOOTER_PREFIX = "AutoCategoryPageNumber_"


@dataclass(frozen=True)
class Fund:
    excel_row: int
    code: str
    name: str
    category: str


@dataclass(frozen=True)
class Match:
    fund: Fund
    presentation: Path
    score: int


def clean_text(value) -> str:
    return "" if value is None else str(value).strip()


def canonical_category(value: str) -> str | None:
    text = clean_text(value).casefold()
    if "equity" in text:
        return "Equity"
    if "debt" in text or "fixed income" in text:
        return "Debt"
    if "hybrid" in text:
        return "Hybrid"
    return None


def normalize(value: str) -> str:
    text = unicodedata.normalize("NFKD", clean_text(value)).casefold()
    text = text.replace("&", " and ")
    text = re.sub(
        r"\b(pptx?|pptm|ppsx?|ppsm|presentation|factsheet|fact sheet|portfolio|snapshot|"
        r"focus|fund|fs|regular|direct|plan|growth|option)\b",
        " ",
        text,
    )
    return re.sub(r"[^a-z0-9]+", " ", text).strip()


def find_header_index(headers: list[str], alternatives: tuple[str, ...]) -> int | None:
    normalized = {normalize(header): index for index, header in enumerate(headers)}
    for alternative in alternatives:
        index = normalized.get(normalize(alternative))
        if index is not None:
            return index
    return None


def read_funds(excel_path: Path, selected_categories: set[str]) -> list[Fund]:
    workbook = load_workbook(excel_path, data_only=True, read_only=True)
    try:
        sheet = workbook[workbook.sheetnames[0]]
        rows = sheet.iter_rows(values_only=True)
        raw_header = next(rows, None)
        if not raw_header:
            raise ValueError("The first Excel sheet is empty.")

        headers = [clean_text(value) for value in raw_header]
        code_column = find_header_index(
            headers,
            ("Raw Data Tab Name", "Fund Code", "Scheme Code", "Code"),
        )
        name_column = find_header_index(
            headers,
            ("Fund Name", "Scheme Name", "Presentation Name"),
        )
        category_column = find_header_index(
            headers,
            ("Report Type", "Category", "Fund Category", "Asset Class"),
        )

        missing = []
        if name_column is None:
            missing.append("Fund Name")
        if category_column is None:
            missing.append("Report Type/Category")
        if missing:
            raise ValueError("Missing Excel column(s): " + ", ".join(missing))

        funds: list[Fund] = []
        unsupported: list[str] = []
        for excel_row, row in enumerate(rows, start=2):
            name = clean_text(row[name_column] if name_column < len(row) else None)
            if not name:
                continue
            raw_category = clean_text(
                row[category_column] if category_column < len(row) else None
            )
            category = canonical_category(raw_category)
            if category is None:
                if raw_category:
                    unsupported.append(f"row {excel_row}: {raw_category}")
                continue
            if category not in selected_categories:
                continue
            code = ""
            if code_column is not None and code_column < len(row):
                code = clean_text(row[code_column])
            funds.append(Fund(excel_row, code, name, category))

        if not funds:
            selected = ", ".join(category for category in CATEGORY_ORDER if category in selected_categories)
            raise ValueError(f"No funds were found for the selected categories: {selected}.")
        return funds
    finally:
        workbook.close()


def presentation_files(folder: Path, output_path: Path) -> list[Path]:
    output_resolved = output_path.resolve()
    files = []
    for path in folder.iterdir():
        if not path.is_file() or path.name.startswith("~$"):
            continue
        if path.suffix.casefold() not in SUPPORTED_EXTENSIONS:
            continue
        try:
            if path.resolve() == output_resolved:
                continue
        except OSError:
            pass
        files.append(path)
    files.sort(key=lambda value: value.name.casefold())
    if not files:
        raise ValueError("No PowerPoint files were found in the selected folder.")
    return files


def match_score(fund: Fund, presentation: Path) -> int:
    stem = normalize(presentation.stem)
    name = normalize(fund.name)
    code = normalize(fund.code)
    if not stem:
        return -100_000
    if code and stem == code:
        return 1_000_000
    if code and re.search(rf"(?:^| ){re.escape(code)}(?: |$)", stem):
        return 900_000
    if name and stem == name:
        return 800_000
    if name and name in stem:
        return 700_000 + len(name)
    if stem and stem in name and len(stem) >= 8:
        return 650_000 + len(stem)

    name_tokens = name.split()
    stem_tokens = stem.split()
    name_set = set(name_tokens)
    stem_set = set(stem_tokens)
    common = name_set & stem_set
    missing = name_set - stem_set
    extra = stem_set - name_set
    score = len(common) * 120 - len(missing) * 90 - len(extra) * 15
    if name_tokens and stem_tokens and name_tokens[0] == stem_tokens[0]:
        score += 30
    return score


def minimum_match_score(fund: Fund) -> int:
    token_count = max(1, len(normalize(fund.name).split()))
    return max(180, token_count * 55)


def match_presentations(
    funds: list[Fund],
    folder: Path,
    output_path: Path,
) -> tuple[list[Match], list[Fund], list[Path]]:
    files = presentation_files(folder, output_path)
    unused = set(files)
    matches: list[Match] = []
    missing: list[Fund] = []

    # Funds remain in Excel row order. A file is consumed at most once.
    for fund in funds:
        ranked = sorted(
            ((match_score(fund, path), path) for path in unused),
            key=lambda item: (-item[0], item[1].name.casefold()),
        )
        if not ranked or ranked[0][0] < minimum_match_score(fund):
            missing.append(fund)
            continue
        score, path = ranked[0]
        matches.append(Match(fund, path, score))
        unused.remove(path)

    return matches, missing, sorted(unused, key=lambda value: value.name.casefold())


def ordered_matches(matches: list[Match], selected_categories: set[str]) -> list[Match]:
    """Category blocks follow Equity, Debt, Hybrid; rows retain Excel order."""
    by_category = {category: [] for category in CATEGORY_ORDER}
    for match in matches:
        by_category[match.fund.category].append(match)
    result = []
    for category in CATEGORY_ORDER:
        if category in selected_categories:
            result.extend(by_category[category])
    return result


def presentation_size(presentation) -> tuple[float, float]:
    return float(presentation.PageSetup.SlideWidth), float(presentation.PageSetup.SlideHeight)


def size_matches(first: tuple[float, float], second: tuple[float, float], tolerance=0.5) -> bool:
    return abs(first[0] - second[0]) <= tolerance and abs(first[1] - second[1]) <= tolerance


def cm_to_points(value: float) -> float:
    return value / 2.54 * 72.0


def office_rgb(hex_color: str) -> int:
    value = hex_color.lstrip("#")
    red, green, blue = (int(value[index:index + 2], 16) for index in (0, 2, 4))
    return red + (green << 8) + (blue << 16)


def iter_shapes(shapes):
    for index in range(1, int(shapes.Count) + 1):
        yield shapes.Item(index)


def remove_generated_footers(presentation):
    for slide_index in range(1, int(presentation.Slides.Count) + 1):
        slide = presentation.Slides(slide_index)
        for shape in list(iter_shapes(slide.Shapes))[::-1]:
            try:
                if str(shape.Name).startswith(FOOTER_PREFIX):
                    shape.Delete()
            except Exception:
                pass


def add_page_footer(slide, page_number: int, slide_width: float, slide_height: float):
    size = cm_to_points(FOOTER_SIZE_CM)
    left = slide_width - size - cm_to_points(FOOTER_RIGHT_CM)
    top = slide_height - size - cm_to_points(FOOTER_BOTTOM_CM)
    circle = slide.Shapes.AddShape(9, left, top, size, size)
    circle.Name = f"{FOOTER_PREFIX}{slide.SlideIndex}"
    circle.LockAspectRatio = -1
    circle.Fill.Solid()
    circle.Fill.ForeColor.RGB = office_rgb(FOOTER_COLOR)
    circle.Line.Visible = 0
    frame = circle.TextFrame
    frame.MarginLeft = frame.MarginRight = frame.MarginTop = frame.MarginBottom = 0
    frame.WordWrap = 0
    frame.AutoSize = 0
    frame.VerticalAnchor = 3
    frame.TextRange.Text = str(page_number)
    frame.TextRange.ParagraphFormat.Alignment = 2
    frame.TextRange.Font.Name = "Arial"
    frame.TextRange.Font.Size = FOOTER_FONT_SIZE
    frame.TextRange.Font.Bold = -1
    frame.TextRange.Font.Color.RGB = office_rgb("#FFFFFF")


def source_slide_counts(powerpoint, matches: list[Match]) -> dict[Path, int]:
    counts: dict[Path, int] = {}
    for match in matches:
        path = match.presentation.resolve()
        if path in counts:
            continue
        source = powerpoint.Presentations.Open(
            str(path), ReadOnly=True, Untitled=False, WithWindow=False
        )
        try:
            counts[path] = int(source.Slides.Count)
        finally:
            source.Close()
    return counts


def automatic_category_starts(all_matches: list[Match], counts: dict[Path, int]) -> dict[str, int]:
    """Calculate category starts from actual fund slide counts and fixed pages.

    Fixed logical sequence:
      Cover 1; Index 2-3; Tax 4-5; Equity Outlook 6;
      Equity Funds start 7;
      Debt Outlook follows the last Equity Fund page;
      Debt Funds follow the one-page Debt Outlook;
      Snapshot is four pages after Debt Funds;
      Hybrid Outlook is two pages after Snapshot;
      Hybrid Funds follow Hybrid Outlook.
    """
    totals = {category: 0 for category in CATEGORY_ORDER}
    for match in all_matches:
        totals[match.fund.category] += counts[match.presentation.resolve()]

    equity_start = EQUITY_FUND_START_PAGE
    debt_start = equity_start + totals["Equity"] + DEBT_OUTLOOK_PAGES
    hybrid_start = (
        debt_start + totals["Debt"] + SNAPSHOT_PAGES + HYBRID_OUTLOOK_PAGES
    )
    return {"Equity": equity_start, "Debt": debt_start, "Hybrid": hybrid_start}


def merge_presentations(
    selected_matches: list[Match],
    all_matches: list[Match],
    output_path: Path,
    progress: Callable[[int, int, str], None],
) -> tuple[int, int, dict[str, int]]:
    if pythoncom is None or win32com is None:
        raise RuntimeError(
            "Install pywin32 and run on Windows with Microsoft PowerPoint desktop installed."
        )
    if not selected_matches:
        raise ValueError("No matched presentations are selected for merging.")

    pythoncom.CoInitialize()
    powerpoint = destination = source = None
    try:
        powerpoint = win32com.client.DispatchEx("PowerPoint.Application")
        powerpoint.Visible = True

        # Count every category, even when the GUI is currently merging only one.
        # This keeps Debt and Hybrid numbering aligned with the complete document.
        counts = source_slide_counts(powerpoint, all_matches)
        starts = automatic_category_starts(all_matches, counts)

        output_path.parent.mkdir(parents=True, exist_ok=True)
        if output_path.exists():
            output_path.unlink()

        first = selected_matches[0]
        progress(1, len(selected_matches), f"{first.fund.category}: {first.fund.name}")
        source = powerpoint.Presentations.Open(
            str(first.presentation.resolve()), ReadOnly=True, Untitled=False, WithWindow=False
        )
        base_size = presentation_size(source)
        first_count = int(source.Slides.Count)
        if first_count <= 0:
            raise ValueError(f"The first presentation has no slides: {first.presentation.name}")
        source.SaveCopyAs(str(output_path.resolve()), OUTPUT_FORMAT_PPTX)
        source.Close(); source = None

        destination = powerpoint.Presentations.Open(
            str(output_path.resolve()), ReadOnly=False, Untitled=False, WithWindow=False
        )
        ranges: list[tuple[str, int, int]] = [(first.fund.category, 1, first_count)]
        total_slides = first_count

        for position, match in enumerate(selected_matches[1:], start=2):
            progress(position, len(selected_matches), f"{match.fund.category}: {match.fund.name}")
            source = powerpoint.Presentations.Open(
                str(match.presentation.resolve()), ReadOnly=True, Untitled=False, WithWindow=False
            )
            current_size = presentation_size(source)
            count = int(source.Slides.Count)
            source.Close(); source = None
            if not size_matches(base_size, current_size):
                raise ValueError(
                    f"Slide-size mismatch for '{match.presentation.name}'. All fund PPTs "
                    "must use the same page size so source layouts remain unchanged."
                )
            if count <= 0:
                continue
            first_inserted = int(destination.Slides.Count) + 1
            destination.Slides.InsertFromFile(
                str(match.presentation.resolve()), int(destination.Slides.Count), 1, count
            )
            ranges.append((match.fund.category, first_inserted, first_inserted + count - 1))
            total_slides += count

        remove_generated_footers(destination)
        width, height = presentation_size(destination)
        category_offsets = {category: 0 for category in CATEGORY_ORDER}
        for category, first_slide, last_slide in ranges:
            first_page = starts[category] + category_offsets[category]
            for local_offset, slide_index in enumerate(range(first_slide, last_slide + 1)):
                add_page_footer(
                    destination.Slides(slide_index), first_page + local_offset, width, height
                )
            category_offsets[category] += last_slide - first_slide + 1

        destination.Save()
        destination.Close(); destination = None
        return len(selected_matches), total_slides, starts
    finally:
        if source is not None:
            try: source.Close()
            except Exception: pass
        if destination is not None:
            try: destination.Close()
            except Exception: pass
        if powerpoint is not None:
            try: powerpoint.Quit()
            except Exception: pass
        pythoncom.CoUninitialize()


class MergeWorker(QObject):
    progress = pyqtSignal(int, int, str)
    completed = pyqtSignal(str, int, int, object)
    failed = pyqtSignal(str)

    def __init__(self, selected_matches: list[Match], all_matches: list[Match], output_path: Path):
        super().__init__()
        self.selected_matches = selected_matches
        self.all_matches = all_matches
        self.output_path = output_path

    def run(self):
        try:
            files, slides, starts = merge_presentations(
                self.selected_matches, self.all_matches, self.output_path, self.progress.emit
            )
            self.completed.emit(str(self.output_path), files, slides, starts)
        except Exception as error:
            traceback.print_exc()
            self.failed.emit(f"{type(error).__name__}: {error}")


STYLE = """
QMainWindow, QWidget {
    background: #f5f7fb;
    color: #20243b;
    font-family: 'Segoe UI';
    font-size: 10pt;
}
QFrame#card {
    background: white;
    border: 1px solid #dce1eb;
    border-radius: 12px;
}
QLineEdit {
    background: white;
    border: 1px solid #ccd3df;
    border-radius: 8px;
    min-height: 40px;
    padding: 0 12px;
}
QLineEdit:focus { border: 2px solid #96134D; }
QPushButton {
    background: white;
    border: 1px solid #c8cfdb;
    border-radius: 8px;
    min-height: 40px;
    padding: 0 18px;
}
QPushButton:hover { border-color: #96134D; color: #96134D; }
QPushButton#primary {
    background: #96134D;
    color: white;
    border: none;
    font-weight: 700;
    min-height: 48px;
}
QPushButton#primary:disabled { background: #ba7895; }
QCheckBox { spacing: 8px; }
QProgressBar {
    background: white;
    border: 1px solid #d4dae5;
    border-radius: 7px;
    min-height: 24px;
    text-align: center;
}
QProgressBar::chunk { background: #96134D; border-radius: 6px; }
"""


class MainWindow(QMainWindow):
    def __init__(self):
        super().__init__()
        self.thread: QThread | None = None
        self.worker: MergeWorker | None = None
        self.setWindowTitle(APP_TITLE)
        self.resize(980, 650)
        self.build_ui()
        self.setStyleSheet(STYLE)

    def build_ui(self):
        root = QWidget()
        self.setCentralWidget(root)
        layout = QVBoxLayout(root)
        layout.setContentsMargins(40, 30, 40, 30)
        layout.setSpacing(18)

        title = QLabel(APP_TITLE)
        title.setFont(QFont("Segoe UI", 23, QFont.Weight.Bold))
        layout.addWidget(title)

        subtitle = QLabel(
            "Select the fund Excel file, the folder containing individual fund "
            "presentations, the categories to include, and the output PPTX. "
            "Funds are merged category-wise in Excel order. Category page starts are calculated automatically from actual fund slide counts and the fixed document pages."
        )
        subtitle.setWordWrap(True)
        layout.addWidget(subtitle)

        card = QFrame()
        card.setObjectName("card")
        form = QFormLayout(card)
        form.setContentsMargins(28, 25, 28, 25)
        form.setVerticalSpacing(18)

        self.excel_field = QLineEdit()
        self.folder_field = QLineEdit()
        self.output_field = QLineEdit()
        self.excel_field.setPlaceholderText("Select .xlsx or .xlsm file")
        self.folder_field.setPlaceholderText("Select folder containing individual PPT/PPTX files")
        self.output_field.setPlaceholderText("Select output .pptx file")

        form.addRow("Fund Excel file", self.path_row(self.excel_field, self.pick_excel))
        form.addRow("Individual PPT folder", self.path_row(self.folder_field, self.pick_folder))

        category_widget = QWidget()
        category_layout = QHBoxLayout(category_widget)
        category_layout.setContentsMargins(0, 0, 0, 0)
        self.equity_check = QCheckBox("Equity")
        self.debt_check = QCheckBox("Debt")
        self.hybrid_check = QCheckBox("Hybrid")
        for checkbox in (self.equity_check, self.debt_check, self.hybrid_check):
            checkbox.setChecked(True)
            category_layout.addWidget(checkbox)
        category_layout.addStretch()
        form.addRow("Categories to merge", category_widget)

        form.addRow("Output PPTX file", self.path_row(self.output_field, self.pick_output))
        layout.addWidget(card)

        order_note = QLabel(
            "Numbering basis: Cover 1; Index 2-3; Tax 4-5; Equity Outlook 6; "
            "Equity Funds from 7; then Debt Outlook 1 page; Debt Funds; Snapshot "
            "4 pages; Hybrid Outlook 2 pages; Hybrid Funds. Only fund PPT files are merged."
        )
        order_note.setWordWrap(True)
        layout.addWidget(order_note)

        self.progress = QProgressBar()
        self.progress.setRange(0, 1)
        self.progress.setValue(0)
        layout.addWidget(self.progress)

        self.status = QLabel("Ready")
        self.status.setWordWrap(True)
        layout.addWidget(self.status)

        self.merge_button = QPushButton("Merge selected categories")
        self.merge_button.setObjectName("primary")
        self.merge_button.clicked.connect(self.start_merge)
        layout.addWidget(self.merge_button)

    def path_row(self, field: QLineEdit, callback):
        widget = QWidget()
        row = QHBoxLayout(widget)
        row.setContentsMargins(0, 0, 0, 0)
        browse = QPushButton("Browse")
        browse.clicked.connect(callback)
        row.addWidget(field)
        row.addWidget(browse)
        return widget

    def pick_excel(self):
        path, _ = QFileDialog.getOpenFileName(
            self,
            "Select fund Excel file",
            "",
            "Excel workbooks (*.xlsx *.xlsm)",
        )
        if path:
            self.excel_field.setText(path)

    def pick_folder(self):
        path = QFileDialog.getExistingDirectory(
            self,
            "Select individual fund PPT folder",
        )
        if path:
            self.folder_field.setText(path)

    def pick_output(self):
        path, _ = QFileDialog.getSaveFileName(
            self,
            "Save merged presentation",
            "Merged_Fund_Presentations.pptx",
            "PowerPoint presentation (*.pptx)",
        )
        if path:
            if not path.lower().endswith(".pptx"):
                path += ".pptx"
            self.output_field.setText(path)

    def selected_categories(self) -> set[str]:
        selected = set()
        if self.equity_check.isChecked():
            selected.add("Equity")
        if self.debt_check.isChecked():
            selected.add("Debt")
        if self.hybrid_check.isChecked():
            selected.add("Hybrid")
        return selected

    def start_merge(self):
        try:
            excel_path = Path(self.excel_field.text().strip())
            folder_path = Path(self.folder_field.text().strip())
            output_text = self.output_field.text().strip()
            output_path = Path(output_text) if output_text else Path()
            categories = self.selected_categories()

            if not excel_path.is_file():
                raise ValueError("Select a valid Excel file.")
            if not folder_path.is_dir():
                raise ValueError("Select a valid folder containing the fund presentations.")
            if not output_text or output_path.suffix.casefold() != ".pptx":
                raise ValueError("Select a valid output .pptx file.")
            if not categories:
                raise ValueError("Select at least one category: Equity, Debt, or Hybrid.")

            # Read and match all three categories so Debt and Hybrid starting pages
            # can be calculated even when the GUI merges only one category.
            all_funds = read_funds(excel_path, set(CATEGORY_ORDER))
            all_matches, missing, unused = match_presentations(all_funds, folder_path, output_path)
            all_matches = ordered_matches(all_matches, set(CATEGORY_ORDER))
            matches = [match for match in all_matches if match.fund.category in categories]
            if not matches:
                raise ValueError("No fund presentation matched the selected categories.")

            if missing:
                preview = "\n".join(
                    f"- Row {fund.excel_row}: [{fund.category}] {fund.name}"
                    for fund in missing[:25]
                )
                more = "" if len(missing) <= 25 else f"\n...and {len(missing) - 25} more"
                answer = QMessageBox.question(
                    self,
                    "Missing fund presentations",
                    f"{len(missing)} selected fund presentation(s) were not matched:\n\n"
                    f"{preview}{more}\n\nContinue with the {len(matches)} matched files?",
                )
                if answer != QMessageBox.StandardButton.Yes:
                    return

            self.merge_button.setDisabled(True)
            self.progress.setRange(0, len(matches))
            self.progress.setValue(0)
            self.status.setText(
                f"Preparing {len(matches)} presentations. "
                f"Unmatched folder files ignored: {len(unused)}."
            )

            self.thread = QThread(self)
            self.worker = MergeWorker(matches, all_matches, output_path)
            self.worker.moveToThread(self.thread)
            self.thread.started.connect(self.worker.run)
            self.worker.progress.connect(self.on_progress)
            self.worker.completed.connect(self.on_completed)
            self.worker.failed.connect(self.on_failed)
            self.worker.completed.connect(self.thread.quit)
            self.worker.failed.connect(self.thread.quit)
            self.thread.finished.connect(self.cleanup_worker)
            self.thread.start()
        except Exception as error:
            QMessageBox.critical(self, "Cannot start merge", str(error))

    def on_progress(self, current: int, total: int, description: str):
        self.progress.setMaximum(total)
        self.progress.setValue(current)
        self.status.setText(f"Merging {current}/{total}: {description}")

    def on_completed(self, output: str, file_count: int, slide_count: int, starts):
        self.merge_button.setDisabled(False)
        self.status.setText("Merge completed")
        QMessageBox.information(
            self,
            "Merge completed",
            f"Created:\n{output}\n\n"
            f"Presentations merged: {file_count}\n"
            f"Total slides: {slide_count}\n\n"
            f"Equity fund start: {starts['Equity']}\n"
            f"Debt fund start: {starts['Debt']}\n"
            f"Hybrid fund start: {starts['Hybrid']}",
        )

    def on_failed(self, error: str):
        self.merge_button.setDisabled(False)
        self.status.setText("Merge failed")
        QMessageBox.critical(self, "Merge failed", error)

    def cleanup_worker(self):
        if self.worker is not None:
            self.worker.deleteLater()
        if self.thread is not None:
            self.thread.deleteLater()
        self.worker = None
        self.thread = None

    def closeEvent(self, event):
        if self.thread is not None and self.thread.isRunning():
            QMessageBox.information(
                self,
                "Merge in progress",
                "Wait for the current PowerPoint merge to finish before closing the application.",
            )
            event.ignore()
            return
        event.accept()


def main() -> int:
    app = QApplication(sys.argv)
    app.setStyle("Fusion")
    window = MainWindow()
    window.show()
    return app.exec()


if __name__ == "__main__":
    raise SystemExit(main())
