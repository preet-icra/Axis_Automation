"""Create table-aligned pie charts in Excel *-Holding worksheets.

Install:
    py -m pip install PyQt6 openpyxl
"""
from __future__ import annotations

import os
import re
import sys
import traceback
from dataclasses import dataclass
from pathlib import Path
from typing import Callable

from openpyxl import load_workbook
from openpyxl.chart import PieChart, Reference
from openpyxl.chart.label import DataLabel, DataLabelList
from openpyxl.chart.marker import DataPoint
from openpyxl.chart.shapes import GraphicalProperties
from openpyxl.chart.text import RichText
from openpyxl.drawing.text import CharacterProperties, Paragraph, ParagraphProperties, RichTextProperties
from openpyxl.utils import get_column_letter
from PyQt6.QtCore import QObject, QThread, pyqtSignal
from PyQt6.QtGui import QFont
from PyQt6.QtWidgets import (
    QApplication, QCheckBox, QFileDialog, QGridLayout, QGroupBox, QHBoxLayout,
    QLabel, QLineEdit, QMainWindow, QMessageBox, QPlainTextEdit, QProgressBar,
    QPushButton, QVBoxLayout, QWidget,
)

PALETTES = {
    "ASSET": ["156082", "97144D", "193661", "0D9DCE", "E59FB9", "A02B93", "4EA72E", "E97132"],
    "RATING": ["97144D", "E59FB9", "193661", "0D9DCE", "A02B93", "4EA72E", "E97132", "156082"],
    "SECTOR": ["156082", "E97132", "196B24", "0F9ED5", "A02B93", "4EA72E", "0D3A4E", "A02B3E", "994010", "0F4B22", "0D6A8A"],
    "COUNTRY": ["97144D", "E59FB9", "193661", "0D9DCE", "A02B93", "4EA72E", "E97132", "156082"],
}
TITLES = {key: f"Composition By {key.title()}" for key in PALETTES}
HEADER_RE = re.compile(r"^COMPOSITION\s+BY\s+(ASSET|RATING|SECTOR|COUNTRY)\s*(?:\(%\)|%)?\s*$", re.I)
SUPPORTED_EXTENSIONS = {".xlsx", ".xlsm"}
DARK_TEXT, WHITE_TEXT = "202124", "FFFFFF"

# User-specified chart sizes in centimetres.
# Tables with up to 8 data rows use the compact size; tables with 9 or more
# data rows use the large size. Change LARGE_TABLE_MIN_ROWS if required.
SMALL_CHART_WIDTH_CM = 12.00
SMALL_CHART_HEIGHT_CM = 6.70
LARGE_CHART_WIDTH_CM = 13.28
LARGE_CHART_HEIGHT_CM = 10.62
LARGE_TABLE_MIN_ROWS = 9

# Exactly one blank worksheet row is kept between a table and its chart.
# If a table ends at row 10, row 11 stays blank and the chart starts at row 12.
CHART_ROW_GAP = 1

# Excel's standard row height is approximately 0.529 cm. A small safety margin
# prevents a resized chart from touching the next table border.
DEFAULT_ROW_HEIGHT_CM = 0.529
CHART_BOTTOM_SAFETY_CM = 0.25
MINIMUM_CHART_HEIGHT_CM = 3.80


class WorkbookProcessingError(Exception):
    pass


@dataclass
class TableInfo:
    kind: str
    header_row: int
    label_col: int
    value_col: int
    rows: list[int]

    @property
    def first_row(self) -> int:
        return self.rows[0]

    @property
    def last_row(self) -> int:
        return self.rows[-1]


@dataclass
class Box:
    left: int
    top: int
    right: int
    bottom: int

    def intersects(self, other: "Box") -> bool:
        return not (
            self.right < other.left or self.left > other.right
            or self.bottom < other.top or self.top > other.bottom
        )


def clean_text(value) -> str:
    return "" if value is None else " ".join(str(value).replace("\n", " ").split())


def positive_number(value) -> float | None:
    if value is None or isinstance(value, bool):
        return None
    if isinstance(value, (int, float)):
        number = float(value)
        return number if number > 0 else None
    if isinstance(value, str):
        text = value.strip().replace(",", "")
        try:
            number = float(text[:-1]) / 100.0 if text.endswith("%") else float(text)
            return number if number > 0 else None
        except ValueError:
            return None
    return None


def is_dark(rgb: str) -> bool:
    rgb = rgb.strip().lstrip("#")
    try:
        red, green, blue = (int(rgb[i:i + 2], 16) for i in (0, 2, 4))
    except (ValueError, TypeError):
        return False
    return 0.299 * red + 0.587 * green + 0.114 * blue < 145


def merged_range_at(ws, row: int, col: int):
    for merged in ws.merged_cells.ranges:
        if merged.min_row <= row <= merged.max_row and merged.min_col <= col <= merged.max_col:
            return merged
    return None


def find_value_column(ws, header_row: int, label_col: int) -> int | None:
    label_merge = merged_range_at(ws, header_row, label_col)
    start_col = label_merge.max_col + 1 if label_merge else label_col + 1
    for col in range(start_col, min(ws.max_column, start_col + 5) + 1):
        if "net assets" in clean_text(ws.cell(header_row, col).value).lower():
            value_merge = merged_range_at(ws, header_row, col)
            return value_merge.min_col if value_merge else col
    return start_col if start_col <= ws.max_column else None


def find_data_rows(ws, header_row: int, label_col: int, value_col: int) -> list[int]:
    rows, started = [], False
    for row in range(header_row + 1, min(ws.max_row, header_row + 100) + 1):
        label = clean_text(ws.cell(row, label_col).value)
        value = positive_number(ws.cell(row, value_col).value)
        if HEADER_RE.match(label) or label.upper() in {"GRAND TOTAL", "NET ASSETS"}:
            break
        if label and value is not None:
            rows.append(row)
            started = True
        elif not started and not label and value is None:
            continue
        elif started:
            break
        else:
            break
    return rows


def discover_tables(ws, value_ws) -> list[TableInfo]:
    tables = []
    for row in range(1, min(ws.max_row, 150) + 1):
        for col in range(1, ws.max_column + 1):
            match = HEADER_RE.match(clean_text(ws.cell(row, col).value))
            if not match:
                continue
            kind = match.group(1).upper()
            value_col = find_value_column(ws, row, col)
            if value_col is None:
                continue
            data_rows = find_data_rows(value_ws, row, col, value_col)
            if data_rows:
                tables.append(TableInfo(kind, row, col, value_col, data_rows))
    return sorted(tables, key=lambda item: (item.header_row, item.label_col))


def chart_dimensions(kind: str, names: list[str]) -> tuple[float, float]:
    count = len(names)
    longest = max((len(name) for name in names), default=0)
    if count <= 3:
        width, height = 8.0, 5.2
    elif count <= 6:
        width, height = 9.5, 6.2
    elif count <= 10:
        width, height = 11.5, 7.4
    elif count <= 15:
        width, height = 13.5, 8.8
    elif count <= 25:
        width, height = 16.0, 10.5
    else:
        width, height = 18.5, 12.0
    width += min(3.5, max(0, longest - 18) * 0.07)
    if kind == "SECTOR":
        width += 1.0
        height += 0.8
    return min(width, 22.0), min(height, 14.0)


def label_text(color: str) -> RichText:
    props = CharacterProperties(solidFill=color)
    return RichText(
        bodyPr=RichTextProperties(),
        p=[Paragraph(pPr=ParagraphProperties(defRPr=props),
                     endParaRPr=CharacterProperties(solidFill=color))],
    )


def create_pie_chart(ws, table: TableInfo) -> PieChart:
    names = [clean_text(ws.cell(row, table.label_col).value) for row in table.rows]
    values = [positive_number(ws.cell(row, table.value_col).value) or 0.0 for row in table.rows]
    total = sum(values) or 1.0
    palette = PALETTES[table.kind]

    chart = PieChart()
    chart.title = TITLES[table.kind]
    chart.style = 10
    chart.varyColors = True
    chart.firstSliceAng = 270
    if len(table.rows) >= LARGE_TABLE_MIN_ROWS:
        chart.width = LARGE_CHART_WIDTH_CM
        chart.height = LARGE_CHART_HEIGHT_CM
    else:
        chart.width = SMALL_CHART_WIDTH_CM
        chart.height = SMALL_CHART_HEIGHT_CM
    chart.add_data(Reference(ws, min_col=table.value_col, min_row=table.first_row,
                             max_row=table.last_row), titles_from_data=False)
    chart.set_categories(Reference(ws, min_col=table.label_col, min_row=table.first_row,
                                   max_row=table.last_row))

    points = []
    for idx in range(len(table.rows)):
        fill = palette[idx % len(palette)]
        graphic = GraphicalProperties(solidFill=fill)
        graphic.line.solidFill = WHITE_TEXT
        graphic.line.width = 12700
        points.append(DataPoint(idx=idx, spPr=graphic))
    chart.series[0].data_points = points

    labels = DataLabelList()
    labels.showVal = True
    labels.showPercent = False
    labels.showCatName = False
    labels.showSerName = False
    labels.showLegendKey = False
    labels.showLeaderLines = True
    labels.numFmt = "0.00%"
    labels.dLblPos = "bestFit"

    overrides = []
    for idx, value in enumerate(values):
        share = value / total
        outside = share < 0.05
        fill = palette[idx % len(palette)]
        font = DARK_TEXT if outside or not is_dark(fill) else WHITE_TEXT
        overrides.append(DataLabel(
            idx=idx, dLblPos="outEnd" if outside else "bestFit",
            showVal=True, showPercent=False, showCatName=False,
            showSerName=False, showLegendKey=False,
            showLeaderLines=outside, numFmt="0.00%", txPr=label_text(font),
        ))
    labels.dLbl = overrides
    chart.dataLabels = labels
    chart.legend.position = "r"
    chart.legend.overlay = False
    return chart


def chart_span_rows(height_cm: float) -> int:
    return max(18, int(round(height_cm / 0.53)) + 4)


def chart_span_columns(width_cm: float) -> int:
    # Conservative estimate based on a standard Excel column width.
    return max(5, int(round(width_cm / 1.65)) + 1)


def table_box(table: TableInfo) -> Box:
    # Include the value column and a one-cell safety margin.
    return Box(table.label_col, table.header_row,
               table.value_col + 1, table.last_row + 1)


def row_height_cm(ws, row: int) -> float:
    """Return the displayed height of an Excel row in centimetres."""
    points = ws.row_dimensions[row].height
    if points is None:
        return DEFAULT_ROW_HEIGHT_CM
    return max(0.10, float(points) * 2.54 / 72.0)


def available_height_before_next_table(
    ws,
    table: TableInfo,
    all_tables: list[TableInfo],
) -> float | None:
    """Calculate chart space before the next table in the same vertical lane."""
    next_tables = [
        other
        for other in all_tables
        if other is not table
        and other.label_col == table.label_col
        and other.header_row > table.last_row
    ]
    if not next_tables:
        return None

    next_table = min(next_tables, key=lambda item: item.header_row)

    # Keep one blank row below the current table, then start the chart.
    chart_start_row = table.last_row + CHART_ROW_GAP + 1

    # Keep one blank row between the chart and the next table as well.
    chart_last_row = next_table.header_row - 2
    if chart_last_row < chart_start_row:
        return 0.0

    available = sum(
        row_height_cm(ws, row)
        for row in range(chart_start_row, chart_last_row + 1)
    )
    return max(0.0, available - CHART_BOTTOM_SAFETY_CM)


def fit_chart_height_below_table(
    ws,
    table: TableInfo,
    all_tables: list[TableInfo],
    chart: PieChart,
) -> tuple[str, bool]:
    """Place a chart after one blank row and reduce height if another table follows."""
    desired_height = float(chart.height)
    available_height = available_height_before_next_table(ws, table, all_tables)
    height_reduced = False

    if available_height is not None and available_height < desired_height:
        # Reduce only the height. Width remains exactly 12.00 cm or 13.28 cm.
        # The minimum keeps the chart readable. If the physical gap is even
        # smaller, the minimum is still used and the activity log reports it.
        chart.height = max(MINIMUM_CHART_HEIGHT_CM, available_height)
        height_reduced = chart.height < desired_height

    anchor_column = table.label_col
    anchor_row = table.last_row + CHART_ROW_GAP + 1
    anchor = f"{get_column_letter(anchor_column)}{anchor_row}"
    return anchor, height_reduced


def process_workbook(
    input_path: str,
    output_path: str,
    replace_existing: bool,
    log: Callable[[str], None] = print,
    progress: Callable[[int], None] = lambda _: None,
) -> int:
    keep_vba = Path(input_path).suffix.lower() == ".xlsm"
    workbook = value_workbook = None
    holding_sheets: list[str] = []
    added = 0

    try:
        log(f"Opening workbook: {input_path}")
        workbook = load_workbook(input_path, data_only=False, keep_vba=keep_vba)
        value_workbook = load_workbook(input_path, data_only=True, keep_vba=keep_vba)
        holding_sheets = [name for name in workbook.sheetnames
                          if name.strip().lower().endswith("-holding")]
        if not holding_sheets:
            raise WorkbookProcessingError("No worksheet ending with '-Holding' was found.")

        skipped = []
        for sheet_index, sheet_name in enumerate(holding_sheets, 1):
            ws, value_ws = workbook[sheet_name], value_workbook[sheet_name]
            log(f"Processing worksheet: {sheet_name}")
            if replace_existing:
                ws._charts = []

            tables = discover_tables(ws, value_ws)
            if not tables:
                log("  No supported composition tables found.")
                progress(round(sheet_index * 100 / len(holding_sheets)))
                continue

            for table in tables:
                try:
                    chart = create_pie_chart(ws, table)
                    original_height = float(chart.height)
                    anchor, height_reduced = fit_chart_height_below_table(
                        ws, table, tables, chart
                    )
                    ws.add_chart(chart, anchor)
                    added += 1

                    resize_message = (
                        f"; height reduced from {original_height:.2f} cm"
                        if height_reduced
                        else ""
                    )
                    log(
                        f"  Added {TITLES[table.kind]} below its table at {anchor}; "
                        f"{len(table.rows)} categories; final size "
                        f"{chart.width:.2f} x {chart.height:.2f} cm"
                        f"{resize_message}."
                    )
                except Exception as exc:
                    message = f"{sheet_name} / {TITLES[table.kind]}: {exc}"
                    skipped.append(message)
                    log(f"  Skipped {TITLES[table.kind]}: {exc}")

            progress(round(sheet_index * 100 / len(holding_sheets)))

        if added == 0:
            raise WorkbookProcessingError(
                "No eligible charts were created. Review the activity log."
            )

        try:
            workbook.calculation.fullCalcOnLoad = True
            workbook.calculation.forceFullCalc = True
            workbook.calculation.calcMode = "auto"
        except Exception:
            pass

        log(f"Saving output workbook: {output_path}")
        try:
            workbook.save(output_path)
        except PermissionError as exc:
            raise WorkbookProcessingError(
                "The output file is open or not writable. Close Excel and try again."
            ) from exc

        log(f"Finished. Added {added} chart(s).")
        if skipped:
            log(f"Skipped {len(skipped)} table(s):")
            for item in skipped:
                log(f"  - {item}")
    finally:
        if workbook is not None:
            workbook.close()
        if value_workbook is not None:
            value_workbook.close()

    check = load_workbook(output_path, data_only=False, keep_vba=keep_vba)
    saved = sum(len(check[name]._charts) for name in holding_sheets)
    check.close()
    if saved < added:
        raise WorkbookProcessingError("The saved workbook is missing one or more charts.")
    return added


class Worker(QObject):
    progress = pyqtSignal(int)
    message = pyqtSignal(str)
    finished = pyqtSignal(str, int)
    failed = pyqtSignal(str, str)

    def __init__(self, source: str, target: str, replace: bool):
        super().__init__()
        self.source, self.target, self.replace = source, target, replace

    def run(self):
        try:
            count = process_workbook(
                self.source, self.target, self.replace,
                self.message.emit, self.progress.emit,
            )
            self.finished.emit(self.target, count)
        except Exception as exc:
            self.failed.emit(str(exc), traceback.format_exc())


class MainWindow(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("Axis Holding Pie Chart Generator")
        self.resize(880, 630)
        self.thread = None
        self.worker = None
        self.build_ui()

    def build_ui(self):
        root = QWidget()
        self.setCentralWidget(root)
        layout = QVBoxLayout(root)
        layout.setContentsMargins(24, 22, 24, 22)
        layout.setSpacing(14)

        title = QLabel("Axis Holding Pie Chart Generator")
        title.setFont(QFont("Segoe UI", 18, QFont.Weight.Bold))
        layout.addWidget(title)
        description = QLabel(
            "Each chart is aligned directly below its source table. If the desired "
            "position is occupied by another table or chart, the chart is moved down "
            "within the same column until a clear position is found."
        )
        description.setWordWrap(True)
        layout.addWidget(description)

        group = QGroupBox("Workbook")
        grid = QGridLayout(group)
        self.input_edit, self.output_edit = QLineEdit(), QLineEdit()
        input_button, output_button = QPushButton("Browse..."), QPushButton("Save as...")
        input_button.clicked.connect(self.choose_input)
        output_button.clicked.connect(self.choose_output)
        grid.addWidget(QLabel("Input file:"), 0, 0)
        grid.addWidget(self.input_edit, 0, 1)
        grid.addWidget(input_button, 0, 2)
        grid.addWidget(QLabel("Output file:"), 1, 0)
        grid.addWidget(self.output_edit, 1, 1)
        grid.addWidget(output_button, 1, 2)
        layout.addWidget(group)

        self.replace_check = QCheckBox("Replace existing charts on all -Holding sheets")
        self.replace_check.setChecked(True)
        layout.addWidget(self.replace_check)

        row = QHBoxLayout()
        self.run_button = QPushButton("Create Pie Charts")
        self.run_button.setMinimumHeight(42)
        self.run_button.clicked.connect(self.start_processing)
        row.addWidget(self.run_button)
        row.addStretch()
        layout.addLayout(row)

        self.progress_bar = QProgressBar()
        layout.addWidget(self.progress_bar)
        layout.addWidget(QLabel("Activity log:"))
        self.log_edit = QPlainTextEdit()
        self.log_edit.setReadOnly(True)
        layout.addWidget(self.log_edit, 1)

    def choose_input(self):
        path, _ = QFileDialog.getOpenFileName(
            self, "Select workbook", "", "Excel workbooks (*.xlsx *.xlsm)"
        )
        if path:
            self.input_edit.setText(path)
            source = Path(path)
            self.output_edit.setText(str(source.with_name(
                f"{source.stem}_one_row_gap_charts{source.suffix}"
            )))

    def choose_output(self):
        current = self.output_edit.text().strip() or "holding_charts.xlsx"
        path, _ = QFileDialog.getSaveFileName(
            self, "Save output workbook", current, "Excel workbooks (*.xlsx *.xlsm)"
        )
        if path:
            self.output_edit.setText(path)

    def validate_paths(self) -> tuple[str, str]:
        source, target = self.input_edit.text().strip(), self.output_edit.text().strip()
        if not source or not Path(source).is_file():
            raise ValueError("Select a valid input workbook.")
        if Path(source).suffix.lower() not in SUPPORTED_EXTENSIONS:
            raise ValueError("The input must be an .xlsx or .xlsm workbook.")
        if not target:
            raise ValueError("Choose an output workbook.")
        if os.path.abspath(source) == os.path.abspath(target):
            raise ValueError("The output filename must be different from the input filename.")
        if Path(source).suffix.lower() != Path(target).suffix.lower():
            raise ValueError("Input and output extensions must match.")
        Path(target).parent.mkdir(parents=True, exist_ok=True)
        return source, target

    def start_processing(self):
        try:
            source, target = self.validate_paths()
        except ValueError as exc:
            QMessageBox.warning(self, "Invalid selection", str(exc))
            return

        self.log_edit.clear()
        self.progress_bar.setValue(0)
        self.run_button.setEnabled(False)
        self.thread = QThread()
        self.worker = Worker(source, target, self.replace_check.isChecked())
        self.worker.moveToThread(self.thread)
        self.thread.started.connect(self.worker.run)
        self.worker.message.connect(self.log_edit.appendPlainText)
        self.worker.progress.connect(self.progress_bar.setValue)
        self.worker.finished.connect(self.processing_finished)
        self.worker.failed.connect(self.processing_failed)
        self.worker.finished.connect(self.thread.quit)
        self.worker.failed.connect(self.thread.quit)
        self.thread.finished.connect(self.thread.deleteLater)
        self.thread.start()

    def processing_finished(self, path: str, count: int):
        self.run_button.setEnabled(True)
        self.progress_bar.setValue(100)
        QMessageBox.information(
            self, "Finished", f"Created {count} pie chart(s).\n\nSaved to:\n{path}"
        )

    def processing_failed(self, message: str, details: str):
        self.run_button.setEnabled(True)
        self.log_edit.appendPlainText("\nTechnical details:\n" + details)
        QMessageBox.critical(self, "Processing failed", message)


def main() -> int:
    print("Starting Axis Holding Pie Chart Generator...", flush=True)
    app = QApplication(sys.argv)
    app.setApplicationName("Axis Holding Pie Chart Generator")
    app.setStyle("Fusion")
    window = MainWindow()
    window.show()
    print("Application window opened.", flush=True)
    return app.exec()


if __name__ == "__main__":
    try:
        sys.exit(main())
    except ModuleNotFoundError as exc:
        print(f"Missing package: {exc.name}", flush=True)
        print(f'Install with: "{sys.executable}" -m pip install PyQt6 openpyxl', flush=True)
        input("Press Enter to close...")
    except Exception:
        details = traceback.format_exc()
        print(details, flush=True)
        try:
            Path(__file__).with_name("axis_chart_generator_error.log").write_text(
                details, encoding="utf-8"
            )
        except Exception:
            pass
        input("Press Enter to close...")
